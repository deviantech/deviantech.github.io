// Apparently service workers can only be loaded from a top-level file, but our build pattern puts them down a directory.
// This file exists just to link them together.
self.importScripts('background/background.js')
