"use strict";
(self["webpackChunkvoyd_browser_extension"] = self["webpackChunkvoyd_browser_extension"] || []).push([[996],{

/***/ 70017:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_user_avatar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(49183);
/* harmony import */ var react_user_avatar__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_user_avatar__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(37724);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(85893);
var _excluded = ["user", "size"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


 // Note: Tried applying overflow:'hidden' to prevent broken avatar alt text from taking up whole page, but
// that messed w/ normal avatar's flow.
// Note: does NOT accept className prop, as it gets set by underlying library (fork and add cn support?)



var Avatar = function Avatar(_ref) {
  var user = _ref.user,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 48 : _ref$size,
      props = _objectWithoutProperties(_ref, _excluded);

  return user ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)((react_user_avatar__WEBPACK_IMPORTED_MODULE_0___default()), _objectSpread({
    size: size,
    name: user.name || user.handle || 'anonymous',
    src: user.avatar,
    alt: "".concat((0,common_utils__WEBPACK_IMPORTED_MODULE_1__/* .handle */ .pr)(user), "'s avatar")
  }, props)) : null;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Avatar);

/***/ }),

/***/ 92153:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "j0": () => (/* binding */ ReviewStaff),
  "ZP": () => (/* binding */ ReviewCard)
});

// UNUSED EXPORTS: ReviewContent

// EXTERNAL MODULE: ./src/lib/common/utils/index.js
var utils = __webpack_require__(37724);
// EXTERNAL MODULE: ./node_modules/react-markdown/lib/react-markdown.js + 111 modules
var react_markdown = __webpack_require__(57378);
// EXTERNAL MODULE: ./node_modules/remark-gfm/index.js + 27 modules
var remark_gfm = __webpack_require__(48216);
// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(85893);
;// CONCATENATED MODULE: ./src/lib/common/components/MarkdownText.js

 // TODO: *should* we be adding noreferrer? Seems like noopenner is enough, and we DO want domains to see links came from us...



var LinkRenderer = function LinkRenderer(_ref) {
  var href = _ref.href,
      children = _ref.children;
  return /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
    href: href,
    target: "_blank",
    rel: "ugc nofollow noopener",
    children: children
  });
};

var customComponents = {
  a: LinkRenderer
};

var MarkdownText = function MarkdownText(_ref2) {
  var text = _ref2.text;
  return /*#__PURE__*/(0,jsx_runtime.jsx)(react_markdown/* ReactMarkdown */.D, {
    remarkPlugins: [remark_gfm/* default */.Z],
    components: customComponents,
    children: text
  });
};

/* harmony default export */ const components_MarkdownText = (MarkdownText);
// EXTERNAL MODULE: ./src/lib/common/routes.js
var routes = __webpack_require__(11147);
// EXTERNAL MODULE: ./src/lib/universal-interface/UniversalLink.js
var UniversalLink = __webpack_require__(84261);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(67294);
;// CONCATENATED MODULE: ./src/lib/common/components/Hashtags.js
var _excluded = ["hashtags", "prefix", "className", "tagClassName", "spacer"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







var Hashtags = function Hashtags(_ref) {
  var _ref$hashtags = _ref.hashtags,
      hashtags = _ref$hashtags === void 0 ? [] : _ref$hashtags,
      prefix = _ref.prefix,
      className = _ref.className,
      tagClassName = _ref.tagClassName,
      spacer = _ref.spacer,
      props = _objectWithoutProperties(_ref, _excluded);

  return (hashtags === null || hashtags === void 0 ? void 0 : hashtags.length) === 0 ? null : /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: (0,utils.cn)(prefix && 'flex flex-wrap', className),
    children: [prefix, hashtags.map(function (hashtag) {
      var tag = hashtag.value || hashtag; // Handle passing in array of hashtag _options_ or actual values

      return /*#__PURE__*/(0,jsx_runtime.jsxs)(react.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)(Hashtag, _objectSpread(_objectSpread({
          tag: tag
        }, props), {}, {
          className: tagClassName
        }), tag), spacer && /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
          className: "w-4"
        })]
      }, tag);
    })]
  });
}; // assumes already run through stringToHashtag

var Hashtag = function Hashtag(_ref2) {
  var tag = _ref2.tag,
      link = _ref2.link,
      className = _ref2.className;
  var classes = (0,utils.cn)('k-span', className);
  if (!link) return /*#__PURE__*/(0,jsx_runtime.jsxs)("span", {
    className: classes,
    children: ["#", tag]
  });
  return /*#__PURE__*/(0,jsx_runtime.jsx)(UniversalLink/* default */.Z, {
    href: routes/* default.hashtagUrl */.Z.hashtagUrl(tag),
    className: classes,
    text: "#".concat(tag)
  });
};
/* harmony default export */ const components_Hashtags = (Hashtags);
// EXTERNAL MODULE: ./src/lib/common/components/Logo.js
var Logo = __webpack_require__(7144);
// EXTERNAL MODULE: ./src/lib/common/components/Avatar.js
var Avatar = __webpack_require__(70017);
// EXTERNAL MODULE: ./src/lib/common/components/TimeAgo.js
var TimeAgo = __webpack_require__(3716);
// EXTERNAL MODULE: ./src/lib/common/components/ConditionalWrap.js
var ConditionalWrap = __webpack_require__(90792);
;// CONCATENATED MODULE: ./src/lib/common/components/ReviewCard/index.js













var colors = {
  divider: ['mb-5 from-red-800 to-red-500', 'from-gray-800 via-gray-400 to-gray-800', 'mt-5 from-green-500 to-green-900'],
  triColor: ['text-red-600', 'text-gray-600', 'text-green-600'],
  tri: ['-translate-x-1/2 translate-y-[22px] rotate-180', '-translate-x-1/2 rotate-90', 'ml-[4px] -translate-x-1/2 -translate-y-[22px]'],
  bg: ['bg-red-50', 'bg-gray-100', 'bg-green-50'],
  comment: ['text-red-900', 'text-gray-900', 'text-green-900']
};

var ReviewCardWithContext = function ReviewCardWithContext(_ref) {
  var review = _ref.review,
      user = _ref.user,
      className = _ref.className,
      title = _ref.title,
      onReviewPage = _ref.onReviewPage,
      children = _ref.children,
      ContextComponent = _ref.ContextComponent,
      skipLinks = _ref.skipLinks,
      skipStaff = _ref.skipStaff,
      bylineSuffix = _ref.bylineSuffix,
      skipByline = _ref.skipByline,
      pageKey = _ref.pageKey;

  var _normalizeReview = (0,utils/* normalizeReview */.tK)(review),
      vote = _normalizeReview.vote,
      comment = _normalizeReview.comment,
      hashtags = _normalizeReview.hashtags,
      meta = _normalizeReview.meta;

  var domainKey = meta.domainKey;
  var contextClasses = "p-4 flex flex-col flex-shrink-0 items-center justify-center w-[200px] h-full rounded-l-md ".concat(skipLinks ? '' : 'hover:bg-gray-100');
  var wrapperClasses = 'flex flex-grow flex-col p-4 pl-0 h-full rounded-r-md';
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: (0,utils.cn)('flex', className),
    children: [ContextComponent ? /*#__PURE__*/(0,jsx_runtime.jsx)(ContextComponent, {
      domainKey: domainKey,
      pageKey: pageKey,
      className: contextClasses
    }) : user ? /*#__PURE__*/(0,jsx_runtime.jsx)(ContextualUser, {
      user: user,
      className: contextClasses,
      skipLinks: skipLinks
    }) : skipStaff ? null : /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      className: "w-4 flex-shrink-0"
    }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "flex flex-grow",
      children: [skipStaff ? null : /*#__PURE__*/(0,jsx_runtime.jsx)(ReviewStaff, {
        vote: vote
      }), /*#__PURE__*/(0,jsx_runtime.jsxs)(ConditionalWrap/* default */.Z, {
        condition: !skipLinks && !onReviewPage,
        wrap: function wrap(kid) {
          return /*#__PURE__*/(0,jsx_runtime.jsx)(UniversalLink/* UniversalClickableDiv */.C, {
            href: user ? routes/* default.reviewUrl */.Z.reviewUrl(user, domainKey, pageKey) : routes/* default.siteUrl */.Z.siteUrl(domainKey),
            className: (0,utils.cn)(wrapperClasses, 'hover:bg-gray-100 cursor-pointer'),
            children: kid
          });
        },
        elseWrap: function elseWrap(kid) {
          return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
            className: wrapperClasses,
            children: kid
          });
        },
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("div", {
          className: "text-center text-xl mb-2",
          children: title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(ReviewContent, {
          review: review,
          onReviewPage: onReviewPage,
          bylineSuffix: bylineSuffix,
          skipByline: skipByline
        }), onReviewPage ? /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
          className: "p-4 pb-1 flex flex-col gap-4 items-center lg:flex-row",
          children: children
        }) : /*#__PURE__*/(0,jsx_runtime.jsx)(ReviewDetails, {
          meta: meta
        })]
      })]
    })]
  });
};

var ContextualUser = function ContextualUser(_ref2) {
  var user = _ref2.user,
      className = _ref2.className,
      skipLinks = _ref2.skipLinks;
  return /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalWrap/* default */.Z, {
    condition: !skipLinks,
    wrap: function wrap(kid) {
      return /*#__PURE__*/(0,jsx_runtime.jsx)(UniversalLink/* default */.Z, {
        href: routes/* default.userUrl */.Z.userUrl(user),
        className: className,
        children: kid
      });
    },
    elseWrap: function elseWrap(kid) {
      return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        className: className,
        children: kid
      });
    },
    children: /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)(Avatar/* default */.Z, {
        user: user,
        size: "128",
        className: "border-2 border-gray-600 rounded-full mb-4"
      }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "flex items-end",
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("span", {
          className: "text-lg font-light text-gray-600 pr-[2px]",
          children: "@"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
          className: "text-2xl text-gray-800",
          children: user.handle
        })]
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        className: "text-base font-light text-gray-700 text-center leading-tight",
        children: user.tagline
      })]
    })
  });
};

var ReviewStaff = function ReviewStaff(_ref3) {
  var vote = _ref3.vote,
      className = _ref3.className;
  var justification = vote > 0 ? 'justify-start' : vote < 0 ? 'justify-end' : 'justify-center';
  return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
    className: (0,utils.cn)('w-1 flex flex-col min-h-max bg-gradient-to-b ', className, justification, colors.divider[vote + 1]),
    children: /*#__PURE__*/(0,jsx_runtime.jsx)(Logo/* default */.ZP, {
      upClassName: colors.triColor[vote + 1],
      downClassName: "text-transparent",
      className: (0,utils.cn)('h-8 w-8', colors.tri[vote + 1])
    })
  });
};
var ReviewContent = function ReviewContent(_ref4) {
  var review = _ref4.review,
      onReviewPage = _ref4.onReviewPage,
      bylineSuffix = _ref4.bylineSuffix,
      skipByline = _ref4.skipByline;

  var _normalizeReview2 = (0,utils/* normalizeReview */.tK)(review),
      vote = _normalizeReview2.vote,
      comment = _normalizeReview2.comment,
      hashtags = _normalizeReview2.hashtags,
      meta = _normalizeReview2.meta; // TODO:PACKET - why needed, should it be normalized in the getter?


  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: (0,utils.cn)(colors.bg[vote + 1], 'p-4 border-2 rounded-r-md border-l-0 w-full flex flex-col justify-between overflow-x-auto space-y-4'),
    children: [comment !== null && comment !== void 0 && comment.length ? /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "text-gray-700 flex relative",
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        className: "absolute text-4xl font-serif",
        "aria-hidden": "true",
        children: "\u201C"
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        className: (0,utils.cn)('ml-5 prose', onReviewPage ? 'text-xl leading-normal' : 'max-h-32 overflow-y-auto leading-snug'),
        children: /*#__PURE__*/(0,jsx_runtime.jsx)(components_MarkdownText, {
          text: comment
        })
      })]
    }) : null, /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "flex flex-col space-y-2",
      children: [hashtags !== null && hashtags !== void 0 && hashtags.length ? /*#__PURE__*/(0,jsx_runtime.jsx)(components_Hashtags, {
        hashtags: hashtags,
        className: "text-base md:text-xl flex flex-wrap w-full space-x-1 md:space-x-2",
        tagClassName: "text-gray-800",
        spacer: true
      }) : null, skipByline ? null : /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "text-xs italic text-gray-400 text-left",
        children: ["Viewed", /*#__PURE__*/(0,jsx_runtime.jsxs)("span", {
          className: "whitespace-nowrap",
          children: [' ', meta.updatedAt && /*#__PURE__*/(0,jsx_runtime.jsx)(TimeAgo/* default */.Z, {
            datetime: meta.updatedAt
          }), ' ']
        }), bylineSuffix]
      })]
    })]
  });
};

var ReviewDetails = function ReviewDetails(_ref5) {
  var meta = _ref5.meta;

  var _ref6 = meta || {},
      _ref6$numRuleReviews = _ref6.numRuleReviews,
      numRuleReviews = _ref6$numRuleReviews === void 0 ? 0 : _ref6$numRuleReviews,
      _ref6$numPageReviews = _ref6.numPageReviews,
      numPageReviews = _ref6$numPageReviews === void 0 ? 0 : _ref6$numPageReviews;

  var numReviews = numRuleReviews + numPageReviews;
  return numReviews > 0 ? /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: "mt-1 mx-2 text-xs text-light flex justify-end items-center text-gray-400",
    children: ["+", (0,utils/* plur */.Jn)(numReviews, 'page review')]
  }) : null;
};

/* harmony default export */ const ReviewCard = (ReviewCardWithContext);

/***/ }),

/***/ 66330:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "v_": () => (/* binding */ ShareDomainReview),
  "Ol": () => (/* binding */ SharePageReview),
  "ZP": () => (/* binding */ components_ShareReview)
});

// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(67294);
// EXTERNAL MODULE: ./src/lib/common/utils/index.js
var utils = __webpack_require__(37724);
// EXTERNAL MODULE: ./src/lib/common/routes.js
var routes = __webpack_require__(11147);
// EXTERNAL MODULE: ./node_modules/lodash/lodash.js
var lodash = __webpack_require__(96486);
// EXTERNAL MODULE: ./src/lib/universal-interface/hooks.js
var hooks = __webpack_require__(50731);
// EXTERNAL MODULE: ./src/lib/common/logic/index.js
var logic = __webpack_require__(55231);
;// CONCATENATED MODULE: ./src/lib/common/hooks/useShareableReviewComponents.js
var _excluded = ["getComponents", "review", "domainKey", "pageKey", "author", "alreadyParsed"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }









var contextualName = function contextualName(_ref) {
  var uid = _ref.uid,
      author = _ref.author,
      possessive = _ref.possessive;

  if (uid && author.id === uid) {
    return 'my';
  } else {
    var base = (0,utils/* handle */.pr)(author);
    return possessive ? "".concat(base, "'s") : base;
  }
};

var useShareableReviewComponents = function useShareableReviewComponents(_ref2) {
  var getComponents = _ref2.getComponents,
      review = _ref2.review,
      domainKey = _ref2.domainKey,
      pageKey = _ref2.pageKey,
      author = _ref2.author,
      alreadyParsed = _ref2.alreadyParsed,
      props = _objectWithoutProperties(_ref2, _excluded);

  var uid = (0,hooks/* useCurrentUserId */.dO)();
  return (0,react.useMemo)(function () {
    if (alreadyParsed) return alreadyParsed;
    return getComponents({
      review: review,
      domainKey: domainKey,
      author: author,
      uid: uid,
      pageKey: pageKey
    });
  }, [getComponents, review, domainKey, author, alreadyParsed, uid, pageKey]);
};

var useShareableDomainReviewComponents = function useShareableDomainReviewComponents(props) {
  return useShareableReviewComponents(_objectSpread(_objectSpread({}, props), {}, {
    getComponents: getDomainReviewComponents
  }));
};
var useShareablePageReviewComponents = function useShareablePageReviewComponents(props) {
  return useShareableReviewComponents(_objectSpread(_objectSpread({}, props), {}, {
    getComponents: getPageReviewComponents
  }));
};

var getDomainReviewComponents = function getDomainReviewComponents(_ref3) {
  var domainPacket = _ref3.domainPacket,
      review = _ref3.review,
      domainKey = _ref3.domainKey,
      author = _ref3.author,
      uid = _ref3.uid;
  var my = contextualName({
    uid: uid,
    author: author,
    possessive: true
  }); // Note: if given explicit review to share, won't have meta.numPageReviews... that's probably fine, minor tweaks to shared messages for now.
  // May be worth breaking up the isomorphic <ShareReview /> approach and just pass domainPacket for domain reviews?

  var _normalizeReview = (0,utils/* normalizeReview */.tK)(review || (domainPacket === null || domainPacket === void 0 ? void 0 : domainPacket.domainReview)),
      comment = _normalizeReview.comment,
      vote = _normalizeReview.vote,
      hashtags = _normalizeReview.hashtags,
      meta = _normalizeReview.meta;

  var humanVote = "".concat((0,logic/* humanizeVote */.UP)(vote)).concat(meta !== null && meta !== void 0 && meta.numPageReviews || meta !== null && meta !== void 0 && meta.numRuleReviews ? ' (with complications)' : '');
  return {
    url: routes/* default.userDomainReviewUrl */.Z.userDomainReviewUrl(author, domainKey),
    title: "".concat((0,utils/* handle */.pr)(author), "'s take on ").concat(domainKey),
    displayHashtag: hashtags.length ? "#".concat(hashtags[0]) : null,
    fbQuote: comment,
    // TODO: see how it renders, but probably add some callback to the site
    summary: "In short, generally ".concat(humanVote, "... but check out ").concat(my, " full review of ").concat(domainKey, " for details."),
    hashtags: hashtags,
    // Email being sent directly to another user should use "my vote" voice. Others are public postings that should probably use "Kali's vote" voice.
    emailSubject: "".concat((0,lodash.capitalize)(my), " take on ").concat(domainKey),
    emailBody: "In short, generally ".concat(humanVote, ". Check out the full review here:")
  };
};

var getPageReviewComponents = function getPageReviewComponents(_ref4) {
  var review = _ref4.review,
      domainKey = _ref4.domainKey,
      pageKey = _ref4.pageKey,
      author = _ref4.author,
      uid = _ref4.uid;
  var my = contextualName({
    uid: uid,
    author: author,
    possessive: true
  });

  var _normalizeReview2 = (0,utils/* normalizeReview */.tK)(review),
      comment = _normalizeReview2.comment,
      vote = _normalizeReview2.vote,
      hashtags = _normalizeReview2.hashtags;

  var address = (0,logic/* addressFromPageKey */.gh)({
    pageKey: pageKey,
    domainKey: domainKey,
    review: review,
    withoutProtocol: true
  });
  var humanVote = (0,logic/* humanizeVote */.UP)(vote);
  return {
    url: routes/* default.userDomainPageReviewUrl */.Z.userDomainPageReviewUrl(author, domainKey, pageKey),
    title: "".concat((0,utils/* handle */.pr)(author), "'s take on ").concat(address),
    displayHashtag: hashtags.length ? "#".concat(hashtags[0]) : null,
    fbQuote: comment,
    // TODO: see how it renders, but probably add some callback to the site
    summary: "In short, generally ".concat(humanVote, "... but check out ").concat(my, " full review of ").concat(address, " for details."),
    hashtags: hashtags,
    // Email being sent directly to another user should use "my vote" voice. Others are public postings that should probably use "Kali's vote" voice.
    emailSubject: "".concat((0,lodash.capitalize)(my), " take on ").concat(address),
    emailBody: "In short, generally ".concat(humanVote, ". Check out the full review here:")
  };
};
// EXTERNAL MODULE: ./src/lib/common/config/index.js
var config = __webpack_require__(66245);
// EXTERNAL MODULE: ./node_modules/react-share/es/EmailShareButton.js
var EmailShareButton = __webpack_require__(48137);
// EXTERNAL MODULE: ./node_modules/react-share/es/FacebookShareButton.js
var FacebookShareButton = __webpack_require__(16573);
// EXTERNAL MODULE: ./node_modules/react-share/es/LinkedinShareButton.js
var LinkedinShareButton = __webpack_require__(53597);
// EXTERNAL MODULE: ./node_modules/react-share/es/RedditShareButton.js
var RedditShareButton = __webpack_require__(75341);
// EXTERNAL MODULE: ./node_modules/react-share/es/TwitterShareButton.js
var TwitterShareButton = __webpack_require__(46616);
// EXTERNAL MODULE: ./node_modules/react-share/es/PinterestShareButton.js
var PinterestShareButton = __webpack_require__(61366);
// EXTERNAL MODULE: ./node_modules/react-share/es/TumblrShareButton.js
var TumblrShareButton = __webpack_require__(98865);
// EXTERNAL MODULE: ./node_modules/react-share/es/WhatsappShareButton.js
var WhatsappShareButton = __webpack_require__(12834);
// EXTERNAL MODULE: ./node_modules/react-share/es/EmailIcon.js
var EmailIcon = __webpack_require__(66339);
// EXTERNAL MODULE: ./node_modules/react-share/es/FacebookIcon.js
var FacebookIcon = __webpack_require__(1020);
// EXTERNAL MODULE: ./node_modules/react-share/es/LinkedinIcon.js
var LinkedinIcon = __webpack_require__(37332);
// EXTERNAL MODULE: ./node_modules/react-share/es/RedditIcon.js
var RedditIcon = __webpack_require__(70431);
// EXTERNAL MODULE: ./node_modules/react-share/es/TwitterIcon.js
var TwitterIcon = __webpack_require__(87385);
// EXTERNAL MODULE: ./node_modules/react-share/es/PinterestIcon.js
var PinterestIcon = __webpack_require__(94493);
// EXTERNAL MODULE: ./node_modules/react-share/es/TumblrIcon.js
var TumblrIcon = __webpack_require__(95019);
// EXTERNAL MODULE: ./node_modules/react-share/es/WhatsappIcon.js
var WhatsappIcon = __webpack_require__(69275);
// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(85893);
;// CONCATENATED MODULE: ./src/lib/common/components/ShareButtons/index.js
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

var ShareButtons_excluded = ["network", "skipLabel"],
    _excluded2 = ["network", "size", "iconProps"],
    _excluded3 = ["network"];

function ShareButtons_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function ShareButtons_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ShareButtons_ownKeys(Object(source), !0).forEach(function (key) { ShareButtons_defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ShareButtons_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function ShareButtons_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function ShareButtons_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = ShareButtons_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function ShareButtons_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }






var log = utils/* logger.extend */.kg.extend('ShareButtons'); // TODO: OPTIMIZE - use webpack's dynamic imports to only load the parts we need
// Full docs for each: https://github.com/nygardk/react-share




var Buttons = {
  EmailShareButton: EmailShareButton/* default */.Z,
  FacebookShareButton: FacebookShareButton/* default */.Z,
  LinkedinShareButton: LinkedinShareButton/* default */.Z,
  RedditShareButton: RedditShareButton/* default */.Z,
  TwitterShareButton: TwitterShareButton/* default */.Z,
  PinterestShareButton: PinterestShareButton/* default */.Z,
  TumblrShareButton: TumblrShareButton/* default */.Z,
  WhatsappShareButton: WhatsappShareButton/* default */.Z // HatenaShareButton, InstapaperShareButton, LineShareButton, LivejournalShareButton, MailruShareButton, OKShareButton, PocketShareButton, TelegramShareButton, ViberShareButton, VKShareButton, WorkplaceShareButton

};
var Icons = {
  EmailIcon: EmailIcon/* default */.Z,
  FacebookIcon: FacebookIcon/* default */.Z,
  LinkedinIcon: LinkedinIcon/* default */.Z,
  RedditIcon: RedditIcon/* default */.Z,
  TwitterIcon: TwitterIcon/* default */.Z,
  PinterestIcon: PinterestIcon/* default */.Z,
  TumblrIcon: TumblrIcon/* default */.Z,
  WhatsappIcon: WhatsappIcon/* default */.Z // FacebookMessengerIcon, HatenaIcon, InstapaperIcon, LineIcon, LivejournalIcon, MailruIcon, OKIcon, PocketIcon, TelegramIcon, ViberIcon, VKIcon, WeiboIcon, WorkplaceIcon

}; // TODO: unable FB, Reddit to show share counts once we have a page to share

var Counts = {// FacebookShareCount,
  // PinterestShareCount,
  // TumblrShareCount,
  //  RedditShareCount,
  // HatenaShareCount, OKShareCount, VKShareCount,
};
var suffixLength = 'ShareButton'.length;
var SUPPORTED_NETWORKS = Object.keys(Buttons).map(function (name) {
  return name.substring(0, name.length - suffixLength);
}); // Note: window opening blocked until promise is resolved

var makeShareWindowOpenHandler = function makeShareWindowOpenHandler(network) {
  return /*#__PURE__*/_asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
    return _regeneratorRuntime().wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            log('onShareWindowOpen', network);

          case 1:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
}; // Note: seems to fire when the opened window navigates away, e.g. to a login screen for the underlying network.
// There does NOT seem to be any clear trigger for "this was successfully shared" :/


var makeShareWindowCloseHandler = function makeShareWindowCloseHandler(network) {
  return function () {
    log('onShareWindowClose', network); // TODO: track user clicks and move their most used networks higher up the priority chain (cautious w/ SSG)
  };
};

var ShareCount = /*#__PURE__*/react.memo(function (_ref2) {
  var network = _ref2.network,
      url = _ref2.url;
  var CountTag = Counts["".concat(network, "ShareCount")]; // Pretty sure this shouldn't be necessary... and yet

  if (!CountTag) return null;
  return /*#__PURE__*/(0,jsx_runtime.jsx)(CountTag, {
    url: url,
    children: function children(shareCount) {
      return /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
        className: "text-white bg-blue-300 rounded-full px-2 py-1 text-sm",
        children: shareCount
      });
    }
  });
});
ShareCount.displayName = 'ShareCount';
var Icon = /*#__PURE__*/react.memo(function (_ref3) {
  var network = _ref3.network,
      skipLabel = _ref3.skipLabel,
      props = ShareButtons_objectWithoutProperties(_ref3, ShareButtons_excluded);

  var IconTag = Icons["".concat(network, "Icon")]; // Pretty sure this shouldn't be necessary... and yet

  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: "relative flex flex-col m-1 items-center group",
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)(IconTag, ShareButtons_objectSpread({
      size: 46,
      round: true
    }, props)), skipLabel ? null : /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      className: (0,utils.cn)('small', // Hack to make btns fancy on user page without messing w/ extension
      props.size && props.size < 40 && 'text-gray-500 transition-opacity duration-300 opacity-0 group-hover:opacity-100 absolute bottom-6 mb-2'),
      children: network.toLowerCase()
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ShareCount, {
      network: network,
      url: props.url
    })]
  });
});
Icon.displayName = 'Icon';
var FullShareButton = /*#__PURE__*/react.memo(function (_ref4) {
  var network = _ref4.network,
      size = _ref4.size,
      iconProps = _ref4.iconProps,
      props = ShareButtons_objectWithoutProperties(_ref4, _excluded2);

  var ButtonTag = Buttons["".concat(network, "ShareButton")];
  return /*#__PURE__*/(0,jsx_runtime.jsx)(ButtonTag, ShareButtons_objectSpread(ShareButtons_objectSpread({}, props), {}, {
    className: "filter grayscale hover:filter-none" // TODO: works, but what should we track? via network, via sharing user, via review leaving user... what's useful for us?
    // onClick={() => alert(`clicked ${network}`)}
    ,
    children: /*#__PURE__*/(0,jsx_runtime.jsx)(Icon, ShareButtons_objectSpread({
      network: network,
      size: size
    }, iconProps))
  }));
});
FullShareButton.displayName = 'FullShareButton';

var activeNetworksForUserId = function activeNetworksForUserId(uid, num) {
  // TODO: POLISH - add per-user customization of which networks to show
  return (0,lodash.take)(SUPPORTED_NETWORKS, num);
};

var ShareButtons = function ShareButtons(_ref5) {
  var _ref5$num = _ref5.num,
      num = _ref5$num === void 0 ? 5 : _ref5$num,
      btnClassName = _ref5.btnClassName,
      size = _ref5.size,
      iconProps = _ref5.iconProps,
      url = _ref5.url,
      title = _ref5.title,
      summary = _ref5.summary,
      emailBody = _ref5.emailBody,
      emailSubject = _ref5.emailSubject,
      fbQuote = _ref5.fbQuote,
      displayHashtag = _ref5.displayHashtag,
      hashtags = _ref5.hashtags;
  var uid = (0,hooks/* useCurrentUserId */.dO)();
  var activeNetworks = (0,react.useMemo)(function () {
    return activeNetworksForUserId(uid, num);
  }, [uid, num]);
  var ConditionalShareButton = (0,react.useCallback)(function (_ref6) {
    var network = _ref6.network,
        props = ShareButtons_objectWithoutProperties(_ref6, _excluded3);

    return activeNetworks.includes(network) ? /*#__PURE__*/(0,jsx_runtime.jsx)(FullShareButton, ShareButtons_objectSpread(ShareButtons_objectSpread({
      network: network,
      url: url,
      onShareWindowClose: makeShareWindowCloseHandler(network),
      beforeOnClick: makeShareWindowOpenHandler(network)
    }, props), {}, {
      className: btnClassName,
      size: size,
      iconProps: iconProps
    })) : null;
  }, [url, btnClassName, activeNetworks]);
  var imageUrl = null; // TODO

  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: "flex flex-wrap justify-center mt-3",
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Email",
      subject: emailSubject,
      body: emailBody
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Facebook",
      quote: fbQuote,
      hashtag: displayHashtag
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Linkedin",
      title: title,
      summary: summary,
      source: config/* default.siteRootUrl */.ZP.siteRootUrl
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Reddit",
      title: title
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Twitter",
      title: title,
      hashtags: hashtags,
      via: config/* default.siteRootUrl */.ZP.siteRootUrl
    }), config/* default.fbAppId */.ZP.fbAppId && /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "FacebookMessenger",
      appId: config/* default.fbAppId */.ZP.fbAppId
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Hatena",
      title: title
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Instapaper",
      title: title,
      description: summary
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Line",
      title: title
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Livejournal",
      title: title,
      description: summary
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Mailru",
      title: title,
      description: summary,
      imageUrl: imageUrl
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "OKShare",
      title: title,
      description: summary,
      image: imageUrl
    }), imageUrl && /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Pinterest",
      media: imageUrl,
      description: title
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Pocket",
      title: title
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Telegram",
      title: title
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Tumblr",
      title: title,
      tags: hashtags,
      caption: summary
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Viber",
      title: title,
      separator: ": "
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "VK",
      title: title,
      image: imageUrl,
      noVkLinks: true
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Weibo",
      title: title,
      image: imageUrl
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Whatsapp",
      title: title,
      separator: ": "
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalShareButton, {
      network: "Workplace",
      quote: fbQuote,
      hashtag: displayHashtag
    })]
  });
};

/* harmony default export */ const components_ShareButtons = (ShareButtons);
// EXTERNAL MODULE: ./src/lib/common/components/Button/index.js
var Button = __webpack_require__(95673);
// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/react-hot-toast.esm.js + 1 modules
var react_hot_toast_esm = __webpack_require__(88279);
// EXTERNAL MODULE: ./node_modules/use-clipboard-copy/dist/index.js
var dist = __webpack_require__(16248);
;// CONCATENATED MODULE: ./src/lib/common/components/CopyToClipboard.js






var CopyToClipboard = function CopyToClipboard(_ref) {
  var label = _ref.label,
      desc = _ref.desc,
      value = _ref.value;
  var clipboard = (0,dist.useClipboard)({
    onSuccess: function onSuccess() {
      react_hot_toast_esm/* default.success */.ZP.success( /*#__PURE__*/(0,jsx_runtime.jsxs)("span", {
        children: ["Copied", desc ? " ".concat(desc) : '', " to clipboard:", ' ', /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
          className: "text-xs text-gray-500 text-monospace break-words",
          children: value
        })]
      }));
    },
    onError: function onError() {
      react_hot_toast_esm/* default.error */.ZP.error('Browser is not cooperating - please copy text manually');
    }
  });
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: "text-center",
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)("input", {
      ref: clipboard.target,
      value: value,
      className: "hidden",
      readOnly: true
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(Button/* default */.Z, {
      onClick: clipboard.copy,
      variant: "secondary",
      children: label
    })]
  });
};

/* harmony default export */ const components_CopyToClipboard = (CopyToClipboard);
;// CONCATENATED MODULE: ./src/lib/common/components/ShareReview/index.js
var ShareReview_excluded = ["getterFn", "author", "review", "domainKey", "pageKey", "components", "className", "showUrl", "numBtns"],
    ShareReview_excluded2 = ["pageKey"];

function ShareReview_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function ShareReview_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ShareReview_ownKeys(Object(source), !0).forEach(function (key) { ShareReview_defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ShareReview_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function ShareReview_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function ShareReview_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = ShareReview_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function ShareReview_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







var DoShareReview = function DoShareReview(_ref) {
  var getterFn = _ref.getterFn,
      author = _ref.author,
      review = _ref.review,
      domainKey = _ref.domainKey,
      pageKey = _ref.pageKey,
      components = _ref.components,
      _ref$className = _ref.className,
      className = _ref$className === void 0 ? 'p-3 rounded bg-gray-100' : _ref$className,
      showUrl = _ref.showUrl,
      numBtns = _ref.numBtns,
      props = ShareReview_objectWithoutProperties(_ref, ShareReview_excluded);

  var whatToShare = getterFn({
    review: review,
    author: author,
    domainKey: domainKey,
    pageKey: pageKey,
    alreadyParsed: components
  });
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: className,
    children: [showUrl && /*#__PURE__*/(0,jsx_runtime.jsx)(components_CopyToClipboard, {
      value: whatToShare.url,
      label: "Copy Review URL"
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(components_ShareButtons, ShareReview_objectSpread(ShareReview_objectSpread({}, whatToShare), {}, {
      num: numBtns
    }, props))]
  });
};

var ShareDomainReview = function ShareDomainReview(props) {
  return /*#__PURE__*/(0,jsx_runtime.jsx)(DoShareReview, ShareReview_objectSpread({
    getterFn: useShareableDomainReviewComponents
  }, props));
};
var SharePageReview = function SharePageReview(props) {
  return /*#__PURE__*/(0,jsx_runtime.jsx)(DoShareReview, ShareReview_objectSpread({
    getterFn: useShareablePageReviewComponents
  }, props));
};

var ShareReview = function ShareReview(_ref2) {
  var pageKey = _ref2.pageKey,
      props = ShareReview_objectWithoutProperties(_ref2, ShareReview_excluded2);

  return pageKey ? /*#__PURE__*/(0,jsx_runtime.jsx)(SharePageReview, ShareReview_objectSpread({
    pageKey: pageKey
  }, props)) : /*#__PURE__*/(0,jsx_runtime.jsx)(ShareDomainReview, ShareReview_objectSpread({}, props));
};

/* harmony default export */ const components_ShareReview = (ShareReview);

/***/ }),

/***/ 3716:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var timeago_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(74746);
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(37724);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(85893);
var _excluded = ["datetime"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var TimeAgo = function TimeAgo(_ref) {
  var datetime = _ref.datetime,
      props = _objectWithoutProperties(_ref, _excluded);

  if (!datetime) return null;

  try {
    var dt = (0,common_utils__WEBPACK_IMPORTED_MODULE_1__/* .dateFromDatish */ .l_)(datetime);
    return dt ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(timeago_react__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z, _objectSpread({
      title: dt.toLocaleString(),
      datetime: dt
    }, props)) : null;
  } catch (e) {
    return null;
  }
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TimeAgo);

/***/ }),

/***/ 39257:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37724);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(85893);




var SubnavBar = function SubnavBar(_ref) {
  var className = _ref.className,
      children = _ref.children,
      onClick = _ref.onClick;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
    className: (0,common_utils__WEBPACK_IMPORTED_MODULE_0__.cn)('p-2 bg-gray-100 flex items-center justify-between', onClick && 'cursor-pointer select-none', className),
    onClick: onClick,
    children: children
  });
};

SubnavBar.ActionTitle = function (_ref2) {
  var title = _ref2.title,
      children = _ref2.children,
      onClick = _ref2.onClick,
      className = _ref2.className;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
    className: (0,common_utils__WEBPACK_IMPORTED_MODULE_0__.cn)('inline-flex items-center', className),
    role: "button",
    onClick: onClick,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("span", {
      className: "whitespace-nowrap",
      children: [title, " "]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("span", {
      className: "break-words",
      children: children
    })]
  });
};

SubnavBar.ActionTitle.displayName = 'SubnavBar.ActionTitle';

SubnavBar.RightTitle = function (_ref3) {
  var children = _ref3.children;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
    className: "whitespace-nowrap",
    children: children
  });
};

SubnavBar.RightTitle.displayName = 'SubnavBar.RightTitle';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SubnavBar);

/***/ })

}]);