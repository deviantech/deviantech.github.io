"use strict";
(self["webpackChunkvoyd_browser_extension"] = self["webpackChunkvoyd_browser_extension"] || []).push([[125],{

/***/ 86125:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ext_WriteMode)
});

// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(67294);
// EXTERNAL MODULE: ./node_modules/react-hook-form/dist/index.esm.js
var index_esm = __webpack_require__(42283);
// EXTERNAL MODULE: ./src/lib/common/utils/index.js
var utils = __webpack_require__(37724);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/utils/render.js
var render = __webpack_require__(12351);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/hooks/use-id.js
var use_id = __webpack_require__(19946);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/utils/match.js
var match = __webpack_require__(32984);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/hooks/use-iso-morphic-effect.js
var use_iso_morphic_effect = __webpack_require__(16723);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/keyboard.js
var keyboard = __webpack_require__(61363);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/utils/focus-management.js
var focus_management = __webpack_require__(84575);
;// CONCATENATED MODULE: ./node_modules/@headlessui/react/dist/hooks/use-flags.js
function use_flags_b(g=0){let[r,l]=(0,react.useState)(g),u=(0,react.useCallback)(e=>l(a=>a|e),[l]),n=(0,react.useCallback)(e=>Boolean(r&e),[r]),o=(0,react.useCallback)(e=>l(a=>a&~e),[l]),s=(0,react.useCallback)(e=>l(a=>a^e),[l]);return{addFlag:u,hasFlag:n,removeFlag:o,toggleFlag:s}}

// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/hooks/use-sync-refs.js
var use_sync_refs = __webpack_require__(23784);
;// CONCATENATED MODULE: ./node_modules/@headlessui/react/dist/components/label/label.js
let c=(0,react.createContext)(null);function f(){let l=(0,react.useContext)(c);if(l===null){let t=new Error("You used a <Label /> component, but it is not inside a relevant parent.");throw Error.captureStackTrace&&Error.captureStackTrace(t,f),t}return l}function B(){let[l,t]=(0,react.useState)([]);return[l.length>0?l.join(" "):void 0,(0,react.useMemo)(()=>function(e){let o=(0,react.useCallback)(a=>(t(i=>[...i,a]),()=>t(i=>{let n=i.slice(),d=n.indexOf(a);return d!==-1&&n.splice(d,1),n})),[]),r=(0,react.useMemo)(()=>({register:o,slot:e.slot,name:e.name,props:e.props}),[o,e.slot,e.name,e.props]);return react.createElement(c.Provider,{value:r},e.children)},[t])]}let v="label",M=(0,render/* forwardRefWithAs */.yV)(function(t,s){let{passive:e=!1,...o}=t,r=f(),a=`headlessui-label-${(0,use_id/* useId */.M)()}`,i=(0,use_sync_refs/* useSyncRefs */.T)(s);(0,use_iso_morphic_effect/* useIsoMorphicEffect */.e)(()=>r.register(a),[a,r.register]);let n={ref:i,...r.props,id:a};return e&&("onClick"in n&&delete n.onClick,"onClick"in o&&delete o.onClick),(0,render/* render */.sY)({ourProps:n,theirProps:o,slot:r.slot||{},defaultTag:v,name:r.name||"Label"})});

// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/description/description.js
var description = __webpack_require__(39516);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/utils/owner.js
var owner = __webpack_require__(15466);
;// CONCATENATED MODULE: ./node_modules/@headlessui/react/dist/hooks/use-tree-walker.js
function use_tree_walker_F({container:e,accept:t,walk:r,enabled:c=!0}){let o=(0,react.useRef)(t),l=(0,react.useRef)(r);(0,react.useEffect)(()=>{o.current=t,l.current=r},[t,r]),(0,use_iso_morphic_effect/* useIsoMorphicEffect */.e)(()=>{if(!e||!c)return;let n=(0,owner/* getOwnerDocument */.r)(e);if(!n)return;let f=o.current,p=l.current,d=Object.assign(i=>f(i),{acceptNode:f}),u=n.createTreeWalker(e,NodeFilter.SHOW_ELEMENT,d,!1);for(;u.nextNode();)p(u.currentNode)},[e,c,o,l])}

// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/internal/hidden.js
var internal_hidden = __webpack_require__(46045);
;// CONCATENATED MODULE: ./node_modules/@headlessui/react/dist/utils/form.js
function e(n={},r=null,t=[]){for(let[i,o]of Object.entries(n))form_f(t,s(r,i),o);return t}function s(n,r){return n?n+"["+r+"]":r}function form_f(n,r,t){if(Array.isArray(t))for(let[i,o]of t.entries())form_f(n,s(r,i.toString()),o);else t instanceof Date?n.push([r,t.toISOString()]):typeof t=="boolean"?n.push([r,t?"1":"0"]):typeof t=="string"?n.push([r,t]):typeof t=="number"?n.push([r,`${t}`]):t==null?n.push([r,""]):e(t,r,n)}function form_p(n){var t;let r=(t=n==null?void 0:n.form)!=null?t:n.closest("form");if(!!r){for(let i of r.elements)if(i.tagName==="INPUT"&&i.type==="submit"||i.tagName==="BUTTON"&&i.type==="submit"||i.nodeName==="INPUT"&&i.type==="image"){i.click();return}}}

;// CONCATENATED MODULE: ./node_modules/@headlessui/react/dist/components/radio-group/radio-group.js
var se=(t=>(t[t.RegisterOption=0]="RegisterOption",t[t.UnregisterOption=1]="UnregisterOption",t))(se||{});let ue={[0](n,o){let t=[...n.options,{id:o.id,element:o.element,propsRef:o.propsRef}];return{...n,options:(0,focus_management/* sortByDomNode */.z2)(t,r=>r.element.current)}},[1](n,o){let t=n.options.slice(),r=n.options.findIndex(m=>m.id===o.id);return r===-1?n:(t.splice(r,1),{...n,options:t})}},U=(0,react.createContext)(null);U.displayName="RadioGroupContext";function z(n){let o=(0,react.useContext)(U);if(o===null){let t=new Error(`<${n} /> is missing a parent <RadioGroup /> component.`);throw Error.captureStackTrace&&Error.captureStackTrace(t,z),t}return o}function ce(n,o){return (0,match/* match */.E)(o.type,ue,n,o)}let fe="div",be=(0,render/* forwardRefWithAs */.yV)(function(o,t){let{value:r,name:m,onChange:f,disabled:R=!1,...I}=o,[{options:a},A]=(0,react.useReducer)(ce,{options:[]}),[T,C]=B(),[k,c]=(0,description/* useDescriptions */.f)(),g=`headlessui-radiogroup-${(0,use_id/* useId */.M)()}`,y=(0,react.useRef)(null),b=(0,use_sync_refs/* useSyncRefs */.T)(y,t),E=(0,react.useMemo)(()=>a.find(e=>!e.propsRef.current.disabled),[a]),D=(0,react.useMemo)(()=>a.some(e=>e.propsRef.current.value===r),[a,r]),s=(0,react.useCallback)(e=>{var i;if(R||e===r)return!1;let d=(i=a.find(p=>p.propsRef.current.value===e))==null?void 0:i.propsRef.current;return d!=null&&d.disabled?!1:(f(e),!0)},[f,r,R,a]);use_tree_walker_F({container:y.current,accept(e){return e.getAttribute("role")==="radio"?NodeFilter.FILTER_REJECT:e.hasAttribute("role")?NodeFilter.FILTER_SKIP:NodeFilter.FILTER_ACCEPT},walk(e){e.setAttribute("role","none")}});let h=(0,react.useCallback)(e=>{let d=y.current;if(!d)return;let i=(0,owner/* getOwnerDocument */.r)(d),p=a.filter(l=>l.propsRef.current.disabled===!1).map(l=>l.element.current);switch(e.key){case keyboard/* Keys.Enter */.R.Enter:form_p(e.currentTarget);break;case keyboard/* Keys.ArrowLeft */.R.ArrowLeft:case keyboard/* Keys.ArrowUp */.R.ArrowUp:if(e.preventDefault(),e.stopPropagation(),(0,focus_management/* focusIn */.jA)(p,focus_management/* Focus.Previous */.TO.Previous|focus_management/* Focus.WrapAround */.TO.WrapAround)===focus_management/* FocusResult.Success */.fE.Success){let u=a.find(G=>G.element.current===(i==null?void 0:i.activeElement));u&&s(u.propsRef.current.value)}break;case keyboard/* Keys.ArrowRight */.R.ArrowRight:case keyboard/* Keys.ArrowDown */.R.ArrowDown:if(e.preventDefault(),e.stopPropagation(),(0,focus_management/* focusIn */.jA)(p,focus_management/* Focus.Next */.TO.Next|focus_management/* Focus.WrapAround */.TO.WrapAround)===focus_management/* FocusResult.Success */.fE.Success){let u=a.find(G=>G.element.current===(i==null?void 0:i.activeElement));u&&s(u.propsRef.current.value)}break;case keyboard/* Keys.Space */.R.Space:{e.preventDefault(),e.stopPropagation();let l=a.find(u=>u.element.current===(i==null?void 0:i.activeElement));l&&s(l.propsRef.current.value)}break}},[y,a,s]),F=(0,react.useCallback)(e=>(A({type:0,...e}),()=>A({type:1,id:e.id})),[A]),S=(0,react.useMemo)(()=>({registerOption:F,firstOption:E,containsCheckedOption:D,change:s,disabled:R,value:r}),[F,E,D,s,R,r]),_={ref:b,id:g,role:"radiogroup","aria-labelledby":T,"aria-describedby":k,onKeyDown:h};return react.createElement(c,{name:"RadioGroup.Description"},react.createElement(C,{name:"RadioGroup.Label"},react.createElement(U.Provider,{value:S},m!=null&&r!=null&&e({[m]:r}).map(([e,d])=>react.createElement(internal_hidden/* Hidden */._,{features:internal_hidden/* Features.Hidden */.A.Hidden,...(0,render/* compact */.oA)({key:e,as:"input",type:"radio",checked:d!=null,hidden:!0,readOnly:!0,name:e,value:d})})),(0,render/* render */.sY)({ourProps:_,theirProps:I,defaultTag:fe,name:"RadioGroup"}))))});var me=(t=>(t[t.Empty=1]="Empty",t[t.Active=2]="Active",t))(me||{});let Re="div",Te=(0,render/* forwardRefWithAs */.yV)(function(o,t){let r=(0,react.useRef)(null),m=(0,use_sync_refs/* useSyncRefs */.T)(r,t),f=`headlessui-radiogroup-option-${(0,use_id/* useId */.M)()}`,[R,I]=B(),[a,A]=(0,description/* useDescriptions */.f)(),{addFlag:T,removeFlag:C,hasFlag:k}=use_flags_b(1),{value:c,disabled:g=!1,...y}=o,b=(0,react.useRef)({value:c,disabled:g});(0,use_iso_morphic_effect/* useIsoMorphicEffect */.e)(()=>{b.current.value=c},[c,b]),(0,use_iso_morphic_effect/* useIsoMorphicEffect */.e)(()=>{b.current.disabled=g},[g,b]);let{registerOption:E,disabled:D,change:s,firstOption:h,containsCheckedOption:F,value:S}=z("RadioGroup.Option");(0,use_iso_morphic_effect/* useIsoMorphicEffect */.e)(()=>E({id:f,element:r,propsRef:b}),[f,E,r,o]);let _=(0,react.useCallback)(()=>{var H;!s(c)||(T(2),(H=r.current)==null||H.focus())},[T,s,c]),e=(0,react.useCallback)(()=>T(2),[T]),d=(0,react.useCallback)(()=>C(2),[C]),i=(h==null?void 0:h.id)===f,p=D||g,l=S===c,u={ref:m,id:f,role:"radio","aria-checked":l?"true":"false","aria-labelledby":R,"aria-describedby":a,"aria-disabled":p?!0:void 0,tabIndex:(()=>p?-1:l||!F&&i?0:-1)(),onClick:p?void 0:_,onFocus:p?void 0:e,onBlur:p?void 0:d},G=(0,react.useMemo)(()=>({checked:l,disabled:p,active:k(2)}),[l,p,k]);return react.createElement(A,{name:"RadioGroup.Description"},react.createElement(I,{name:"RadioGroup.Label"},(0,render/* render */.sY)({ourProps:u,theirProps:y,slot:G,defaultTag:Re,name:"RadioGroup.Option"})))}),We=Object.assign(be,{Option:Te,Label:M,Description:description/* Description */.d});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(85893);
;// CONCATENATED MODULE: ./src/lib/common/components/Form/MultiStateSelector/index.js
var _excluded = ["btnClassName"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






var GenericMultiStateSelector = /*#__PURE__*/react.forwardRef(function (_ref, ref) {
  var label = _ref.label,
      className = _ref.className,
      optionClassName = _ref.optionClassName,
      _ref$options = _ref.options,
      options = _ref$options === void 0 ? [] : _ref$options,
      _ref$inline = _ref.inline,
      inline = _ref$inline === void 0 ? false : _ref$inline,
      value = _ref.value,
      onChange = _ref.onChange;
  return /*#__PURE__*/(0,jsx_runtime.jsxs)(We, {
    value: value,
    onChange: onChange,
    className: (0,utils.cn)('whitespace-nowrap', className),
    ref: ref,
    children: [label && /*#__PURE__*/(0,jsx_runtime.jsx)(We.Label, {
      children: label
    }), options.map(function (_ref2, idx) {
      var value = _ref2.value,
          label = _ref2.label,
          className = _ref2.className,
          checkedClassName = _ref2.checkedClassName,
          activeClassName = _ref2.activeClassName;
      return /*#__PURE__*/(0,jsx_runtime.jsx)(We.Option, {
        value: value,
        className: (0,utils.cn)(inline ? 'inline' : 'block', 'cursor-pointer'),
        children: function children(_ref3) {
          var checked = _ref3.checked,
              active = _ref3.active;
          return /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
            className: (0,utils.cn)(checked && (checkedClassName || 'bg-gray-700'), active && (activeClassName || 'bg-gray-800'), optionClassName, className),
            children: label
          });
        }
      }, idx);
    })]
  });
});
GenericMultiStateSelector.displayName = 'GenericMultiStateSelector';
var ButtonGroupSelector = /*#__PURE__*/react.forwardRef(function (_ref4, ref) {
  var btnClassName = _ref4.btnClassName,
      props = _objectWithoutProperties(_ref4, _excluded);

  return /*#__PURE__*/(0,jsx_runtime.jsx)(GenericMultiStateSelector, _objectSpread(_objectSpread({
    ref: ref
  }, props), {}, {
    inline: true,
    optionClassName: btnClassName,
    className: (0,utils.cn)(props.className, 'mx-auto py-2 select-none')
  }));
});
ButtonGroupSelector.displayName = 'ButtonGroupSelector';
/* harmony default export */ const MultiStateSelector = ((/* unused pure expression or super */ null && (GenericMultiStateSelector)));
;// CONCATENATED MODULE: ./src/lib/common/components/Form/VoteField.js
var VoteField_excluded = ["btnClassName"],
    _excluded2 = ["name", "validationRules"],
    _excluded3 = ["ref"];

function VoteField_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function VoteField_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? VoteField_ownKeys(Object(source), !0).forEach(function (key) { VoteField_defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : VoteField_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function VoteField_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function VoteField_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = VoteField_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function VoteField_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




 // Note: forwardRef is not functional (partially added to support useController, but seems just for focusing on error state so
// "fixed" for now by just not passing ref down)



var VoteInput = /*#__PURE__*/react.forwardRef(function (_ref, ref) {
  var _ref$btnClassName = _ref.btnClassName,
      btnClassName = _ref$btnClassName === void 0 ? 'p-2' : _ref$btnClassName,
      props = VoteField_objectWithoutProperties(_ref, VoteField_excluded);

  var btnDefault = 'bg-gray-500 hover:bg-gray-600 transition ease-in-out duration-600';
  return /*#__PURE__*/(0,jsx_runtime.jsx)(ButtonGroupSelector, VoteField_objectSpread({
    ref: ref,
    btnClassName: (0,utils.cn)(btnDefault, btnClassName),
    options: [{
      label: /*#__PURE__*/(0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: "\uD83D\uDC4D"
      }),
      value: 1,
      className: 'rounded-l',
      activeClassName: 'bg-green-500',
      checkedClassName: 'bg-green-600'
    }, {
      label: /*#__PURE__*/(0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: "\uD83E\uDD37\u200D\u2642\uFE0F"
      }),
      value: 0
    }, {
      label: /*#__PURE__*/(0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: "\uD83D\uDC4E"
      }),
      value: -1,
      className: 'rounded-r',
      activeClassName: 'bg-red-700',
      checkedClassName: 'bg-red-800'
    }]
  }, props));
}); // Subfield -- linked to the form provider, but call like <WrappedInput type="vote" ... /> to wrap in error handling/hintText

var VoteField = function VoteField(_ref2) {
  var name = _ref2.name,
      validationRules = _ref2.validationRules,
      props = VoteField_objectWithoutProperties(_ref2, _excluded2);

  var _useController = (0,index_esm/* useController */.bc)({
    name: name,
    rules: validationRules
  }),
      _useController$field = _useController.field,
      ref = _useController$field.ref,
      inputProps = VoteField_objectWithoutProperties(_useController$field, _excluded3);

  return /*#__PURE__*/(0,jsx_runtime.jsx)(VoteInput, VoteField_objectSpread(VoteField_objectSpread(VoteField_objectSpread({}, props), inputProps), {}, {
    name: name
  }));
};

/* harmony default export */ const Form_VoteField = (VoteField);
// EXTERNAL MODULE: ./src/lib/common/components/ConditionalWrap.js
var ConditionalWrap = __webpack_require__(90792);
// EXTERNAL MODULE: ./src/lib/common/components/Form/SelectField/index.js
var SelectField = __webpack_require__(12969);
;// CONCATENATED MODULE: ./node_modules/react-textarea-autosize/node_modules/@babel/runtime/helpers/esm/extends.js
function _extends() {
  _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}
;// CONCATENATED MODULE: ./node_modules/react-textarea-autosize/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js
function objectWithoutPropertiesLoose_objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}
;// CONCATENATED MODULE: ./node_modules/use-isomorphic-layout-effect/dist/use-isomorphic-layout-effect.browser.esm.js


var index =  react.useLayoutEffect ;

/* harmony default export */ const use_isomorphic_layout_effect_browser_esm = (index);

;// CONCATENATED MODULE: ./node_modules/use-latest/dist/use-latest.esm.js



var useLatest = function useLatest(value) {
  var ref = (0,react.useRef)(value);
  use_isomorphic_layout_effect_browser_esm(function () {
    ref.current = value;
  });
  return ref;
};

/* harmony default export */ const use_latest_esm = (useLatest);

;// CONCATENATED MODULE: ./node_modules/use-composed-ref/dist/use-composed-ref.esm.js


var updateRef = function updateRef(ref, value) {
  if (typeof ref === 'function') {
    ref(value);
    return;
  }
  ref.current = value;
};

var useComposedRef = function useComposedRef(libRef, userRef) {
  var prevUserRef = (0,react.useRef)();
  return (0,react.useCallback)(function (instance) {
    libRef.current = instance;

    if (prevUserRef.current) {
      updateRef(prevUserRef.current, null);
    }

    prevUserRef.current = userRef;

    if (!userRef) {
      return;
    }

    updateRef(userRef, instance);
  }, [userRef]);
};

/* harmony default export */ const use_composed_ref_esm = (useComposedRef);

;// CONCATENATED MODULE: ./node_modules/react-textarea-autosize/dist/react-textarea-autosize.browser.esm.js






var HIDDEN_TEXTAREA_STYLE = {
  'min-height': '0',
  'max-height': 'none',
  height: '0',
  visibility: 'hidden',
  overflow: 'hidden',
  position: 'absolute',
  'z-index': '-1000',
  top: '0',
  right: '0'
};

var forceHiddenStyles = function forceHiddenStyles(node) {
  Object.keys(HIDDEN_TEXTAREA_STYLE).forEach(function (key) {
    node.style.setProperty(key, HIDDEN_TEXTAREA_STYLE[key], 'important');
  });
};

//   export type CalculatedNodeHeights = [height: number, rowHeight: number];
// https://github.com/microsoft/TypeScript/issues/28259

var hiddenTextarea = null;

var getHeight = function getHeight(node, sizingData) {
  var height = node.scrollHeight;

  if (sizingData.sizingStyle.boxSizing === 'border-box') {
    // border-box: add border, since height = content + padding + border
    return height + sizingData.borderSize;
  } // remove padding, since height = content


  return height - sizingData.paddingSize;
};

function calculateNodeHeight(sizingData, value, minRows, maxRows) {
  if (minRows === void 0) {
    minRows = 1;
  }

  if (maxRows === void 0) {
    maxRows = Infinity;
  }

  if (!hiddenTextarea) {
    hiddenTextarea = document.createElement('textarea');
    hiddenTextarea.setAttribute('tabindex', '-1');
    hiddenTextarea.setAttribute('aria-hidden', 'true');
    forceHiddenStyles(hiddenTextarea);
  }

  if (hiddenTextarea.parentNode === null) {
    document.body.appendChild(hiddenTextarea);
  }

  var paddingSize = sizingData.paddingSize,
      borderSize = sizingData.borderSize,
      sizingStyle = sizingData.sizingStyle;
  var boxSizing = sizingStyle.boxSizing;
  Object.keys(sizingStyle).forEach(function (_key) {
    var key = _key;
    hiddenTextarea.style[key] = sizingStyle[key];
  });
  forceHiddenStyles(hiddenTextarea);
  hiddenTextarea.value = value;
  var height = getHeight(hiddenTextarea, sizingData); // measure height of a textarea with a single row

  hiddenTextarea.value = 'x';
  var rowHeight = hiddenTextarea.scrollHeight - paddingSize;
  var minHeight = rowHeight * minRows;

  if (boxSizing === 'border-box') {
    minHeight = minHeight + paddingSize + borderSize;
  }

  height = Math.max(minHeight, height);
  var maxHeight = rowHeight * maxRows;

  if (boxSizing === 'border-box') {
    maxHeight = maxHeight + paddingSize + borderSize;
  }

  height = Math.min(maxHeight, height);
  return [height, rowHeight];
}

var noop = function noop() {};
var pick = function pick(props, obj) {
  return props.reduce(function (acc, prop) {
    acc[prop] = obj[prop];
    return acc;
  }, {});
};

var SIZING_STYLE = ['borderBottomWidth', 'borderLeftWidth', 'borderRightWidth', 'borderTopWidth', 'boxSizing', 'fontFamily', 'fontSize', 'fontStyle', 'fontWeight', 'letterSpacing', 'lineHeight', 'paddingBottom', 'paddingLeft', 'paddingRight', 'paddingTop', // non-standard
'tabSize', 'textIndent', // non-standard
'textRendering', 'textTransform', 'width', 'wordBreak'];
var isIE = !!document.documentElement.currentStyle ;

var getSizingData = function getSizingData(node) {
  var style = window.getComputedStyle(node);

  if (style === null) {
    return null;
  }

  var sizingStyle = pick(SIZING_STYLE, style);
  var boxSizing = sizingStyle.boxSizing; // probably node is detached from DOM, can't read computed dimensions

  if (boxSizing === '') {
    return null;
  } // IE (Edge has already correct behaviour) returns content width as computed width
  // so we need to add manually padding and border widths


  if (isIE && boxSizing === 'border-box') {
    sizingStyle.width = parseFloat(sizingStyle.width) + parseFloat(sizingStyle.borderRightWidth) + parseFloat(sizingStyle.borderLeftWidth) + parseFloat(sizingStyle.paddingRight) + parseFloat(sizingStyle.paddingLeft) + 'px';
  }

  var paddingSize = parseFloat(sizingStyle.paddingBottom) + parseFloat(sizingStyle.paddingTop);
  var borderSize = parseFloat(sizingStyle.borderBottomWidth) + parseFloat(sizingStyle.borderTopWidth);
  return {
    sizingStyle: sizingStyle,
    paddingSize: paddingSize,
    borderSize: borderSize
  };
};

var useWindowResizeListener = function useWindowResizeListener(listener) {
  var latestListener = use_latest_esm(listener);
  (0,react.useLayoutEffect)(function () {
    var handler = function handler(event) {
      latestListener.current(event);
    };

    window.addEventListener('resize', handler);
    return function () {
      window.removeEventListener('resize', handler);
    };
  }, []);
};

var TextareaAutosize = function TextareaAutosize(_ref, userRef) {
  var cacheMeasurements = _ref.cacheMeasurements,
      maxRows = _ref.maxRows,
      minRows = _ref.minRows,
      _ref$onChange = _ref.onChange,
      onChange = _ref$onChange === void 0 ? noop : _ref$onChange,
      _ref$onHeightChange = _ref.onHeightChange,
      onHeightChange = _ref$onHeightChange === void 0 ? noop : _ref$onHeightChange,
      props = objectWithoutPropertiesLoose_objectWithoutPropertiesLoose(_ref, ["cacheMeasurements", "maxRows", "minRows", "onChange", "onHeightChange"]);

  if (false) {}

  var isControlled = props.value !== undefined;
  var libRef = (0,react.useRef)(null);
  var ref = use_composed_ref_esm(libRef, userRef);
  var heightRef = (0,react.useRef)(0);
  var measurementsCacheRef = (0,react.useRef)();

  var resizeTextarea = function resizeTextarea() {
    var node = libRef.current;
    var nodeSizingData = cacheMeasurements && measurementsCacheRef.current ? measurementsCacheRef.current : getSizingData(node);

    if (!nodeSizingData) {
      return;
    }

    measurementsCacheRef.current = nodeSizingData;

    var _calculateNodeHeight = calculateNodeHeight(nodeSizingData, node.value || node.placeholder || 'x', minRows, maxRows),
        height = _calculateNodeHeight[0],
        rowHeight = _calculateNodeHeight[1];

    if (heightRef.current !== height) {
      heightRef.current = height;
      node.style.setProperty('height', height + "px", 'important');
      onHeightChange(height, {
        rowHeight: rowHeight
      });
    }
  };

  var handleChange = function handleChange(event) {
    if (!isControlled) {
      resizeTextarea();
    }

    onChange(event);
  };

  {
    (0,react.useLayoutEffect)(resizeTextarea);
    useWindowResizeListener(resizeTextarea);
  }

  return /*#__PURE__*/(0,react.createElement)("textarea", _extends({}, props, {
    onChange: handleChange,
    ref: ref
  }));
};

var react_textarea_autosize_browser_esm_index = /* #__PURE__ */(0,react.forwardRef)(TextareaAutosize);

/* harmony default export */ const react_textarea_autosize_browser_esm = (react_textarea_autosize_browser_esm_index);

;// CONCATENATED MODULE: ./src/lib/common/components/Form/InputField.js
var InputField_excluded = ["name", "type", "validationRules", "defaultValue"],
    InputField_excluded2 = ["ref"];

function InputField_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function InputField_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? InputField_ownKeys(Object(source), !0).forEach(function (key) { InputField_defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : InputField_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function InputField_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function InputField_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = InputField_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function InputField_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var InputField = function InputField(_ref) {
  var name = _ref.name,
      type = _ref.type,
      validationRules = _ref.validationRules,
      _ref$defaultValue = _ref.defaultValue,
      defaultValue = _ref$defaultValue === void 0 ? '' : _ref$defaultValue,
      props = InputField_objectWithoutProperties(_ref, InputField_excluded);

  var _useController = (0,index_esm/* useController */.bc)({
    name: name,
    rules: validationRules,
    defaultValue: defaultValue
  }),
      _useController$field = _useController.field,
      ref = _useController$field.ref,
      inputProps = InputField_objectWithoutProperties(_useController$field, InputField_excluded2);

  var Tag = type === 'textarea' ? react_textarea_autosize_browser_esm : 'input';
  return /*#__PURE__*/(0,jsx_runtime.jsx)(Tag, InputField_objectSpread(InputField_objectSpread(InputField_objectSpread({
    name: name
  }, props), inputProps), {}, {
    type: type,
    ref: ref
  }));
};

/* harmony default export */ const Form_InputField = (InputField);
// EXTERNAL MODULE: ./src/lib/common/components/Form/HashtagSelectField.js
var HashtagSelectField = __webpack_require__(67368);
;// CONCATENATED MODULE: ./src/lib/common/components/Form/WrappedInput.js
var WrappedInput_excluded = ["name", "helpText", "type", "wrapperClassName", "inputClassName", "Prefix", "Suffix"];

function WrappedInput_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function WrappedInput_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? WrappedInput_ownKeys(Object(source), !0).forEach(function (key) { WrappedInput_defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : WrappedInput_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function WrappedInput_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function WrappedInput_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = WrappedInput_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function WrappedInput_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }











var BaseInputClassName = 'w-full p-1 px-2 border-bottom text-lg rounded';
var InputClassName = "border-gray-300 text-gray-600 bg-gray-100 focus:bg-white";
var ErrorInputClassName = 'border-red-300 text-gray-600 bg-red-100 focus:bg-red-50';

var fieldFromType = function fieldFromType(type) {
  /* TODO: ui w/ focus/ring */
  if (type === 'vote') return Form_VoteField;
  if (type === 'select') return SelectField/* default */.Z;
  if (type === 'hashtag') return HashtagSelectField/* default */.Z;
  return Form_InputField;
};

var customInputStyles = function customInputStyles(type) {
  return ['vote', 'select', 'hashtag'].indexOf(type) !== -1;
}; // Wrapper around any other form input type to handle displaying helpText + errors (specific to react-hook-form context)


var WrappedInput = /*#__PURE__*/(0,react.forwardRef)(function (_ref, ref) {
  var name = _ref.name,
      helpText = _ref.helpText,
      _ref$type = _ref.type,
      type = _ref$type === void 0 ? 'text' : _ref$type,
      _ref$wrapperClassName = _ref.wrapperClassName,
      wrapperClassName = _ref$wrapperClassName === void 0 ? 'mb-2' : _ref$wrapperClassName,
      inputClassName = _ref.inputClassName,
      Prefix = _ref.Prefix,
      Suffix = _ref.Suffix,
      props = WrappedInput_objectWithoutProperties(_ref, WrappedInput_excluded);

  var Field = (0,react.useMemo)(function () {
    return fieldFromType(type);
  }, [type]);

  var _useFormState = (0,index_esm/* useFormState */.cl)({
    name: name
  }),
      errors = _useFormState.errors;

  var error = errors[name];
  var inputProps = (0,react.useMemo)(function () {
    return Object.assign({
      type: type,
      error: error,
      className: (0,utils.cn)(inputClassName, inputClassName || customInputStyles(type) || BaseInputClassName, inputClassName || customInputStyles(type) || (error ? ErrorInputClassName : InputClassName))
    }, props, {
      'aria-invalid': error ? 'true' : 'false'
    });
  }, [props, Field, type, inputClassName, error]);
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: (0,utils.cn)('flex flex-col items-start w-full', wrapperClassName),
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)(ConditionalWrap/* default */.Z, {
      condition: !!Prefix || !!Suffix,
      wrap: function wrap(kid) {
        return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
          className: "flex items-center w-full",
          children: [Prefix && /*#__PURE__*/(0,jsx_runtime.jsx)(Prefix, {}), kid, Suffix && /*#__PURE__*/(0,jsx_runtime.jsx)(Suffix, {})]
        });
      },
      children: /*#__PURE__*/(0,jsx_runtime.jsx)(Field, WrappedInput_objectSpread(WrappedInput_objectSpread({}, inputProps), {}, {
        name: name,
        ref: ref
      }))
    }), error && /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      className: "text-sm text-red-500",
      role: "alert",
      children: error.message
    }), helpText && !error && /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      className: "text-sm text-gray-500",
      children: helpText
    })]
  });
});
/* harmony default export */ const Form_WrappedInput = (WrappedInput);
;// CONCATENATED MODULE: ./src/lib/common/components/Spinner.js




var Spinner = function Spinner(_ref) {
  var className = _ref.className,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 5 : _ref$size;
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("svg", {
    className: (0,utils.cn)("w-".concat(size, " h-").concat(size), 'animate-spin inline-block', className),
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)("circle", {
      className: "opacity-25",
      cx: "12",
      cy: "12",
      r: "10",
      stroke: "currentColor",
      strokeWidth: "4"
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("path", {
      className: "opacity-75",
      fill: "currentColor",
      d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
    })]
  });
};

/* harmony default export */ const components_Spinner = (Spinner);
// EXTERNAL MODULE: ./src/lib/common/components/Button/index.js
var Button = __webpack_require__(95673);
;// CONCATENATED MODULE: ./src/lib/common/components/Form/SubmitButton.js





var SubmitButton = function SubmitButton(_ref) {
  var title = _ref.title,
      children = _ref.children,
      disabled = _ref.disabled,
      isDirty = _ref.isDirty,
      isSubmitting = _ref.isSubmitting,
      className = _ref.className,
      size = _ref.size;
  return /*#__PURE__*/(0,jsx_runtime.jsxs)(Button/* default */.Z, {
    type: "submit",
    disabled: disabled || isSubmitting || typeof isDirty !== 'undefined' && !isDirty,
    className: className,
    variant: "primary",
    size: size,
    children: [isSubmitting && /*#__PURE__*/(0,jsx_runtime.jsx)(components_Spinner, {
      className: "text-white mr-2 -ml-1"
    }), title, children]
  });
};

/* harmony default export */ const Form_SubmitButton = (SubmitButton);
;// CONCATENATED MODULE: ./src/lib/common/components/Form/index.js






 // Fields

 // Inputs

 // Misc components,


// EXTERNAL MODULE: ./src/lib/common/recoil/index.js
var recoil = __webpack_require__(34858);
// EXTERNAL MODULE: ./src/lib/common/components/icons/index.js + 12 modules
var icons = __webpack_require__(61383);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/WriteMode/WriteReview/PageReviewAddressSubtitle.js





var PageReviewAddressSubtitle = function PageReviewAddressSubtitle() {
  var _useRecoilValue = (0,recoil/* useRecoilValue */.sJ)(recoil/* currentAtom */.C),
      domainKey = _useRecoilValue.domainKey,
      pageKey = _useRecoilValue.pageKey,
      pageAddressParts = _useRecoilValue.pageAddressParts;

  var protocol = pageAddressParts.protocol,
      path = pageAddressParts.path,
      subdomain = pageAddressParts.subdomain,
      params = pageAddressParts.params;
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: "text-sm leading-5 text-gray-700 break-all overflow-y-auto",
    style: {
      maxHeight: 70
    },
    children: [ false && /*#__PURE__*/0, subdomain && subdomain != 'www' ? "".concat(subdomain, ".") : null, /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
      className: "",
      children: domainKey
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
      className: "",
      children: path
    }), (params === null || params === void 0 ? void 0 : params.length) > 0 ? /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
      className: "text-red-500 ml-1",
      title: "Params are *not* included when determining the current page",
      children: "[\u2026]"
    }) : null]
  });
};

/* harmony default export */ const WriteReview_PageReviewAddressSubtitle = (PageReviewAddressSubtitle);
// EXTERNAL MODULE: ./node_modules/lodash/lodash.js
var lodash = __webpack_require__(96486);
// EXTERNAL MODULE: ./src/lib/messaging/fromFrontend/index.js
var fromFrontend = __webpack_require__(56421);
;// CONCATENATED MODULE: ./src/lib/universal-interface/siteApi.js
 // For use in frontend; backend can "import * from common/siteApi" directly

/* harmony default export */ const siteApi = (fromFrontend/* siteAPI */.Cx); // TODO: what if we just loaded directly from popup?
// import * as siteAPI from 'common/siteApi'
// export default siteAPI
// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/react-hot-toast.esm.js + 1 modules
var react_hot_toast_esm = __webpack_require__(88279);
// EXTERNAL MODULE: ./src/lib/universal-interface/hooks.js
var hooks = __webpack_require__(50731);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/WriteMode/WriteReview/useWriteReviewForm.js
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function useWriteReviewForm_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function useWriteReviewForm_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? useWriteReviewForm_ownKeys(Object(source), !0).forEach(function (key) { useWriteReviewForm_defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : useWriteReviewForm_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function useWriteReviewForm_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }












var useSetCurrentDraftReview = function useSetCurrentDraftReview() {
  var writingContext = (0,recoil/* useRecoilValue */.sJ)(recoil/* writingContextAtom */.fR);
  var setDraftDomainReview = (0,recoil/* useSetRecoilState */.Zl)(recoil/* draftDomainReviewAtom */.OF);
  var setDraftPageReview = (0,recoil/* useSetRecoilState */.Zl)(recoil/* draftPageReviewAtom */.qX);
  var setDraftReview = (0,react.useCallback)(function (review) {
    var setterFn = writingContext === 'page' ? setDraftPageReview : setDraftDomainReview;
    setterFn(useWriteReviewForm_objectSpread({
      writingContext: writingContext
    }, review));
  }, [writingContext]);
  return setDraftReview;
};

var useFormatReviewForSubmission = function useFormatReviewForSubmission() {
  var _useRecoilValue = (0,recoil/* useRecoilValue */.sJ)(recoil/* currentAtom */.C),
      pageAddressParts = _useRecoilValue.pageAddressParts;

  var protocol = pageAddressParts.protocol,
      path = pageAddressParts.path,
      subdomain = pageAddressParts.subdomain,
      params = pageAddressParts.params;
  var formatReview = (0,react.useCallback)(function (data) {
    // Format data for server
    if (protocol === 'http:') data.viaHttp = true; // TODO: maybe need to track if viewed as www, so we can recreate the correct domain URL?

    if (subdomain === 'www') data.withWww = true;
    return data;
  }, [protocol, subdomain]);
  return formatReview;
};

var buildDraftReview = function buildDraftReview(initialValues, _ref) {
  var domainKey = _ref.domainKey,
      pageKey = _ref.pageKey,
      isDirty = _ref.isDirty;
  var review = (0,utils/* normalizeReview */.tK)(initialValues);
  review.meta.domainKey = domainKey;
  if (pageKey) review.meta.pageKey = pageKey; // NOTE: standardizing around the current structure, but we should probably shift to just trusting the domainKey and pageKey in meta

  review.domainKey = domainKey;
  if (isDirty) review.isDirty = isDirty;
  if (pageKey) review.pageKey = pageKey;
  return review;
};

var useSyncFormChangesToDraftReview = function useSyncFormChangesToDraftReview(_ref2) {
  var initialValues = _ref2.initialValues,
      watch = _ref2.watch;
  var draftReview = (0,recoil/* useRecoilValue */.sJ)(recoil/* draftReviewSelector */.ku);
  var setDraftReview = useSetCurrentDraftReview();

  var _useRecoilValue2 = (0,recoil/* useRecoilValue */.sJ)(recoil/* currentAtom */.C),
      domainKey = _useRecoilValue2.domainKey,
      pageKey = _useRecoilValue2.pageKey;

  (0,react.useEffect)(function () {
    // On every form change, update draftReview -- allows persisting draft across accidental extension closings.
    var subscription = watch(function (rawFormValue, _ref3) {
      var name = _ref3.name,
          type = _ref3.type;
      console.log('[useSyncFormChangesToDraftReview]', {
        rawFormValue: rawFormValue,
        name: name,
        type: type
      }); // TODO?? rawFormValue seems to include a `0` key...

      var vote = rawFormValue.vote,
          hashtags = rawFormValue.hashtags,
          comment = rawFormValue.comment;
      var draft = {
        vote: vote,
        hashtags: hashtags,
        comment: comment
      };
      var isDirty = !(0,lodash.isEqual)(draft, initialValues);
      setDraftReview(buildDraftReview(draft, {
        domainKey: domainKey,
        pageKey: pageKey,
        isDirty: isDirty
      }));
    });
    return function () {
      return subscription.unsubscribe();
    };
  }, [setDraftReview, initialValues, watch, domainKey, pageKey]);
};

var useFormSubmissionHandler = function useFormSubmissionHandler(_ref4) {
  var setReviewToShare = _ref4.setReviewToShare,
      resetForm = _ref4.resetForm;
  var writingContext = (0,recoil/* useRecoilValue */.sJ)(recoil/* writingContextAtom */.fR);
  var formatReviewForSubmission = useFormatReviewForSubmission();
  var refetchCurrentDomainPacket = (0,hooks/* useRefetchCurrentDomainPacket */.mg)();
  var setDraftReview = useSetCurrentDraftReview();

  var _useRecoilValue3 = (0,recoil/* useRecoilValue */.sJ)(recoil/* currentAtom */.C),
      domainKey = _useRecoilValue3.domainKey,
      pageKey = _useRecoilValue3.pageKey;

  var handler = (0,react.useCallback)( /*#__PURE__*/function () {
    var _ref5 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee(raw) {
      var data, action;
      return _regeneratorRuntime().wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              data = formatReviewForSubmission(raw); // Optimistic about success

              setReviewToShare(useWriteReviewForm_objectSpread(useWriteReviewForm_objectSpread({}, data), {}, {
                loading: true
              }));
              action = writingContext === 'page' ? 'doReviewJustThePage' : 'doReviewJustTheDomain';
              console.log('SUBMITTING REVIEW:', action, data);
              react_hot_toast_esm/* default.promise */.ZP.promise(siteApi[action]({
                domainKey: domainKey,
                pageKey: pageKey,
                data: data
              }), {
                loading: 'Saving...',
                success: function success(savedReview) {
                  // FYI meta.createdAt might be set to {} here, even if set correctly in firebase
                  console.log('Saved review:', savedReview);
                  setReviewToShare(useWriteReviewForm_objectSpread(useWriteReviewForm_objectSpread({}, savedReview), {}, {
                    loading: false
                  })); // Reset the draft review to have isDirty=false

                  setDraftReview(buildDraftReview({}, {
                    domainKey: domainKey,
                    pageKey: pageKey
                  }));
                  resetForm(savedReview);
                  refetchCurrentDomainPacket();
                  return 'Saved!';
                },
                error: function error(_error) {
                  var _error$message;

                  console.log('Error setting site review:', _error);
                  setReviewToShare(null);
                  resetForm(data);
                  var msg = _error !== null && _error !== void 0 && (_error$message = _error.message) !== null && _error$message !== void 0 && _error$message.length ? _error.message : _error !== null && _error !== void 0 && _error.length ? _error : '';
                  if (msg === 'Forbidden') return "Unable to save review... there's a related known bug though, so please try hitting Save again.";
                  return "Unable to save your review changes! ".concat(msg, "\n           ");
                }
              });

            case 5:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function (_x) {
      return _ref5.apply(this, arguments);
    };
  }(), [formatReviewForSubmission, domainKey, pageKey, setReviewToShare, writingContext, resetForm, setDraftReview, refetchCurrentDomainPacket]);
  return handler;
};

var useResetFormOnReviewChange = function useResetFormOnReviewChange(_ref6) {
  var resetForm = _ref6.resetForm,
      initialValues = _ref6.initialValues;
  var draftReview = (0,recoil/* useRecoilValue */.sJ)(recoil/* draftReviewSelector */.ku) || {}; // Writing context changes - reset form to draft state, if any, else to existing review
  // Note: draftReview intentionally not a dependency, recoil data flow makes it work

  (0,react.useEffect)(function () {
    console.log('Resetting form because draftReview has changed (b/c review changed)', {
      draftReview: draftReview,
      initialValues: initialValues
    });
    resetForm(draftReview.isDirty ? draftReview.draft : initialValues || {});
  }, [resetForm, initialValues]);
};

var ContextualReviewFormLabel = function ContextualReviewFormLabel(_props) {
  var _useRecoilValue4 = (0,recoil/* useRecoilValue */.sJ)(recoil/* currentAtom */.C),
      domainKey = _useRecoilValue4.domainKey;

  var writingContext = (0,recoil/* useRecoilValue */.sJ)(recoil/* writingContextAtom */.fR);
  return writingContext === 'page' ? /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
    className: "",
    children: /*#__PURE__*/(0,jsx_runtime.jsx)(WriteReview_PageReviewAddressSubtitle, {})
  }) : /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
    className: "text-2xl font-medium",
    children: domainKey
  });
};

var useWriteReviewForm = function useWriteReviewForm() {
  // review == either pageReview or the domainReview part of the hydrated domainPacket, depending on writingContext
  var review = (0,recoil/* useRecoilValue */.sJ)(recoil/* currentReviewSelector */.cN);
  var draftReview = (0,recoil/* useRecoilValue */.sJ)(recoil/* draftReviewSelector */.ku); // TODO: if draftReview.domainKey !== CURRENT domainKey, then we need to reset the form

  console.log('useWriteReviewForm BEGIN', {
    review: review,
    draftReview: draftReview
  });
  var initialValues = (0,react.useMemo)(function () {
    return (0,utils/* normalizeReviewForForm */.pX)(review);
  }, [review]);
  var formMethods = (0,index_esm/* useForm */.cI)();
  var watch = formMethods.watch,
      reset = formMethods.reset,
      handleSubmit = formMethods.handleSubmit,
      formState = formMethods.formState;
  var formIsDirty = formState.isDirty,
      isSubmitting = formState.isSubmitting;
  var resetForm = (0,react.useCallback)(function (data) {
    return reset((0,utils/* normalizeReviewForForm */.pX)(data));
  }, [reset]);
  useResetFormOnReviewChange({
    resetForm: resetForm,
    initialValues: initialValues
  });
  useSyncFormChangesToDraftReview({
    watch: watch,
    initialValues: initialValues
  });
  var setReviewToShare = (0,recoil/* useSetRecoilState */.Zl)(recoil/* reviewToShareAtom */.WX);
  var switchToSharing = (0,react.useCallback)(function () {
    setReviewToShare(review);
  }, [review, setReviewToShare]);
  var doSubmit = useFormSubmissionHandler({
    setReviewToShare: setReviewToShare,
    resetForm: resetForm
  });
  console.log('Debugging in useWriteReviewForm:', {
    review: review,
    draftReview: draftReview,
    initialValues: initialValues
  });
  return {
    formMethods: formMethods,
    hasReviewBeenSaved: !!(review !== null && review !== void 0 && review.meta),
    isSubmitting: isSubmitting,
    switchToSharing: switchToSharing,
    isDirty: formIsDirty || draftReview.isDirty || false,
    // Note: relying on draft, not formState directly, so we can properly handle "form loaded dirty from draft and *has* changed but it changed back to initial value so isDirty should be false"
    onSubmit: handleSubmit(doSubmit, console.warn) // TODO: does this need to be wrapped to make it constant?

  };
};

/* harmony default export */ const WriteReview_useWriteReviewForm = (useWriteReviewForm);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/WriteMode/WriteReview/index.js
function WriteReview_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function WriteReview_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? WriteReview_ownKeys(Object(source), !0).forEach(function (key) { WriteReview_defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : WriteReview_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function WriteReview_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









var WriteReview = function WriteReview(_props) {
  var hashtagOptions = (0,recoil/* useRecoilValue */.sJ)(recoil/* currentHashtagOptionsSelector */.iV);

  var _useWriteReviewForm = WriteReview_useWriteReviewForm(),
      formMethods = _useWriteReviewForm.formMethods,
      isSubmitting = _useWriteReviewForm.isSubmitting,
      isDirty = _useWriteReviewForm.isDirty,
      switchToSharing = _useWriteReviewForm.switchToSharing,
      onSubmit = _useWriteReviewForm.onSubmit,
      hasReviewBeenSaved = _useWriteReviewForm.hasReviewBeenSaved;

  return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
    className: "p-3 bg-white border-t",
    children: /*#__PURE__*/(0,jsx_runtime.jsx)(index_esm/* FormProvider */.RV, WriteReview_objectSpread(WriteReview_objectSpread({}, formMethods), {}, {
      children: /*#__PURE__*/(0,jsx_runtime.jsxs)("form", {
        onSubmit: onSubmit,
        children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
          className: "mb-2 text-center",
          children: [/*#__PURE__*/(0,jsx_runtime.jsx)("div", {
            className: "px-2 font-sans text-xl font-light",
            children: /*#__PURE__*/(0,jsx_runtime.jsx)(ContextualReviewFormLabel, {})
          }), /*#__PURE__*/(0,jsx_runtime.jsx)(Form_WrappedInput, {
            type: "vote",
            name: "vote",
            wrapperClassName: "my-5",
            btnClassName: "text-2xl p-3"
          })]
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Form_WrappedInput, {
          name: "comment",
          type: "textarea",
          placeholder: "Why?",
          inputClassName: "text-base block w-full p-2 mb-2 border rounded",
          maxRows: 10,
          autoFocus: true
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Form_WrappedInput, {
          type: "hashtag",
          name: "hashtags",
          placeholder: "Any hashtags for the domain?",
          options: hashtagOptions,
          inputClassName: "text-base block w-full mb-2"
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
          className: "flex items-center justify-between",
          children: [/*#__PURE__*/(0,jsx_runtime.jsx)(Form_SubmitButton, {
            isSubmitting: isSubmitting,
            isDirty: isDirty,
            children: isDirty ? hasReviewBeenSaved ? 'Save Changes' : 'Save Review' : 'No changes to save'
          }), hasReviewBeenSaved ? /*#__PURE__*/(0,jsx_runtime.jsxs)(Button/* default */.Z, {
            variant: "hover",
            onClick: switchToSharing,
            children: [isDirty ? 'Share without changes' : 'Return to sharing', " \u232A"]
          }) : /*#__PURE__*/(0,jsx_runtime.jsx)("span", {})]
        })]
      })
    }))
  });
};

/* harmony default export */ const WriteMode_WriteReview = (WriteReview);
// EXTERNAL MODULE: ./src/lib/common/components/ShareReview/index.js + 3 modules
var components_ShareReview = __webpack_require__(66330);
// EXTERNAL MODULE: ./src/lib/common/components/TimeAgo.js
var TimeAgo = __webpack_require__(3716);
// EXTERNAL MODULE: ./src/lib/common/logic/index.js
var logic = __webpack_require__(55231);
// EXTERNAL MODULE: ./src/lib/common/components/ReviewCard/index.js + 2 modules
var ReviewCard = __webpack_require__(92153);
// EXTERNAL MODULE: ./src/lib/universal-interface/UniversalLink.js
var UniversalLink = __webpack_require__(84261);
// EXTERNAL MODULE: ./src/lib/common/routes.js
var routes = __webpack_require__(11147);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/WriteMode/ShareReview/index.js









 // TODO: look into webpack's dynamic imports to slim the initial popup load, then load the rest in the background





var HumanReviewStatus = function HumanReviewStatus(_ref) {
  var meta = _ref.meta;

  var _ref2 = meta || {},
      createdAt = _ref2.createdAt,
      updatedAt = _ref2.updatedAt;

  if (!createdAt && !updatedAt) return null; // shouldn't be here, but...

  if (!updatedAt || (0,utils/* sameDate */.y$)(createdAt, updatedAt)) return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
    children: ["posted ", /*#__PURE__*/(0,jsx_runtime.jsx)(TimeAgo/* default */.Z, {
      datetime: createdAt
    })]
  });
  return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
    children: ["updated ", /*#__PURE__*/(0,jsx_runtime.jsx)(TimeAgo/* default */.Z, {
      datetime: updatedAt
    })]
  });
};

var ShareHeader = function ShareHeader(_ref3) {
  var domainKey = _ref3.domainKey,
      pageKey = _ref3.pageKey,
      writingContext = _ref3.writingContext,
      review = _ref3.review,
      backToWriting = _ref3.backToWriting;
  var label = (0,react.useMemo)(function () {
    return writingContext === 'domain' ? domainKey : (0,logic/* addressFromPageKey */.gh)({
      pageKey: pageKey,
      domainKey: domainKey,
      withoutProtocol: true
    });
  }, [writingContext, pageKey, domainKey]);
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: "mb-1",
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
      className: "font-bold",
      children: label
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      className: "text-sm text-gray-500",
      children: review.loading ? /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "flex py-1 justify-center items-center",
        role: "status",
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("div", {
          className: "inline-block mr-1",
          style: {
            width: '16px'
          },
          children: /*#__PURE__*/(0,jsx_runtime.jsx)(components_Spinner, {
            size: "4"
          })
        }), review.meta ? 'updating' : 'posting', " review..."]
      }) : /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "",
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)(HumanReviewStatus, {
          meta: review.meta
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
          href: "#",
          onClick: backToWriting,
          className: "ml-1 text-gray-700 hover:text-gray-900",
          children: "[edit]"
        })]
      })
    })]
  });
};

var ShareBody = function ShareBody(_ref4) {
  var review = _ref4.review,
      domainKey = _ref4.domainKey,
      pageKey = _ref4.pageKey;
  var currentUser = (0,hooks/* useCurrentUser */.xJ)();
  return /*#__PURE__*/(0,jsx_runtime.jsx)(UniversalLink/* default */.Z, {
    href: routes/* default.reviewUrl */.Z.reviewUrl(currentUser, domainKey, pageKey),
    children: /*#__PURE__*/(0,jsx_runtime.jsx)(ReviewCard/* default */.ZP, {
      review: review,
      className: "my-5 shadow-xl rounded-md w-full bg-white hover:bg-gray-50",
      onReviewPage: true
    })
  });
};

var ShareReview = function ShareReview(_ref5) {
  var _review$meta;

  var domainKey = _ref5.domainKey,
      pageKey = _ref5.pageKey,
      rawReview = _ref5.review,
      domainPacket = _ref5.domainPacket,
      author = _ref5.author,
      backToWriting = _ref5.backToWriting,
      writingContext = _ref5.writingContext;
  var ShareTag = writingContext === 'page' ? components_ShareReview/* SharePageReview */.Ol : components_ShareReview/* ShareDomainReview */.v_;
  var review = (0,utils/* useNormalizedReviewPacket */.Ko)(rawReview); // NOTE: still think we could centralize normalizeReview calls to where data was initially loaded, rather than scattered through code (but hard b/c e.g. sharing gets draftReviews set optimistically before actually hearing back from firestore)

  if (!review) return null;
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: "p-3 text-center bg-gray-100",
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)(ShareHeader, {
      domainKey: domainKey,
      pageKey: pageKey,
      review: review,
      backToWriting: backToWriting,
      writingContext: writingContext
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ShareBody, {
      review: review,
      domainKey: domainKey,
      pageKey: writingContext === 'page' ? pageKey : undefined
    }), (review === null || review === void 0 ? void 0 : (_review$meta = review.meta) === null || _review$meta === void 0 ? void 0 : _review$meta.createdAt) && /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
        className: "mt-6 mb-1 font-light",
        children: "Share Your Review:"
      }), /*#__PURE__*/(0,jsx_runtime.jsx)(ShareTag, {
        domainKey: domainKey,
        pageKey: pageKey,
        review: review,
        author: author,
        size: 46,
        showUrl: true
      })]
    })]
  });
};

/* harmony default export */ const WriteMode_ShareReview = (ShareReview);
// EXTERNAL MODULE: ./src/lib/common/components/ext/SubnavBar.js
var SubnavBar = __webpack_require__(39257);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/utils/bugs.js
var bugs = __webpack_require__(64103);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/hooks/use-resolve-button-type.js
var use_resolve_button_type = __webpack_require__(14157);
;// CONCATENATED MODULE: ./node_modules/@headlessui/react/dist/components/switch/switch.js
let m=(0,react.createContext)(null);m.displayName="GroupContext";let j=react.Fragment;function N(f){let[n,i]=(0,react.useState)(null),[e,a]=B(),[o,d]=(0,description/* useDescriptions */.f)(),u=(0,react.useMemo)(()=>({switch:n,setSwitch:i,labelledby:e,describedby:o}),[n,i,e,o]),p={},t=f;return react.createElement(d,{name:"Switch.Description"},react.createElement(a,{name:"Switch.Label",props:{onClick(){!n||(n.click(),n.focus({preventScroll:!0}))}}},react.createElement(m.Provider,{value:u},(0,render/* render */.sY)({ourProps:p,theirProps:t,defaultTag:j,name:"Switch.Group"}))))}let $="button",q=(0,render/* forwardRefWithAs */.yV)(function(n,i){let{checked:e,onChange:a,name:o,value:d,...u}=n,p=`headlessui-switch-${(0,use_id/* useId */.M)()}`,t=(0,react.useContext)(m),h=(0,react.useRef)(null),S=(0,use_sync_refs/* useSyncRefs */.T)(h,i,t===null?null:t.setSwitch),s=(0,react.useCallback)(()=>a(!e),[a,e]),w=(0,react.useCallback)(r=>{if((0,bugs/* isDisabledReactIssue7711 */.P)(r.currentTarget))return r.preventDefault();r.preventDefault(),s()},[s]),E=(0,react.useCallback)(r=>{r.key===keyboard/* Keys.Space */.R.Space?(r.preventDefault(),s()):r.key===keyboard/* Keys.Enter */.R.Enter&&form_p(r.currentTarget)},[s]),P=(0,react.useCallback)(r=>r.preventDefault(),[]),v=(0,react.useMemo)(()=>({checked:e}),[e]),g={id:p,ref:S,role:"switch",type:(0,use_resolve_button_type/* useResolveButtonType */.f)(n,h),tabIndex:0,"aria-checked":e,"aria-labelledby":t==null?void 0:t.labelledby,"aria-describedby":t==null?void 0:t.describedby,onClick:w,onKeyUp:E,onKeyPress:P};return react.createElement(react.Fragment,null,o!=null&&e&&react.createElement(internal_hidden/* Hidden */._,{features:internal_hidden/* Features.Hidden */.A.Hidden,...(0,render/* compact */.oA)({as:"input",type:"checkbox",hidden:!0,readOnly:!0,checked:e,name:o,value:d})}),(0,render/* render */.sY)({ourProps:g,theirProps:u,slot:v,defaultTag:$,name:"Switch"}))}),de=Object.assign(q,{Group:N,Label:M,Description:description/* Description */.d});

;// CONCATENATED MODULE: ./src/lib/common/components/ext/WriteMode/SelectWritingContext/index.js
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }









var SelectWritingContext_noop = function noop() {
  return null;
};

var SelectWritingContext = /*#__PURE__*/react.forwardRef(function (_props, ref) {
  var _useRecoilState = (0,recoil/* useRecoilState */.FV)(recoil/* writingContextAtom */.fR),
      _useRecoilState2 = _slicedToArray(_useRecoilState, 2),
      writingContext = _useRecoilState2[0],
      setWritingContext = _useRecoilState2[1];

  var toggleWritingContext = (0,react.useCallback)(function () {
    setWritingContext(writingContext === 'domain' ? 'page' : 'domain');
  }, [writingContext, setWritingContext]);
  var checked = (0,react.useMemo)(function () {
    return writingContext === 'page';
  }, [writingContext]);
  return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
    ref: ref,
    className: "fixed w-full max-w-[420px] shadow-xl border-b",
    style: {
      zIndex: 50
    },
    children: /*#__PURE__*/(0,jsx_runtime.jsxs)(SubnavBar/* default */.Z, {
      onClick: toggleWritingContext,
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)(SubnavBar/* default.ActionTitle */.Z.ActionTitle, {
        title: "Reviewing:",
        className: "text-base"
      }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "flex items-center justify-end text-base",
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("div", {
          className: (0,utils.cn)(writingContext === 'domain' && 'font-bold'),
          children: "Domain"
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)(de, {
          checked: checked,
          onChange: SelectWritingContext_noop,
          className: (0,utils.cn)(checked ? 'bg-gray-400' : 'bg-gray-300', 'mx-2 relative inline-flex items-start flex-shrink-0 h-[19px] w-[36px] border-2 border-transparent rounded-full cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-gray-400 focus-visible:ring-opacity-75', 'transition-colors ease-in-out duration-200'),
          children: [/*#__PURE__*/(0,jsx_runtime.jsx)("span", {
            className: "sr-only",
            children: "Write Page Review"
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
            "aria-hidden": "true",
            className: (0,utils.cn)(checked ? 'translate-x-4' : 'translate-x-0', 'bg-gray-100 pointer-events-none inline-block h-[15px] w-[15px] rounded-full shadow-lg ring-0', 'transition ease-in-out duration-200')
          })]
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
          className: (0,utils.cn)(writingContext === 'page' && 'font-bold'),
          children: "Current Page"
        })]
      })]
    })
  });
});
SelectWritingContext.displayName = 'SelectWritingContext';
/* harmony default export */ const WriteMode_SelectWritingContext = (SelectWritingContext);
// EXTERNAL MODULE: ./node_modules/usehooks-ts/dist/esm/index.js + 64 modules
var esm = __webpack_require__(69608);
// EXTERNAL MODULE: ./src/lib/common/components/ErrorBoundary.js
var ErrorBoundary = __webpack_require__(64981);
// EXTERNAL MODULE: ./src/lib/common/hooks/index.js
var common_hooks = __webpack_require__(98415);
// EXTERNAL MODULE: ./src/lib/common/components/Loader.js
var Loader = __webpack_require__(38626);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/WriteMode/index.js
function WriteMode_slicedToArray(arr, i) { return WriteMode_arrayWithHoles(arr) || WriteMode_iterableToArrayLimit(arr, i) || WriteMode_unsupportedIterableToArray(arr, i) || WriteMode_nonIterableRest(); }

function WriteMode_nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function WriteMode_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return WriteMode_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return WriteMode_arrayLikeToArray(o, minLen); }

function WriteMode_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function WriteMode_iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function WriteMode_arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }















var ShareCurrentReview = function ShareCurrentReview(_ref) {
  var review = _ref.review;
  var writingContext = (0,recoil/* useRecoilValue */.sJ)(recoil/* writingContextAtom */.fR);

  var _useRecoilValue = (0,recoil/* useRecoilValue */.sJ)(recoil/* currentAtom */.C),
      domainKey = _useRecoilValue.domainKey,
      pageKey = _useRecoilValue.pageKey;

  var currentUser = (0,hooks/* useCurrentUser */.xJ)();
  var domainPacket = (0,recoil/* useRecoilValue */.sJ)(recoil/* currentUserDomainPacketSelector */.OO);
  var setReviewToShare = (0,recoil/* useSetRecoilState */.Zl)(recoil/* reviewToShareAtom */.WX);
  var stopSharingReview = (0,common_hooks/* useLinkCallback */._P)(function () {
    return setReviewToShare(null);
  }, []);
  return /*#__PURE__*/(0,jsx_runtime.jsx)(WriteMode_ShareReview, {
    review: review,
    domainPacket: domainPacket,
    writingContext: writingContext,
    domainKey: domainKey,
    pageKey: pageKey,
    author: currentUser,
    backToWriting: stopSharingReview
  });
};

var WriteMode = function WriteMode() {
  var reviewToShare = (0,recoil/* useRecoilValue */.sJ)(recoil/* reviewToShareAtom */.WX);

  var _useElementSize = (0,esm/* useElementSize */.h4)(),
      _useElementSize2 = WriteMode_slicedToArray(_useElementSize, 2),
      headerRef = _useElementSize2[0],
      headerHeight = _useElementSize2[1].height;

  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: "relative overflow-y-hidden",
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)(WriteMode_SelectWritingContext, {
      ref: headerRef
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      className: "relative overflow-y-auto",
      style: {
        marginTop: headerHeight || 40
      },
      children: /*#__PURE__*/(0,jsx_runtime.jsx)(ErrorBoundary/* default */.Z, {
        children: /*#__PURE__*/(0,jsx_runtime.jsx)(react.Suspense, {
          fallback: /*#__PURE__*/(0,jsx_runtime.jsx)(Loader/* Loader */.aN, {}),
          children: reviewToShare ? /*#__PURE__*/(0,jsx_runtime.jsx)(ShareCurrentReview, {
            review: reviewToShare
          }) : /*#__PURE__*/(0,jsx_runtime.jsx)(WriteMode_WriteReview, {})
        })
      })
    })]
  });
};

/* harmony default export */ const ext_WriteMode = (WriteMode);

/***/ })

}]);