(self["webpackChunkeditor_browser_extension"] = self["webpackChunkeditor_browser_extension"] || []).push([["src_popup_containers_WriteModeContainer_WriteModeContainer_jsx"],{

/***/ "./src/lib/common/components/CopyToClipboard.js":
/*!******************************************************!*\
  !*** ./src/lib/common/components/CopyToClipboard.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var common_hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/hooks */ "./src/lib/common/hooks/index.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Button.js");
/* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-toast-notifications */ "./node_modules/react-toast-notifications/dist/index.js");
/* harmony import */ var use_clipboard_copy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! use-clipboard-copy */ "./node_modules/use-clipboard-copy/dist/index.js");
/* harmony import */ var use_clipboard_copy__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(use_clipboard_copy__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");








var CopyToClipboard = function CopyToClipboard(_ref) {
  var label = _ref.label,
      desc = _ref.desc,
      value = _ref.value;

  var _useToasts = (0,react_toast_notifications__WEBPACK_IMPORTED_MODULE_1__.useToasts)(),
      addToast = _useToasts.addToast;

  var clipboard = (0,use_clipboard_copy__WEBPACK_IMPORTED_MODULE_2__.useClipboard)({
    onSuccess: function onSuccess() {
      addToast( /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
        children: ["Copied", desc ? " ".concat(desc) : '', " to clipboard:", ' ', /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("span", {
          className: "text-monospace text-break",
          children: value
        })]
      }), // TODO: this extends past edge of toast!
      {
        appearance: 'success',
        id: 'copy-to-clipboard'
      });
    },
    onError: function onError() {
      addToast( /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
        children: "Browser is not cooperating - please copy text manually"
      }), {
        appearance: 'warning',
        id: 'copy-to-clipboard'
      });
    }
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: "input-group input-group-sm",
    children: [label && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("div", {
      className: "input-group-prepend",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("span", {
        className: "input-group-text",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("span", {
          className: "small pt-1",
          children: [label, ":"]
        })
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("input", {
      ref: clipboard.target,
      value: value,
      type: "text",
      className: "text-monospace form-control",
      readOnly: true
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("div", {
      className: "input-group-append",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.default, {
        onClick: clipboard.copy,
        variant: "outline-secondary",
        children: "Copy"
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CopyToClipboard);

/***/ }),

/***/ "./src/lib/common/components/Divider.js":
/*!**********************************************!*\
  !*** ./src/lib/common/components/Divider.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
 // Relies on bootstrap styling





var Divider = function Divider(_ref) {
  var text = _ref.text,
      className = _ref.className;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
    className: (0,common_utils__WEBPACK_IMPORTED_MODULE_0__.cn)('row align-items-center', className),
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
      className: "col",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("hr", {})
    }), text && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
        className: "col-auto",
        children: text
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
        className: "col",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("hr", {})
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Divider);

/***/ }),

/***/ "./src/lib/common/components/Fields/TriStateSelector.js":
/*!**************************************************************!*\
  !*** ./src/lib/common/components/Fields/TriStateSelector.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "TriStateSelectorField": () => (/* binding */ TriStateSelectorField)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Button.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/ButtonGroup.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/FormControl.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }








var TriStateButton = function TriStateButton(_ref) {
  var activeColor = _ref.activeColor,
      _ref$passiveColor = _ref.passiveColor,
      passiveColor = _ref$passiveColor === void 0 ? 'secondary' : _ref$passiveColor,
      active = _ref.active,
      title = _ref.title,
      onClick = _ref.onClick;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.default, {
    variant: active ? activeColor : passiveColor,
    onClick: onClick,
    children: title
  });
};

var TriStateInput = function TriStateInput(_ref2) {
  var value = _ref2.value,
      onChange = _ref2.onChange,
      yesTitle = _ref2.yesTitle,
      noTitle = _ref2.noTitle,
      unsetTitle = _ref2.unsetTitle,
      passiveColor = _ref2.passiveColor,
      className = _ref2.className,
      isInvalid = _ref2.isInvalid,
      props = _objectWithoutProperties(_ref2, ["value", "onChange", "yesTitle", "noTitle", "unsetTitle", "passiveColor", "className", "isInvalid"]);

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_5__.default, _objectSpread(_objectSpread({}, props), {}, {
    className: (0,common_utils__WEBPACK_IMPORTED_MODULE_2__.cn)('m-2', className, isInvalid && 'is-invalid'),
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(TriStateButton, {
      activeColor: "success",
      passiveColor: passiveColor,
      title: yesTitle || 'Yep',
      active: value === 1,
      onClick: function onClick() {
        return onChange(1);
      }
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(TriStateButton, {
      activeColor: "dark",
      passiveColor: passiveColor,
      title: unsetTitle || 'Not Sure',
      active: [1, -1].indexOf(value) === -1,
      onClick: function onClick() {
        return onChange(0);
      }
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(TriStateButton, {
      activeColor: "danger",
      passiveColor: passiveColor,
      title: noTitle || 'Nope',
      active: value === -1,
      onClick: function onClick() {
        return onChange(-1);
      }
    })]
  }));
};

var TriStateSelector = function TriStateSelector(_ref3) {
  var initialValue = _ref3.initialValue,
      onChange = _ref3.onChange,
      props = _objectWithoutProperties(_ref3, ["initialValue", "onChange"]);

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialValue),
      _useState2 = _slicedToArray(_useState, 2),
      val = _useState2[0],
      setVal = _useState2[1];

  var handleChange = function handleChange(nextVal) {
    setVal(nextVal);
    onChange && onChange(nextVal);
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(TriStateInput, _objectSpread(_objectSpread({}, props), {}, {
    value: val,
    onChange: handleChange
  }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TriStateSelector);
var TriStateSelectorField = function TriStateSelectorField(props) {
  var _useField = (0,formik__WEBPACK_IMPORTED_MODULE_1__.useField)(props),
      _useField2 = _slicedToArray(_useField, 3),
      field = _useField2[0],
      error = _useField2[1].error,
      setValue = _useField2[2].setValue;

  var Wrapper = error ? 'div' : react__WEBPACK_IMPORTED_MODULE_0__.Fragment;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(Wrapper, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(TriStateInput, {
      value: field.value,
      onChange: setValue,
      isInvalid: error
    }), error && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.default.Feedback, {
      type: "invalid",
      children: error
    })]
  });
};

/***/ }),

/***/ "./src/lib/common/components/ShareButtons/index.js":
/*!*********************************************************!*\
  !*** ./src/lib/common/components/ShareButtons/index.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var common_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/config */ "./src/lib/common/config/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var common_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! common/hooks */ "./src/lib/common/hooks/index.js");
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-share */ "./node_modules/react-share/es/EmailShareButton.js");
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-share */ "./node_modules/react-share/es/FacebookShareButton.js");
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-share */ "./node_modules/react-share/es/LinkedinShareButton.js");
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-share */ "./node_modules/react-share/es/RedditShareButton.js");
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-share */ "./node_modules/react-share/es/TwitterShareButton.js");
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-share */ "./node_modules/react-share/es/PinterestShareButton.js");
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! react-share */ "./node_modules/react-share/es/TumblrShareButton.js");
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! react-share */ "./node_modules/react-share/es/WhatsappShareButton.js");
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! react-share */ "./node_modules/react-share/es/EmailIcon.js");
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! react-share */ "./node_modules/react-share/es/FacebookIcon.js");
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! react-share */ "./node_modules/react-share/es/LinkedinIcon.js");
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! react-share */ "./node_modules/react-share/es/RedditIcon.js");
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! react-share */ "./node_modules/react-share/es/TwitterIcon.js");
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! react-share */ "./node_modules/react-share/es/PinterestIcon.js");
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! react-share */ "./node_modules/react-share/es/TumblrIcon.js");
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! react-share */ "./node_modules/react-share/es/WhatsappIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }






var log = common_utils__WEBPACK_IMPORTED_MODULE_4__.logger.extend('ShareButtons'); // TODO: OPTIMIZE - use webpack's dynamic imports to only load the parts we need
// Full docs for each: https://github.com/nygardk/react-share




var Buttons = {
  EmailShareButton: react_share__WEBPACK_IMPORTED_MODULE_6__.default,
  FacebookShareButton: react_share__WEBPACK_IMPORTED_MODULE_7__.default,
  LinkedinShareButton: react_share__WEBPACK_IMPORTED_MODULE_8__.default,
  RedditShareButton: react_share__WEBPACK_IMPORTED_MODULE_9__.default,
  TwitterShareButton: react_share__WEBPACK_IMPORTED_MODULE_10__.default,
  PinterestShareButton: react_share__WEBPACK_IMPORTED_MODULE_11__.default,
  TumblrShareButton: react_share__WEBPACK_IMPORTED_MODULE_12__.default,
  WhatsappShareButton: react_share__WEBPACK_IMPORTED_MODULE_13__.default // HatenaShareButton, InstapaperShareButton, LineShareButton, LivejournalShareButton, MailruShareButton, OKShareButton, PocketShareButton, TelegramShareButton, ViberShareButton, VKShareButton, WorkplaceShareButton

};
var Icons = {
  EmailIcon: react_share__WEBPACK_IMPORTED_MODULE_14__.default,
  FacebookIcon: react_share__WEBPACK_IMPORTED_MODULE_15__.default,
  LinkedinIcon: react_share__WEBPACK_IMPORTED_MODULE_16__.default,
  RedditIcon: react_share__WEBPACK_IMPORTED_MODULE_17__.default,
  TwitterIcon: react_share__WEBPACK_IMPORTED_MODULE_18__.default,
  PinterestIcon: react_share__WEBPACK_IMPORTED_MODULE_19__.default,
  TumblrIcon: react_share__WEBPACK_IMPORTED_MODULE_20__.default,
  WhatsappIcon: react_share__WEBPACK_IMPORTED_MODULE_21__.default // FacebookMessengerIcon, HatenaIcon, InstapaperIcon, LineIcon, LivejournalIcon, MailruIcon, OKIcon, PocketIcon, TelegramIcon, ViberIcon, VKIcon, WeiboIcon, WorkplaceIcon

}; // TODO: unable FB, Reddit to show share counts once we have a page to share

var Counts = {// FacebookShareCount,
  // PinterestShareCount,
  // TumblrShareCount,
  //  RedditShareCount,
  // HatenaShareCount, OKShareCount, VKShareCount,
};
var suffixLength = 'ShareButton'.length;
var SUPPORTED_NETWORKS = Object.keys(Buttons).map(function (name) {
  return name.substring(0, name.length - suffixLength);
}); // Note: window opening blocked until promise is resolved

var makeShareWindowOpenHandler = function makeShareWindowOpenHandler(network) {
  return /*#__PURE__*/_asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            log('onShareWindowOpen', network);

          case 1:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
}; // Note: seems to fire when the opened window navigates away, e.g. to a login screen for the underlying network.
// There does NOT seem to be any clear trigger for "this was successfully shared" :/


var makeShareWindowCloseHandler = function makeShareWindowCloseHandler(network) {
  return function () {
    log('onShareWindowClose', network); // TODO: track user clicks and move their most used networks higher up the priority chain (cautious w/ SSG)
  };
};

var ShareCount = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.memo(function (_ref2) {
  var network = _ref2.network,
      url = _ref2.url;
  var CountTag = Counts["".concat(network, "ShareCount")]; // Pretty sure this shouldn't be necessary... and yet

  if (!CountTag) return null;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(CountTag, {
    url: url,
    children: function children(shareCount) {
      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("span", {
        className: "badge badge-info-light badge-pill text-white",
        children: shareCount
      });
    }
  });
});
var Icon = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.memo(function (_ref3) {
  var network = _ref3.network,
      props = _objectWithoutProperties(_ref3, ["network"]);

  var IconTag = Icons["".concat(network, "Icon")]; // Pretty sure this shouldn't be necessary... and yet

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
    className: "d-flex flex-column m-2 align-items-center",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(IconTag, _objectSpread({
      size: 46,
      round: true
    }, props)), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("div", {
      className: "small text-muted",
      children: network.toLowerCase()
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ShareCount, {
      network: network,
      url: props.url
    })]
  });
});
var FullShareButton = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.memo(function (_ref4) {
  var network = _ref4.network,
      iconProps = _ref4.iconProps,
      props = _objectWithoutProperties(_ref4, ["network", "iconProps"]);

  var ButtonTag = Buttons["".concat(network, "ShareButton")];
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ButtonTag, _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(Icon, _objectSpread({
      network: network
    }, iconProps))
  }));
});

var activeNetworksForUserId = function activeNetworksForUserId(uid, num) {
  // TODO: POLISH - add per-user customization of which networks to show
  return (0,lodash__WEBPACK_IMPORTED_MODULE_2__.take)(SUPPORTED_NETWORKS, num);
};

var ShareButtons = function ShareButtons(_ref5) {
  var _ref5$num = _ref5.num,
      num = _ref5$num === void 0 ? 5 : _ref5$num,
      url = _ref5.url,
      title = _ref5.title,
      summary = _ref5.summary,
      emailBody = _ref5.emailBody,
      emailSubject = _ref5.emailSubject,
      fbQuote = _ref5.fbQuote,
      displayHashtag = _ref5.displayHashtag,
      hashtags = _ref5.hashtags;
  var uid = (0,common_hooks__WEBPACK_IMPORTED_MODULE_3__.useCurrentUserId)();
  var activeNetworks = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
    return activeNetworksForUserId(uid, num);
  }, [uid, num]);
  var ConditionalShareButton = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(function (_ref6) {
    var network = _ref6.network,
        props = _objectWithoutProperties(_ref6, ["network"]);

    return activeNetworks.includes(network) ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(FullShareButton, _objectSpread({
      network: network,
      url: url,
      onShareWindowClose: makeShareWindowCloseHandler(network),
      beforeOnClick: makeShareWindowOpenHandler(network)
    }, props)) : null;
  }, [url, activeNetworks]);
  var imageUrl = null; // TODO

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
    className: "d-flex flex-wrap justify-content-center mt-3",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Email",
      subject: emailSubject,
      body: emailBody
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Facebook",
      quote: fbQuote,
      hashtag: displayHashtag
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Linkedin",
      title: title,
      summary: summary,
      source: common_config__WEBPACK_IMPORTED_MODULE_0__.default.siteRootUrl
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Reddit",
      title: title
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Twitter",
      title: title,
      hashtags: hashtags,
      via: common_config__WEBPACK_IMPORTED_MODULE_0__.default.siteRootUrl
    }), common_config__WEBPACK_IMPORTED_MODULE_0__.default.fbAppId && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "FacebookMessenger",
      appId: common_config__WEBPACK_IMPORTED_MODULE_0__.default.fbAppId
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Hatena",
      title: title
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Instapaper",
      title: title,
      description: summary
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Line",
      title: title
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Livejournal",
      title: title,
      description: summary
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Mailru",
      title: title,
      description: summary,
      imageUrl: imageUrl
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "OKShare",
      title: title,
      description: summary,
      image: imageUrl
    }), imageUrl && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Pinterest",
      media: imageUrl,
      description: title
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Pocket",
      title: title
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Telegram",
      title: title
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Tumblr",
      title: title,
      tags: hashtags,
      caption: summary
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Viber",
      title: title,
      separator: ": "
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "VK",
      title: title,
      image: imageUrl,
      noVkLinks: true
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Weibo",
      title: title,
      image: imageUrl
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Whatsapp",
      title: title,
      separator: ": "
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(ConditionalShareButton, {
      network: "Workplace",
      quote: fbQuote,
      hashtag: displayHashtag
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ShareButtons);

/***/ }),

/***/ "./src/lib/common/components/ShareDomainReview/index.js":
/*!**************************************************************!*\
  !*** ./src/lib/common/components/ShareDomainReview/index.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var common_hooks_useShareableDomainReviewComponents__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/hooks/useShareableDomainReviewComponents */ "./src/lib/common/hooks/useShareableDomainReviewComponents.js");
/* harmony import */ var cc_ShareButtons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! cc/ShareButtons */ "./src/lib/common/components/ShareButtons/index.js");
/* harmony import */ var cc_CopyToClipboard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! cc/CopyToClipboard */ "./src/lib/common/components/CopyToClipboard.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







var ShareDomainReview = function ShareDomainReview(_ref) {
  var domainKey = _ref.domainKey,
      author = _ref.author,
      review = _ref.review,
      components = _ref.components,
      _ref$showUrl = _ref.showUrl,
      showUrl = _ref$showUrl === void 0 ? false : _ref$showUrl,
      _ref$numBtns = _ref.numBtns,
      numBtns = _ref$numBtns === void 0 ? 5 : _ref$numBtns;
  var whatToShare = (0,common_hooks_useShareableDomainReviewComponents__WEBPACK_IMPORTED_MODULE_0__.default)({
    review: review,
    author: author,
    domainKey: domainKey,
    alreadyParsed: components
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: "bg-light rounded p-3",
    children: [showUrl && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(cc_CopyToClipboard__WEBPACK_IMPORTED_MODULE_2__.default, {
      value: whatToShare.url,
      label: "Public URL"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(cc_ShareButtons__WEBPACK_IMPORTED_MODULE_1__.default, _objectSpread(_objectSpread({}, whatToShare), {}, {
      num: numBtns
    }))]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ShareDomainReview);

/***/ }),

/***/ "./src/lib/common/components/SpeechBubble/index.js":
/*!*********************************************************!*\
  !*** ./src/lib/common/components/SpeechBubble/index.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
 // Pulled styling from https://projects.verou.me/bubbly/ (note currently lives in customized-bootstrap to integrate with theme colors)



var SpeechBubble = function SpeechBubble(_ref) {
  var text = _ref.text,
      variant = _ref.variant,
      className = _ref.className;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
    className: (0,common_utils__WEBPACK_IMPORTED_MODULE_0__.cn)('py-2 px-3 speech-bubble', className, "bg-".concat(variant, " speech-bubble-").concat(variant)),
    children: text
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SpeechBubble);

/***/ }),

/***/ "./src/lib/common/components/ext/WriteMode/ShareReview/index.js":
/*!**********************************************************************!*\
  !*** ./src/lib/common/components/ext/WriteMode/ShareReview/index.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var cc_Hashtags__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cc/Hashtags */ "./src/lib/common/components/Hashtags.js");
/* harmony import */ var cc_ShareDomainReview__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! cc/ShareDomainReview */ "./src/lib/common/components/ShareDomainReview/index.js");
/* harmony import */ var cc_VoteEmote__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! cc/VoteEmote */ "./src/lib/common/components/VoteEmote.js");
/* harmony import */ var cc_Avatar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! cc/Avatar */ "./src/lib/common/components/Avatar.js");
/* harmony import */ var cc_TimeAgo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! cc/TimeAgo */ "./src/lib/common/components/TimeAgo.js");
/* harmony import */ var cc_SpeechBubble__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! cc/SpeechBubble */ "./src/lib/common/components/SpeechBubble/index.js");
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var common_logic__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! common/logic */ "./src/lib/common/logic/index.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Alert.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }










 // TODO: look into webpack's dynamic imports to slim the initial popup load, then load the rest in the background





var HumanReviewStatus = function HumanReviewStatus(_ref) {
  var meta = _ref.meta;
  var createdAt = meta.createdAt,
      updatedAt = meta.updatedAt;
  if (!createdAt && !updatedAt) return null; // shouldn't be here, but...

  if (!updatedAt || (0,common_utils__WEBPACK_IMPORTED_MODULE_6__.sameDate)(createdAt, updatedAt)) return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
    children: ["posted ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(cc_TimeAgo__WEBPACK_IMPORTED_MODULE_4__.default, {
      datetime: createdAt
    })]
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
    children: ["updated ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(cc_TimeAgo__WEBPACK_IMPORTED_MODULE_4__.default, {
      datetime: updatedAt
    })]
  });
};

var ShareHeader = function ShareHeader(_ref2) {
  var domainKey = _ref2.domainKey,
      sharing = _ref2.sharing,
      backToWriting = _ref2.backToWriting;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("h4", {
      className: "font-weight-light mb-0",
      children: domainKey
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("div", {
      className: "small text-muted",
      children: sharing.loading ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
        className: "d-flex justify-content-center align-items-center",
        role: "status",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("div", {
          className: "text-secondary-light spinner-border spinner-border-sm"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("span", {
          className: "ml-1",
          children: [sharing.meta ? 'updating' : 'posting', " review..."]
        })]
      }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
        className: "",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(HumanReviewStatus, {
          meta: sharing.meta
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("a", {
          href: "#",
          onClick: backToWriting,
          className: "ml-1 text-dark",
          children: "[edit]"
        })]
      })
    })]
  });
};

var DetailedExceptionsText = function DetailedExceptionsText(_ref3) {
  var _ref3$rules = _ref3.rules,
      rules = _ref3$rules === void 0 ? [] : _ref3$rules;
  var numRules = rules.length;
  if (numRules === 0) return null;
  if (numRules === 1) return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
    children: [" with one (", (0,common_logic__WEBPACK_IMPORTED_MODULE_7__.humanizeVote)(rules[0].vote), ") exception."]
  });

  var _partition = (0,lodash__WEBPACK_IMPORTED_MODULE_8__.partition)(rules, function (r) {
    return r.vote > 0;
  }),
      _partition2 = _slicedToArray(_partition, 2),
      pos = _partition2[0],
      nonPos = _partition2[1];

  var _partition3 = (0,lodash__WEBPACK_IMPORTED_MODULE_8__.partition)(nonPos, function (r) {
    return r.vote < 0;
  }),
      _partition4 = _slicedToArray(_partition3, 2),
      neg = _partition4[0],
      neutral = _partition4[1];

  var partialString = function partialString(segment, label) {
    if (segment.length === 0) return null;
    if (segment.length === numRules) return label;
    return [segment.length, label].join(' ');
  };

  var parts = (0,lodash__WEBPACK_IMPORTED_MODULE_8__.compact)([partialString(pos, (0,common_logic__WEBPACK_IMPORTED_MODULE_7__.humanizeVote)(1)), partialString(neg, (0,common_logic__WEBPACK_IMPORTED_MODULE_7__.humanizeVote)(-1)), partialString(neutral, (0,common_logic__WEBPACK_IMPORTED_MODULE_7__.humanizeVote)(0))]);
  return parts.length === 1 ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
    children: [" with ", (0,common_utils__WEBPACK_IMPORTED_MODULE_6__.plur)(numRules, "".concat(parts[0], " exceptions")), "."]
  }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
    children: [' ', "with ", numRules, " exceptions (", (0,common_utils__WEBPACK_IMPORTED_MODULE_6__.toSentence)(parts), ")."]
  });
};
/* TODO: make this pretty + how show complexity of any rules? */


var ShareBody = function ShareBody(_ref4) {
  var _sharing$meta;

  var sharing = _ref4.sharing,
      domainKey = _ref4.domainKey,
      currentUser = _ref4.currentUser;
  var comment = sharing.comment,
      vote = sharing.vote,
      _sharing$hashtags = sharing.hashtags,
      hashtags = _sharing$hashtags === void 0 ? [] : _sharing$hashtags,
      _sharing$rules = sharing.rules,
      rules = _sharing$rules === void 0 ? [] : _sharing$rules;
  var isComplex = rules.length > 0;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
    className: "p-2 bg-light rounded",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
      className: "d-flex align-items-center justify-content-around",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(cc_Avatar__WEBPACK_IMPORTED_MODULE_3__.default, {
        user: currentUser,
        size: 48,
        className: "mx-2"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
        className: "d-flex flex-column flex-grow-1 m-3",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
          className: "",
          children: ["You rated ", domainKey, isComplex && ' as generally ', /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(cc_VoteEmote__WEBPACK_IMPORTED_MODULE_2__.default, {
            vote: vote,
            className: "ml-1"
          }), isComplex ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(DetailedExceptionsText, {
            rules: rules
          }) : '.']
        }), comment && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(cc_SpeechBubble__WEBPACK_IMPORTED_MODULE_5__.default, {
          variant: "info-light",
          text: comment,
          className: "mt-3 w-100"
        }), ((_sharing$meta = sharing.meta) === null || _sharing$meta === void 0 ? void 0 : _sharing$meta.domainKey) && sharing.meta.domainKey !== domainKey && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_10__.default, {
          variant: "warning",
          className: "mt-3",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_10__.default.Heading, {
            children: "Caching issue / domain mismatch"
          }), "Review data is for ", sharing.meta.domainKey, ", but current context is now ", domainKey, "."]
        })]
      })]
    }), hashtags && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(cc_Hashtags__WEBPACK_IMPORTED_MODULE_0__.default, {
      hashtags: hashtags,
      className: "d-flex justify-content-center mt-1"
    })]
  });
};

var ShareReview = function ShareReview(_ref5) {
  var sharing = _ref5.sharing,
      domainKey = _ref5.domainKey,
      backToWriting = _ref5.backToWriting,
      currentUser = _ref5.currentUser;
  var meta = sharing.meta;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
    className: "p-3 text-center",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(ShareHeader, {
      domainKey: domainKey,
      sharing: sharing,
      backToWriting: backToWriting
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("hr", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(ShareBody, {
      domainKey: domainKey,
      sharing: sharing,
      currentUser: currentUser
    }), (meta === null || meta === void 0 ? void 0 : meta.createdAt) && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("hr", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("h4", {
        className: "font-weight-light",
        children: "Share Your Review:"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(cc_ShareDomainReview__WEBPACK_IMPORTED_MODULE_1__.default, {
        domainKey: domainKey,
        review: sharing,
        author: currentUser,
        showUrl: true
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ShareReview);

/***/ }),

/***/ "./src/lib/common/components/ext/WriteMode/WriteReview/RuleFormModal/Fields.js":
/*!*************************************************************************************!*\
  !*** ./src/lib/common/components/ext/WriteMode/WriteReview/RuleFormModal/Fields.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VerbField": () => (/* binding */ VerbField),
/* harmony export */   "NounField": () => (/* binding */ NounField)
/* harmony export */ });
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/InputGroup.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/FormControl.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Button.js");
/* harmony import */ var cc_Fields_selects__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! cc/Fields/selects */ "./src/lib/common/components/Fields/selects.js");
/* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-select */ "./node_modules/react-select/dist/index-b19cc27c.browser.esm.js");
/* harmony import */ var common_logic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! common/logic */ "./src/lib/common/logic/index.js");
/* harmony import */ var common_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! common/hooks */ "./src/lib/common/hooks/index.js");
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var _RuleFormModal_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./RuleFormModal.module.css */ "./src/lib/common/components/ext/WriteMode/WriteReview/RuleFormModal/RuleFormModal.module.css");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











var verbFieldStyles = {
  control: function control(provided) {
    return _objectSpread(_objectSpread({}, provided), {}, {
      minHeight: 'unset'
    });
  },
  indicatorsContainer: function indicatorsContainer(provided) {
    return _objectSpread(_objectSpread({}, provided), {}, {
      padding: '0px'
    });
  },
  indicatorSeparator: function indicatorSeparator(provided) {
    return _objectSpread(_objectSpread({}, provided), {}, {
      margin: '6px 0px'
    });
  }
}; // Surprised this is such a pain to access, but we just need to inject a bit of styling to shrink the padding

var DropdownIndicator = function DropdownIndicator(_ref) {
  var children = _ref.children,
      props = _objectWithoutProperties(_ref, ["children"]);

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(react_select__WEBPACK_IMPORTED_MODULE_7__.c.DropdownIndicator, _objectSpread(_objectSpread({}, props), {}, {
    className: (0,common_utils__WEBPACK_IMPORTED_MODULE_4__.cn)(props.classname, _RuleFormModal_module_css__WEBPACK_IMPORTED_MODULE_5__.default.dropdownIndicator)
  }));
};

var VerbField = function VerbField(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(cc_Fields_selects__WEBPACK_IMPORTED_MODULE_1__.default, _objectSpread(_objectSpread({}, props), {}, {
    options: common_logic__WEBPACK_IMPORTED_MODULE_2__.VerbOptions,
    isSearchable: false,
    styles: verbFieldStyles,
    components: {
      DropdownIndicator: DropdownIndicator
    }
  }));
};
var NounField = function NounField(_ref2) {
  var className = _ref2.className,
      name = _ref2.name;

  var _useField = (0,formik__WEBPACK_IMPORTED_MODULE_0__.useField)(name),
      _useField2 = _slicedToArray(_useField, 3),
      value = _useField2[0].value,
      _useField2$ = _useField2[1],
      initialValue = _useField2$.initialValue,
      error = _useField2$.error,
      touched = _useField2$.touched,
      setValue = _useField2[2].setValue;

  var doReset = (0,common_hooks__WEBPACK_IMPORTED_MODULE_3__.useLinkCallback)(function () {
    return setValue(initialValue);
  }, [initialValue]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_8__.default, {
    className: className,
    hasValidation: error,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_9__.default, {
      name: name,
      type: "text",
      value: value || '',
      onChange: function onChange(evt) {
        return setValue(evt.target.value);
      },
      onFocus: function onFocus(e) {
        return e.currentTarget.select();
      },
      size: "sm",
      className: _RuleFormModal_module_css__WEBPACK_IMPORTED_MODULE_5__.default.textInput,
      autoFocus: true,
      isInvalid: error
    }), value !== initialValue && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_8__.default.Append, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_10__.default, {
        variant: "light",
        size: "sm",
        onClick: doReset,
        className: (0,common_utils__WEBPACK_IMPORTED_MODULE_4__.cn)('border', _RuleFormModal_module_css__WEBPACK_IMPORTED_MODULE_5__.default.textResetBtn),
        children: "Reset"
      })
    }), error && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_9__.default.Feedback, {
      type: "invalid",
      children: error
    })]
  });
};

/***/ }),

/***/ "./src/lib/common/components/ext/WriteMode/WriteReview/RuleFormModal/index.js":
/*!************************************************************************************!*\
  !*** ./src/lib/common/components/ext/WriteMode/WriteReview/RuleFormModal/index.js ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddRuleModal": () => (/* binding */ AddRuleModal),
/* harmony export */   "EditRuleModal": () => (/* binding */ EditRuleModal)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_formik__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-bootstrap-formik */ "./src/lib/common/vendor/react-bootstrap-formik/index.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Modal.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Button.js");
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var cc_Fields_TriStateSelector__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! cc/Fields/TriStateSelector */ "./src/lib/common/components/Fields/TriStateSelector.js");
/* harmony import */ var common_logic__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! common/logic */ "./src/lib/common/logic/index.js");
/* harmony import */ var common_hooks_useModalResizing__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! common/hooks/useModalResizing */ "./src/lib/common/hooks/useModalResizing.js");
/* harmony import */ var cc_Divider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! cc/Divider */ "./src/lib/common/components/Divider.js");
/* harmony import */ var _Fields__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Fields */ "./src/lib/common/components/ext/WriteMode/WriteReview/RuleFormModal/Fields.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










 // TODO: fix-style




var smallStyle = {
  fontSize: '0.9rem'
};
var RuleSection = (0,formik__WEBPACK_IMPORTED_MODULE_3__.connect)(function (_ref) {
  var title = _ref.title,
      formik = _ref.formik,
      last = _ref.last;
  var baseKey = title.toLowerCase();
  var verbKey = "".concat(baseKey, ".verb");
  var nounKey = "".concat(baseKey, ".noun");
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
      className: "d-flex align-items-center",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("div", {
        className: "flex-grow-0 m-0 mr-2 h6",
        children: title
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(_Fields__WEBPACK_IMPORTED_MODULE_8__.VerbField, {
        name: verbKey,
        className: "flex-grow-1"
      })]
    }), (0,formik__WEBPACK_IMPORTED_MODULE_3__.getIn)(formik.values, verbKey) !== 'any' && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
      className: "d-flex align-items-start justify-content-end mt-1",
      style: smallStyle,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("div", {
        className: "w-25"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("div", {
        className: "text-nowrap mr-2 mt-1",
        children: "This value:"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(_Fields__WEBPACK_IMPORTED_MODULE_8__.NounField, {
        name: nounKey,
        className: "flex-grow-1"
      })]
    })]
  });
}); // TODO: pass in isOpen instead of just not rendering -- breaks the fade out as it is currently

var RuleFormModal = function RuleFormModal(_ref2) {
  var rule = _ref2.rule,
      onSubmit = _ref2.onSubmit,
      _ref2$isOpen = _ref2.isOpen,
      isOpen = _ref2$isOpen === void 0 ? true : _ref2$isOpen,
      otherRules = _ref2.otherRules,
      closeModal = _ref2.closeModal,
      isNewRule = _ref2.isNewRule;

  var _useModalResizing = (0,common_hooks_useModalResizing__WEBPACK_IMPORTED_MODULE_6__.default)(),
      onEntered = _useModalResizing.onEntered,
      onExited = _useModalResizing.onExited;

  var paramRestrictions = rule.paramRestrictions || [];
  var doSubmit = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function (values) {
    var _data$subdomain, _data$path;

    var data = _objectSpread({}, values); // No nouns needed if verb is "any"


    if (((_data$subdomain = data.subdomain) === null || _data$subdomain === void 0 ? void 0 : _data$subdomain.verb) === 'any') delete data.subdomain.noun;
    if (((_data$path = data.path) === null || _data$path === void 0 ? void 0 : _data$path.verb) === 'any') delete data.path.noun; // TODO: prevent unmounting before completes -- make onSubmit return a promise and use .then(closeModal)

    onSubmit(data);
    closeModal();
  }, [onSubmit, closeModal]);
  var validateDomainRule = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function (rule) {
    var errors = {};
    var vote = rule.vote,
        _rule$subdomain = rule.subdomain,
        subdomain = _rule$subdomain === void 0 ? {} : _rule$subdomain,
        _rule$path = rule.path,
        path = _rule$path === void 0 ? {} : _rule$path;

    if ([-1, 0, 1].indexOf(vote || 0) === -1) {
      errors.vote = 'Vote is not valid';
    }

    if (subdomain.verb === 'any' && path.verb === 'any') {
      errors.path = errors.path || {};
      errors.path.verb = 'Path (or subdomain) must be set to something more specific (otherwise this rule is no different than the domain default)';
    }

    var duplicatesExisting = otherRules.find(function (other) {
      return (0,common_logic__WEBPACK_IMPORTED_MODULE_5__.rulesAreEquivalent)(rule, other);
    });

    if (duplicatesExisting) {
      errors.path = errors.path || {};
      errors.path[path.verb === 'any' ? 'verb' : 'noun'] = 'You already have another rule with the same conditions';
    }

    var validateSection = function validateSection(key) {
      var part = rule[key];

      if (part.verb !== 'any' && (!part.noun || part.noun === '')) {
        errors[key] = errors[key] || {};
        errors[key].noun = 'cannot be blank';
      }
    };

    validateSection('path');
    validateSection('subdomain');
    return errors;
  }, [otherRules]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(react_bootstrap_formik__WEBPACK_IMPORTED_MODULE_2__.default, {
      initialValues: rule,
      onSubmit: doSubmit,
      validate: validateDomainRule,
      validateOnBlur: true,
      validateOnChange: true,
      children: function children(_ref3) {
        var touched = _ref3.touched,
            errors = _ref3.errors,
            submitForm = _ref3.submitForm,
            isValid = _ref3.isValid;
        return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_10__.default, {
          show: isOpen,
          onHide: closeModal,
          backdrop: touched ? 'static' : true,
          onEntered: onEntered,
          onExited: onExited,
          centered: true,
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_10__.default.Body, {
            className: "mx-2",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("h5", {
              className: "lead",
              children: ["When ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("em", {
                children: "these"
              }), " conditions are met:"]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
              className: "ml-5 mt-3",
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(RuleSection, {
                title: "Subdomain"
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(cc_Divider__WEBPACK_IMPORTED_MODULE_7__.default, {
                text: "and",
                className: "my-4 w-75 mx-auto text-muted"
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(RuleSection, {
                title: "Path",
                last: true
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("h5", {
              className: "lead mt-4",
              children: ["Then apply ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("em", {
                children: "this"
              }), " recommendation:"]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("div", {
              className: "text-center",
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(cc_Fields_TriStateSelector__WEBPACK_IMPORTED_MODULE_4__.TriStateSelectorField, {
                name: "vote"
              })
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_10__.default.Footer, {
            className: "bg-light",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(react_bootstrap_formik__WEBPACK_IMPORTED_MODULE_2__.default.Textarea, {
              name: "comment",
              placeholder: "What prompted the exception? (optional)",
              type: "textarea",
              cols: "2",
              groupClassName: "w-100"
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
              className: "d-flex justify-content-between w-100",
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_11__.default, {
                variant: "light",
                onClick: closeModal,
                children: "Cancel"
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_11__.default, {
                variant: "primary",
                onClick: submitForm,
                autoFocus: true,
                disabled: !isValid,
                children: [isNewRule ? 'Add' : 'Update', " Rule"]
              })]
            })]
          })]
        });
      }
    })
  });
};

var voteFromDefaultDomainVote = function voteFromDefaultDomainVote(defaultDomainVote) {
  var dv = (defaultDomainVote || 0) * -1;
  if (dv === 0) dv = 1;
};

var makeDefaultRule = function makeDefaultRule(defaultDomainVote, address) {
  // Any chance these are already parsed in redux?
  var _urlDataFromAddress = (0,common_logic__WEBPACK_IMPORTED_MODULE_5__.urlDataFromAddress)(address),
      path = _urlDataFromAddress.path,
      subdomain = _urlDataFromAddress.subdomain,
      params = _urlDataFromAddress.params;

  return {
    vote: voteFromDefaultDomainVote(defaultDomainVote),
    subdomain: {
      verb: 'any',
      noun: subdomain
    },
    path: {
      verb: 'equals',
      noun: path
    }
  };
};

var AddRuleModal = function AddRuleModal(_ref4) {
  var defaultDomainVote = _ref4.defaultDomainVote,
      address = _ref4.address,
      props = _objectWithoutProperties(_ref4, ["defaultDomainVote", "address"]);

  var rule = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
    return makeDefaultRule(defaultDomainVote, address);
  }, [defaultDomainVote, address]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(RuleFormModal, _objectSpread(_objectSpread({
    rule: rule
  }, props), {}, {
    isNewRule: true
  }));
};
var EditRuleModal = function EditRuleModal(_ref5) {
  var rule = _ref5.rule,
      allRules = _ref5.allRules,
      props = _objectWithoutProperties(_ref5, ["rule", "allRules"]);

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(RuleFormModal, _objectSpread(_objectSpread({}, props), {}, {
    rule: rule,
    otherRules: (0,lodash__WEBPACK_IMPORTED_MODULE_1__.filter)(allRules, function (candidateRule) {
      return !(0,common_logic__WEBPACK_IMPORTED_MODULE_5__.rulesAreEquivalent)(rule, candidateRule);
    })
  }));
};

/***/ }),

/***/ "./src/lib/common/components/ext/WriteMode/WriteReview/Rules.js":
/*!**********************************************************************!*\
  !*** ./src/lib/common/components/ext/WriteMode/WriteReview/Rules.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var react_sortable_hoc__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-sortable-hoc */ "./node_modules/react-sortable-hoc/dist/react-sortable-hoc.esm.js");
/* harmony import */ var common_logic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! common/logic */ "./src/lib/common/logic/index.js");
/* harmony import */ var cc_VoteEmote__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! cc/VoteEmote */ "./src/lib/common/components/VoteEmote.js");
/* harmony import */ var _Rules_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Rules.module.scss */ "./src/lib/common/components/ext/WriteMode/WriteReview/Rules.module.scss");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");




 // TODO: make this a grab handle, not a button click cursor



var DragHandle = (0,react_sortable_hoc__WEBPACK_IMPORTED_MODULE_1__.sortableHandle)(function (_ref) {
  var vote = _ref.vote;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("span", {
    className: (0,common_utils__WEBPACK_IMPORTED_MODULE_0__.cn)('dragHandle text-monospace text-muted', _Rules_module_scss__WEBPACK_IMPORTED_MODULE_4__.default.dragHandle),
    role: "button",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(cc_VoteEmote__WEBPACK_IMPORTED_MODULE_3__.default, {
      vote: vote
    })
  });
});

var Rule = function Rule(_ref2) {
  var rule = _ref2.rule,
      onDelete = _ref2.onDelete,
      onEdit = _ref2.onEdit;
  var mood = rule.vote === 1 ? 'success' : rule.vote === -1 ? 'danger' : 'secondary';
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("div", {
    className: (0,common_utils__WEBPACK_IMPORTED_MODULE_0__.cn)('list-group-item align-items-center p-2', "bg-".concat(mood, "-light")),
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
      className: "d-flex w-100 align-items-center justify-content-between small",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(DragHandle, {
        vote: rule.vote
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
        className: "flex-grow-1 mx-3",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("span", {
          children: " if "
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(common_logic__WEBPACK_IMPORTED_MODULE_2__.HumanizedRuleText, {
          rule: rule
        }), rule.comment && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("span", {
          children: " \uD83D\uDCAC"
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
        className: "small",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("a", {
          href: "#",
          onClick: function onClick() {
            return onEdit(rule);
          },
          className: "text-muted",
          children: "Edit"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("span", {
          className: "text-muted",
          children: " | "
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("a", {
          href: "#",
          onClick: function onClick() {
            return confirm('Are you sure you want to delete this rule?') && onDelete(rule.localId);
          },
          className: "text-muted",
          children: "Delete"
        })]
      })]
    })
  });
};

var SortableRule = (0,react_sortable_hoc__WEBPACK_IMPORTED_MODULE_1__.sortableElement)(Rule);
var SortableRulesContainer = (0,react_sortable_hoc__WEBPACK_IMPORTED_MODULE_1__.sortableContainer)(function (_ref3) {
  var rules = _ref3.rules,
      onDelete = _ref3.onDelete,
      onEdit = _ref3.onEdit;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("div", {
    className: "list-group",
    children: rules.map(function (rule, index) {
      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(SortableRule, {
        index: index,
        rule: rule,
        onDelete: onDelete,
        onEdit: onEdit
      }, "sortable-rule-".concat(rule.localId));
    })
  });
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SortableRulesContainer);

/***/ }),

/***/ "./src/lib/common/components/ext/WriteMode/WriteReview/index.js":
/*!**********************************************************************!*\
  !*** ./src/lib/common/components/ext/WriteMode/WriteReview/index.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react_bootstrap_formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-bootstrap-formik */ "./src/lib/common/vendor/react-bootstrap-formik/index.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Button.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/FormGroup.js");
/* harmony import */ var _useRulesReducer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./useRulesReducer */ "./src/lib/common/components/ext/WriteMode/WriteReview/useRulesReducer.js");
/* harmony import */ var _RuleFormModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./RuleFormModal */ "./src/lib/common/components/ext/WriteMode/WriteReview/RuleFormModal/index.js");
/* harmony import */ var common_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! common/hooks */ "./src/lib/common/hooks/index.js");
/* harmony import */ var _Rules__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Rules */ "./src/lib/common/components/ext/WriteMode/WriteReview/Rules.js");
/* harmony import */ var cc_Fields_hashtags__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! cc/Fields/hashtags */ "./src/lib/common/components/Fields/hashtags.js");
/* harmony import */ var cc_Fields_TriStateSelector__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! cc/Fields/TriStateSelector */ "./src/lib/common/components/Fields/TriStateSelector.js");
/* harmony import */ var cc_Popover__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! cc/Popover */ "./src/lib/common/components/Popover.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var common_api__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! common/api */ "./src/lib/common/api/index.js");
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

















var log = common_utils__WEBPACK_IMPORTED_MODULE_11__.logger.extend('WriteReview');

var Section = function Section(_ref) {
  var center = _ref.center,
      children = _ref.children,
      className = _ref.className;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)("div", {
    className: (0,common_utils__WEBPACK_IMPORTED_MODULE_11__.cn)('bg-white p-2', className || 'mb-3', center && 'text-center'),
    children: children
  });
};

var defaultDomainPacket = {
  hashtags: [],
  comment: '',
  vote: 0
};

var WriteReview = function WriteReview(_ref2) {
  var domainKey = _ref2.domainKey,
      address = _ref2.address,
      uid = _ref2.uid,
      domainPacket = _ref2.domainPacket,
      setSharing = _ref2.setSharing,
      refetchDomainPacket = _ref2.refetchDomainPacket,
      onReviewSubmissionFailure = _ref2.onReviewSubmissionFailure;
  var initialValues = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
    return Object.assign({}, defaultDomainPacket, domainPacket);
  }, [domainPacket] // TODO: best value here? feels like we want domainPacket?.meta?.updatedAt?.toDate()?.toString(), but ext doesn't have toDate method
  );
  var hashtagOptions = (0,common_hooks__WEBPACK_IMPORTED_MODULE_4__.useHashtagOptionsFor)(uid, initialValues.hashtags);

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialValues.rules && initialValues.rules.length),
      _useState2 = _slicedToArray(_useState, 2),
      complicated = _useState2[0],
      setComplicated = _useState2[1];

  var _useToggle = (0,common_hooks__WEBPACK_IMPORTED_MODULE_4__.useToggle)(false),
      _useToggle2 = _slicedToArray(_useToggle, 2),
      showAddRuleModal = _useToggle2[0],
      toggleAddRuleModal = _useToggle2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null),
      _useState4 = _slicedToArray(_useState3, 2),
      editModalRule = _useState4[0],
      setEditModalRule = _useState4[1];

  var _useRulesReducer = (0,_useRulesReducer__WEBPACK_IMPORTED_MODULE_2__.default)(initialValues.rules),
      rules = _useRulesReducer.rules,
      addDomainRule = _useRulesReducer.addDomainRule,
      reorderDomainRules = _useRulesReducer.reorderDomainRules,
      removeDomainRule = _useRulesReducer.removeDomainRule,
      updateDomainRule = _useRulesReducer.updateDomainRule,
      formatRulesForServer = _useRulesReducer.formatRulesForServer;

  var onSubmit = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function (values) {
    var data = _objectSpread({}, values); // If the user switched back to simple mode, keep the rules locally but don't return them on submit


    if (complicated) {
      data.rules = formatRulesForServer(rules);
    } else {
      delete data.rules;
    }

    if (address.slice(0, 7) === 'http://') data.viaHttp = true;
    common_api__WEBPACK_IMPORTED_MODULE_10__.default.setDomainReview({
      userId: uid,
      domainKey: domainKey,
      data: data
    }).then(refetchDomainPacket)["catch"](function (error) {
      log('[ERROR] setting domain review: ', error === null || error === void 0 ? void 0 : error.message);
      onReviewSubmissionFailure && onReviewSubmissionFailure(error === null || error === void 0 ? void 0 : error.message, data);
    }); // Optimistic about success

    data.loading = true;
    setSharing(data);
  }, [complicated, rules, domainKey, onReviewSubmissionFailure, refetchDomainPacket, setSharing, uid, address, formatRulesForServer]);
  var needRulesToSubmit = complicated && rules.length === 0;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("div", {
    className: "pt-2",
    children: [showAddRuleModal && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)(_RuleFormModal__WEBPACK_IMPORTED_MODULE_3__.AddRuleModal // TODO: ideally we'd pass in *current* default value from domainPacket form (so rule can default to opposite), but we'd have to be nested in the form which is invalid html
    , {
      defaultDomainVote: initialValues.vote,
      otherRules: rules,
      address: address,
      onSubmit: addDomainRule,
      closeModal: toggleAddRuleModal
    }), editModalRule && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)(_RuleFormModal__WEBPACK_IMPORTED_MODULE_3__.EditRuleModal, {
      rule: editModalRule,
      allRules: rules,
      domainKey: domainKey,
      onSubmit: updateDomainRule,
      closeModal: function closeModal() {
        return setEditModalRule(null);
      }
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)(react_bootstrap_formik__WEBPACK_IMPORTED_MODULE_1__.default, {
      initialValues: initialValues,
      onSubmit: onSubmit,
      children: function children(_ref3) {
        var values = _ref3.values,
            touched = _ref3.touched,
            dirty = _ref3.dirty;
        var isDirty = dirty || !(0,lodash__WEBPACK_IMPORTED_MODULE_9__.isEqual)(rules || [], initialValues.rules || []);
        return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(Section, {
            center: true,
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("p", {
              className: "lead m-0",
              children: [complicated ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("span", {
                children: ["What is your ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)("em", {
                  children: "default"
                }), " recommendation for pages on", ' ']
              }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)("span", {
                children: "Would you recommend "
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)("strong", {
                children: domainKey
              }), "?"]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)(cc_Fields_TriStateSelector__WEBPACK_IMPORTED_MODULE_7__.TriStateSelectorField, {
              name: "vote"
            }), !complicated && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)("p", {
              className: "m-0",
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)("small", {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)("a", {
                  className: "text-primary",
                  href: "#",
                  onClick: function onClick() {
                    return setComplicated(true);
                  },
                  children: "It's complicated..."
                })
              })
            })]
          }), complicated && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(Section, {
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("h5", {
              className: "d-flex justify-content-between",
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)("span", {
                children: "Advanced Rules"
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("small", {
                children: [' ', "(", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)("a", {
                  className: "text-danger small",
                  href: "#",
                  onClick: function onClick() {
                    return setComplicated(false);
                  },
                  children: "Back to simple mode..."
                }), ")"]
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("div", {
              className: "mx-2",
              children: [rules.length === 0 && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("p", {
                  className: "mb-0 text-center text-muted",
                  children: ["No rules yet.", ' ', /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)(cc_Popover__WEBPACK_IMPORTED_MODULE_8__.default, {
                    title: "Advanced Mode",
                    placement: "bottom" // TODO: icon
                    ,
                    trigger: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)("span", {
                      id: "AdvancedModePopover",
                      role: "button",
                      className: "badge",
                      children: "\u2139"
                    }),
                    content: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)("p", {
                      className: "mb-0",
                      children: "More complicated opinions are handled by comparing any given URL against a list of rules you provide. The first rule to match wins."
                    })
                  })]
                })
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)(_Rules__WEBPACK_IMPORTED_MODULE_5__.default, {
                rules: rules,
                onDelete: removeDomainRule,
                onEdit: setEditModalRule,
                onSortEnd: reorderDomainRules,
                onSortStart: function onSortStart() {
                  return document.body.style.cursor = 'grabbing';
                },
                useDragHandle: true
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)("div", {
                className: "d-flex align-items-center justify-content-center",
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_13__.default, {
                  className: "mt-2",
                  size: "sm",
                  variant: "outline-info",
                  onClick: toggleAddRuleModal,
                  autoFocus: true,
                  children: [rules.length ? 'Append New' : 'Create', " Rule"]
                })
              })]
            })]
          }), (!!values.vote || complicated) && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(Section, {
            className: "mb-0",
            children: [complicated && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("h5", {
              children: ["Metadata ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)("small", {
                children: "(optional)"
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_14__.default, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)(react_bootstrap_formik__WEBPACK_IMPORTED_MODULE_1__.default.Textarea, {
                name: "comment",
                cols: "2",
                placeholder: "Why?",
                autoFocus: !complicated
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_14__.default, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)(cc_Fields_hashtags__WEBPACK_IMPORTED_MODULE_6__.HashtagSelectField, {
                name: "hashtags",
                placeholder: "Any hashtags for the domain?",
                options: hashtagOptions
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("div", {
              className: "d-flex justify-content-between pt-3",
              children: [needRulesToSubmit ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_13__.default, {
                variant: "secondary",
                disabled: true,
                children: "Must add rule before saving..."
              }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)(react_bootstrap_formik__WEBPACK_IMPORTED_MODULE_1__.default.Submit, {
                disabled: !isDirty,
                children: isDirty ? domainPacket ? 'Save Changes' : 'Save Review' : 'No changes to save'
              }), domainPacket ?
              /*#__PURE__*/
              // TODO: this doesn't seem to be picking up dirty changes properly
              (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_13__.default, {
                variant: "link",
                className: "text-muted",
                onClick: function onClick() {
                  return setSharing(domainPacket);
                },
                children: [isDirty ? 'Share without changes' : 'Return to sharing', ' ', "\u232A"]
              }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx)("span", {})]
            })]
          })]
        });
      }
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WriteReview);

/***/ }),

/***/ "./src/lib/common/components/ext/WriteMode/WriteReview/useRulesReducer.js":
/*!********************************************************************************!*\
  !*** ./src/lib/common/components/ext/WriteMode/WriteReview/useRulesReducer.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @reduxjs/toolkit */ "./node_modules/@reduxjs/toolkit/dist/redux-toolkit.esm.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

// Note this includes immer, so is fine despite looking like it mutates state...



var ruleIdx = 0; // Allows us to identify rules by a temporary *local* ID (that is NOT sent to the server)
// for ease of updating/deleting

var assignLocalId = function assignLocalId(_ref) {
  var vote = _ref.vote,
      rule = _objectWithoutProperties(_ref, ["vote"]);

  return _objectSpread(_objectSpread({}, rule), {}, {
    vote: vote || 0,
    localId: "".concat(ruleIdx++, ".").concat(Math.random())
  });
}; // Strip off the local Id before sending to server


var formatRulesForServer = function formatRulesForServer(rules) {
  return rules.map(function (_ref2) {
    var localId = _ref2.localId,
        rule = _objectWithoutProperties(_ref2, ["localId"]);

    return rule;
  });
};

var rulesReducer = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__.createReducer)([], {
  ADD_RULE: function ADD_RULE(draft, _ref3) {
    var rule = _ref3.rule;
    draft.push(assignLocalId(rule));
  },
  REORDER_RULE: function REORDER_RULE(draft, _ref4) {
    var oldIndex = _ref4.oldIndex,
        newIndex = _ref4.newIndex;
    var insertAt = oldIndex > newIndex ? newIndex - 1 : newIndex;
    var rule = draft.splice(oldIndex, 1)[0];
    draft.splice(insertAt, 0, rule);
  },
  REMOVE_RULE: function REMOVE_RULE(draft, _ref5) {
    var localId = _ref5.localId;
    var ruleIndex = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.findIndex)(draft, function (r) {
      return r.localId === localId;
    });
    if (ruleIndex > -1) draft.splice(ruleIndex, 1);
  },
  UPDATE_RULE: function UPDATE_RULE(draft, _ref6) {
    var rule = _ref6.rule;
    var ruleIndex = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.findIndex)(draft, function (r) {
      return r.localId === rule.localId;
    });
    draft.splice(ruleIndex, 1, rule);
  }
});

var useRulesReducer = function useRulesReducer(initialRules) {
  var _useReducer = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(rulesReducer, (initialRules || []).map(assignLocalId)),
      _useReducer2 = _slicedToArray(_useReducer, 2),
      rules = _useReducer2[0],
      ruleDispatch = _useReducer2[1];

  var addDomainRule = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(function (rule) {
    return ruleDispatch({
      type: 'ADD_RULE',
      rule: rule
    });
  }, [ruleDispatch]);
  var reorderDomainRules = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(function (_ref7) {
    var oldIndex = _ref7.oldIndex,
        newIndex = _ref7.newIndex;
    document.body.style.cursor = 'default';
    ruleDispatch({
      type: 'REORDER_RULE',
      oldIndex: oldIndex,
      newIndex: newIndex
    });
  }, [ruleDispatch]);
  var removeDomainRule = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(function (localId) {
    return ruleDispatch({
      type: 'REMOVE_RULE',
      localId: localId
    });
  }, [ruleDispatch]);
  var updateDomainRule = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(function (updatedRule) {
    return ruleDispatch({
      type: 'UPDATE_RULE',
      rule: updatedRule
    });
  }, [ruleDispatch]);
  return {
    rules: rules,
    addDomainRule: addDomainRule,
    reorderDomainRules: reorderDomainRules,
    removeDomainRule: removeDomainRule,
    updateDomainRule: updateDomainRule,
    formatRulesForServer: formatRulesForServer
  };
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useRulesReducer);

/***/ }),

/***/ "./src/lib/common/components/ext/WriteMode/index.js":
/*!**********************************************************!*\
  !*** ./src/lib/common/components/ext/WriteMode/index.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _WriteReview__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WriteReview */ "./src/lib/common/components/ext/WriteMode/WriteReview/index.js");
/* harmony import */ var _ShareReview__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ShareReview */ "./src/lib/common/components/ext/WriteMode/ShareReview/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var common_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! common/hooks */ "./src/lib/common/hooks/index.js");
/* harmony import */ var cc_Loader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! cc/Loader */ "./src/lib/common/components/Loader.js");
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-toast-notifications */ "./node_modules/react-toast-notifications/dist/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }











var log = common_utils__WEBPACK_IMPORTED_MODULE_5__.logger.extend('WriteMode');

var WriteModeWrapper = function WriteModeWrapper(_ref) {
  var domainKey = _ref.domainKey,
      uid = _ref.uid,
      props = _objectWithoutProperties(_ref, ["domainKey", "uid"]);

  var _useDomainPacket = (0,common_hooks__WEBPACK_IMPORTED_MODULE_3__.useDomainPacket)({
    domainKey: domainKey,
    userId: uid
  }),
      domainPacket = _useDomainPacket.data,
      refetchDomainPacket = _useDomainPacket.refetch,
      loading = _useDomainPacket.loading;

  if (loading) return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)(cc_Loader__WEBPACK_IMPORTED_MODULE_4__.Loader, {}); // todo: better match loader to content

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)(WriteMode, _objectSpread({
    domainKey: domainKey,
    uid: uid,
    domainPacket: domainPacket,
    refetchDomainPacket: refetchDomainPacket
  }, props));
};

var WriteMode = function WriteMode(_ref2) {
  var domainKey = _ref2.domainKey,
      address = _ref2.address,
      uid = _ref2.uid,
      domainPacket = _ref2.domainPacket,
      refetchDomainPacket = _ref2.refetchDomainPacket,
      currentUser = _ref2.currentUser,
      updateScoreBadge = _ref2.updateScoreBadge;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(domainPacket),
      _useState2 = _slicedToArray(_useState, 2),
      sharing = _useState2[0],
      setSharing = _useState2[1];

  var clearSharing = (0,common_hooks__WEBPACK_IMPORTED_MODULE_3__.useLinkCallback)(function () {
    return setSharing(null);
  }, []);

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(domainPacket),
      _useState4 = _slicedToArray(_useState3, 2),
      effectivePacket = _useState4[0],
      setEffectivePacket = _useState4[1]; // Layer of indirection so we can override domainPacket w/ local changes if failed to save


  var _useToasts = (0,react_toast_notifications__WEBPACK_IMPORTED_MODULE_6__.useToasts)(),
      addToast = _useToasts.addToast;

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    var _domainPacket$meta;

    if (!(domainPacket !== null && domainPacket !== void 0 && (_domainPacket$meta = domainPacket.meta) !== null && _domainPacket$meta !== void 0 && _domainPacket$meta.domainKey) || domainPacket.meta.domainKey !== domainKey) {
      clearSharing();
    } else {
      setSharing(domainPacket);
      setEffectivePacket(domainPacket);
      updateScoreBadge(); // TODO: is this best place? In ext triggers reloading browser Icon
    }
  }, [domainKey, domainPacket]);
  var onReviewSubmissionFailure = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(function (err, unsavedData) {
    addToast( /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: ["Unable to save your review changes! ", err]
    }), {
      appearance: 'warning',
      id: 'review-failed'
    });
    setEffectivePacket(unsavedData);
    clearSharing();
    updateScoreBadge(); // TODO: is this best place? In ext triggers reloading browser Icon
  }, [addToast, setEffectivePacket]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)("div", {
    className: "w-100 p-2",
    children: sharing ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)(_ShareReview__WEBPACK_IMPORTED_MODULE_1__.default, {
      domainKey: domainKey,
      sharing: sharing,
      backToWriting: clearSharing,
      currentUser: currentUser
    }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)(_WriteReview__WEBPACK_IMPORTED_MODULE_0__.default, {
      address: address,
      domainKey: domainKey,
      domainPacket: effectivePacket,
      refetchDomainPacket: refetchDomainPacket,
      uid: uid,
      setSharing: setSharing,
      onReviewSubmissionFailure: onReviewSubmissionFailure
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WriteModeWrapper);

/***/ }),

/***/ "./src/lib/common/hooks/useShareableDomainReviewComponents.js":
/*!********************************************************************!*\
  !*** ./src/lib/common/hooks/useShareableDomainReviewComponents.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var common_routes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! common/routes */ "./src/lib/common/routes.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./hooks */ "./src/lib/common/hooks/hooks.js");






var useShareableDomainReviewComponents = function useShareableDomainReviewComponents(_ref) {
  var review = _ref.review,
      domainKey = _ref.domainKey,
      author = _ref.author,
      alreadyParsed = _ref.alreadyParsed;
  var uid = (0,_hooks__WEBPACK_IMPORTED_MODULE_4__.useCurrentUserId)();
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
    if (alreadyParsed) return alreadyParsed;

    var contextualName = function contextualName(possessive) {
      if (uid && author.id === uid) {
        return 'my';
      } else {
        var base = (0,common_utils__WEBPACK_IMPORTED_MODULE_1__.handle)(author);
        return possessive ? "".concat(base, "'s") : base;
      }
    };

    var comment = review.comment,
        vote = review.vote,
        _review$hashtags = review.hashtags,
        hashtags = _review$hashtags === void 0 ? [] : _review$hashtags,
        _review$rules = review.rules,
        rules = _review$rules === void 0 ? [] : _review$rules;
    var isComplex = rules.length;
    var humanVote = "".concat(vote > 0 ? 'positive' : vote < 0 ? 'negative' : 'ambivalent').concat(isComplex ? ' (with complications)' : '');
    var url = common_routes__WEBPACK_IMPORTED_MODULE_2__.default.userDomainReviewUrl(author, domainKey);
    var displayHashtag = hashtags.length ? "#".concat(hashtags[0]) : null; // TODO: confirm we can't use multiple hashtags for FB

    var title = "".concat((0,common_utils__WEBPACK_IMPORTED_MODULE_1__.handle)(author), "'s take on ").concat(domainKey);
    var summary = "In short, generally ".concat(humanVote, "... but check out ").concat(contextualName(true), " full review of ").concat(domainKey, " for details.");
    var fbQuote = comment; // TODO: see how it renders, but probably add some callback to the site
    // Email being sent directly to another user should use "my vote" voice. Others are public postings that should probably use "Kali's vote" voice.

    var emailSubject = "".concat((0,lodash__WEBPACK_IMPORTED_MODULE_3__.capitalize)(contextualName(true)), " take on ").concat(domainKey);
    var emailBody = "In short, generally ".concat(humanVote, ". Check out the full review here:");
    return {
      url: url,
      title: title,
      summary: summary,
      emailBody: emailBody,
      emailSubject: emailSubject,
      fbQuote: fbQuote,
      displayHashtag: displayHashtag,
      hashtags: hashtags
    };
  }, [review, domainKey, author, alreadyParsed, uid]);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useShareableDomainReviewComponents);

/***/ }),

/***/ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Checkbox.js":
/*!**********************************************************************************!*\
  !*** ./src/lib/common/vendor/react-bootstrap-formik/components/Form/Checkbox.js ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Checkbox": () => (/* binding */ Checkbox)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Form.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils */ "./src/lib/common/vendor/react-bootstrap-formik/components/utils.js");
/* harmony import */ var _Group__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Group */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Group.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }









var Checkbox = function Checkbox(_ref) {
  var custom = _ref.custom,
      props = _objectWithoutProperties(_ref, ["custom"]);

  var _useFormikContext = (0,formik__WEBPACK_IMPORTED_MODULE_1__.useFormikContext)(),
      values = _useFormikContext.values,
      errors = _useFormikContext.errors,
      setFieldValue = _useFormikContext.setFieldValue;

  var _useContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_Group__WEBPACK_IMPORTED_MODULE_4__.GroupContext),
      _useContext$name = _useContext.name,
      groupName = _useContext$name === void 0 ? '' : _useContext$name;

  var _useField = (0,formik__WEBPACK_IMPORTED_MODULE_1__.useField)(props),
      _useField2 = _slicedToArray(_useField, 1),
      _useField2$ = _useField2[0],
      name = _useField2$.name,
      onBlur = _useField2$.onBlur;

  var isChecked = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
    return values[groupName].includes(name);
  }, [groupName, name, values]);
  var isInvalid = !!errors[groupName];
  var onChange = props.onChange;
  var handleChange = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function (e) {
    onChange && onChange(e);
    setFieldValue(groupName, isChecked ? values[groupName].filter(function (value) {
      return value !== name;
    }) : [].concat(_toConsumableArray(values[groupName]), [name]));
  }, [groupName, isChecked, name, onChange, setFieldValue, values]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.default.Check, _objectSpread(_objectSpread({}, props), {}, {
    id: name,
    type: "checkbox",
    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'is-invalid': isInvalid
    }),
    custom: custom,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.default.Check.Input, _objectSpread(_objectSpread({}, props), {}, {
      type: "checkbox",
      checked: isChecked,
      isInvalid: isInvalid,
      onChange: handleChange,
      onBlur: onBlur
    })), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.default.Check.Label, {
      title: props.title,
      children: props.label
    })]
  }));
};
Checkbox.defaultProps = {
  onChange: _utils__WEBPACK_IMPORTED_MODULE_3__.noop
};

/***/ }),

/***/ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Group.js":
/*!*******************************************************************************!*\
  !*** ./src/lib/common/vendor/react-bootstrap-formik/components/Form/Group.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GroupContext": () => (/* binding */ GroupContext),
/* harmony export */   "Group": () => (/* binding */ Group)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Form.js");
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






var GroupContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({});
var Group = function Group(_ref) {
  var label = _ref.label,
      helpText = _ref.helpText,
      error = _ref.error,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, ["label", "helpText", "error", "children"]);

  var _useField = (0,formik__WEBPACK_IMPORTED_MODULE_1__.useField)(props),
      _useField2 = _slicedToArray(_useField, 1),
      fieldError = _useField2[0].error;

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(GroupContext.Provider, {
    value: {
      name: props.name
    },
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.default.Group, _objectSpread(_objectSpread({}, props), {}, {
      children: [label && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.default.Label, {
        children: label
      }), children, /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.default.Control.Feedback, {
        type: "invalid",
        children: error !== null && error !== void 0 ? error : fieldError
      }), helpText && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.default.Text, {
        muted: true,
        children: helpText
      })]
    }))
  });
};

/***/ }),

/***/ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Input.js":
/*!*******************************************************************************!*\
  !*** ./src/lib/common/vendor/react-bootstrap-formik/components/Form/Input.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Input": () => (/* binding */ Input)
/* harmony export */ });
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Form.js");
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils */ "./src/lib/common/vendor/react-bootstrap-formik/components/utils.js");
/* harmony import */ var _Group__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Group */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Group.js");
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./hooks */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/hooks.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







var Input = function Input(_ref) {
  var label = _ref.label,
      helpText = _ref.helpText,
      groupClassName = _ref.groupClassName,
      props = _objectWithoutProperties(_ref, ["label", "helpText", "groupClassName"]);

  var _useField = (0,formik__WEBPACK_IMPORTED_MODULE_0__.useField)(props),
      _useField2 = _slicedToArray(_useField, 2),
      _useField2$ = _useField2[0],
      name = _useField2$.name,
      value = _useField2$.value,
      onBlur = _useField2$.onBlur,
      error = _useField2[1].error;

  var handleChange = (0,_hooks__WEBPACK_IMPORTED_MODULE_3__.useChange)(props);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_Group__WEBPACK_IMPORTED_MODULE_2__.Group, {
    name: name,
    controlId: name,
    label: label,
    helpText: helpText,
    error: error,
    className: groupClassName,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_5__.default.Control, _objectSpread(_objectSpread({}, props), {}, {
      name: name,
      value: value === null || value === void 0 ? void 0 : value.toString(),
      isInvalid: !!error,
      onChange: handleChange,
      onBlur: onBlur
    }))
  });
};
Input.defaultProps = {
  onChange: _utils__WEBPACK_IMPORTED_MODULE_1__.noop
};

/***/ }),

/***/ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Radio.js":
/*!*******************************************************************************!*\
  !*** ./src/lib/common/vendor/react-bootstrap-formik/components/Form/Radio.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Radio": () => (/* binding */ Radio)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Form.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils */ "./src/lib/common/vendor/react-bootstrap-formik/components/utils.js");
/* harmony import */ var _Group__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Group */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Group.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }









var Radio = function Radio(_ref) {
  var custom = _ref.custom,
      props = _objectWithoutProperties(_ref, ["custom"]);

  var _useFormikContext = (0,formik__WEBPACK_IMPORTED_MODULE_1__.useFormikContext)(),
      values = _useFormikContext.values,
      errors = _useFormikContext.errors,
      setFieldValue = _useFormikContext.setFieldValue;

  var _useContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_Group__WEBPACK_IMPORTED_MODULE_4__.GroupContext),
      _useContext$name = _useContext.name,
      groupName = _useContext$name === void 0 ? '' : _useContext$name;

  var _useField = (0,formik__WEBPACK_IMPORTED_MODULE_1__.useField)(props),
      _useField2 = _slicedToArray(_useField, 1),
      _useField2$ = _useField2[0],
      name = _useField2$.name,
      onBlur = _useField2$.onBlur;

  var isInvalid = !!errors[groupName];
  var onChange = props.onChange;
  var handleChange = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function (e) {
    onChange && onChange(e);
    setFieldValue(groupName, name);
  }, [groupName, name, onChange, setFieldValue]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.default.Check, _objectSpread(_objectSpread({}, props), {}, {
    id: name,
    name: groupName,
    type: "radio",
    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'is-invalid': isInvalid
    }),
    custom: custom,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.default.Check.Input, _objectSpread(_objectSpread({}, props), {}, {
      type: "radio",
      checked: values[groupName] === name,
      isInvalid: isInvalid,
      onChange: handleChange,
      onBlur: onBlur
    })), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.default.Check.Label, {
      title: props.title,
      children: props.label
    })]
  }));
};
Radio.defaultProps = {
  onChange: _utils__WEBPACK_IMPORTED_MODULE_3__.noop
};

/***/ }),

/***/ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Range.js":
/*!*******************************************************************************!*\
  !*** ./src/lib/common/vendor/react-bootstrap-formik/components/Form/Range.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Range": () => (/* binding */ Range)
/* harmony export */ });
/* harmony import */ var _Input__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Input */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Input.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



var Range = function Range(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_Input__WEBPACK_IMPORTED_MODULE_0__.Input, _objectSpread(_objectSpread({}, props), {}, {
    type: "range"
  }));
};

/***/ }),

/***/ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Select.js":
/*!********************************************************************************!*\
  !*** ./src/lib/common/vendor/react-bootstrap-formik/components/Form/Select.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Select": () => (/* binding */ Select)
/* harmony export */ });
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Form.js");
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils */ "./src/lib/common/vendor/react-bootstrap-formik/components/utils.js");
/* harmony import */ var _Group__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Group */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Group.js");
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./hooks */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/hooks.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }








var Select = function Select(_ref) {
  var label = _ref.label,
      helpText = _ref.helpText,
      placeholder = _ref.placeholder,
      children = _ref.children,
      groupClassName = _ref.groupClassName,
      props = _objectWithoutProperties(_ref, ["label", "helpText", "placeholder", "children", "groupClassName"]);

  var _useField = (0,formik__WEBPACK_IMPORTED_MODULE_0__.useField)(props),
      _useField2 = _slicedToArray(_useField, 2),
      _useField2$ = _useField2[0],
      name = _useField2$.name,
      value = _useField2$.value,
      onBlur = _useField2$.onBlur,
      error = _useField2[1].error;

  var handleChange = (0,_hooks__WEBPACK_IMPORTED_MODULE_3__.useChange)(props);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_Group__WEBPACK_IMPORTED_MODULE_2__.Group, {
    name: name,
    controlId: name,
    label: label,
    helpText: helpText,
    error: error,
    className: groupClassName,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_5__.default.Control, _objectSpread(_objectSpread({}, props), {}, {
      as: "select",
      name: name,
      value: value === null || value === void 0 ? void 0 : value.toString(),
      isInvalid: !!error,
      onChange: handleChange,
      onBlur: onBlur,
      children: [placeholder && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("option", {
        value: "",
        disabled: true,
        children: placeholder
      }), children]
    }))
  });
};
Select.defaultProps = {
  onChange: _utils__WEBPACK_IMPORTED_MODULE_1__.noop
};

/***/ }),

/***/ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Submit.js":
/*!********************************************************************************!*\
  !*** ./src/lib/common/vendor/react-bootstrap-formik/components/Form/Submit.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Submit": () => (/* binding */ Submit)
/* harmony export */ });
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Button.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Spinner.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var Submit = function Submit(_ref) {
  var withSpinner = _ref.withSpinner,
      props = _objectWithoutProperties(_ref, ["withSpinner"]);

  var _useFormikContext = (0,formik__WEBPACK_IMPORTED_MODULE_0__.useFormikContext)(),
      isSubmitting = _useFormikContext.isSubmitting;

  var disabled = isSubmitting || props.disabled;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.default, _objectSpread(_objectSpread({
    type: "submit"
  }, props), {}, {
    disabled: disabled,
    children: [withSpinner && isSubmitting ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.default, {
      size: "sm",
      animation: "border",
      className: "mr-1"
    }) : null, props.children]
  }));
};
Submit.defaultProps = {
  withSpinner: true
};

/***/ }),

/***/ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Textarea.js":
/*!**********************************************************************************!*\
  !*** ./src/lib/common/vendor/react-bootstrap-formik/components/Form/Textarea.js ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Textarea": () => (/* binding */ Textarea)
/* harmony export */ });
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Form.js");
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils */ "./src/lib/common/vendor/react-bootstrap-formik/components/utils.js");
/* harmony import */ var _Group__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Group */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Group.js");
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./hooks */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/hooks.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







var Textarea = function Textarea(_ref) {
  var label = _ref.label,
      helpText = _ref.helpText,
      groupClassName = _ref.groupClassName,
      props = _objectWithoutProperties(_ref, ["label", "helpText", "groupClassName"]);

  var _useField = (0,formik__WEBPACK_IMPORTED_MODULE_0__.useField)(props),
      _useField2 = _slicedToArray(_useField, 2),
      _useField2$ = _useField2[0],
      name = _useField2$.name,
      value = _useField2$.value,
      onBlur = _useField2$.onBlur,
      error = _useField2[1].error;

  var handleChange = (0,_hooks__WEBPACK_IMPORTED_MODULE_3__.useChange)(props);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_Group__WEBPACK_IMPORTED_MODULE_2__.Group, {
    name: name,
    controlId: name,
    label: label,
    helpText: helpText,
    error: error,
    className: groupClassName,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_5__.default.Control, _objectSpread(_objectSpread({}, props), {}, {
      as: "textarea",
      name: name,
      value: value === null || value === void 0 ? void 0 : value.toString(),
      isInvalid: !!error,
      onChange: handleChange,
      onBlur: onBlur
    }))
  });
};
Textarea.defaultProps = {
  onChange: _utils__WEBPACK_IMPORTED_MODULE_1__.noop
};

/***/ }),

/***/ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/hooks.js":
/*!*******************************************************************************!*\
  !*** ./src/lib/common/vendor/react-bootstrap-formik/components/Form/hooks.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useChange": () => (/* binding */ useChange)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }



function useChange(props) {
  var _useField = (0,formik__WEBPACK_IMPORTED_MODULE_1__.useField)(props),
      _useField2 = _slicedToArray(_useField, 1),
      onChange = _useField2[0].onChange;

  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function (e) {
    return props.onChange && props.onChange(e), onChange(e);
  }, [onChange, props.onChange]);
}

/***/ }),

/***/ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/index.js":
/*!*******************************************************************************!*\
  !*** ./src/lib/common/vendor/react-bootstrap-formik/components/Form/index.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Form": () => (/* binding */ Form)
/* harmony export */ });
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Form.js");
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var _Group__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Group */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Group.js");
/* harmony import */ var _Input__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Input */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Input.js");
/* harmony import */ var _Select__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Select */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Select.js");
/* harmony import */ var _Textarea__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Textarea */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Textarea.js");
/* harmony import */ var _Checkbox__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Checkbox */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Checkbox.js");
/* harmony import */ var _Radio__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Radio */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Radio.js");
/* harmony import */ var _Range__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Range */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Range.js");
/* harmony import */ var _Submit__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Submit */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/Submit.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }












var Form = function Form(_ref) {
  var className = _ref.className,
      _children = _ref.children,
      props = _objectWithoutProperties(_ref, ["className", "children"]);

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(formik__WEBPACK_IMPORTED_MODULE_0__.Formik, _objectSpread(_objectSpread({}, props), {}, {
    children: function children(formikProps) {
      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_10__.default, {
        className: className,
        onSubmit: formikProps.handleSubmit,
        children: typeof _children === 'function' ? _children(formikProps) : React.Children.count(_children) === 1 ? React.Children.only(_children) : null
      });
    }
  }));
};
Form.Group = _Group__WEBPACK_IMPORTED_MODULE_1__.Group;
Form.Input = _Input__WEBPACK_IMPORTED_MODULE_2__.Input;
Form.Textarea = _Textarea__WEBPACK_IMPORTED_MODULE_4__.Textarea;
Form.Select = _Select__WEBPACK_IMPORTED_MODULE_3__.Select;
Form.Checkbox = _Checkbox__WEBPACK_IMPORTED_MODULE_5__.Checkbox;
Form.Radio = _Radio__WEBPACK_IMPORTED_MODULE_6__.Radio;
Form.Range = _Range__WEBPACK_IMPORTED_MODULE_7__.Range;
Form.Submit = _Submit__WEBPACK_IMPORTED_MODULE_8__.Submit;

/***/ }),

/***/ "./src/lib/common/vendor/react-bootstrap-formik/components/utils.js":
/*!**************************************************************************!*\
  !*** ./src/lib/common/vendor/react-bootstrap-formik/components/utils.js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "noop": () => (/* binding */ noop)
/* harmony export */ });
var noop = function noop() {
  return null;
};

/***/ }),

/***/ "./src/lib/common/vendor/react-bootstrap-formik/index.js":
/*!***************************************************************!*\
  !*** ./src/lib/common/vendor/react-bootstrap-formik/index.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Form": () => (/* reexport safe */ _components_Form__WEBPACK_IMPORTED_MODULE_0__.Form),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_Form__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/Form */ "./src/lib/common/vendor/react-bootstrap-formik/components/Form/index.js");


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_components_Form__WEBPACK_IMPORTED_MODULE_0__.Form);

/***/ }),

/***/ "./src/popup/containers/WriteModeContainer/WriteModeContainer.jsx":
/*!************************************************************************!*\
  !*** ./src/popup/containers/WriteModeContainer/WriteModeContainer.jsx ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var lib_messaging_fromFrontend__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lib/messaging/fromFrontend */ "./src/lib/messaging/fromFrontend/index.js");
/* harmony import */ var cc_ext_WriteMode__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! cc/ext/WriteMode */ "./src/lib/common/components/ext/WriteMode/index.js");
/* harmony import */ var common_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! common/hooks */ "./src/lib/common/hooks/index.js");
/* harmony import */ var cc_Empty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! cc/Empty */ "./src/lib/common/components/Empty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");







var WriteModeContainer = function WriteModeContainer(_ref) {
  var address = _ref.address,
      domainKey = _ref.domainKey,
      tabId = _ref.tabId;
  // TODO: shouldn't need both..
  var uid = (0,common_hooks__WEBPACK_IMPORTED_MODULE_2__.useCurrentUserId)();
  var currentUser = (0,common_hooks__WEBPACK_IMPORTED_MODULE_2__.useCurrentUser)();
  var updateScoreBadge = (0,react__WEBPACK_IMPORTED_MODULE_4__.useCallback)(function () {
    lib_messaging_fromFrontend__WEBPACK_IMPORTED_MODULE_0__.heyBackend.updateScoreBadge(tabId, address);
  }, [tabId, address]); // behind auth gate, so these should never be undefined...

  if (!uid || !currentUser) return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(cc_Empty__WEBPACK_IMPORTED_MODULE_3__.default, {
    children: "Authentication required"
  }); // TODO: domainPacket?

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(cc_ext_WriteMode__WEBPACK_IMPORTED_MODULE_1__.default, {
    domainKey: domainKey,
    address: address,
    uid: uid,
    currentUser: currentUser,
    updateScoreBadge: updateScoreBadge
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WriteModeContainer);

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/sass-loader/dist/cjs.js!./src/lib/common/components/ext/WriteMode/WriteReview/RuleFormModal/RuleFormModal.module.css":
/*!*********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/sass-loader/dist/cjs.js!./src/lib/common/components/ext/WriteMode/WriteReview/RuleFormModal/RuleFormModal.module.css ***!
  \*********************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "._2KptqvgqMs6eUuX3648GzC {\n  padding: 4px !important; }\n\n._2FiP5e-Xy8qLb9JatkLaV5 {\n  padding: 2px 0.5rem;\n  height: auto; }\n\n._1-gy3QStfXWHifhQNhT8Xj {\n  padding: 0px 8px; }\n", "",{"version":3,"sources":["webpack://./src/lib/common/components/ext/WriteMode/WriteReview/RuleFormModal/RuleFormModal.module.css"],"names":[],"mappings":"AAAA;EACE,uBAAuB,EAAA;;AAGzB;EACE,mBAAmB;EACnB,YAAY,EAAA;;AAGd;EACE,gBAAgB,EAAA","sourcesContent":[".dropdownIndicator {\n  padding: 4px !important;\n}\n\n.textInput {\n  padding: 2px 0.5rem;\n  height: auto;\n}\n\n.textResetBtn {\n  padding: 0px 8px;\n}\n"],"sourceRoot":""}]);
// Exports
___CSS_LOADER_EXPORT___.locals = {
	"dropdownIndicator": "_2KptqvgqMs6eUuX3648GzC",
	"textInput": "_2FiP5e-Xy8qLb9JatkLaV5",
	"textResetBtn": "_1-gy3QStfXWHifhQNhT8Xj"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/sass-loader/dist/cjs.js!./src/lib/common/components/ext/WriteMode/WriteReview/Rules.module.scss":
/*!************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/sass-loader/dist/cjs.js!./src/lib/common/components/ext/WriteMode/WriteReview/Rules.module.scss ***!
  \************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "._30CkG9u4XFaRZ0vF87FZSQ {\n  cursor: move;\n  cursor: grab !important;\n  font-size: 1.2rem;\n  margin: -5px 0; }\n", "",{"version":3,"sources":["webpack://./src/lib/common/components/ext/WriteMode/WriteReview/Rules.module.scss"],"names":[],"mappings":"AACA;EACE,YAAY;EACZ,uBAAuB;EACvB,iBAAiB;EACjB,cAAc,EAAA","sourcesContent":["// Note: cursor moved to grabbing and back again via ugly manual onSortStart/onSortEnd callbacks - https://github.com/clauderic/react-sortable-hoc/issues/328\n.dragHandle {\n  cursor: move;\n  cursor: grab !important;\n  font-size: 1.2rem;\n  margin: -5px 0;\n}\n"],"sourceRoot":""}]);
// Exports
___CSS_LOADER_EXPORT___.locals = {
	"dragHandle": "_30CkG9u4XFaRZ0vF87FZSQ"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./src/lib/common/components/ext/WriteMode/WriteReview/RuleFormModal/RuleFormModal.module.css":
/*!****************************************************************************************************!*\
  !*** ./src/lib/common/components/ext/WriteMode/WriteReview/RuleFormModal/RuleFormModal.module.css ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_sass_loader_dist_cjs_js_RuleFormModal_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../../../node_modules/sass-loader/dist/cjs.js!./RuleFormModal.module.css */ "./node_modules/css-loader/dist/cjs.js!./node_modules/sass-loader/dist/cjs.js!./src/lib/common/components/ext/WriteMode/WriteReview/RuleFormModal/RuleFormModal.module.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_sass_loader_dist_cjs_js_RuleFormModal_module_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_sass_loader_dist_cjs_js_RuleFormModal_module_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./src/lib/common/components/ext/WriteMode/WriteReview/Rules.module.scss":
/*!*******************************************************************************!*\
  !*** ./src/lib/common/components/ext/WriteMode/WriteReview/Rules.module.scss ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_sass_loader_dist_cjs_js_Rules_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../../node_modules/sass-loader/dist/cjs.js!./Rules.module.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/sass-loader/dist/cjs.js!./src/lib/common/components/ext/WriteMode/WriteReview/Rules.module.scss");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_sass_loader_dist_cjs_js_Rules_module_scss__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_sass_loader_dist_cjs_js_Rules_module_scss__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ })

}]);
//# sourceMappingURL=src_popup_containers_WriteModeContainer_WriteModeContainer_jsx.js.map