(self["webpackChunkeditor_browser_extension"] = self["webpackChunkeditor_browser_extension"] || []).push([["src_popup_containers_ReadModeContainer_ReadModeContainer_jsx"],{

/***/ "./src/lib/common/components/Ratings.js":
/*!**********************************************!*\
  !*** ./src/lib/common/components/Ratings.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PercentPositiveText": () => (/* binding */ PercentPositiveText),
/* harmony export */   "PercentPositiveBar": () => (/* binding */ PercentPositiveBar),
/* harmony export */   "MultiPercentBar": () => (/* binding */ MultiPercentBar),
/* harmony export */   "MultiPercentText": () => (/* binding */ MultiPercentText)
/* harmony export */ });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }






var PercentPositiveText = function PercentPositiveText(_ref) {
  var className = _ref.className,
      overallVote = _ref.overallVote,
      numPositive = _ref.numPositive,
      numTotal = _ref.numTotal;
  var numNegative = numTotal - numPositive;
  var numCounting = Math.max(numPositive, numNegative);
  var desc = numTotal === 1 ? 'From one review' : numTotal === numCounting ? "Unanimous across ".concat(numTotal, " reviews") : overallVote === 0 ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: ["Even split across ", numTotal, " reviews"]
  }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [numCounting, " of ", numTotal]
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("div", {
    className: className,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("p", {
      className: "lead text-center mb-0",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("small", {
        children: desc
      })
    })
  });
};
var PercentPositiveBar = function PercentPositiveBar(_ref2) {
  var className = _ref2.className,
      _ref2$height = _ref2.height,
      height = _ref2$height === void 0 ? 2 : _ref2$height,
      numPositive = _ref2.numPositive,
      numTotal = _ref2.numTotal;
  var numNegative = numTotal - numPositive;
  var numCounting = Math.max(numPositive, numNegative);
  var percent = (numCounting / numTotal * 100).toFixed(2); // TODO: fix-style

  var heightStyle = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
    return {
      height: "".concat(height, "px")
    };
  }, [height]);
  var onStyle = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
    return {
      width: "".concat(percent, "%")
    };
  }, [percent]);
  var offStyle = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
    return {
      width: "".concat(100 - percent, "%")
    };
  }, [percent]);
  var mood = numTotal === 0 || numNegative === numPositive ? 'secondary' : numPositive > numNegative ? 'success' : 'danger';
  var invMood = mood === 'secondary' ? 'dark' : mood === 'success' ? 'danger' : 'success';
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("div", {
    className: className,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
      className: "progress",
      style: heightStyle,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("div", {
        className: "progress-bar bg-".concat(mood, " text-dark"),
        role: "progressbar",
        style: onStyle,
        "aria-valuenow": percent,
        "aria-valuemin": "0",
        "aria-valuemax": "100"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("div", {
        className: "progress-bar bg-".concat(invMood),
        role: "progressbar",
        style: offStyle,
        "aria-valuenow": 100 - percent,
        "aria-valuemin": "0",
        "aria-valuemax": "100"
      })]
    })
  });
}; // Expects components to be object of { mood: num }

var MultiPercentBar = function MultiPercentBar(_ref3) {
  var className = _ref3.className,
      _ref3$height = _ref3.height,
      height = _ref3$height === void 0 ? 2 : _ref3$height,
      components = _ref3.components;
  var numTotal = Object.values(components).reduce(function (a, b) {
    return a + b;
  });
  var tuples = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.sortBy)(Object.entries(components), function (_ref4) {
    var _ref5 = _slicedToArray(_ref4, 2),
        key = _ref5[0],
        num = _ref5[1];

    return -num;
  });
  var i = 0; // TODO: fix-style

  var heightStyle = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
    return {
      height: "".concat(height, "px")
    };
  }, [height]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("div", {
    className: className,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("div", {
      className: "progress",
      style: heightStyle,
      children: tuples.map(function (_ref6) {
        var _ref7 = _slicedToArray(_ref6, 2),
            mood = _ref7[0],
            num = _ref7[1];

        var percent = num / numTotal * 100;
        i = i + percent; // TODO: fix-style

        var widthStyle = {
          width: "".concat(percent.toFixed(2), "%")
        };
        return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("div", {
          className: "progress-bar bg-".concat(mood, " text-dark"),
          role: "progressbar",
          style: widthStyle,
          "aria-valuenow": i,
          "aria-valuemin": "0",
          "aria-valuemax": "100"
        }, mood);
      })
    })
  });
};
var MultiPercentText = function MultiPercentText(_ref8) {
  var className = _ref8.className,
      overallVote = _ref8.overallVote,
      _ref8$numPositive = _ref8.numPositive,
      numPositive = _ref8$numPositive === void 0 ? 0 : _ref8$numPositive,
      _ref8$numNegative = _ref8.numNegative,
      numNegative = _ref8$numNegative === void 0 ? 0 : _ref8$numNegative,
      _ref8$numNeutral = _ref8.numNeutral,
      numNeutral = _ref8$numNeutral === void 0 ? 0 : _ref8$numNeutral;
  var numTotal = numPositive + numNegative + numNeutral;
  var numCounting = Math.max(numPositive, numNegative, numNeutral);
  var desc = numTotal === 1 ? 'From one review' : numTotal === numCounting ? "Unanimous across ".concat(numTotal, " reviews") : overallVote === 0 ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: ["Even split across ", numTotal, " reviews"]
  }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [numCounting, " of ", numTotal]
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("div", {
    className: className,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("p", {
      className: "lead text-center mb-0",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("small", {
        children: desc
      })
    })
  });
};

/***/ }),

/***/ "./src/lib/common/components/ext/ReadMode/ReadModeContent/Details/ScoredReviewLineItem.js":
/*!************************************************************************************************!*\
  !*** ./src/lib/common/components/ext/ReadMode/ReadModeContent/Details/ScoredReviewLineItem.js ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var cc_Ratings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cc/Ratings */ "./src/lib/common/components/Ratings.js");
/* harmony import */ var cc_Hashtags__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! cc/Hashtags */ "./src/lib/common/components/Hashtags.js");
/* harmony import */ var common_logic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! common/logic */ "./src/lib/common/logic/index.js");
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var common_routes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! common/routes */ "./src/lib/common/routes.js");
/* harmony import */ var universal_components_UniversalLink__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! universal/components/UniversalLink */ "./src/lib/universal-interface/components/UniversalLink.js");
/* harmony import */ var cc_TimeAgo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! cc/TimeAgo */ "./src/lib/common/components/TimeAgo.js");
/* harmony import */ var cc_Popover__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! cc/Popover */ "./src/lib/common/components/Popover.js");
/* harmony import */ var cc_VoteEmote__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! cc/VoteEmote */ "./src/lib/common/components/VoteEmote.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");













var PopoverComment = function PopoverComment(_ref) {
  var user = _ref.user,
      comment = _ref.comment,
      onPageRule = _ref.onPageRule,
      suffix = _ref.suffix;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("blockquote", {
    className: "alert alert-".concat(onPageRule ? 'warning' : 'info', " my-1"),
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("p", {
      className: "mb-0",
      children: comment
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("footer", {
      className: "blockquote-footer",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("cite", {
        children: (0,common_utils__WEBPACK_IMPORTED_MODULE_3__.handle)(user)
      }), suffix]
    })]
  });
};

var ReviewDetailPopover = function ReviewDetailPopover(_ref2) {
  var review = _ref2.review,
      matchedRule = _ref2.matchedRule,
      user = _ref2.user;
  var comment = review.comment;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("p", {
      className: "mb-0",
      children: matchedRule ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
        children: ["Rating (", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(cc_VoteEmote__WEBPACK_IMPORTED_MODULE_8__.default, {
          vote: matchedRule.vote
        }), ") only applies to pages on this domain where:"]
      }) : 'Rating applies to entire domain.'
    }), matchedRule && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(common_logic__WEBPACK_IMPORTED_MODULE_2__.HumanizedRule, {
      rule: matchedRule,
      className: "mr-2"
    }), (matchedRule === null || matchedRule === void 0 ? void 0 : matchedRule.comment) && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(PopoverComment, {
      user: user,
      comment: matchedRule.comment,
      suffix: " on this specific rule",
      onPageRule: true
    }), matchedRule && comment && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("hr", {
      className: "my-2"
    }), comment && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(PopoverComment, {
      user: user,
      comment: comment,
      suffix: matchedRule !== null && matchedRule !== void 0 && matchedRule.comment ? ' on the domain in general' : null
    })]
  });
}; // TODO: pull from actual data... if we want to add this in.
// (would need to write the data -- replace bar w/ tristate selector on hover to rate from extension)
// Punting for now - we need coverage breadth before we need filtering within the coverage we have - but
// may be easy extension interactivity to add in later.


var ReviewLineItemRatingsSummary = function ReviewLineItemRatingsSummary(_ref3) {
  var review = _ref3.review;
  var reviewsSummary = review.reviewsSummary || {
    numPositive: 3,
    numTotal: 4
  };
  var _reviewsSummary$numPo = reviewsSummary.numPositive,
      numPositive = _reviewsSummary$numPo === void 0 ? 0 : _reviewsSummary$numPo,
      _reviewsSummary$numTo = reviewsSummary.numTotal,
      numTotal = _reviewsSummary$numTo === void 0 ? 4 : _reviewsSummary$numTo;
  if (numTotal === 0) return null;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
    className: "text-muted",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("small", {
      children: (0,common_utils__WEBPACK_IMPORTED_MODULE_3__.plur)(numTotal, 'ratings')
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(cc_Ratings__WEBPACK_IMPORTED_MODULE_0__.PercentPositiveBar, {
      numPositive: numPositive,
      numTotal: numTotal
    })]
  });
};

var ScoredReviewLineItem = function ScoredReviewLineItem(_ref4) {
  var scored = _ref4.scored,
      domainKey = _ref4.domainKey,
      idx = _ref4.idx;
  var matchedRule = scored.matchedRule,
      review = scored.fullDomainPacket,
      user = scored.user;
  var timestamp = review.meta.updatedAt || review.meta.createdAt;
  var rulePop = "rule-".concat(idx);
  var hasComment = review.comment || (matchedRule === null || matchedRule === void 0 ? void 0 : matchedRule.comment);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("li", {
    className: "list-group-item",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
      className: "d-flex align-items-center",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(cc_Popover__WEBPACK_IMPORTED_MODULE_7__.default, {
        title: matchedRule ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
          children: ["Page Rule (domain default: ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(cc_VoteEmote__WEBPACK_IMPORTED_MODULE_8__.default, {
            vote: review.vote
          }), ")"]
        }) : 'Domain Review' // TODO page rule show domain dfault
        ,
        content: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(ReviewDetailPopover, {
          review: review,
          matchedRule: matchedRule,
          user: user
        }),
        trigger: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
          id: rulePop,
          role: "button",
          className: "badge badge-".concat(matchedRule ? 'dark' : 'secondary', " mr-2"),
          children: [matchedRule ? 'Page' : 'Domain', hasComment && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
            children: " \uD83D\uDCAC"
          })]
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
        className: "flex-grow-1",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(universal_components_UniversalLink__WEBPACK_IMPORTED_MODULE_5__.default, {
          title: (0,common_utils__WEBPACK_IMPORTED_MODULE_3__.handle)(user),
          href: common_routes__WEBPACK_IMPORTED_MODULE_4__.default.userDomainReviewUrl(user, domainKey),
          className: "mr-2"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(cc_Hashtags__WEBPACK_IMPORTED_MODULE_1__.default, {
          hashtags: review.hashtags,
          className: "d-inline-flex small",
          tagClassName: "text-muted",
          link: true
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(cc_TimeAgo__WEBPACK_IMPORTED_MODULE_6__.default, {
        datetime: timestamp,
        className: "ml-2 small text-muted text-nowrap"
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ScoredReviewLineItem);

/***/ }),

/***/ "./src/lib/common/components/ext/ReadMode/ReadModeContent/Details/index.js":
/*!*********************************************************************************!*\
  !*** ./src/lib/common/components/ext/ReadMode/ReadModeContent/Details/index.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Card.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Accordion.js");
/* harmony import */ var cc_VoteEmote__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cc/VoteEmote */ "./src/lib/common/components/VoteEmote.js");
/* harmony import */ var _ScoredReviewLineItem__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ScoredReviewLineItem */ "./src/lib/common/components/ext/ReadMode/ReadModeContent/Details/ScoredReviewLineItem.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");






var ScoreSection = function ScoreSection(_ref) {
  var effectiveVote = _ref.effectiveVote,
      title = _ref.title,
      scores = _ref.scores,
      numTotal = _ref.numTotal,
      domainKey = _ref.domainKey;
  if (scores.length === 0 && effectiveVote === 0) return null; // No need to display empty Neutral section

  var mood = (0,cc_VoteEmote__WEBPACK_IMPORTED_MODULE_0__.getMood)(effectiveVote);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.default, {
    className: "rounded-0",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.default.Toggle, {
      as: react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.default.Header,
      eventKey: "tab-".concat(effectiveVote),
      className: "d-flex justify-content-between align-items-center border-bottom",
      role: "button",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
        className: "h6 mb-0",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(cc_VoteEmote__WEBPACK_IMPORTED_MODULE_0__.default, {
          vote: effectiveVote,
          className: "mr-2"
        }), title]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("span", {
        className: "badge badge-pill badge-".concat(mood),
        children: [scores.length, " / ", numTotal]
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.default.Collapse, {
      eventKey: "tab-".concat(effectiveVote),
      children: scores.length === 0 ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("p", {
        className: "lead my-3 text-muted text-center",
        children: ["No ", title.toLowerCase(), " reviews to show."]
      }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("ul", {
        className: "list-group list-group-flush",
        children: scores.map(function (scored, idx) {
          return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_ScoredReviewLineItem__WEBPACK_IMPORTED_MODULE_1__.default, {
            idx: "".concat(title, "-").concat(idx),
            scored: scored,
            domainKey: domainKey
          }, idx);
        })
      })
    })]
  });
};

var Details = function Details(_ref2) {
  var _ref2$positive = _ref2.positive,
      positive = _ref2$positive === void 0 ? [] : _ref2$positive,
      _ref2$negative = _ref2.negative,
      negative = _ref2$negative === void 0 ? [] : _ref2$negative,
      _ref2$neutral = _ref2.neutral,
      neutral = _ref2$neutral === void 0 ? [] : _ref2$neutral,
      domainKey = _ref2.domainKey;
  var defaultTab = positive.length >= negative.length && positive.length >= neutral.length ? 1 : negative.length > neutral.length ? -1 : 0;
  var numTotal = positive.length + negative.length + neutral.length;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.default, {
    defaultActiveKey: "tab-".concat(defaultTab),
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(ScoreSection, {
      domainKey: domainKey,
      title: "Positive",
      effectiveVote: 1,
      scores: positive,
      numTotal: numTotal
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(ScoreSection, {
      domainKey: domainKey,
      title: "Neutral",
      effectiveVote: 0,
      scores: neutral,
      numTotal: numTotal
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(ScoreSection, {
      domainKey: domainKey,
      title: "Negative",
      effectiveVote: -1,
      scores: negative,
      numTotal: numTotal
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Details);

/***/ }),

/***/ "./src/lib/common/components/ext/ReadMode/ReadModeContent/OverallRating/DisplayCurrentPage.js":
/*!****************************************************************************************************!*\
  !*** ./src/lib/common/components/ext/ReadMode/ReadModeContent/OverallRating/DisplayCurrentPage.js ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var common_logic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/logic */ "./src/lib/common/logic/index.js");
/* harmony import */ var cc_Popover__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! cc/Popover */ "./src/lib/common/components/Popover.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }







var TableRow = function TableRow(_ref) {
  var label = _ref.label,
      value = _ref.value,
      valueObject = _ref.valueObject;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("tr", {
    className: "small",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("th", {
      scope: "row",
      children: label
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("td", {
      className: "text-monospace",
      children: Object.entries(valueObject || {}).length ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("dl", {
        className: "row mb-0",
        children: Object.entries(valueObject).map(function (_ref2) {
          var _ref3 = _slicedToArray(_ref2, 2),
              key = _ref3[0],
              val = _ref3[1];

          return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("dt", {
              className: "col",
              children: key
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("div", {
              className: "col",
              children: "="
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("dd", {
              className: "col mb-0",
              children: val
            })]
          });
        })
      }) : value !== null && value !== void 0 && value.length ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
        children: value
      }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("span", {
        className: "font-italic",
        children: "none"
      })
    })]
  });
};

var DisplayCurrentPage = function DisplayCurrentPage(_ref4) {
  var address = _ref4.address;

  // TODO: only parse this once per load... just pull from redux here
  var _urlDataFromAddress = (0,common_logic__WEBPACK_IMPORTED_MODULE_0__.urlDataFromAddress)(address),
      path = _urlDataFromAddress.path,
      domainKey = _urlDataFromAddress.domainKey,
      subdomain = _urlDataFromAddress.subdomain,
      params = _urlDataFromAddress.params;

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(cc_Popover__WEBPACK_IMPORTED_MODULE_1__.default, {
    title: "Current URL Components",
    placement: "bottom" // overrideTrigger={['click']}
    ,
    trigger: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
      children: ["Current path: ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("mark", {
        className: "text-break",
        children: path
      })]
    }),
    noBodyPadding: true,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("table", {
      className: "table table-responsive w-100 mb-0",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("tbody", {
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(TableRow, {
          label: "Domain",
          value: domainKey
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(TableRow, {
          label: "Subdomain",
          value: subdomain
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(TableRow, {
          label: "Path",
          value: path
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(TableRow, {
          label: "Params",
          valueObject: params
        })]
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DisplayCurrentPage);

/***/ }),

/***/ "./src/lib/common/components/ext/ReadMode/ReadModeContent/OverallRating/index.js":
/*!***************************************************************************************!*\
  !*** ./src/lib/common/components/ext/ReadMode/ReadModeContent/OverallRating/index.js ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var cc_VoteEmote__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cc/VoteEmote */ "./src/lib/common/components/VoteEmote.js");
/* harmony import */ var cc_Ratings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! cc/Ratings */ "./src/lib/common/components/Ratings.js");
/* harmony import */ var _DisplayCurrentPage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./DisplayCurrentPage */ "./src/lib/common/components/ext/ReadMode/ReadModeContent/OverallRating/DisplayCurrentPage.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");







var OverallRating = function OverallRating(_ref) {
  var address = _ref.address,
      mood = _ref.mood,
      overallVote = _ref.overallVote,
      numPositive = _ref.numPositive,
      numNegative = _ref.numNegative,
      numNeutral = _ref.numNeutral,
      onDetailToggle = _ref.onDetailToggle;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("div", {
      className: "text-center my-0 alert alert-".concat(mood, " small rounded-0"),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(_DisplayCurrentPage__WEBPACK_IMPORTED_MODULE_2__.default, {
        address: address
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("div", {
      className: "jumbotron jumbotron-fluid bg-".concat(mood, " mb-0 pb-3"),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
        className: "container-fluid px-2",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          className: "alert alert-light mx-5 mb-0",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("h1", {
            className: "display-4 text-center",
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(cc_VoteEmote__WEBPACK_IMPORTED_MODULE_0__.default, {
              vote: overallVote,
              className: "p-1"
            })
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(cc_Ratings__WEBPACK_IMPORTED_MODULE_1__.MultiPercentBar, {
            components: {
              success: numPositive,
              'secondary-light': numNeutral,
              danger: numNegative
            }
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(cc_Ratings__WEBPACK_IMPORTED_MODULE_1__.MultiPercentText, {
            className: "mt-2",
            overallVote: overallVote,
            mood: mood,
            numPositive: numPositive,
            numNeutral: numNeutral,
            numNegative: numNegative
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("div", {
          className: "text-center mt-3",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("a", {
            className: "btn btn-".concat(mood, " btn-large"),
            href: "#",
            role: "button",
            onClick: onDetailToggle,
            children: "Details..."
          })
        })]
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OverallRating);

/***/ }),

/***/ "./src/lib/common/components/ext/ReadMode/ReadModeContent/index.js":
/*!*************************************************************************!*\
  !*** ./src/lib/common/components/ext/ReadMode/ReadModeContent/index.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var cc_VoteEmote__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cc/VoteEmote */ "./src/lib/common/components/VoteEmote.js");
/* harmony import */ var cc_Loader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! cc/Loader */ "./src/lib/common/components/Loader.js");
/* harmony import */ var _OverallRating__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./OverallRating */ "./src/lib/common/components/ext/ReadMode/ReadModeContent/OverallRating/index.js");
/* harmony import */ var _Details__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Details */ "./src/lib/common/components/ext/ReadMode/ReadModeContent/Details/index.js");
/* harmony import */ var common_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! common/hooks */ "./src/lib/common/hooks/index.js");
/* harmony import */ var cc_Empty__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! cc/Empty */ "./src/lib/common/components/Empty.js");
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");






 // TODO: add toggle between domain defaults and page level scores?
// TODO: easy toggle between domain as a whole (only non-complex rules OR those with a default set) vs. this specific URL (all counted, but some might be neutral)





var ReadModeContent = function ReadModeContent(_ref) {
  var domainKey = _ref.domainKey,
      address = _ref.address,
      activeUids = _ref.activeUids,
      candidateUsers = _ref.candidateUsers,
      recceUser = _ref.recceUser,
      showDetails = _ref.showDetails,
      toggleDetails = _ref.toggleDetails;

  var _useDomainReviewsByUs = (0,common_hooks__WEBPACK_IMPORTED_MODULE_4__.useDomainReviewsByUserIds)({
    domainKey: domainKey,
    byUserIds: activeUids
  }),
      allReviews = _useDomainReviewsByUs.data,
      loading = _useDomainReviewsByUs.loading;

  var _useScoreAddressAgain = (0,common_hooks__WEBPACK_IMPORTED_MODULE_4__.useScoreAddressAgainstReviews)(address, allReviews, candidateUsers),
      positiveReviews = _useScoreAddressAgain.positiveReviews,
      negativeReviews = _useScoreAddressAgain.negativeReviews,
      neutralReviews = _useScoreAddressAgain.neutralReviews; // Note: left for UI testing in web (Details display fails obvi, but easy to test different combos for Overview)
  // const {
  //   positiveReviews = [1,2,4],
  //   negativeReviews = [1,3],
  //   neutralReviews = [4,],
  // } = {}
  // const allReviews = positiveReviews + negativeReviews + neutralReviews


  if (loading) return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)(cc_Loader__WEBPACK_IMPORTED_MODULE_1__.Loader, {});
  if (!(allReviews !== null && allReviews !== void 0 && allReviews.length)) return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(cc_Empty__WEBPACK_IMPORTED_MODULE_5__.default, {
    children: [domainKey, " not yet reviewed ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("small", {
      children: ["(by", ' ', recceUser ? (0,common_utils__WEBPACK_IMPORTED_MODULE_6__.handle)(recceUser) : "your selected user".concat(activeUids.length === 1 ? '' : 's'), ")"]
    })]
  });
  var delta = positiveReviews.length - negativeReviews.length;
  var overallVote = delta > 0 ? 1 : delta === 0 ? 0 : -1;
  var mood = (0,cc_VoteEmote__WEBPACK_IMPORTED_MODULE_0__.getMood)(overallVote);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)(_OverallRating__WEBPACK_IMPORTED_MODULE_2__.default, {
      address: address,
      mood: mood,
      overallVote: overallVote,
      numPositive: positiveReviews.length,
      numNegative: negativeReviews.length,
      numNeutral: neutralReviews.length,
      onDetailToggle: toggleDetails
    }), showDetails && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)(_Details__WEBPACK_IMPORTED_MODULE_3__.default, {
      positive: positiveReviews,
      negative: negativeReviews,
      neutral: neutralReviews,
      domainKey: domainKey
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ReadModeContent);

/***/ }),

/***/ "./src/lib/common/components/ext/ReadMode/SelectReadingFrom/CurrentlyActiveDescription.js":
/*!************************************************************************************************!*\
  !*** ./src/lib/common/components/ext/ReadMode/SelectReadingFrom/CurrentlyActiveDescription.js ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");




var CurrentlyActiveDescription = function CurrentlyActiveDescription(_ref) {
  var activeOptions = _ref.activeOptions,
      recceUser = _ref.recceUser;

  if (recceUser) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
      className: "ml-2 p-2 badge badge-warning text-uppercase",
      children: (0,common_utils__WEBPACK_IMPORTED_MODULE_0__.handle)(recceUser)
    });
  }

  if (!activeOptions || activeOptions.length === 0) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
      className: "ml-2 p-2 badge badge-warning text-uppercase",
      children: "No active users!"
    });
  }

  if (activeOptions.length < 3) {
    return activeOptions.map(function (opt, idx) {
      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
        className: "ml-1 badge badge-info-light",
        children: ["@", opt.label]
      }, idx);
    });
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
    className: "ml-2 p-1 px-2 badge badge-info text-uppercase",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("span", {
      children: [activeOptions.length, " active users"]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CurrentlyActiveDescription);

/***/ }),

/***/ "./src/lib/common/components/ext/ReadMode/SelectReadingFrom/ReadingFromSelector/index.js":
/*!***********************************************************************************************!*\
  !*** ./src/lib/common/components/ext/ReadMode/SelectReadingFrom/ReadingFromSelector/index.js ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-select */ "./node_modules/react-select/dist/react-select.browser.esm.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _selectHelpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./selectHelpers */ "./src/lib/common/components/ext/ReadMode/SelectReadingFrom/ReadingFromSelector/selectHelpers.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");





var ReadingFromSelector = function ReadingFromSelector(_ref) {
  var options = _ref.options,
      selectedUsers = _ref.selectedUsers,
      onChange = _ref.onChange;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(react_select__WEBPACK_IMPORTED_MODULE_3__.default, {
    placeholder: "Select users to active...",
    noOptionsMessage: _selectHelpers__WEBPACK_IMPORTED_MODULE_1__.noOptionsMessage,
    formatOptionLabel: _selectHelpers__WEBPACK_IMPORTED_MODULE_1__.formatOptionLabel,
    styles: _selectHelpers__WEBPACK_IMPORTED_MODULE_1__.customSelectStyles,
    closeMenuOnSelect: false,
    captureMenuScroll: false,
    menuIsOpen: true,
    autoFocus: true,
    isMulti: true,
    options: (0,lodash__WEBPACK_IMPORTED_MODULE_0__.sortBy)(options, 'label'),
    value: selectedUsers,
    onChange: onChange
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ReadingFromSelector);

/***/ }),

/***/ "./src/lib/common/components/ext/ReadMode/SelectReadingFrom/ReadingFromSelector/selectHelpers.js":
/*!*******************************************************************************************************!*\
  !*** ./src/lib/common/components/ext/ReadMode/SelectReadingFrom/ReadingFromSelector/selectHelpers.js ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "noOptionsMessage": () => (/* binding */ noOptionsMessage),
/* harmony export */   "formatOptionLabel": () => (/* binding */ formatOptionLabel),
/* harmony export */   "customSelectStyles": () => (/* binding */ customSelectStyles)
/* harmony export */ });
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var cc_Avatar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! cc/Avatar */ "./src/lib/common/components/Avatar.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






var noOptionsMessage = function noOptionsMessage(_ref) {
  var inputValue = _ref.inputValue;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("p", {
    className: "mb-0",
    children: ["No unselected users", ' ', (inputValue === null || inputValue === void 0 ? void 0 : inputValue.length) === 0 ? 'remain.' : "match \"".concat(inputValue, "\"")]
  });
}; // NOTE: Used in the menu AND when selected...

var formatOptionLabel = function formatOptionLabel(option, _ref2) {
  var context = _ref2.context;

  // Once selected, within the search bar at the top
  if (context === 'value') {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
      className: "text-dark",
      children: ["@", option.label]
    });
  } // When unselected, in the menu below


  if (context === 'menu') {
    var user = option.user;

    var _ref3 = user || {},
        name = _ref3.name,
        _ref3$meta = _ref3.meta;

    _ref3$meta = _ref3$meta === void 0 ? {} : _ref3$meta;
    var _ref3$meta$numDomainR = _ref3$meta.numDomainReviews,
        numDomainReviews = _ref3$meta$numDomainR === void 0 ? 0 : _ref3$meta$numDomainR;
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
      className: "option text-info font-weight-normal d-flex align-items-center p-2",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(cc_Avatar__WEBPACK_IMPORTED_MODULE_1__.default, {
        user: user,
        size: 40,
        className: "mr-2"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
        className: "d-inline-flex flex-column",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("span", {
          children: (0,common_utils__WEBPACK_IMPORTED_MODULE_0__.handle)(user)
        }), (name === null || name === void 0 ? void 0 : name.length) && name !== option.label && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("span", {
          className: "text-muted small ml-1",
          children: name
        })]
      }), numDomainReviews > 0 ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("span", {
        className: "m-1 ml-3 badge badge-pill badge-secondary font-weight-light py-1 px-2",
        children: (0,common_utils__WEBPACK_IMPORTED_MODULE_0__.plur)(numDomainReviews, 'review')
      }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("span", {
        className: "ml-3 text-muted small",
        children: "(no reviews yet)"
      })]
    });
  } // Don't think we should get here, but a valid fallback regardless


  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: option.label
  });
};
var customSelectStyles = {
  // Make menu look like it belongs in the modal (rather than floating above it)
  menu: function menu(provided) {
    return _objectSpread(_objectSpread({}, provided), {}, {
      boxShadow: 'none',
      position: 'relative',
      marginBottom: '10px'
    });
  },
  // Indent options a bit
  option: function option(provided) {
    return _objectSpread(_objectSpread({}, provided), {}, {
      padding: '0',
      display: 'flex',
      alignItems: 'center',
      borderRadius: '5px',
      width: 'auto',
      fontSize: '1rem'
    });
  }
};

/***/ }),

/***/ "./src/lib/common/components/ext/ReadMode/SelectReadingFrom/SelectActiveUsersModal.js":
/*!********************************************************************************************!*\
  !*** ./src/lib/common/components/ext/ReadMode/SelectReadingFrom/SelectActiveUsersModal.js ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SelectActiveUsersModal": () => (/* binding */ SelectActiveUsersModal),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Modal.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Alert.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Button.js");
/* harmony import */ var common_hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! common/hooks */ "./src/lib/common/hooks/index.js");
/* harmony import */ var _ReadingFromSelector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ReadingFromSelector */ "./src/lib/common/components/ext/ReadMode/SelectReadingFrom/ReadingFromSelector/index.js");
/* harmony import */ var cc_Popover__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! cc/Popover */ "./src/lib/common/components/Popover.js");
/* harmony import */ var common_hooks_useModalResizing__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! common/hooks/useModalResizing */ "./src/lib/common/hooks/useModalResizing.js");
/* harmony import */ var universal_components_UniversalLink__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! universal/components/UniversalLink */ "./src/lib/universal-interface/components/UniversalLink.js");
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var common_routes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! common/routes */ "./src/lib/common/routes.js");
/* harmony import */ var cc_Avatar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! cc/Avatar */ "./src/lib/common/components/Avatar.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }















var Filter = function Filter(_ref) {
  var label = _ref.label,
      active = _ref.active,
      onClick = _ref.onClick;
  return active ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("span", {
    className: "text-muted",
    children: label
  }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("a", {
    href: "#",
    onClick: onClick,
    children: label
  });
}; // Note: ideal to auto-select Submit after all selected, but refs don't work in function components


var SelectActiveUsersModal = function SelectActiveUsersModal(_ref2) {
  var recceUser = _ref2.recceUser,
      show = _ref2.show,
      toggleModal = _ref2.toggleModal,
      options = _ref2.options,
      activeOptions = _ref2.activeOptions,
      onSubmit = _ref2.onSubmit,
      clearRecceUser = _ref2.clearRecceUser,
      adoptRecceUser = _ref2.adoptRecceUser;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(activeOptions),
      _useState2 = _slicedToArray(_useState, 2),
      selectedUserOptions = _useState2[0],
      setSelectedUserOptions = _useState2[1];

  var _useModalResizing = (0,common_hooks_useModalResizing__WEBPACK_IMPORTED_MODULE_4__.default)(),
      onEntered = _useModalResizing.onEntered,
      onExited = _useModalResizing.onExited;

  var handleSubmit = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function () {
    onSubmit(selectedUserOptions);
  }, [selectedUserOptions.map(function (o) {
    return o.value;
  }).join(':')]); // eslint-disable-line

  var selectAll = (0,common_hooks__WEBPACK_IMPORTED_MODULE_1__.useLinkCallback)(function () {
    setSelectedUserOptions(options);
  }, [options.length]);
  var selectNone = (0,common_hooks__WEBPACK_IMPORTED_MODULE_1__.useLinkCallback)(function () {
    setSelectedUserOptions([]);
  }, []);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_10__.default, {
    show: show,
    onHide: toggleModal,
    backdrop: selectedUserOptions.length === activeOptions.length ? true : 'static',
    onEntered: onEntered,
    onExited: onExited,
    centered: true,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_10__.default.Header, {
      className: "bg-light",
      closeButton: true,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_10__.default.Title, {
        className: "mb-0",
        children: ["Activate Specific Users", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(cc_Popover__WEBPACK_IMPORTED_MODULE_3__.default, {
          title: "Active Users",
          placement: "bottom",
          trigger: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("div", {
            role: "button",
            className: "badge ml-1",
            children: "\u2139"
          }),
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("p", {
            children: ["This modal lets you to select precisely which, of all the users you follow, you want to be ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("em", {
              children: "active"
            }), " right now."]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("p", {
            children: ["Each page you visit will be compared against ratings from", ' ', /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("em", {
              children: "the currently active"
            }), " users that you select here."]
          })]
        })]
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_10__.default.Body, {
      className: "pb-0",
      children: [recceUser && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_11__.default, {
        variant: "warning",
        className: "mb-3",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_11__.default.Heading, {
          children: "Recce Mode"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("p", {
          children: ["You are currently sampling the reviews of a user you don't yet follow,", ' ', /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(universal_components_UniversalLink__WEBPACK_IMPORTED_MODULE_5__.default, {
            href: common_routes__WEBPACK_IMPORTED_MODULE_7__.default.userUrl(recceUser),
            title: (0,common_utils__WEBPACK_IMPORTED_MODULE_6__.handle)(recceUser),
            className: "alert-link"
          }), ":"]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("hr", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
          className: "d-flex justify-content-center",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(cc_Avatar__WEBPACK_IMPORTED_MODULE_8__.default, {
            user: recceUser
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
            className: "mx-2",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("strong", {
              children: recceUser.name
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("br", {}), (0,common_utils__WEBPACK_IMPORTED_MODULE_6__.plur)(recceUser.meta.numFollowers || 0, 'follower')]
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("hr", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("p", {
          children: ["You can", ' ', /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("strong", {
            children: ["continue evaluating ", (0,common_utils__WEBPACK_IMPORTED_MODULE_6__.handle)(recceUser), "'s reviews"]
          }), ' ', "by closing this modal, or when you're ready to make a decision:"]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
          className: "mx-5 my-3 d-flex justify-content-between",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__.default, {
            variant: "secondary",
            onClick: clearRecceUser,
            children: "Drop User"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__.default, {
            variant: "primary",
            onClick: adoptRecceUser,
            children: "Follow User"
          })]
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
        className: "small mb-1 d-flex align-items-center",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("span", {
          className: "mr-1",
          children: "Filters: "
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(Filter, {
          label: "Select All",
          onClick: selectAll,
          active: selectedUserOptions.length === options.length
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("span", {
          className: "text-muted mx-1",
          children: "|"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(Filter, {
          label: "Select None",
          onClick: selectNone,
          active: selectedUserOptions.length === 0
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(_ReadingFromSelector__WEBPACK_IMPORTED_MODULE_2__.default, {
        options: options,
        onChange: setSelectedUserOptions,
        selectedUsers: selectedUserOptions
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_10__.default.Footer, {
      className: "bg-light d-flex justify-content-between",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(universal_components_UniversalLink__WEBPACK_IMPORTED_MODULE_5__.default, {
        href: common_routes__WEBPACK_IMPORTED_MODULE_7__.default.usersUrl,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__.default, {
          variant: "light",
          children: "Follow More Users"
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_12__.default, {
        variant: "primary",
        onClick: handleSubmit,
        children: "Activate Users"
      })]
    })]
  });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SelectActiveUsersModal);

/***/ }),

/***/ "./src/lib/common/components/ext/ReadMode/SelectReadingFrom/index.js":
/*!***************************************************************************!*\
  !*** ./src/lib/common/components/ext/ReadMode/SelectReadingFrom/index.js ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var common_hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! common/hooks */ "./src/lib/common/hooks/index.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Button.js");
/* harmony import */ var cc_ext_SubnavBar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! cc/ext/SubnavBar */ "./src/lib/common/components/ext/SubnavBar.js");
/* harmony import */ var _CurrentlyActiveDescription__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./CurrentlyActiveDescription */ "./src/lib/common/components/ext/ReadMode/SelectReadingFrom/CurrentlyActiveDescription.js");
/* harmony import */ var _SelectActiveUsersModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./SelectActiveUsersModal */ "./src/lib/common/components/ext/ReadMode/SelectReadingFrom/SelectActiveUsersModal.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }











var makeOptionForUser = function makeOptionForUser(user) {
  return {
    label: user.handle,
    value: user.id,
    user: user
  };
};

var SelectReadingFrom = function SelectReadingFrom(_ref) {
  var onChange = _ref.onChange,
      _ref$activeUids = _ref.activeUids,
      activeUids = _ref$activeUids === void 0 ? [] : _ref$activeUids,
      followedUsers = _ref.followedUsers,
      recceUser = _ref.recceUser,
      clearRecceUser = _ref.clearRecceUser,
      adoptRecceUser = _ref.adoptRecceUser;

  var _useToggle = (0,common_hooks__WEBPACK_IMPORTED_MODULE_1__.useToggle)(false),
      _useToggle2 = _slicedToArray(_useToggle, 2),
      modal = _useToggle2[0],
      toggleModal = _useToggle2[1];
  /* eslint-disable */


  var options = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
    return (followedUsers || []).map(makeOptionForUser);
  }, [followedUsers.length]);
  /* eslint-enable */
  // PERF: should probably memoize this - use the whyDidYouRender (?) hook to trace performance implications

  var activeOptions = options.filter(function (opt) {
    return activeUids.includes(opt.value);
  });
  var handleModalSubmission = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function (chosenUserOptions) {
    var uids = (chosenUserOptions || []).map(function (_ref2) {
      var value = _ref2.value;
      return value;
    });
    onChange(uids);
    toggleModal(false);
  }, [onChange, toggleModal]);
  var handleClearingRecceUser = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function () {
    toggleModal(false);
    clearRecceUser();
  }, []);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(cc_ext_SubnavBar__WEBPACK_IMPORTED_MODULE_2__.default, {
      className: recceUser && 'bg-warning-light',
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(cc_ext_SubnavBar__WEBPACK_IMPORTED_MODULE_2__.default.ActionTitle, {
        title: recceUser ? 'Temporarily sampling:' : 'According to:',
        onClick: toggleModal,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(_CurrentlyActiveDescription__WEBPACK_IMPORTED_MODULE_3__.default, {
          activeOptions: activeOptions,
          recceUser: recceUser
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.default, {
        size: "sm",
        variant: recceUser ? 'warning-light' : 'light',
        className: recceUser ? '' : 'text-muted',
        onClick: toggleModal,
        children: "Change"
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(_SelectActiveUsersModal__WEBPACK_IMPORTED_MODULE_4__.default, {
      recceUser: recceUser,
      show: modal,
      toggleModal: toggleModal,
      options: options,
      activeOptions: activeOptions,
      onSubmit: handleModalSubmission,
      clearRecceUser: handleClearingRecceUser,
      adoptRecceUser: adoptRecceUser
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SelectReadingFrom);

/***/ }),

/***/ "./src/lib/common/components/ext/ReadMode/index.js":
/*!*********************************************************!*\
  !*** ./src/lib/common/components/ext/ReadMode/index.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _ReadModeContent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ReadModeContent */ "./src/lib/common/components/ext/ReadMode/ReadModeContent/index.js");
/* harmony import */ var _SelectReadingFrom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SelectReadingFrom */ "./src/lib/common/components/ext/ReadMode/SelectReadingFrom/index.js");
/* harmony import */ var cc_Empty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! cc/Empty */ "./src/lib/common/components/Empty.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Alert.js");
/* harmony import */ var common_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! common/config */ "./src/lib/common/config/index.js");
/* harmony import */ var common_routes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! common/routes */ "./src/lib/common/routes.js");
/* harmony import */ var universal_components_UniversalLink__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! universal/components/UniversalLink */ "./src/lib/universal-interface/components/UniversalLink.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }













var ReadModeWithoutUsers = function ReadModeWithoutUsers() {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_8__.default, {
    variant: "info",
    className: "rounded-0 p-3 m-0",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_8__.default.Heading, {
      children: ["Welcome to ", common_config__WEBPACK_IMPORTED_MODULE_4__.default.appName]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)("strong", {
      children: "Just one more step! "
    }), "This screen will show you how the users you follow have rated the current domain... but first you must\xA0", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)(universal_components_UniversalLink__WEBPACK_IMPORTED_MODULE_6__.default, {
      href: common_routes__WEBPACK_IMPORTED_MODULE_5__.default.usersUrl,
      className: "alert-link",
      title: "follow some users"
    }), "."]
  });
}; // Note: can remove the wrapper and put this logic directly into ReadMode -
// only keeping separate in dev to make it easier to add additional conditional ReadMode hooks


var ReadModeWrapper = function ReadModeWrapper(_ref) {
  var followedUsers = _ref.followedUsers,
      props = _objectWithoutProperties(_ref, ["followedUsers"]);

  if (!(followedUsers !== null && followedUsers !== void 0 && followedUsers.length) || followedUsers.length === 1 && followedUsers[0].id === props.currentUserId) return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)(ReadModeWithoutUsers, _objectSpread({}, props));
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)(ReadMode, _objectSpread(_objectSpread({}, props), {}, {
    followedUsers: followedUsers
  }));
};

var ReadMode = function ReadMode(_ref2) {
  var domainKey = _ref2.domainKey,
      address = _ref2.address,
      currentUserId = _ref2.currentUserId,
      followedUsers = _ref2.followedUsers,
      recceUser = _ref2.recceUser,
      _ref2$activeUids = _ref2.activeUids,
      activeUids = _ref2$activeUids === void 0 ? [] : _ref2$activeUids,
      setActiveUids = _ref2.setActiveUids,
      clearRecceUser = _ref2.clearRecceUser,
      adoptRecceUser = _ref2.adoptRecceUser,
      showDetails = _ref2.showDetails,
      toggleDetails = _ref2.toggleDetails;
  var onSetReadingFrom = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function (uids) {
    setActiveUids(uids);
    clearRecceUser();
  }, [setActiveUids, clearRecceUser]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)(_SelectReadingFrom__WEBPACK_IMPORTED_MODULE_2__.default, {
      onChange: onSetReadingFrom,
      followedUsers: followedUsers,
      activeUids: activeUids,
      recceUser: recceUser,
      currentUserId: currentUserId,
      clearRecceUser: clearRecceUser,
      adoptRecceUser: adoptRecceUser
    }), activeUids.length === 0 && !recceUser ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)(cc_Empty__WEBPACK_IMPORTED_MODULE_3__.default, {
      children: "You must activate users to see their domain ratings in this space."
    }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)(_ReadModeContent__WEBPACK_IMPORTED_MODULE_1__.default, {
      domainKey: domainKey,
      address: address,
      recceUser: recceUser,
      activeUids: recceUser ? [recceUser.id] : activeUids,
      candidateUsers: recceUser ? [recceUser] : followedUsers,
      showDetails: showDetails,
      toggleDetails: toggleDetails
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ReadModeWrapper);

/***/ }),

/***/ "./src/lib/common/components/ext/SubnavBar.js":
/*!****************************************************!*\
  !*** ./src/lib/common/components/ext/SubnavBar.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");




var SubnavBar = function SubnavBar(_ref) {
  var className = _ref.className,
      children = _ref.children;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
    className: (0,common_utils__WEBPACK_IMPORTED_MODULE_0__.cn)('p-2 bg-light d-flex align-items-center justify-content-between', className),
    children: children
  });
};

SubnavBar.ActionTitle = function (_ref2) {
  var title = _ref2.title,
      children = _ref2.children,
      onClick = _ref2.onClick;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
    className: "font-weight-light d-inline-flex align-items-center",
    role: "button",
    onClick: onClick,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("span", {
      className: "text-nowrap",
      children: [title, " "]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("span", {
      className: "text-break",
      children: children
    })]
  });
};

SubnavBar.RightTitle = function (_ref3) {
  var children = _ref3.children;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
    className: "text-nowrap",
    children: children
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SubnavBar);

/***/ }),

/***/ "./src/lib/messaging/notifySite.js":
/*!*****************************************!*\
  !*** ./src/lib/messaging/notifySite.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "notifySite": () => (/* binding */ notifySite),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "notifySiteOfRecceChange": () => (/* binding */ notifySiteOfRecceChange)
/* harmony export */ });
/* harmony import */ var utils_ext__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! utils/ext */ "./src/lib/utils/ext.js");
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }


var notifySite = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(actionName, args) {
    var tab;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0,utils_ext__WEBPACK_IMPORTED_MODULE_0__.getActiveTab)();

          case 2:
            tab = _context.sent;
            _context.next = 5;
            return utils_ext__WEBPACK_IMPORTED_MODULE_0__.default.tabs.sendMessage(tab.id, {
              type: 'proxyToSite',
              payload: {
                actionName: actionName,
                args: args
              }
            });

          case 5:
            return _context.abrupt("return", _context.sent);

          case 6:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function notifySite(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (notifySite);
var notifySiteOfRecceChange = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(actionName, uid) {
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            if (uid) {
              _context2.next = 2;
              break;
            }

            return _context2.abrupt("return");

          case 2:
            _context2.prev = 2;
            _context2.next = 5;
            return notifySite(actionName, [uid]);

          case 5:
            return _context2.abrupt("return", _context2.sent);

          case 8:
            _context2.prev = 8;
            _context2.t0 = _context2["catch"](2);

          case 10:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2, null, [[2, 8]]);
  }));

  return function notifySiteOfRecceChange(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

/***/ }),

/***/ "./src/lib/redux/slices/reading.js":
/*!*****************************************!*\
  !*** ./src/lib/redux/slices/reading.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "initialState": () => (/* binding */ initialState),
/* harmony export */   "clearRecceUser": () => (/* binding */ clearRecceUser),
/* harmony export */   "setActiveReadingUserIds": () => (/* binding */ setActiveReadingUserIds),
/* harmony export */   "setFollowedUsers": () => (/* binding */ setFollowedUsers),
/* harmony export */   "setRecceUser": () => (/* binding */ setRecceUser),
/* harmony export */   "toggleDetails": () => (/* binding */ toggleDetails),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @reduxjs/toolkit */ "./node_modules/@reduxjs/toolkit/dist/redux-toolkit.esm.js");
/* harmony import */ var common_slices_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/slices/auth */ "./src/lib/common/slices/auth.js");
/* harmony import */ var lib_messaging_notifySite__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lib/messaging/notifySite */ "./src/lib/messaging/notifySite.js");
var _extraReducers;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }




var initialState = {
  activeUids: [],
  showDetails: false,
  followedUsers: null // flag for "not yet tried to load"

};
var clearRecceUser = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__.createAsyncThunk)('reading/clearRecceUser', /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(_, _ref) {
    var _getState$reading$rec;

    var getState;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            getState = _ref.getState;
            return _context.abrupt("return", (0,lib_messaging_notifySite__WEBPACK_IMPORTED_MODULE_1__.notifySiteOfRecceChange)('clearRecceUser', (_getState$reading$rec = getState().reading.recceUser) === null || _getState$reading$rec === void 0 ? void 0 : _getState$reading$rec.id));

          case 2:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function (_x, _x2) {
    return _ref2.apply(this, arguments);
  };
}());
var slice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__.createSlice)({
  name: 'reading',
  initialState: initialState,
  reducers: {
    setRecceUser: function setRecceUser(state, _ref3) {
      var payload = _ref3.payload;
      state.recceUser = payload.user;
    },
    setActiveReadingUserIds: function setActiveReadingUserIds(state, _ref4) {
      var payload = _ref4.payload;
      state.activeUids = payload.activeUids || [];
    },
    setFollowedUsers: function setFollowedUsers(state, _ref5) {
      var payload = _ref5.payload;
      var followedUsers = payload.followedUsers || [];
      state.followedUsers = followedUsers;

      if (state.recceUser) {
        var followedUids = followedUsers.map(function (_ref6) {
          var id = _ref6.id;
          return id;
        });
        if (followedUids.indexOf(state.recceUser.id) > -1) state.recceUser = null;
      }
    },
    toggleDetails: function toggleDetails(state) {
      state.showDetails = !state.showDetails;
    }
  },
  extraReducers: (_extraReducers = {}, _defineProperty(_extraReducers, common_slices_auth__WEBPACK_IMPORTED_MODULE_0__.recordLoggedOut, function () {
    return Object.assign({}, initialState);
  }), _defineProperty(_extraReducers, clearRecceUser.fulfilled, function (state) {
    state.recceUser = null;
  }), _extraReducers)
});
var _slice$actions = slice.actions,
    setActiveReadingUserIds = _slice$actions.setActiveReadingUserIds,
    setFollowedUsers = _slice$actions.setFollowedUsers,
    setRecceUser = _slice$actions.setRecceUser,
    toggleDetails = _slice$actions.toggleDetails;

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (slice.reducer);

/***/ }),

/***/ "./src/popup/containers/ReadModeContainer/ReadModeContainer.jsx":
/*!**********************************************************************!*\
  !*** ./src/popup/containers/ReadModeContainer/ReadModeContainer.jsx ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var cc_ext_ReadMode__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cc/ext/ReadMode */ "./src/lib/common/components/ext/ReadMode/index.js");
/* harmony import */ var cc_Loader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! cc/Loader */ "./src/lib/common/components/Loader.js");
/* harmony import */ var cc_Empty__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! cc/Empty */ "./src/lib/common/components/Empty.js");
/* harmony import */ var lib_messaging_fromFrontend__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lib/messaging/fromFrontend */ "./src/lib/messaging/fromFrontend/index.js");
/* harmony import */ var slices_reading__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! slices/reading */ "./src/lib/redux/slices/reading.js");
/* harmony import */ var common_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! common/hooks */ "./src/lib/common/hooks/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");










var ReadModeContainer = function ReadModeContainer(_ref) {
  var domainKey = _ref.domainKey,
      address = _ref.address,
      tabId = _ref.tabId;
  var currentUserId = (0,common_hooks__WEBPACK_IMPORTED_MODULE_5__.useCurrentUserId)();

  var _useSelector = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)(function (_ref2) {
    var reading = _ref2.reading;
    return reading;
  }),
      recceUser = _useSelector.recceUser,
      activeUids = _useSelector.activeUids,
      showDetails = _useSelector.showDetails,
      followedUsers = _useSelector.followedUsers;

  var updateScoreBadge = (0,react__WEBPACK_IMPORTED_MODULE_7__.useCallback)(function () {
    lib_messaging_fromFrontend__WEBPACK_IMPORTED_MODULE_3__.heyBackend.updateScoreBadge(tabId, address);
  }, [tabId, address]); // TODO: autodispatch?

  var dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useDispatch)();
  var clearRecceUser = (0,react__WEBPACK_IMPORTED_MODULE_7__.useCallback)(function () {
    dispatch((0,slices_reading__WEBPACK_IMPORTED_MODULE_4__.clearRecceUser)()); // TODO: await? higher up the stack?

    updateScoreBadge();
  }, []);
  var adoptRecceUser = (0,react__WEBPACK_IMPORTED_MODULE_7__.useCallback)(function () {
    lib_messaging_fromFrontend__WEBPACK_IMPORTED_MODULE_3__.heyBackend.adoptRecceUser(recceUser.id).then(function () {
      // TODO: currently updateScoreBadge's logic means "update current user's review b/c they left a new one". Add passing the uid to update to support recce case.
      updateScoreBadge();
    });
  }, [recceUser]);
  var setActiveUids = (0,react__WEBPACK_IMPORTED_MODULE_7__.useCallback)(function (activeUids) {
    dispatch((0,slices_reading__WEBPACK_IMPORTED_MODULE_4__.setActiveReadingUserIds)({
      activeUids: activeUids
    })).then(function () {
      return updateScoreBadge();
    });
  }, []);
  var toggleDetails = (0,react__WEBPACK_IMPORTED_MODULE_7__.useCallback)(function () {
    dispatch((0,slices_reading__WEBPACK_IMPORTED_MODULE_4__.toggleDetails)());
  }); // TODO: implement a USE version so we see following changes? (later - for now we assume ext is in your browser, we try to tell ext to refresh when you follow/unfollow)

  if (followedUsers === null) return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx)(cc_Loader__WEBPACK_IMPORTED_MODULE_1__.Loader, {}); // We're behind auth gate, so these should never be undefined, and background script's onAuthChanged should handle keeping data fresh

  if (!currentUserId) return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx)(cc_Empty__WEBPACK_IMPORTED_MODULE_2__.default, {
    children: "Authentication required"
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx)(cc_ext_ReadMode__WEBPACK_IMPORTED_MODULE_0__.default, {
    address: address,
    domainKey: domainKey,
    currentUserId: currentUserId,
    followedUsers: followedUsers,
    recceUser: recceUser,
    activeUids: activeUids,
    setActiveUids: setActiveUids,
    clearRecceUser: clearRecceUser,
    adoptRecceUser: adoptRecceUser,
    showDetails: showDetails,
    toggleDetails: toggleDetails,
    updateScoreBadge: updateScoreBadge
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ReadModeContainer);

/***/ }),

/***/ "./node_modules/react-bootstrap/esm/Accordion.js":
/*!*******************************************************!*\
  !*** ./node_modules/react-bootstrap/esm/Accordion.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/esm/extends */ "./node_modules/react-bootstrap/node_modules/@babel/runtime/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutPropertiesLoose__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectWithoutPropertiesLoose */ "./node_modules/react-bootstrap/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var uncontrollable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! uncontrollable */ "./node_modules/uncontrollable/lib/esm/index.js");
/* harmony import */ var _ThemeProvider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ThemeProvider */ "./node_modules/react-bootstrap/esm/ThemeProvider.js");
/* harmony import */ var _AccordionToggle__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./AccordionToggle */ "./node_modules/react-bootstrap/esm/AccordionToggle.js");
/* harmony import */ var _SelectableContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./SelectableContext */ "./node_modules/react-bootstrap/esm/SelectableContext.js");
/* harmony import */ var _AccordionCollapse__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./AccordionCollapse */ "./node_modules/react-bootstrap/esm/AccordionCollapse.js");
/* harmony import */ var _AccordionContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./AccordionContext */ "./node_modules/react-bootstrap/esm/AccordionContext.js");










var Accordion = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3__.forwardRef(function (props, ref) {
  var _useUncontrolled = (0,uncontrollable__WEBPACK_IMPORTED_MODULE_4__.useUncontrolled)(props, {
    activeKey: 'onSelect'
  }),
      _useUncontrolled$as = _useUncontrolled.as,
      Component = _useUncontrolled$as === void 0 ? 'div' : _useUncontrolled$as,
      activeKey = _useUncontrolled.activeKey,
      bsPrefix = _useUncontrolled.bsPrefix,
      children = _useUncontrolled.children,
      className = _useUncontrolled.className,
      onSelect = _useUncontrolled.onSelect,
      controlledProps = (0,_babel_runtime_helpers_esm_objectWithoutPropertiesLoose__WEBPACK_IMPORTED_MODULE_1__.default)(_useUncontrolled, ["as", "activeKey", "bsPrefix", "children", "className", "onSelect"]);

  var finalClassName = classnames__WEBPACK_IMPORTED_MODULE_2___default()(className, (0,_ThemeProvider__WEBPACK_IMPORTED_MODULE_5__.useBootstrapPrefix)(bsPrefix, 'accordion'));
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3__.createElement(_AccordionContext__WEBPACK_IMPORTED_MODULE_6__.default.Provider, {
    value: activeKey || null
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3__.createElement(_SelectableContext__WEBPACK_IMPORTED_MODULE_7__.default.Provider, {
    value: onSelect || null
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3__.createElement(Component, (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__.default)({
    ref: ref
  }, controlledProps, {
    className: finalClassName
  }), children)));
});
Accordion.displayName = 'Accordion';
Accordion.Toggle = _AccordionToggle__WEBPACK_IMPORTED_MODULE_8__.default;
Accordion.Collapse = _AccordionCollapse__WEBPACK_IMPORTED_MODULE_9__.default;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Accordion);

/***/ }),

/***/ "./node_modules/react-bootstrap/esm/AccordionCollapse.js":
/*!***************************************************************!*\
  !*** ./node_modules/react-bootstrap/esm/AccordionCollapse.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/esm/extends */ "./node_modules/react-bootstrap/node_modules/@babel/runtime/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutPropertiesLoose__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectWithoutPropertiesLoose */ "./node_modules/react-bootstrap/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _Collapse__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Collapse */ "./node_modules/react-bootstrap/esm/Collapse.js");
/* harmony import */ var _AccordionContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./AccordionContext */ "./node_modules/react-bootstrap/esm/AccordionContext.js");
/* harmony import */ var _SelectableContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./SelectableContext */ "./node_modules/react-bootstrap/esm/SelectableContext.js");






var AccordionCollapse = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2__.forwardRef(function (_ref, ref) {
  var children = _ref.children,
      eventKey = _ref.eventKey,
      props = (0,_babel_runtime_helpers_esm_objectWithoutPropertiesLoose__WEBPACK_IMPORTED_MODULE_1__.default)(_ref, ["children", "eventKey"]);

  var contextEventKey = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_AccordionContext__WEBPACK_IMPORTED_MODULE_3__.default); // Empty SelectableContext is to prevent elements in the collapse
  // from collapsing the accordion when clicked.

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2__.createElement(_SelectableContext__WEBPACK_IMPORTED_MODULE_4__.default.Provider, {
    value: null
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2__.createElement(_Collapse__WEBPACK_IMPORTED_MODULE_5__.default, (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__.default)({
    ref: ref,
    in: contextEventKey === eventKey
  }, props), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2__.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_2__.Children.only(children))));
});
AccordionCollapse.displayName = 'AccordionCollapse';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AccordionCollapse);

/***/ }),

/***/ "./node_modules/react-bootstrap/esm/AccordionContext.js":
/*!**************************************************************!*\
  !*** ./node_modules/react-bootstrap/esm/AccordionContext.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");

var context = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createContext(null);
context.displayName = 'AccordionContext';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (context);

/***/ }),

/***/ "./node_modules/react-bootstrap/esm/AccordionToggle.js":
/*!*************************************************************!*\
  !*** ./node_modules/react-bootstrap/esm/AccordionToggle.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useAccordionToggle": () => (/* binding */ useAccordionToggle),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/esm/extends */ "./node_modules/react-bootstrap/node_modules/@babel/runtime/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutPropertiesLoose__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectWithoutPropertiesLoose */ "./node_modules/react-bootstrap/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _SelectableContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./SelectableContext */ "./node_modules/react-bootstrap/esm/SelectableContext.js");
/* harmony import */ var _AccordionContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./AccordionContext */ "./node_modules/react-bootstrap/esm/AccordionContext.js");





function useAccordionToggle(eventKey, onClick) {
  var contextEventKey = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_AccordionContext__WEBPACK_IMPORTED_MODULE_3__.default);
  var onSelect = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_SelectableContext__WEBPACK_IMPORTED_MODULE_4__.default);
  return function (e) {
    /*
      Compare the event key in context with the given event key.
      If they are the same, then collapse the component.
    */
    var eventKeyPassed = eventKey === contextEventKey ? null : eventKey;
    if (onSelect) onSelect(eventKeyPassed, e);
    if (onClick) onClick(e);
  };
}
var AccordionToggle = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2__.forwardRef(function (_ref, ref) {
  var _ref$as = _ref.as,
      Component = _ref$as === void 0 ? 'button' : _ref$as,
      children = _ref.children,
      eventKey = _ref.eventKey,
      onClick = _ref.onClick,
      props = (0,_babel_runtime_helpers_esm_objectWithoutPropertiesLoose__WEBPACK_IMPORTED_MODULE_1__.default)(_ref, ["as", "children", "eventKey", "onClick"]);

  var accordionOnClick = useAccordionToggle(eventKey, onClick);

  if (Component === 'button') {
    props.type = 'button';
  }

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2__.createElement(Component, (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__.default)({
    ref: ref,
    onClick: accordionOnClick
  }, props), children);
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AccordionToggle);

/***/ }),

/***/ "./node_modules/react-bootstrap/esm/Card.js":
/*!**************************************************!*\
  !*** ./node_modules/react-bootstrap/esm/Card.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/esm/extends */ "./node_modules/react-bootstrap/node_modules/@babel/runtime/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutPropertiesLoose__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectWithoutPropertiesLoose */ "./node_modules/react-bootstrap/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _ThemeProvider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ThemeProvider */ "./node_modules/react-bootstrap/esm/ThemeProvider.js");
/* harmony import */ var _createWithBsPrefix__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./createWithBsPrefix */ "./node_modules/react-bootstrap/esm/createWithBsPrefix.js");
/* harmony import */ var _divWithClassName__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./divWithClassName */ "./node_modules/react-bootstrap/esm/divWithClassName.js");
/* harmony import */ var _CardContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./CardContext */ "./node_modules/react-bootstrap/esm/CardContext.js");
/* harmony import */ var _CardImg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./CardImg */ "./node_modules/react-bootstrap/esm/CardImg.js");









var DivStyledAsH5 = (0,_divWithClassName__WEBPACK_IMPORTED_MODULE_4__.default)('h5');
var DivStyledAsH6 = (0,_divWithClassName__WEBPACK_IMPORTED_MODULE_4__.default)('h6');
var CardBody = (0,_createWithBsPrefix__WEBPACK_IMPORTED_MODULE_5__.default)('card-body');
var CardTitle = (0,_createWithBsPrefix__WEBPACK_IMPORTED_MODULE_5__.default)('card-title', {
  Component: DivStyledAsH5
});
var CardSubtitle = (0,_createWithBsPrefix__WEBPACK_IMPORTED_MODULE_5__.default)('card-subtitle', {
  Component: DivStyledAsH6
});
var CardLink = (0,_createWithBsPrefix__WEBPACK_IMPORTED_MODULE_5__.default)('card-link', {
  Component: 'a'
});
var CardText = (0,_createWithBsPrefix__WEBPACK_IMPORTED_MODULE_5__.default)('card-text', {
  Component: 'p'
});
var CardHeader = (0,_createWithBsPrefix__WEBPACK_IMPORTED_MODULE_5__.default)('card-header');
var CardFooter = (0,_createWithBsPrefix__WEBPACK_IMPORTED_MODULE_5__.default)('card-footer');
var CardImgOverlay = (0,_createWithBsPrefix__WEBPACK_IMPORTED_MODULE_5__.default)('card-img-overlay');
var defaultProps = {
  body: false
};
var Card = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3__.forwardRef(function (_ref, ref) {
  var bsPrefix = _ref.bsPrefix,
      className = _ref.className,
      bg = _ref.bg,
      text = _ref.text,
      border = _ref.border,
      body = _ref.body,
      children = _ref.children,
      _ref$as = _ref.as,
      Component = _ref$as === void 0 ? 'div' : _ref$as,
      props = (0,_babel_runtime_helpers_esm_objectWithoutPropertiesLoose__WEBPACK_IMPORTED_MODULE_1__.default)(_ref, ["bsPrefix", "className", "bg", "text", "border", "body", "children", "as"]);

  var prefix = (0,_ThemeProvider__WEBPACK_IMPORTED_MODULE_6__.useBootstrapPrefix)(bsPrefix, 'card');
  var cardContext = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(function () {
    return {
      cardHeaderBsPrefix: prefix + "-header"
    };
  }, [prefix]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3__.createElement(_CardContext__WEBPACK_IMPORTED_MODULE_7__.default.Provider, {
    value: cardContext
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3__.createElement(Component, (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__.default)({
    ref: ref
  }, props, {
    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(className, prefix, bg && "bg-" + bg, text && "text-" + text, border && "border-" + border)
  }), body ?
  /*#__PURE__*/
  // @ts-ignore
  react__WEBPACK_IMPORTED_MODULE_3__.createElement(CardBody, null, children) : children));
});
Card.displayName = 'Card';
Card.defaultProps = defaultProps;
Card.Img = _CardImg__WEBPACK_IMPORTED_MODULE_8__.default;
Card.Title = CardTitle;
Card.Subtitle = CardSubtitle;
Card.Body = CardBody;
Card.Link = CardLink;
Card.Text = CardText;
Card.Header = CardHeader;
Card.Footer = CardFooter;
Card.ImgOverlay = CardImgOverlay;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Card);

/***/ }),

/***/ "./node_modules/react-bootstrap/esm/CardImg.js":
/*!*****************************************************!*\
  !*** ./node_modules/react-bootstrap/esm/CardImg.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/esm/extends */ "./node_modules/react-bootstrap/node_modules/@babel/runtime/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_helpers_esm_objectWithoutPropertiesLoose__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectWithoutPropertiesLoose */ "./node_modules/react-bootstrap/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _ThemeProvider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ThemeProvider */ "./node_modules/react-bootstrap/esm/ThemeProvider.js");





var defaultProps = {
  variant: null
};
var CardImg = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3__.forwardRef( // Need to define the default "as" during prop destructuring to be compatible with styled-components github.com/react-bootstrap/react-bootstrap/issues/3595
function (_ref, ref) {
  var bsPrefix = _ref.bsPrefix,
      className = _ref.className,
      variant = _ref.variant,
      _ref$as = _ref.as,
      Component = _ref$as === void 0 ? 'img' : _ref$as,
      props = (0,_babel_runtime_helpers_esm_objectWithoutPropertiesLoose__WEBPACK_IMPORTED_MODULE_1__.default)(_ref, ["bsPrefix", "className", "variant", "as"]);

  var prefix = (0,_ThemeProvider__WEBPACK_IMPORTED_MODULE_4__.useBootstrapPrefix)(bsPrefix, 'card-img');
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3__.createElement(Component, (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__.default)({
    ref: ref,
    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(variant ? prefix + "-" + variant : prefix, className)
  }, props));
});
CardImg.displayName = 'CardImg';
CardImg.defaultProps = defaultProps;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CardImg);

/***/ })

}]);
//# sourceMappingURL=src_popup_containers_ReadModeContainer_ReadModeContainer_jsx.js.map