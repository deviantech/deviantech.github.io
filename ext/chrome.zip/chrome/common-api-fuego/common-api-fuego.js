(self["webpackChunkeditor_browser_extension"] = self["webpackChunkeditor_browser_extension"] || []).push([["common-api-fuego"],{

/***/ "./src/lib/common/swrFirestore/fuego.js":
/*!**********************************************!*\
  !*** ./src/lib/common/swrFirestore/fuego.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _nandorojo_swr_firestore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @nandorojo/swr-firestore */ "./node_modules/@nandorojo/swr-firestore/lib/module/index.js");
/* harmony import */ var _nandorojo_swr_firestore__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_nandorojo_swr_firestore__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var common_config_firebase__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! common/config/firebase */ "./src/lib/common/config/firebase.js");
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! firebase/app */ "./node_modules/firebase/app/dist/index.esm.js");
/* harmony import */ var firebase_analytics__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! firebase/analytics */ "./node_modules/firebase/analytics/dist/index.esm.js");
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! firebase/auth */ "./node_modules/firebase/auth/dist/index.esm.js");
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase/firestore */ "./node_modules/firebase/firestore/dist/index.esm.js");
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }






 // Wrap up our firebase initialization in a convenient object for use-firestore
// See: https://github.com/nandorojo/swr-firestore/issues/59#issuecomment-719950071

var Fuego = function Fuego(config) {
  _classCallCheck(this, Fuego);

  this.db = !firebase_app__WEBPACK_IMPORTED_MODULE_2__.default.apps.length ? firebase_app__WEBPACK_IMPORTED_MODULE_2__.default.initializeApp(config).firestore() : firebase_app__WEBPACK_IMPORTED_MODULE_2__.default.app().firestore();
  this.auth = firebase_app__WEBPACK_IMPORTED_MODULE_2__.default.auth; // TODO: enable if we use them... I *think* OK to leave off if not?
  // this.functions = firebase.functions
  // this.storage = firebase.storage
  // Here down is our own customization, not required by nandorojo/swr-firestore

  this.firestore = firebase_app__WEBPACK_IMPORTED_MODULE_2__.default.firestore; // Used for e.g. .FieldPath.documentId()
  // TODO: manage emulation
  // if (true && process.env.NODE_ENV === 'development') {
  //   db.useEmulator('localhost', 8080)
  // }
};

var fuego = new Fuego(common_config_firebase__WEBPACK_IMPORTED_MODULE_1__.default);
(0,_nandorojo_swr_firestore__WEBPACK_IMPORTED_MODULE_0__.setFuego)(fuego);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fuego);

/***/ })

}]);
//# sourceMappingURL=common-api-fuego.js.map