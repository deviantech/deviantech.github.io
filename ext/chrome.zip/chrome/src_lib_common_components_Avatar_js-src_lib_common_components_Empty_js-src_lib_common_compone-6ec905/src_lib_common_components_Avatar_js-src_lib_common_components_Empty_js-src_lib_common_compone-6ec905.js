(self["webpackChunkeditor_browser_extension"] = self["webpackChunkeditor_browser_extension"] || []).push([["src_lib_common_components_Avatar_js-src_lib_common_components_Empty_js-src_lib_common_compone-6ec905"],{

/***/ "./src/lib/common/api/domainReviews/index.js":
/*!***************************************************!*\
  !*** ./src/lib/common/api/domainReviews/index.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getDomainReview": () => (/* reexport safe */ common_swrFirestore__WEBPACK_IMPORTED_MODULE_2__.getDomainReview),
/* harmony export */   "getDomainReviews": () => (/* binding */ getDomainReviews),
/* harmony export */   "setDomainReview": () => (/* binding */ setDomainReview),
/* harmony export */   "removeDomainReview": () => (/* binding */ removeDomainReview)
/* harmony export */ });
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../helpers */ "./src/lib/common/api/helpers.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/debugging.js");
/* harmony import */ var common_swrFirestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! common/swrFirestore */ "./src/lib/common/swrFirestore/businessDomainLogic/domains.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }




var log = common_utils__WEBPACK_IMPORTED_MODULE_1__.logger.extend('API').extend('domainReviews');

 // TODO catch any errors and display in UI and/or toasts

var getDomainReviews = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(_ref) {
    var firestore, domainKey, byUserIds;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            firestore = _ref.firestore, domainKey = _ref.domainKey, byUserIds = _ref.byUserIds;
            _context.t0 = lodash__WEBPACK_IMPORTED_MODULE_0__.compact;
            _context.next = 4;
            return Promise.all((byUserIds || []).map(function (userId) {
              return (0,common_swrFirestore__WEBPACK_IMPORTED_MODULE_2__.getDomainReview)({
                firestore: firestore,
                domainKey: domainKey,
                userId: userId
              });
            }));

          case 4:
            _context.t1 = _context.sent;
            return _context.abrupt("return", (0, _context.t0)(_context.t1));

          case 6:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function getDomainReviews(_x) {
    return _ref2.apply(this, arguments);
  };
}();
var setDomainReview = function setDomainReview(_ref3) {
  var firestore = _ref3.firestore,
      userId = _ref3.userId,
      domainKey = _ref3.domainKey,
      data = _ref3.data;

  // Note: we expect to overwrite the rule entirely if it exists (i.e. we just use set rather than update),
  // so we first copy over any meta information we want to preserve
  var formatReviewForStorage = function formatReviewForStorage(oldReview) {
    var meta = _objectSpread(_objectSpread({}, oldReview === null || oldReview === void 0 ? void 0 : oldReview.meta), {}, {
      domainKey: domainKey,
      userId: userId // Irritatingly still can't get subcollection queries to filter on documentId(), so denormalizing userId AND domain into meta

    });

    var toWrite = _objectSpread(_objectSpread({}, (0,_helpers__WEBPACK_IMPORTED_MODULE_3__.compactDomainReview)(data)), {}, {
      meta: meta
    });

    if (!oldReview) toWrite.meta.createdAt = firestore.FieldValue.serverTimestamp();
    toWrite.meta.updatedAt = firestore.FieldValue.serverTimestamp();
    return toWrite;
  }; // We try to prevent this in the UI, but avoid leaving "empty" (no recommendation) reviews in the DB


  if (data.vote === 0 && (!data.rules || data.rules.length === 0)) {
    console.warn('Received empty review -- removing entirely', data);
    return removeDomainReview({
      firestore: firestore,
      userId: userId,
      domainKey: domainKey
    });
  }

  var ref = firestore.collection('domains').doc(domainKey).collection('domainReviews').doc(userId);
  return firestore.runTransaction( /*#__PURE__*/function () {
    var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(t) {
      var reviewDoc, oldReview, newReview;
      return regeneratorRuntime.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return t.get(ref);

            case 2:
              reviewDoc = _context2.sent;
              oldReview = reviewDoc.exists ? reviewDoc.data() : null;
              newReview = formatReviewForStorage(oldReview);
              return _context2.abrupt("return", t.set(ref, newReview));

            case 6:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));

    return function (_x2) {
      return _ref4.apply(this, arguments);
    };
  }());
}; // NOTE: currently only called from addReview when setting simple review vote to 0

var removeDomainReview = function removeDomainReview(_ref5) {
  var firestore = _ref5.firestore,
      userId = _ref5.userId,
      domainKey = _ref5.domainKey;
  var ref = firestore.collection('domains').doc(domainKey).collection('domainReviews').doc(userId);
  return firestore["delete"](ref);
};

/***/ }),

/***/ "./src/lib/common/api/helpers.js":
/*!***************************************!*\
  !*** ./src/lib/common/api/helpers.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "compactDomainReview": () => (/* binding */ compactDomainReview),
/* harmony export */   "getFollowKey": () => (/* binding */ getFollowKey),
/* harmony export */   "complexRatingMetaKeyForVote": () => (/* binding */ complexRatingMetaKeyForVote)
/* harmony export */ });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
 // Sparse for storage -- strip out empty hashtags + comment keys if not used
// Goal: strip out empty hashtags ([]) or comment (""), but leave vote even if 0

var compactDomainReview = function compactDomainReview(obj) {
  return (0,lodash__WEBPACK_IMPORTED_MODULE_0__.pickBy)(obj, function (val, key) {
    return val && (0,lodash__WEBPACK_IMPORTED_MODULE_0__.isNumber)(val) || val.length && val.length > 0;
  });
}; // User following

var getFollowKey = function getFollowKey(currentUserUid, maybeFollowedUid) {
  return [currentUserUid, maybeFollowedUid].join(':');
}; // NOTE: shared w/ firebase functions repo - any changes need to be synced

var complexRatingMetaKeyForVote = function complexRatingMetaKeyForVote(vote) {
  if (vote === 1) return 'numComplexReviewsPositivish';
  if (vote === -1) return 'numComplexReviewsNegativish';
  return 'numComplexReviewsNeutralish';
};

/***/ }),

/***/ "./src/lib/common/api/index.js":
/*!*************************************!*\
  !*** ./src/lib/common/api/index.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "rawApi": () => (/* binding */ rawApi),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _domainReviews__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./domainReviews */ "./src/lib/common/api/domainReviews/index.js");
/* harmony import */ var _users__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./users */ "./src/lib/common/api/users/index.js");
/* harmony import */ var universal_api_wrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/api-wrapper */ "./src/lib/universal-interface/api-wrapper.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



 // By convention, all API calls must:
// 1. accept a single arg for kwargs (including a firestore, which is auto-injected and should NOT be passed in when calling the API)
// 2. return a promise

var rawApi = _objectSpread(_objectSpread({}, _domainReviews__WEBPACK_IMPORTED_MODULE_0__), _users__WEBPACK_IMPORTED_MODULE_1__); // Net effect: for web, both default export and rawApi will execute directly.
// For extension, any method called on the default export will be referred to the background script
// (which will then automatically call the corresponding method on the rawApi)

var wrappedApi = (0,universal_api_wrapper__WEBPACK_IMPORTED_MODULE_2__.apiWrapper)(rawApi);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (wrappedApi);

/***/ }),

/***/ "./src/lib/common/api/users/index.js":
/*!*******************************************!*\
  !*** ./src/lib/common/api/users/index.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getUserById": () => (/* reexport safe */ common_swrFirestore__WEBPACK_IMPORTED_MODULE_0__.getUserById)
/* harmony export */ });
/* harmony import */ var common_swrFirestore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/swrFirestore */ "./src/lib/common/swrFirestore/businessDomainLogic/users.js");


/***/ }),

/***/ "./src/lib/common/components/Avatar.js":
/*!*********************************************!*\
  !*** ./src/lib/common/components/Avatar.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_user_avatar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-user-avatar */ "./node_modules/react-user-avatar/user-avatar.js");
/* harmony import */ var react_user_avatar__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_user_avatar__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/user.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


 // Note: does NOT accept className prop, as it gets set by underlying library (fork and add cn support?)



var Avatar = function Avatar(_ref) {
  var user = _ref.user,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 48 : _ref$size,
      props = _objectWithoutProperties(_ref, ["user", "size"]);

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)((react_user_avatar__WEBPACK_IMPORTED_MODULE_0___default()), _objectSpread({
    size: size,
    name: user.name,
    src: user.avatar,
    alt: "".concat((0,common_utils__WEBPACK_IMPORTED_MODULE_2__.handle)(user), "'s avatar"),
    style: {
      overflow: 'hidden'
    } // Prevent broken avatar alt text from taking up whole page

  }, props));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Avatar);

/***/ }),

/***/ "./src/lib/common/components/Empty.js":
/*!********************************************!*\
  !*** ./src/lib/common/components/Empty.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");


var Jumbotron = function Jumbotron(_ref) {
  var _ref$bg = _ref.bg,
      bg = _ref$bg === void 0 ? 'light' : _ref$bg,
      children = _ref.children;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
    className: "jumbotron jumbotron-fluid mb-0 bg-".concat(bg),
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
      className: "container-fluid px-2",
      children: children
    })
  });
};

var Empty = function Empty(_ref2) {
  var children = _ref2.children;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Jumbotron, {
    bg: "secondary-light",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", {
      className: "mx-2 font-weight-light text-center text-dark",
      children: children
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Empty);

/***/ }),

/***/ "./src/lib/common/components/Hashtags.js":
/*!***********************************************!*\
  !*** ./src/lib/common/components/Hashtags.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Hashtags": () => (/* binding */ Hashtags),
/* harmony export */   "Hashtag": () => (/* binding */ Hashtag),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/classNames.js");
/* harmony import */ var common_routes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! common/routes */ "./src/lib/common/routes.js");
/* harmony import */ var universal_components_UniversalLink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/UniversalLink */ "./src/lib/universal-interface/components/UniversalLink.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






var Hashtags = function Hashtags(_ref) {
  var _ref$hashtags = _ref.hashtags,
      hashtags = _ref$hashtags === void 0 ? [] : _ref$hashtags,
      prefix = _ref.prefix,
      className = _ref.className,
      tagClassName = _ref.tagClassName,
      props = _objectWithoutProperties(_ref, ["hashtags", "prefix", "className", "tagClassName"]);

  return (hashtags === null || hashtags === void 0 ? void 0 : hashtags.length) === 0 ? null : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
    className: (0,common_utils__WEBPACK_IMPORTED_MODULE_1__.cn)('d-flex flex-wrap', className),
    children: [prefix, hashtags.map(function (tag) {
      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Hashtag, _objectSpread(_objectSpread({
        tag: tag
      }, props), {}, {
        className: tagClassName
      }), tag);
    })]
  });
}; // assumes already run through stringToHashtag

var Hashtag = function Hashtag(_ref2) {
  var tag = _ref2.tag,
      link = _ref2.link,
      className = _ref2.className;
  var classes = (0,common_utils__WEBPACK_IMPORTED_MODULE_1__.cn)('k-span mx-1', className);
  if (!link) return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
    className: classes,
    children: ["#", tag]
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(universal_components_UniversalLink__WEBPACK_IMPORTED_MODULE_2__.default, {
    href: common_routes__WEBPACK_IMPORTED_MODULE_3__.default.hashtagUrl(tag),
    className: classes,
    title: "#".concat(tag)
  });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hashtags);

/***/ }),

/***/ "./src/lib/common/components/Popover.js":
/*!**********************************************!*\
  !*** ./src/lib/common/components/Popover.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/OverlayTrigger.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Popover.js");
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/classNames.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






var Popover = function Popover(_ref) {
  var trigger = _ref.trigger,
      title = _ref.title,
      content = _ref.content,
      noBodyPadding = _ref.noBodyPadding,
      children = _ref.children,
      overrideTrigger = _ref.overrideTrigger,
      props = _objectWithoutProperties(_ref, ["trigger", "title", "content", "noBodyPadding", "children", "overrideTrigger"]);

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_1__.default, _objectSpread(_objectSpread({
    trigger: overrideTrigger || ['hover', 'focus', 'click'],
    overlay: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.default, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.default.Title, {
        children: title
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.default.Content, {
        className: (0,common_utils__WEBPACK_IMPORTED_MODULE_3__.cn)(noBodyPadding && 'p-0'),
        children: [content, children]
      })]
    }),
    transition: false // TODO:POLISH: Remove once https://github.com/react-bootstrap/react-bootstrap is updated to a newer version of
    // react-transition-group (until this, this is necessary to avoid findDOMNode warning in strict mode)

  }, props), {}, {
    children: function children(_ref2) {
      var ref = _ref2.ref,
          triggerHandler = _objectWithoutProperties(_ref2, ["ref"]);

      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", _objectSpread(_objectSpread({
        role: "button",
        ref: ref
      }, triggerHandler), {}, {
        children: trigger
      }));
    }
  }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Popover);

/***/ }),

/***/ "./src/lib/common/components/TimeAgo.js":
/*!**********************************************!*\
  !*** ./src/lib/common/components/TimeAgo.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var timeago_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! timeago-react */ "./node_modules/timeago-react/esm/timeago-react.js");
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/dates.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var TimeAgo = function TimeAgo(_ref) {
  var datetime = _ref.datetime,
      props = _objectWithoutProperties(_ref, ["datetime"]);

  if (!datetime) return null;

  try {
    var dt = (0,common_utils__WEBPACK_IMPORTED_MODULE_2__.dateFromDatish)(datetime);
    return dt ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(timeago_react__WEBPACK_IMPORTED_MODULE_0__.default, _objectSpread({
      title: dt.toLocaleString(),
      datetime: dt
    }, props)) : null;
  } catch (e) {
    return null;
  }
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TimeAgo);

/***/ }),

/***/ "./src/lib/common/components/VoteEmote.js":
/*!************************************************!*\
  !*** ./src/lib/common/components/VoteEmote.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getMood": () => (/* binding */ getMood),
/* harmony export */   "VoteEmote": () => (/* binding */ VoteEmote),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/classNames.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");



var getMood = function getMood(vote) {
  return vote > 0 ? 'success' : vote < 0 ? 'danger' : 'secondary';
};
var VoteEmote = function VoteEmote(_ref) {
  var vote = _ref.vote,
      className = _ref.className;
  var voteEmote;

  switch (vote) {
    case 1:
      voteEmote = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: "\uD83D\uDC4D"
      });
      break;

    case -1:
      voteEmote = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: "\uD83D\uDC4E"
      });
      break;

    default:
      voteEmote = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: "\uD83E\uDD37\u200D\u2642\uFE0F"
      });
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
    className: (0,common_utils__WEBPACK_IMPORTED_MODULE_1__.cn)('text-nowrap', className),
    children: voteEmote
  });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VoteEmote);

/***/ }),

/***/ "./src/lib/common/hooks/domainHooks.js":
/*!*********************************************!*\
  !*** ./src/lib/common/hooks/domainHooks.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useDomainPacket": () => (/* binding */ useDomainPacket),
/* harmony export */   "useDomainReviewsByUserIds": () => (/* binding */ useDomainReviewsByUserIds),
/* harmony export */   "useScoreAddressAgainstReviews": () => (/* binding */ useScoreAddressAgainstReviews)
/* harmony export */ });
/* harmony import */ var common_api__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! common/api */ "./src/lib/common/api/index.js");
/* harmony import */ var common_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! common/hooks */ "./src/lib/common/hooks/firestoreHooks.js");
/* harmony import */ var common_logic__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! common/logic */ "./src/lib/common/logic/domainPacket.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var common_swrFirestore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! common/swrFirestore */ "./src/lib/common/swrFirestore/helpers.js");
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/debugging.js");






var log = common_utils__WEBPACK_IMPORTED_MODULE_1__.logger.extend('hooks').extend('domainHooks'); // TODO: is this hook or API?
// TODO: clearer conventions around when the thing we return is expected to show Loading
// TODO: the api. parts here should be renamed, but idea is that these need to be wrapped in ext frontend to execute in ext backend
// (where, sidenote, they'll use the caching versions of swr)

var useDomainPacket = function useDomainPacket(_ref) {
  var userId = _ref.userId,
      domainKey = _ref.domainKey;
  return (0,common_hooks__WEBPACK_IMPORTED_MODULE_2__.useDirectlyLoadedFirestoreData)(function () {
    if (!userId || !domainKey) return false;
    return (0,common_swrFirestore__WEBPACK_IMPORTED_MODULE_3__.onlyExisting)(common_api__WEBPACK_IMPORTED_MODULE_4__.default.getDomainReview({
      userId: userId,
      domainKey: domainKey
    }));
  }, [userId, domainKey]);
};
var useDomainReviewsByUserIds = function useDomainReviewsByUserIds(_ref2) {
  var domainKey = _ref2.domainKey,
      byUserIds = _ref2.byUserIds;
  return (0,common_hooks__WEBPACK_IMPORTED_MODULE_2__.useDirectlyLoadedFirestoreData)(function () {
    if (!domainKey || !(byUserIds !== null && byUserIds !== void 0 && byUserIds.length)) return false;
    return (0,common_swrFirestore__WEBPACK_IMPORTED_MODULE_3__.onlyExisting)(common_api__WEBPACK_IMPORTED_MODULE_4__.default.getDomainReviews({
      domainKey: domainKey,
      byUserIds: byUserIds
    }));
  }, [domainKey, byUserIds.join(':')]);
}; // Note: be sure candidateUsers array contains ALL uids referenced in reviews!

var useScoreAddressAgainstReviews = function useScoreAddressAgainstReviews(address, reviews, candidateUsers) {
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
    return (0,common_logic__WEBPACK_IMPORTED_MODULE_5__.scoreAddressAgainstUserReviews)({
      address: address,
      reviews: reviews,
      candidateUsers: candidateUsers
    });
  }, [address, reviews, candidateUsers]);
};

/***/ }),

/***/ "./src/lib/common/hooks/firestoreHooks.js":
/*!************************************************!*\
  !*** ./src/lib/common/hooks/firestoreHooks.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useDirectlyLoadedFirestoreData": () => (/* binding */ useDirectlyLoadedFirestoreData)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var common_hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! common/hooks */ "./src/lib/common/hooks/hooks.js");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }



var dataLoadingFlag = Symbol('dataLoading'); // Caution: never change getterFn, not currently memoized (otherwise, use the useMemoCompare hook)

var useDirectlyLoadedFirestoreData = function useDirectlyLoadedFirestoreData(getterFn, dependencyArray) {
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(dataLoadingFlag),
      _useState2 = _slicedToArray(_useState, 2),
      data = _useState2[0],
      setData = _useState2[1];

  var _useToggle = (0,common_hooks__WEBPACK_IMPORTED_MODULE_1__.useToggle)(),
      _useToggle2 = _slicedToArray(_useToggle, 2),
      refetchFlag = _useToggle2[0],
      refetch = _useToggle2[1];

  (0,common_hooks__WEBPACK_IMPORTED_MODULE_1__.useAsyncEffect)( /*#__PURE__*/_asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
    var newData;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return getterFn();

          case 2:
            newData = _context.sent;

            if (!(newData === false)) {
              _context.next = 5;
              break;
            }

            return _context.abrupt("return");

          case 5:
            setData(newData);

          case 6:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  })), [].concat(_toConsumableArray(dependencyArray), [getterFn, refetchFlag]));
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
    return {
      data: data === dataLoadingFlag ? undefined : data,
      loading: data === dataLoadingFlag,
      refetch: refetch
    };
  }, [data, refetchFlag]);
};

/***/ }),

/***/ "./src/lib/common/hooks/useModalResizing.js":
/*!**************************************************!*\
  !*** ./src/lib/common/hooks/useModalResizing.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");

var MARGIN = 20;
/*
 * useModalResizing - returns onEntered/onExited hooks to add to react-bootstrap's modal
 * when it's being used in the browser extension context (tries to make the extension window
 * grow to show full modal height, then shrink again when closed).
 *
 * NOTE: this seem functional up to window heights of ~600px, then hit chrome's max sizes
 */

var useModalResizing = function useModalResizing() {
  var onEntered = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function (modalWrapperElement) {
    if (!window) return true;
    var body = document.querySelector('body');
    var modalElement = modalWrapperElement.querySelector('.modal-content');
    var modalHeight = modalElement.scrollHeight + 2 * MARGIN;
    body.style.minHeight = "".concat(modalHeight, "px");
  }, []);
  var onExited = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function () {
    var body = document.querySelector('body');
    body.style.minHeight = 'initial';
  }, []);
  return {
    onEntered: onEntered,
    onExited: onExited
  };
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useModalResizing);

/***/ }),

/***/ "./src/lib/common/logic/domainPacket.js":
/*!**********************************************!*\
  !*** ./src/lib/common/logic/domainPacket.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "forDomainPacketTest": () => (/* binding */ forDomainPacketTest),
/* harmony export */   "scoreAddressAgainstUserReviews": () => (/* binding */ scoreAddressAgainstUserReviews)
/* harmony export */ });
/* harmony import */ var common_logic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/logic */ "./src/lib/common/logic/rules.js");
/* harmony import */ var common_logic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! common/logic */ "./src/lib/common/logic/domain.js");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

 // *** SCORING ***
// Assumes rules are sorted in priority order, returns score from first match
// @return [score, the specific rule that matched (if any)]

var scoreDomainPacket = function scoreDomainPacket(domainPacket, urlData) {
  if (!domainPacket) return [undefined];
  if (!domainPacket.rules || domainPacket.rules.length === 0) return [domainPacket.vote];

  var ruleMatcher = function ruleMatcher(rule) {
    return (0,common_logic__WEBPACK_IMPORTED_MODULE_0__.ruleMatches)(rule, urlData);
  };

  var matchedRule = domainPacket.rules.find(ruleMatcher);
  return [(matchedRule || domainPacket).vote, matchedRule];
};

var forDomainPacketTest = {
  scoreDomainPacket: scoreDomainPacket
}; // Given:
//  - Address (unparsed URL)
//  - reviews (loaded domainPackets for underlying domainKey)
//  - candidateUsers (array of users - if provided MUST contain all review authors (will be injected into review.user so downstream doesn't have to figure it out))

var scoreAddressAgainstUserReviews = function scoreAddressAgainstUserReviews(_ref) {
  var address = _ref.address,
      reviews = _ref.reviews,
      candidateUsers = _ref.candidateUsers;
  var urlData = !address || !reviews || reviews.length === 0 ? false : (0,common_logic__WEBPACK_IMPORTED_MODULE_1__.urlDataFromAddress)(address);
  if (!urlData || !candidateUsers) return {
    positiveReviews: [],
    negativeReviews: [],
    neutralReviews: []
  };

  var _reviews$reduce = reviews.reduce(function (aggregate, fullDomainPacket) {
    var _scoreDomainPacket = scoreDomainPacket(fullDomainPacket, urlData),
        _scoreDomainPacket2 = _slicedToArray(_scoreDomainPacket, 2),
        score = _scoreDomainPacket2[0],
        matchedRule = _scoreDomainPacket2[1];

    aggregate[score] = aggregate[score] || [];
    var data = {
      matchedRule: matchedRule,
      fullDomainPacket: fullDomainPacket
    };
    var matchedUser = candidateUsers.find( // Looks weird but correct, packet was pulled from /domains/domainKey/domainReviews/userId, so id should === userId
    function (user) {
      return user.id === fullDomainPacket.id;
    });

    if (matchedUser) {
      data.user = matchedUser;
      aggregate["".concat(score)].push(data);
    } else {
      console.log('Not returning review with no matching user (if you dropped a recceUser this is fine, confirm candidate users had IDs set):', {
        matchedRule: matchedRule,
        fullDomainPacket: fullDomainPacket,
        candidateUsers: candidateUsers
      });
    }

    return aggregate;
  }, new Object()),
      _reviews$reduce$ = _reviews$reduce[1],
      positiveReviews = _reviews$reduce$ === void 0 ? [] : _reviews$reduce$,
      _reviews$reduce$2 = _reviews$reduce['-1'],
      negativeReviews = _reviews$reduce$2 === void 0 ? [] : _reviews$reduce$2,
      _reviews$reduce$3 = _reviews$reduce[0],
      neutralReviews = _reviews$reduce$3 === void 0 ? [] : _reviews$reduce$3;

  return {
    positiveReviews: positiveReviews,
    negativeReviews: negativeReviews,
    neutralReviews: neutralReviews
  };
};

/***/ }),

/***/ "./src/lib/common/logic/rules.js":
/*!***************************************!*\
  !*** ./src/lib/common/logic/rules.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "humanizeVote": () => (/* binding */ humanizeVote),
/* harmony export */   "VerbOptions": () => (/* binding */ VerbOptions),
/* harmony export */   "rulesAreEquivalent": () => (/* binding */ rulesAreEquivalent),
/* harmony export */   "ruleExistsInlist": () => (/* binding */ ruleExistsInlist),
/* harmony export */   "ruleMatches": () => (/* binding */ ruleMatches),
/* harmony export */   "HumanizedRule": () => (/* binding */ HumanizedRule),
/* harmony export */   "HumanizedRuleText": () => (/* binding */ HumanizedRuleText),
/* harmony export */   "forRulesTest": () => (/* binding */ forRulesTest)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }





var humanizeVote = function humanizeVote() {
  var vote = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
  if (vote > 0) return 'positive';
  if (vote < 0) return 'negative';
  return 'neutral';
};

var RuleVariant = function RuleVariant(value) {
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
      matcher = _ref.matcher,
      label = _ref.label;

  _classCallCheck(this, RuleVariant);

  if (!value || !matcher) {
    throw 'RuleVariants must have a defined value and matcher';
  }

  this.value = value;
  this.label = label || value;
  this.matcher = matcher;
}; // TODO: add support for "any of"/arrays in rule


var SUPPORTED_RULE_VARIANTS = {
  equals: new RuleVariant('equals', {
    label: 'is exactly',
    matcher: function matcher(noun, input) {
      return input === noun;
    }
  }),
  prefix: new RuleVariant('prefix', {
    label: 'starts with',
    matcher: function matcher(noun, input) {
      return (0,lodash__WEBPACK_IMPORTED_MODULE_1__.startsWith)(input, noun);
    }
  }),
  suffix: new RuleVariant('suffix', {
    label: 'ends with',
    matcher: function matcher(noun, input) {
      return (0,lodash__WEBPACK_IMPORTED_MODULE_1__.endsWith)(input, noun);
    }
  }),
  contains: new RuleVariant('contains', {
    matcher: function matcher(noun, input) {
      return input.indexOf(noun) > -1;
    }
  }),
  any: new RuleVariant('any', {
    label: 'is anything',
    matcher: function matcher() {
      return true;
    }
  })
};
var VerbOptions = Object.entries(SUPPORTED_RULE_VARIANTS).map(function (_ref2) {
  var _ref3 = _slicedToArray(_ref2, 2),
      value = _ref3[0],
      label = _ref3[1].label;

  return {
    value: value,
    label: label
  };
}); // TODO: eventually expand to include params (different set of matchers)?

var SUPPORTED_RULE_FIELDS = ['path', 'subdomain'];

var normalizeRulePart = function normalizeRulePart(part) {
  if (!(part !== null && part !== void 0 && part.verb)) return null;
  if (part.verb === 'any' || (0,lodash__WEBPACK_IMPORTED_MODULE_1__.isEmpty)(part.noun)) return null; // not actually applying any restriction === same as not existing

  return part;
}; // run isEqual *after* compacting falsy noun fields ({verb: 'any', noun: ""} should equalish {verb: 'any'})


var isEqualish = function isEqualish(rulePartA, rulePartB) {
  if (!rulePartA && !rulePartB) return true;
  if (!rulePartA || !rulePartB) return false;
  if (rulePartA.verb !== rulePartB.verb) return false;
  if (rulePartA.noun !== rulePartB.noun) return false;
  return true;
};

var rulesAreEquivalent = function rulesAreEquivalent(a, b) {
  return a && b && (0,lodash__WEBPACK_IMPORTED_MODULE_1__.every)(SUPPORTED_RULE_FIELDS, function (field) {
    return isEqualish(normalizeRulePart(a[field]), normalizeRulePart(b[field]));
  });
}; // TODO: use this to prevent creating duplicate rules

var ruleExistsInlist = function ruleExistsInlist(rule, list) {
  return (0,lodash__WEBPACK_IMPORTED_MODULE_1__.some)(list, function (listItem) {
    return rulesAreEquivalent(listItem, rule);
  });
}; // Note: expects a pre-parsed URL w/ path and subdomain fields
// TODO: We don't currently support the search component of URLs (?foo=bar), but we do parse it from the URL
// and it's available here if we want to e.g. append it to the path for exact matches (need to clarify from UI what user intends)

var ruleMatches = function ruleMatches() {
  var rule = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var parsedURL = arguments.length > 1 ? arguments[1] : undefined;
  return (0,lodash__WEBPACK_IMPORTED_MODULE_1__.every)(SUPPORTED_RULE_FIELDS, function (fieldName) {
    return ruleFieldMatches(rule[fieldName], parsedURL[fieldName]);
  });
};

var ruleFieldMatches = function ruleFieldMatches(ruleField, input) {
  if (!ruleField) return true; // If no restriction present (e.g. for path or subdomain) default to a match all

  var ruleVariant = SUPPORTED_RULE_VARIANTS[ruleField.verb];

  if (!ruleVariant) {
    console.warn('ruleFieldMatches given invalid rule structure or unknown variant -- defaulting to false. Given: ', ruleField);
    return false;
  }

  return ruleVariant.matcher(ruleField.noun, input);
};

var getVariantForFieldDisplay = function getVariantForFieldDisplay(rule, field) {
  var _rule$field;

  if (!rule || !rule[field]) return null;
  if (rule[field].verb === 'any') return null;
  return SUPPORTED_RULE_VARIANTS[(_rule$field = rule[field]) === null || _rule$field === void 0 ? void 0 : _rule$field.verb];
};

var humanizeRuleField = function humanizeRuleField(rule, field) {
  var Tag = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'span';
  var fieldTitle = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.capitalize)(field);
  var ruleVariant = getVariantForFieldDisplay(rule, field);
  if (!ruleVariant) return null;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(Tag, {
    className: "mb-0",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("strong", {
      children: fieldTitle
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("span", {
      children: [" ", ruleVariant.label, " "]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("em", {
      className: "text-monospace",
      children: rule[field].noun
    })]
  });
};

var humanizeRuleFields = function humanizeRuleFields(rule) {
  var Tag = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'li';
  var joinWith = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
  var fields = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.compact)(SUPPORTED_RULE_FIELDS.map(function (field) {
    return humanizeRuleField(rule, field, Tag);
  }));
  var lastFieldIdx = fields.length - 1;
  return fields.map(function (field, idx) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: [field, joinWith && idx < lastFieldIdx ? joinWith : null]
    }, idx);
  });
};

var HumanizedRule = function HumanizedRule(_ref4) {
  var rule = _ref4.rule,
      className = _ref4.className,
      _ref4$Tag = _ref4.Tag,
      Tag = _ref4$Tag === void 0 ? 'ul' : _ref4$Tag,
      _ref4$fieldTag = _ref4.fieldTag,
      fieldTag = _ref4$fieldTag === void 0 ? 'li' : _ref4$fieldTag,
      joinWith = _ref4.joinWith;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(Tag, {
    className: className,
    children: humanizeRuleFields(rule, fieldTag, joinWith)
  });
};
var HumanizedRuleText = function HumanizedRuleText(_ref5) {
  var rule = _ref5.rule,
      className = _ref5.className;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(HumanizedRule, {
    rule: rule,
    className: className,
    Tag: "span",
    fieldTag: "span",
    joinWith: " and "
  });
};
var forRulesTest = {
  ruleFieldMatches: ruleFieldMatches,
  humanizeRuleField: humanizeRuleField
};

/***/ }),

/***/ "./src/lib/common/swrFirestore/businessDomainLogic/domains.js":
/*!********************************************************************!*\
  !*** ./src/lib/common/swrFirestore/businessDomainLogic/domains.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getDomainReview": () => (/* binding */ getDomainReview)
/* harmony export */ });
/* harmony import */ var common_swrFirestore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/swrFirestore */ "./src/lib/common/swrFirestore/core.js");

var getDomainReview = function getDomainReview(_ref) {
  var domainKey = _ref.domainKey,
      userId = _ref.userId;
  return (0,common_swrFirestore__WEBPACK_IMPORTED_MODULE_0__.getDocument)(domainKey && userId ? "domains/".concat(domainKey, "/domainReviews/").concat(userId) : null);
};

/***/ }),

/***/ "./src/lib/common/swrFirestore/businessDomainLogic/users.js":
/*!******************************************************************!*\
  !*** ./src/lib/common/swrFirestore/businessDomainLogic/users.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getUserById": () => (/* binding */ getUserById)
/* harmony export */ });
/* harmony import */ var common_swrFirestore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/swrFirestore */ "./src/lib/common/swrFirestore/core.js");

var getUserById = function getUserById(userId) {
  return (0,common_swrFirestore__WEBPACK_IMPORTED_MODULE_0__.getDocument)(userId ? "users/".concat(userId) : null, {
    parseDates: ['meta.lastReviewedAt', 'meta.deletedAt']
  });
}; // TODO rewrite w/ generic "path from arg" and "opts" config to generate get or use version automatically (or refresh in ext)

/***/ }),

/***/ "./src/lib/common/swrFirestore/core.js":
/*!*********************************************!*\
  !*** ./src/lib/common/swrFirestore/core.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useDocument": () => (/* binding */ useDocument),
/* harmony export */   "useCollection": () => (/* binding */ useCollection),
/* harmony export */   "getDocument": () => (/* binding */ getDocument),
/* harmony export */   "getCollection": () => (/* binding */ getCollection)
/* harmony export */ });
/* harmony import */ var _nandorojo_swr_firestore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @nandorojo/swr-firestore */ "./node_modules/@nandorojo/swr-firestore/lib/module/index.js");
/* harmony import */ var _nandorojo_swr_firestore__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_nandorojo_swr_firestore__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

// Wrappers around the core get/use methods from swr-firestore.
// In extension, ONLY to be used from background (wrapped in another caching layer)

 // Note: These are the only options for getFoo; useFoo also accepts listen, as well as refreshInterval and other undelrying-SWR-library options

var SwrFirestoreKeys = ['parseDates', 'ignoreFirestoreDocumentSnapshotField', 'listen'];
var DefaultSwrFirestoreConfig = {
  parseDates: ['meta.createdAt', 'meta.updatedAt'],
  ignoreFirestoreDocumentSnapshotField: true
};

var swrOptions = function swrOptions() {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      parseDates = _ref.parseDates,
      opts = _objectWithoutProperties(_ref, ["parseDates"]);

  return _objectSpread(_objectSpread(_objectSpread({}, DefaultSwrFirestoreConfig), opts), {}, {
    parseDates: parseDates ? [].concat(_toConsumableArray(DefaultSwrFirestoreConfig.parseDates), _toConsumableArray(parseDates)) : DefaultSwrFirestoreConfig.parseDates
  });
}; // Note: swr-firestore AND use-swr options (e.g. parseDates, listen + SWR) combined in second arg (matches underlying lib)


var useDocument = function useDocument(path, opts) {
  // console.log(`[useDocument] ${path}`, swrOptions(opts))
  return (0,_nandorojo_swr_firestore__WEBPACK_IMPORTED_MODULE_0__.useDocument)(path, swrOptions(opts));
}; // Note: swr-firestore AND use-swr options (e.g. parseDates, listen + SWR) combined in second arg (note does NOT match underlying lib, which has
// all swr-firestore options (e.g. parseDates, listen) merged in with query, while use-swr options are a separate third argument)

var useCollection = function useCollection(path) {
  var query = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var opts = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

  // For some reason the swr-firestore library combines useSWR + swr-firestore options in the useDocument case, but
  // (explicitly *against* what they claim in the documentation: https://github.com/nandorojo/swr-firestore/blob/b5f9a09b13447457526fcf2ce194aa0431130736/src/hooks/use-swr-collection.ts#L291)
  // they have swr-firestore options merged into the query field for the useCollection case.
  // We are standardizing on the last argument (2nd for useDocument, 3rd for useCollection) containing both useSWR and swr-firestore options,
  // while the second argument for useCollection is purely query-related.
  // Pull the SwrFirestoreKeys out of the options field, where I passed them because they're options, and put them in the query field, where
  // the underlying library wants them for some inexplicable reason.
  var _useMemo = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
    var libQuery = query;
    var libOpts = swrOptions(opts);
    SwrFirestoreKeys.forEach(function (key) {
      if (libOpts[key]) {
        libQuery[key] = libOpts[key];
        delete libOpts[key];
      }
    });
    return {
      libQuery: libQuery,
      libOpts: libOpts
    };
  }, [query, opts]),
      libQuery = _useMemo.libQuery,
      libOpts = _useMemo.libOpts; // TODO: do I need the usememocomparison hook thing?


  return (0,_nandorojo_swr_firestore__WEBPACK_IMPORTED_MODULE_0__.useCollection)(path, libQuery, libOpts);
};
var getDocument = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(path, opts) {
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            if (path) {
              _context.next = 2;
              break;
            }

            return _context.abrupt("return", null);

          case 2:
            return _context.abrupt("return", (0,_nandorojo_swr_firestore__WEBPACK_IMPORTED_MODULE_0__.getDocument)(path, swrOptions(opts)));

          case 3:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function getDocument(_x, _x2) {
    return _ref2.apply(this, arguments);
  };
}();
var getCollection = /*#__PURE__*/function () {
  var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(path) {
    var query,
        opts,
        _args2 = arguments;
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            query = _args2.length > 1 && _args2[1] !== undefined ? _args2[1] : {};
            opts = _args2.length > 2 ? _args2[2] : undefined;

            if (path) {
              _context2.next = 4;
              break;
            }

            return _context2.abrupt("return", null);

          case 4:
            return _context2.abrupt("return", (0,_nandorojo_swr_firestore__WEBPACK_IMPORTED_MODULE_0__.getCollection)(path, query, swrOptions(opts)));

          case 5:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));

  return function getCollection(_x3) {
    return _ref3.apply(this, arguments);
  };
}();

/***/ }),

/***/ "./src/lib/common/swrFirestore/helpers.js":
/*!************************************************!*\
  !*** ./src/lib/common/swrFirestore/helpers.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "onlyExisting": () => (/* binding */ onlyExisting)
/* harmony export */ });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
 // Given a doc or docs, strips out those that don't exist

var onlyExisting = function onlyExisting(given) {
  return Array.isArray(given) ? (0,lodash__WEBPACK_IMPORTED_MODULE_0__.filter)(given, 'exists') : given !== null && given !== void 0 && given.exists ? given : null;
};

/***/ }),

/***/ "./src/lib/common/utils/classNames.js":
/*!********************************************!*\
  !*** ./src/lib/common/utils/classNames.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "cn": () => (/* binding */ cn)
/* harmony export */ });
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
 // Alias classNames as cn to remove capitalization issues

var cn = (classnames__WEBPACK_IMPORTED_MODULE_0___default());

/***/ }),

/***/ "./src/lib/common/utils/dates.js":
/*!***************************************!*\
  !*** ./src/lib/common/utils/dates.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "minutes": () => (/* binding */ minutes),
/* harmony export */   "hours": () => (/* binding */ hours),
/* harmony export */   "days": () => (/* binding */ days),
/* harmony export */   "weeks": () => (/* binding */ weeks),
/* harmony export */   "dateStringFromDatish": () => (/* binding */ dateStringFromDatish),
/* harmony export */   "dateFromDatish": () => (/* binding */ dateFromDatish),
/* harmony export */   "sameDate": () => (/* binding */ sameDate)
/* harmony export */ });
/* harmony import */ var _debugging__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./debugging */ "./src/lib/common/utils/debugging.js");
function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }


var minutes = 60;
var hours = 60 * minutes;
var days = hours * 24;
var weeks = days * 7; // https://stackoverflow.com/questions/27012854/change-iso-date-string-to-date-object-javascript

var parseISOString = function parseISOString(s) {
  var b = s.split(/\D+/);
  return new Date(Date.UTC(b[0], --b[1], b[2], b[3], b[4], b[5], b[6]));
};

var dateStringFromDatish = function dateStringFromDatish(datish) {
  var date = dateFromDatish(datish);
  return date !== null && date !== void 0 && date.toISOString ? date.toISOString() : null;
};
var dateFromDatish = function dateFromDatish(datish) {
  if (datish instanceof Date) return datish;
  if (!datish) return null; // Firestore timestamps have a toDate method...

  if (datish.toDate) return datish.toDate(); // ...but not after passing through proxy (?? TODO or fix serialization to convert directly to date?)

  if (datish instanceof Object) {
    if (datish.seconds && datish.nanoseconds) return new Date(datish.seconds * 1000 + datish.nanoseconds / 1000000);
  } // ... finally, somehow w/ SSG + superjson serialization I'm getting stringified (toISOstring) versions from the server (once, then become normal)
  // that look like: 2021-03-22T20:57:23.892Z


  try {
    return parseISOString(datish);
  } catch (e) {
    console.warn('dateFromDatish given non-date input with no toDate fn:', _typeof(datish), (0,_debugging__WEBPACK_IMPORTED_MODULE_0__.inspectObject)(datish));
    return null;
  }
}; // Handle comparing dates OR firestore timestamp objects

var sameDate = function sameDate(a, b) {
  if (!a || !b) return false;
  return dateFromDatish(a).toString() == dateFromDatish(b).toString();
};

/***/ }),

/***/ "./src/lib/common/utils/plur.js":
/*!**************************************!*\
  !*** ./src/lib/common/utils/plur.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "plur": () => (/* binding */ plur)
/* harmony export */ });
/* harmony import */ var pluralize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! pluralize */ "./node_modules/pluralize/pluralize.js");
/* harmony import */ var pluralize__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(pluralize__WEBPACK_IMPORTED_MODULE_0__);

var plur = function plur(number, string) {
  return "".concat(number, " ").concat(pluralize__WEBPACK_IMPORTED_MODULE_0___default()(string, number));
};

/***/ }),

/***/ "./src/lib/common/utils/user.js":
/*!**************************************!*\
  !*** ./src/lib/common/utils/user.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "handle": () => (/* binding */ handle)
/* harmony export */ });
// TODO: add support for link: true?
var handle = function handle(user) {
  var includeDisplay = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
  if (!user) return '[anonymous user]'; // todo: sure we want this default?

  if (user.handle) return includeDisplay && user.name ? "@".concat(user.handle, " (").concat(user.name, ")") : "@".concat(user.handle);
  if (user.name) return user.name;
  return '[unknown user]';
};

/***/ }),

/***/ "./src/lib/universal-interface/api-wrapper.js":
/*!****************************************************!*\
  !*** ./src/lib/universal-interface/api-wrapper.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "apiWrapper": () => (/* binding */ apiWrapper)
/* harmony export */ });
/* harmony import */ var lib_messaging_fromFrontend__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lib/messaging/fromFrontend */ "./src/lib/messaging/fromFrontend/index.js");

var apiWrapper = function apiWrapper() {
  // Seems kinda wasteful to load the actual API when I'm just sending the function name along...
  // console.log('[api executor] initializeApi on rawApi:', rawApi)
  // ... so don't even bother accepting the arg, just return our to-background-please
  return lib_messaging_fromFrontend__WEBPACK_IMPORTED_MODULE_0__.backendAPI;
};

/***/ })

}]);
//# sourceMappingURL=src_lib_common_components_Avatar_js-src_lib_common_components_Empty_js-src_lib_common_compone-6ec905.js.map