(self["webpackChunkeditor_browser_extension"] = self["webpackChunkeditor_browser_extension"] || []).push([["src_popup_components_Authentication_index_js"],{

/***/ "./src/lib/common/config/auth.js":
/*!***************************************!*\
  !*** ./src/lib/common/config/auth.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getDefaultAuthOptions": () => (/* binding */ getDefaultAuthOptions)
/* harmony export */ });
/* harmony import */ var common_routes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/routes */ "./src/lib/common/routes.js");

var getDefaultAuthOptions = function getDefaultAuthOptions(firebase) {
  return {
    signInFlow: 'popup',
    signInOptions: [firebase.auth.EmailAuthProvider.PROVIDER_ID, firebase.auth.GoogleAuthProvider.PROVIDER_ID],
    callbacks: {
      signInSuccessWithAuthResult: function signInSuccessWithAuthResult() {
        return false;
      } // Must be present (and return false) if we don't have a signInSuccessUrl set. Defaulting to no-op since we handle onAuthStateChanged elsewhere.

    },
    // autoUpgradeAnonymousUsers: true,
    tosUrl: common_routes__WEBPACK_IMPORTED_MODULE_0__.default.termsOfServiceUrl,
    privacyPolicyUrl: common_routes__WEBPACK_IMPORTED_MODULE_0__.default.privacyPolicyUrl
  };
};

/***/ }),

/***/ "./src/lib/common/config/firebase.js":
/*!*******************************************!*\
  !*** ./src/lib/common/config/firebase.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Pasted from firestore console
var firebaseConfig = {
  apiKey: 'AIzaSyCO2gdlEZPCMhUakGLbLuuxy4DU4CoKwq8',
  authDomain: 'fkaeditor.firebaseapp.com',
  projectId: 'fkaeditor',
  storageBucket: 'fkaeditor.appspot.com',
  messagingSenderId: '810775960603',
  appId: '1:810775960603:web:d9842c06431c609ec7acbe',
  measurementId: 'G-ESJWQE9BWT' // For Firebase JS SDK v7.20.0 and later, measurementId is optional

};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (firebaseConfig);

/***/ }),

/***/ "./src/popup/components/Authentication/foregroundFirebaseForAuth.js":
/*!**************************************************************************!*\
  !*** ./src/popup/components/Authentication/foregroundFirebaseForAuth.js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase/app */ "./node_modules/firebase/app/dist/index.esm.js");
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase/auth */ "./node_modules/firebase/auth/dist/index.esm.js");
/* harmony import */ var common_config_firebase__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! common/config/firebase */ "./src/lib/common/config/firebase.js");

 // TODO: either remove entirely, if we route authentication via the website, or else make sure only loaded when actively showing
// firestore login UI (we don't want to maintain separate firebase connections from backend/frontend beyond the absolutely necessary)

 // Only initialize if we haven't already loaded (which, btw, we probably should NOT have in frontend?)

if (firebase_app__WEBPACK_IMPORTED_MODULE_0__.default.apps.length) console.warn("Looks like firebase is already configured (if we're in popup context... why tho?)", firebase_app__WEBPACK_IMPORTED_MODULE_0__.default.apps[0]);
firebase_app__WEBPACK_IMPORTED_MODULE_0__.default.apps.length || firebase_app__WEBPACK_IMPORTED_MODULE_0__.default.initializeApp(common_config_firebase__WEBPACK_IMPORTED_MODULE_2__.default); // Initialize firebase instance

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (firebase_app__WEBPACK_IMPORTED_MODULE_0__.default);

/***/ }),

/***/ "./src/popup/components/Authentication/index.js":
/*!******************************************************!*\
  !*** ./src/popup/components/Authentication/index.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_firebaseui_FirebaseAuth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-firebaseui/FirebaseAuth */ "./node_modules/react-firebaseui/FirebaseAuth.js");
/* harmony import */ var _foregroundFirebaseForAuth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./foregroundFirebaseForAuth */ "./src/popup/components/Authentication/foregroundFirebaseForAuth.js");
/* harmony import */ var common_config_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! common/config/auth */ "./src/lib/common/config/auth.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");


 // No custom callbacks needed, so can use defaults directly



var makeUiOptions = function makeUiOptions(firebase) {
  return (0,common_config_auth__WEBPACK_IMPORTED_MODULE_2__.getDefaultAuthOptions)(firebase);
};

var Authentication = function Authentication(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(react_firebaseui_FirebaseAuth__WEBPACK_IMPORTED_MODULE_0__.default, {
    uiConfig: makeUiOptions(_foregroundFirebaseForAuth__WEBPACK_IMPORTED_MODULE_1__.default),
    firebaseAuth: _foregroundFirebaseForAuth__WEBPACK_IMPORTED_MODULE_1__.default.auth()
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Authentication);

/***/ })

}]);
//# sourceMappingURL=src_popup_components_Authentication_index_js.js.map