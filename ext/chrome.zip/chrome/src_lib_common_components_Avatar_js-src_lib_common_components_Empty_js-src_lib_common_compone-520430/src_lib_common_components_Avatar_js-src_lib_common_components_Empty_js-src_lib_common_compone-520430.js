(self["webpackChunkeditor_browser_extension"] = self["webpackChunkeditor_browser_extension"] || []).push([["src_lib_common_components_Avatar_js-src_lib_common_components_Empty_js-src_lib_common_compone-520430"],{

/***/ "./src/lib/common/components/Avatar.js":
/*!*********************************************!*\
  !*** ./src/lib/common/components/Avatar.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_user_avatar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-user-avatar */ "./node_modules/react-user-avatar/user-avatar.js");
/* harmony import */ var react_user_avatar__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_user_avatar__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


 // Prevent broken avatar alt text from taking up whole page
// TODO: fix-style


var style = {
  overflow: 'hidden'
}; // Note: does NOT accept className prop, as it gets set by underlying library (fork and add cn support?)

var Avatar = function Avatar(_ref) {
  var user = _ref.user,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 48 : _ref$size,
      props = _objectWithoutProperties(_ref, ["user", "size"]);

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)((react_user_avatar__WEBPACK_IMPORTED_MODULE_0___default()), _objectSpread({
    size: size,
    name: user.name,
    src: user.avatar,
    alt: "".concat((0,common_utils__WEBPACK_IMPORTED_MODULE_1__.handle)(user), "'s avatar"),
    style: style
  }, props));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Avatar);

/***/ }),

/***/ "./src/lib/common/components/Empty.js":
/*!********************************************!*\
  !*** ./src/lib/common/components/Empty.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");


var Jumbotron = function Jumbotron(_ref) {
  var _ref$bg = _ref.bg,
      bg = _ref$bg === void 0 ? 'light' : _ref$bg,
      children = _ref.children;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
    className: "jumbotron jumbotron-fluid mb-0 bg-".concat(bg),
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
      className: "container-fluid px-2",
      children: children
    })
  });
};

var Empty = function Empty(_ref2) {
  var children = _ref2.children;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Jumbotron, {
    bg: "secondary-light",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", {
      className: "mx-2 font-weight-light text-center text-dark",
      children: children
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Empty);

/***/ }),

/***/ "./src/lib/common/components/Hashtags.js":
/*!***********************************************!*\
  !*** ./src/lib/common/components/Hashtags.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Hashtags": () => (/* binding */ Hashtags),
/* harmony export */   "Hashtag": () => (/* binding */ Hashtag),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var common_routes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! common/routes */ "./src/lib/common/routes.js");
/* harmony import */ var universal_components_UniversalLink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/UniversalLink */ "./src/lib/universal-interface/components/UniversalLink.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






var Hashtags = function Hashtags(_ref) {
  var _ref$hashtags = _ref.hashtags,
      hashtags = _ref$hashtags === void 0 ? [] : _ref$hashtags,
      prefix = _ref.prefix,
      className = _ref.className,
      tagClassName = _ref.tagClassName,
      props = _objectWithoutProperties(_ref, ["hashtags", "prefix", "className", "tagClassName"]);

  return (hashtags === null || hashtags === void 0 ? void 0 : hashtags.length) === 0 ? null : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: (0,common_utils__WEBPACK_IMPORTED_MODULE_0__.cn)('d-flex flex-wrap', className),
    children: [prefix, hashtags.map(function (tag) {
      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(Hashtag, _objectSpread(_objectSpread({
        tag: tag
      }, props), {}, {
        className: tagClassName
      }), tag);
    })]
  });
}; // assumes already run through stringToHashtag

var Hashtag = function Hashtag(_ref2) {
  var tag = _ref2.tag,
      link = _ref2.link,
      className = _ref2.className;
  var classes = (0,common_utils__WEBPACK_IMPORTED_MODULE_0__.cn)('k-span mx-1', className);
  if (!link) return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("span", {
    className: classes,
    children: ["#", tag]
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(universal_components_UniversalLink__WEBPACK_IMPORTED_MODULE_2__.default, {
    href: common_routes__WEBPACK_IMPORTED_MODULE_1__.default.hashtagUrl(tag),
    className: classes,
    title: "#".concat(tag)
  });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hashtags);

/***/ }),

/***/ "./src/lib/common/components/Popover.js":
/*!**********************************************!*\
  !*** ./src/lib/common/components/Popover.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/OverlayTrigger.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/Popover.js");
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






var Popover = function Popover(_ref) {
  var trigger = _ref.trigger,
      title = _ref.title,
      content = _ref.content,
      noBodyPadding = _ref.noBodyPadding,
      children = _ref.children,
      overrideTrigger = _ref.overrideTrigger,
      props = _objectWithoutProperties(_ref, ["trigger", "title", "content", "noBodyPadding", "children", "overrideTrigger"]);

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.default, _objectSpread(_objectSpread({
    trigger: overrideTrigger || ['hover', 'focus', 'click'],
    overlay: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.default, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.default.Title, {
        children: title
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.default.Content, {
        className: (0,common_utils__WEBPACK_IMPORTED_MODULE_0__.cn)(noBodyPadding && 'p-0'),
        children: [content, children]
      })]
    }),
    transition: false // TODO:POLISH: Remove once https://github.com/react-bootstrap/react-bootstrap is updated to a newer version of
    // react-transition-group (until this, this is necessary to avoid findDOMNode warning in strict mode)

  }, props), {}, {
    children: function children(_ref2) {
      var ref = _ref2.ref,
          triggerHandler = _objectWithoutProperties(_ref2, ["ref"]);

      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("span", _objectSpread(_objectSpread({
        role: "button",
        ref: ref
      }, triggerHandler), {}, {
        children: trigger
      }));
    }
  }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Popover);

/***/ }),

/***/ "./src/lib/common/components/TimeAgo.js":
/*!**********************************************!*\
  !*** ./src/lib/common/components/TimeAgo.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var timeago_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! timeago-react */ "./node_modules/timeago-react/esm/timeago-react.js");
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





var TimeAgo = function TimeAgo(_ref) {
  var datetime = _ref.datetime,
      props = _objectWithoutProperties(_ref, ["datetime"]);

  if (!datetime) return null;

  try {
    var dt = (0,common_utils__WEBPACK_IMPORTED_MODULE_1__.dateFromDatish)(datetime);
    return dt ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(timeago_react__WEBPACK_IMPORTED_MODULE_0__.default, _objectSpread({
      title: dt.toLocaleString(),
      datetime: dt
    }, props)) : null;
  } catch (e) {
    return null;
  }
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TimeAgo);

/***/ }),

/***/ "./src/lib/common/components/VoteEmote.js":
/*!************************************************!*\
  !*** ./src/lib/common/components/VoteEmote.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getMood": () => (/* binding */ getMood),
/* harmony export */   "VoteEmote": () => (/* binding */ VoteEmote),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var common_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! common/utils */ "./src/lib/common/utils/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");



var getMood = function getMood(vote) {
  return vote > 0 ? 'success' : vote < 0 ? 'danger' : 'secondary';
};
var VoteEmote = function VoteEmote(_ref) {
  var vote = _ref.vote,
      className = _ref.className;
  var voteEmote;

  switch (vote) {
    case 1:
      voteEmote = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: "\uD83D\uDC4D"
      });
      break;

    case -1:
      voteEmote = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: "\uD83D\uDC4E"
      });
      break;

    default:
      voteEmote = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: "\uD83E\uDD37\u200D\u2642\uFE0F"
      });
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("span", {
    className: (0,common_utils__WEBPACK_IMPORTED_MODULE_0__.cn)('text-nowrap', className),
    children: voteEmote
  });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VoteEmote);

/***/ }),

/***/ "./src/lib/common/hooks/useModalResizing.js":
/*!**************************************************!*\
  !*** ./src/lib/common/hooks/useModalResizing.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");

var MARGIN = 20;
/*
 * useModalResizing - returns onEntered/onExited hooks to add to react-bootstrap's modal
 * when it's being used in the browser extension context (tries to make the extension window
 * grow to show full modal height, then shrink again when closed).
 *
 * NOTE: this seem functional up to window heights of ~600px, then hit chrome's max sizes
 */

var useModalResizing = function useModalResizing() {
  var onEntered = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function (modalWrapperElement) {
    if (!window) return true;
    var body = document.querySelector('body');
    var modalElement = modalWrapperElement.querySelector('.modal-content');
    var modalHeight = modalElement.scrollHeight + 2 * MARGIN;
    body.style.minHeight = "".concat(modalHeight, "px");
  }, []);
  var onExited = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function () {
    var body = document.querySelector('body');
    body.style.minHeight = 'initial';
  }, []);
  return {
    onEntered: onEntered,
    onExited: onExited
  };
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useModalResizing);

/***/ })

}]);
//# sourceMappingURL=src_lib_common_components_Avatar_js-src_lib_common_components_Empty_js-src_lib_common_compone-520430.js.map