"use strict";
(self["webpackChunkvoyd_browser_extension"] = self["webpackChunkvoyd_browser_extension"] || []).push([[145],{

/***/ 145:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ext_ReadMode)
});

// EXTERNAL MODULE: ./src/lib/common/hooks/index.js
var hooks = __webpack_require__(98415);
// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(85893);
;// CONCATENATED MODULE: ./src/lib/common/components/Empty.js


var Empty = function Empty(_ref) {
  var children = _ref.children;
  return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
    bg: "py-2 bg-gray-200",
    children: /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
      className: "m-2 font-light text-center text-gray-800",
      children: children
    })
  });
};

/* harmony default export */ const components_Empty = (Empty);
// EXTERNAL MODULE: ./src/lib/common/components/Loader.js
var Loader = __webpack_require__(38626);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(67294);
// EXTERNAL MODULE: ./src/lib/common/utils/index.js
var utils = __webpack_require__(37724);
// EXTERNAL MODULE: ./src/lib/common/components/VoteEmote.js
var VoteEmote = __webpack_require__(92617);
// EXTERNAL MODULE: ./src/lib/common/components/ReviewCard/index.js + 2 modules
var ReviewCard = __webpack_require__(92153);
// EXTERNAL MODULE: ./src/lib/common/recoil/index.js
var recoil = __webpack_require__(34858);
// EXTERNAL MODULE: ./node_modules/lodash/lodash.js
var lodash = __webpack_require__(96486);
// EXTERNAL MODULE: ./src/lib/common/logic/index.js
var logic = __webpack_require__(55231);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/ReadModeContent/OverallRating/index.js
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }












var OverallRating = function OverallRating(_ref) {
  var featuredReview = _ref.featuredReview,
      vote = _ref.vote,
      overallVote = _ref.overallVote;
  var bg = vote > 0 ? 'bg-green-500' : vote < 0 ? 'bg-red-500' : 'bg-gray-500';

  var _ref2 = featuredReview || {},
      review = _ref2.review,
      user = _ref2.user; // TODO: pull this out somewhere cleanly, this is just a proof of concept until we nail down how we're displaying the featured review


  var bylineSuffix = (0,react.useMemo)(function () {
    return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
      children: ["by ", (0,utils/* handle */.pr)(user)]
    });
  }, [user]);

  var _useRecoilState = (0,recoil/* useRecoilState */.FV)(recoil/* readingContextAtom */.$N),
      _useRecoilState2 = _slicedToArray(_useRecoilState, 2),
      readingContext = _useRecoilState2[0],
      setReadingContext = _useRecoilState2[1];

  var toggleReadingContext = (0,react.useCallback)(function () {
    setReadingContext(readingContext === 'domain' ? 'page' : 'domain');
  }, [readingContext, setReadingContext]);

  var _useRecoilValue = (0,recoil/* useRecoilValue */.sJ)(recoil/* currentAtom */.C),
      domainKey = _useRecoilValue.domainKey,
      pageKey = _useRecoilValue.pageKey;

  var domainContextTitle = (0,react.useMemo)(function () {
    return domainKey ? (0,lodash.capitalize)(domainKey) : 'Domain';
  }, [domainKey]);
  var pageContextTitle = (0,react.useMemo)(function () {
    var _partsFromPageKey = (0,logic/* partsFromPageKey */.n0)(pageKey),
        path = _partsFromPageKey.path;

    return path ? path : 'This Page';
  }, [pageKey]);

  var _useMemo = (0,react.useMemo)(function () {
    return {
      currentContextTitle: readingContext === 'domain' ? domainContextTitle : pageContextTitle,
      altContextTitle: readingContext === 'domain' ? pageContextTitle : domainContextTitle
    };
  }, [pageContextTitle, domainContextTitle, readingContext]),
      currentContextTitle = _useMemo.currentContextTitle,
      altContextTitle = _useMemo.altContextTitle;

  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: (0,utils.cn)(bg),
    children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "p-3 cursor-pointer text-gray-900",
      onClick: toggleReadingContext,
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        className: "text-center text-xl truncate w-full",
        children: currentContextTitle
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        className: "text-center text-sm text-gray-700 truncate w-full",
        children: altContextTitle
      })]
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      className: "px-2 pb-8",
      children: /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        className: "p-4 bg-gray-50 mx-5 mb-0 border rounded-md space-y-5",
        children: featuredReview ? /*#__PURE__*/(0,jsx_runtime.jsx)(ReviewCard/* default */.ZP, {
          review: review // Note: intentionally NOT setting user -- we don't want the left UI
          // title={title}
          // className="w-full hover:bg-gray-100 active:bg-gray-200"
          ,
          skipLinks: true,
          bylineSuffix: bylineSuffix
        }) : /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
          className: "text-6xl text-center flex justify-center items-center",
          children: /*#__PURE__*/(0,jsx_runtime.jsx)(VoteEmote/* default */.Z, {
            vote: overallVote,
            className: "p-1 h-24"
          })
        })
      })
    })]
  });
};

/* harmony default export */ const ReadModeContent_OverallRating = (OverallRating);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/tabs/tabs.js + 1 modules
var tabs = __webpack_require__(17969);
// EXTERNAL MODULE: ./src/lib/common/routes.js
var routes = __webpack_require__(11147);
// EXTERNAL MODULE: ./src/lib/universal-interface/UniversalLink.js
var UniversalLink = __webpack_require__(84261);
// EXTERNAL MODULE: ./src/lib/common/components/Avatar.js
var Avatar = __webpack_require__(70017);
// EXTERNAL MODULE: ./src/lib/common/components/icons/index.js + 13 modules
var icons = __webpack_require__(69798);
// EXTERNAL MODULE: ./src/lib/common/components/ShareReview/index.js + 3 modules
var ShareReview = __webpack_require__(66330);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/ReadModeContent/Details/ScoredReviewLineItem.js
function ScoredReviewLineItem_slicedToArray(arr, i) { return ScoredReviewLineItem_arrayWithHoles(arr) || ScoredReviewLineItem_iterableToArrayLimit(arr, i) || ScoredReviewLineItem_unsupportedIterableToArray(arr, i) || ScoredReviewLineItem_nonIterableRest(); }

function ScoredReviewLineItem_nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function ScoredReviewLineItem_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return ScoredReviewLineItem_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return ScoredReviewLineItem_arrayLikeToArray(o, minLen); }

function ScoredReviewLineItem_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function ScoredReviewLineItem_iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function ScoredReviewLineItem_arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }













var ScoredReviewLineItem = function ScoredReviewLineItem(_ref) {
  var scored = _ref.scored,
      domainKey = _ref.domainKey,
      targetPageKey = _ref.targetPageKey;
  var reviewType = scored.reviewType,
      review = scored.review,
      domainPacket = scored.domainPacket,
      user = scored.user;

  var _useState = (0,react.useState)(false),
      _useState2 = ScoredReviewLineItem_slicedToArray(_useState, 2),
      showShare = _useState2[0],
      setShowShare = _useState2[1];

  var startSharing = (0,hooks/* useLinkCallback */._P)(function () {
    return setShowShare(true);
  }, [setShowShare]);
  var stopSharing = (0,hooks/* useLinkCallback */._P)(function () {
    return setShowShare(false);
  }, [setShowShare]); // note: page reviews link to specific review, otherwise link to domain review (e.g. rule reviews don't have clear destination, link to base instead)

  var pageKey = reviewType === 'pageReview' ? targetPageKey : null;

  var title = /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
    className: "text-base flex justify-between items-center pl-5 text-gray-600",
    children: /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "flex items-center text-left leading-tight break-all",
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)(Avatar/* default */.Z, {
        user: user,
        size: 25,
        className: "border rounded-full mr-1"
      }), (0,utils/* handle */.pr)(user)]
    })
  });

  return /*#__PURE__*/(0,jsx_runtime.jsxs)("li", {
    className: "snap-start relative group w-full",
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)(UniversalLink/* default */.Z, {
      href: routes/* default.reviewUrl */.Z.reviewUrl(user, domainKey, pageKey),
      children: /*#__PURE__*/(0,jsx_runtime.jsx)(ReviewCard/* default */.ZP, {
        review: review,
        title: title,
        className: "w-full hover:bg-gray-100 active:bg-gray-200",
        skipLinks: true,
        skipStaff: true
      })
    }), showShare ? /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      className: "flex absolute inset-0 z-10 bg-gray-400 bg-opacity-90 justify-center items-center p-10",
      style: {
        left: '-25px'
      },
      onClick: stopSharing,
      children: /*#__PURE__*/(0,jsx_runtime.jsx)(ShareReview/* default */.ZP, {
        domainKey: domainKey,
        pageKey: pageKey,
        review: review,
        domainPacket: domainPacket,
        author: user,
        size: 30,
        className: "p-5 flex flex-col space-y-4",
        iconProps: {
          skipLabel: true
        },
        showUrl: true
      })
    }) : /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      onClick: startSharing,
      className: "text-gray-300 hover:text-gray-400 hover:bg-gray-600 hover:bg-opacity-10 rounded-full w-12 h-12 hidden group-hover:flex justify-center items-center absolute bottom-5 right-5 cursor-pointer p-2 pr-3",
      children: /*#__PURE__*/(0,jsx_runtime.jsx)(icons/* ShareIcon */.aA, {
        className: "w-10 h-10"
      })
    })]
  });
};

/* harmony default export */ const Details_ScoredReviewLineItem = (ScoredReviewLineItem);
;// CONCATENATED MODULE: ./src/lib/common/components/VoteArrowWithBadge.js

 // TODO: DRY?




var moodClass = function moodClass(effectiveVote) {
  return effectiveVote > 0 ? 'text-green-600' : effectiveVote < 0 ? 'text-red-600' : 'text-gray-500';
};

var VoteArrowWithBadge = function VoteArrowWithBadge(_ref) {
  var vote = _ref.vote,
      text = _ref.text;
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: (0,utils.cn)('relative', moodClass(vote)),
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      className: "h-full w-full absolute inset-0 flex justify-center items-center z-10 text-xl",
      children: text
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      className: "h-full w-full relative inset-0 flex justify-center items-center",
      children: /*#__PURE__*/(0,jsx_runtime.jsx)(VoteEmote/* default */.Z, {
        vote: vote,
        className: "w-20"
      })
    })]
  });
};

/* harmony default export */ const components_VoteArrowWithBadge = (VoteArrowWithBadge);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/ReadModeContent/Details/index.js
function Details_slicedToArray(arr, i) { return Details_arrayWithHoles(arr) || Details_iterableToArrayLimit(arr, i) || Details_unsupportedIterableToArray(arr, i) || Details_nonIterableRest(); }

function Details_nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function Details_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return Details_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Details_arrayLikeToArray(o, minLen); }

function Details_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function Details_iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function Details_arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }







 // TODO: DRY?




var bgClass = function bgClass(effectiveVote) {
  return effectiveVote > 0 ? 'border-green-600' : effectiveVote < 0 ? 'border-red-600' : 'border-gray-500';
};

var ScoreSectionTab = function ScoreSectionTab(_ref) {
  var effectiveVote = _ref.effectiveVote,
      scores = _ref.scores;
  return /*#__PURE__*/(0,jsx_runtime.jsx)(tabs/* Tab */.O, {
    className: function className(_ref2) {
      var selected = _ref2.selected;
      return (0,utils.cn)('w-full flex flex-col justify-between items-center border-b p-3 space-y-1', selected ? 'bg-gray-100 hover:bg-gray-200' : 'bg-gray-50 hover:bg-gray-200');
    },
    children: /*#__PURE__*/(0,jsx_runtime.jsx)(components_VoteArrowWithBadge, {
      vote: effectiveVote,
      text: scores.length
    })
  });
};

var ScoreSectionPanel = function ScoreSectionPanel(_ref3) {
  var effectiveVote = _ref3.effectiveVote,
      scores = _ref3.scores,
      domainKey = _ref3.domainKey,
      targetPageKey = _ref3.targetPageKey;
  return /*#__PURE__*/(0,jsx_runtime.jsx)(tabs/* Tab.Panel */.O.Panel, {
    className: (0,utils.cn)('bg-white', 'border-t-2', bgClass(effectiveVote)),
    children: scores.length === 0 ? /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      className: "py-5 text-center text-xl font-light text-gray-500",
      children: "None"
    }) : /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "flex w-full",
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        className: "w-4 flex-shrink-0"
      }), /*#__PURE__*/(0,jsx_runtime.jsx)(ReviewCard/* ReviewStaff */.j0, {
        vote: effectiveVote,
        className: "z-10"
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("ul", {
        className: "snap-y w-full",
        children: scores.map(function (scored, idx) {
          return /*#__PURE__*/(0,jsx_runtime.jsx)(Details_ScoredReviewLineItem, {
            scored: scored,
            domainKey: domainKey,
            targetPageKey: targetPageKey
          }, idx);
        })
      })]
    })
  });
};

var Details = function Details(_ref4) {
  var targetPageKey = _ref4.targetPageKey,
      _ref4$positive = _ref4.positive,
      positive = _ref4$positive === void 0 ? [] : _ref4$positive,
      _ref4$negative = _ref4.negative,
      negative = _ref4$negative === void 0 ? [] : _ref4$negative,
      _ref4$neutral = _ref4.neutral,
      neutral = _ref4$neutral === void 0 ? [] : _ref4$neutral,
      domainKey = _ref4.domainKey;
  // TODO: if showNeutral is ALWAYS true, works as expected. But if one context has neutral and the other doesn't:
  // * activeTabIndex is set correctly
  // * the Tab.List is updated correctly to show the correct tab
  // * the Tab.Panels are NOT updated correctly -- shows context from different section than is selected in tab.list
  //
  // e.g. https://recoiljs.org/docs/api-reference/utils/selectorFamily/ - toggle page > domain > page, shows "No negative reviews for page"
  // despite activeTabIndex getting set correctly, and the actual score section does not match the selected
  var showNeutral = (0,react.useMemo)(function () {
    return neutral.length > 0;
  }, [neutral]);
  var defaultIndex = (0,react.useMemo)(function () {
    var defaultTabValue = positive.length >= negative.length && positive.length >= neutral.length ? 1 : negative.length > neutral.length ? -1 : 0;
    var comparisonTable = showNeutral ? [1, 0, -1] : [1, -1];
    var di = comparisonTable.indexOf(defaultTabValue); // console.log('~~~ Details', {
    //   defaultIndex: di,
    //   defaultTabValue,
    //   comparisonTable,
    //   positive,
    //   negative,
    //   neutral,
    // })

    return di;
  }, [neutral, negative, positive, showNeutral]);

  var _useState = (0,react.useState)(defaultIndex),
      _useState2 = Details_slicedToArray(_useState, 2),
      activeTabIndex = _useState2[0],
      setActiveTabIndex = _useState2[1];

  (0,react.useEffect)(function () {
    setActiveTabIndex(defaultIndex);
  }, [setActiveTabIndex, defaultIndex]);
  return /*#__PURE__*/(0,jsx_runtime.jsx)(tabs/* Tab.Group */.O.Group, {
    selectedIndex: activeTabIndex,
    onChange: setActiveTabIndex,
    children: /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      children: [/*#__PURE__*/(0,jsx_runtime.jsxs)(tabs/* Tab.List */.O.List, {
        className: "flex",
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)(ScoreSectionTab, {
          domainKey: domainKey,
          effectiveVote: 1,
          scores: positive
        }), showNeutral ? /*#__PURE__*/(0,jsx_runtime.jsx)(ScoreSectionTab, {
          domainKey: domainKey,
          effectiveVote: 0,
          scores: neutral
        }) : null, /*#__PURE__*/(0,jsx_runtime.jsx)(ScoreSectionTab, {
          domainKey: domainKey,
          effectiveVote: -1,
          scores: negative
        })]
      }), /*#__PURE__*/(0,jsx_runtime.jsxs)(tabs/* Tab.Panels */.O.Panels, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)(ScoreSectionPanel, {
          domainKey: domainKey,
          targetPageKey: targetPageKey,
          scores: positive,
          effectiveVote: 1
        }), showNeutral ? /*#__PURE__*/(0,jsx_runtime.jsx)(ScoreSectionPanel, {
          domainKey: domainKey,
          targetPageKey: targetPageKey,
          scores: neutral,
          effectiveVote: 0
        }) : null, /*#__PURE__*/(0,jsx_runtime.jsx)(ScoreSectionPanel, {
          domainKey: domainKey,
          targetPageKey: targetPageKey,
          scores: negative,
          effectiveVote: -1
        })]
      })]
    })
  });
};

/* harmony default export */ const ReadModeContent_Details = (Details);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/ReadModeContent/index.js







var ReadModeContent = function ReadModeContent(_ref) {
  var domainKey = _ref.domainKey,
      reviewsForPage = _ref.reviewsForPage,
      reviewsForDomain = _ref.reviewsForDomain;
  var readingContext = (0,recoil/* useRecoilValue */.sJ)(recoil/* readingContextAtom */.$N);

  var _ref2 = readingContext === 'page' ? reviewsForPage : reviewsForDomain,
      targetPageKey = _ref2.targetPageKey,
      positiveReviews = _ref2.positiveReviews,
      negativeReviews = _ref2.negativeReviews,
      neutralReviews = _ref2.neutralReviews,
      delta = _ref2.delta,
      overallVote = _ref2.overallVote;

  var winningReviews = delta === 0 && neutralReviews.length ? neutralReviews : delta < 0 ? negativeReviews : positiveReviews; // Featured review: most recent that has meaningful content... else just most recent

  var featuredReview = (0,lodash.find)(winningReviews, function (_ref3) {
    var review = _ref3.review;
    var comment = review.comment,
        hashtags = review.hashtags;
    return (comment === null || comment === void 0 ? void 0 : comment.length) || (hashtags === null || hashtags === void 0 ? void 0 : hashtags.length);
  }) || winningReviews[0];
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: "flex flex-col",
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)(ReadModeContent_OverallRating, {
      featuredReview: featuredReview,
      vote: overallVote,
      overallVote: overallVote
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ReadModeContent_Details, {
      positive: positiveReviews,
      negative: negativeReviews,
      neutral: neutralReviews,
      domainKey: domainKey,
      targetPageKey: targetPageKey
    })]
  });
};

/* harmony default export */ const ReadMode_ReadModeContent = (ReadModeContent);
// EXTERNAL MODULE: ./src/lib/common/components/ext/SubnavBar.js
var SubnavBar = __webpack_require__(39257);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/SelectReadingFrom/CurrentlyActiveDescription.js




var Badge = function Badge(_ref) {
  var className = _ref.className,
      children = _ref.children;
  return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
    className: (0,utils.cn)('ml-2 px-2 py-0.5 mb-0.5 rounded-full text-sm', className),
    children: children
  });
};

var CurrentlyActiveDescription = function CurrentlyActiveDescription(_props) {
  var activeUids = (0,recoil/* useRecoilValue */.sJ)(recoil/* activeUidsAtom */.Ox);

  if (!activeUids || activeUids.length === 0) {
    return /*#__PURE__*/(0,jsx_runtime.jsx)(Badge, {
      className: "bg-yellow-400 text-gray-800 text-uppercase",
      children: "No active views!"
    });
  }

  return /*#__PURE__*/(0,jsx_runtime.jsx)(Badge, {
    className: "bg-blue-100",
    children: /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
      children: (0,utils/* plur */.Jn)(activeUids.length, 'active view')
    })
  });
};

/* harmony default export */ const SelectReadingFrom_CurrentlyActiveDescription = (CurrentlyActiveDescription);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/transitions/transition.js + 5 modules
var transition = __webpack_require__(66091);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/dialog/dialog.js + 6 modules
var dialog = __webpack_require__(30610);
;// CONCATENATED MODULE: ./src/lib/common/components/GenericModal.js
function GenericModal_slicedToArray(arr, i) { return GenericModal_arrayWithHoles(arr) || GenericModal_iterableToArrayLimit(arr, i) || GenericModal_unsupportedIterableToArray(arr, i) || GenericModal_nonIterableRest(); }

function GenericModal_nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function GenericModal_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return GenericModal_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return GenericModal_arrayLikeToArray(o, minLen); }

function GenericModal_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function GenericModal_iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function GenericModal_arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }









var GenericModal = function GenericModal(_ref) {
  var show = _ref.show,
      onClose = _ref.onClose,
      preventIndirectClose = _ref.preventIndirectClose,
      title = _ref.title,
      description = _ref.description,
      children = _ref.children,
      closeIcon = _ref.closeIcon,
      onEntered = _ref.onEntered,
      onExited = _ref.onExited,
      _ref$headerHeight = _ref.headerHeight,
      headerHeight = _ref$headerHeight === void 0 ? 0 : _ref$headerHeight;

  // To enable animation on preventing-closing... hackish, much better with react-simple-animate or similar
  var _useState = (0,react.useState)(false),
      _useState2 = GenericModal_slicedToArray(_useState, 2),
      scale = _useState2[0],
      setScale = _useState2[1];

  var triggerScale = (0,hooks/* useLinkCallback */._P)(function () {
    setScale(true);
    setTimeout(function () {
      return setScale(false);
    }, 200);
  }); // TODO: or just pop up a custom modal to confirm clearing...

  var indirectCloseFn = (0,react.useCallback)(function () {
    preventIndirectClose ? triggerScale() : onClose();
  }, [preventIndirectClose]);
  var inExtensionContext = "extension" === 'extension';
  return (
    /*#__PURE__*/
    // Use the `Transition` component + show prop to add transitions... but there's gotta be a cleaner way to manage this.
    (0,jsx_runtime.jsx)(transition/* Transition */.u, {
      show: !!show,
      as: react.Fragment,
      afterEnter: onEntered,
      afterLeave: onExited,
      children: /*#__PURE__*/(0,jsx_runtime.jsx)(dialog/* Dialog */.V, {
        "static": true,
        open: !!show,
        onClose: indirectCloseFn,
        className: "fixed inset-0 overflow-y-auto",
        style: {
          zIndex: 20
        },
        children: /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
          className: "flex items-center justify-center min-h-screen",
          children: [/*#__PURE__*/(0,jsx_runtime.jsx)(dialog/* Dialog.Overlay */.V.Overlay, {
            className: "fixed inset-0 bg-black opacity-30"
          }), /*#__PURE__*/(0,jsx_runtime.jsx)(transition/* Transition.Child */.u.Child, {
            as: react.Fragment,
            enter: "ease-out duration-300",
            enterFrom: "opacity-0 scale-95",
            enterTo: "opacity-100 scale-100",
            leave: "ease-in duration-200",
            leaveFrom: "opacity-100 scale-100",
            leaveTo: "opacity-0 scale-95",
            children: /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
              className: (0,utils.cn)('k-modal-content m-5', 'relative z-20 mx-auto bg-white rounded shadow', 'transition duration-600 ease-in-out', scale ? 'scale-105' : 'scale-100', inExtensionContext ? 'max-w-[400px]' : 'max-w-lg'),
              style: {
                marginTop: headerHeight
              },
              children: [closeIcon && /*#__PURE__*/(0,jsx_runtime.jsx)(icons/* CloseIcon */.Tw, {
                className: "absolute text-xl text-gray-200 cursor-pointer hover:text-gray-400 right-2 top-2",
                onClick: onClose
              }), title && /*#__PURE__*/(0,jsx_runtime.jsx)(dialog/* Dialog.Title */.V.Title, {
                className: "p-4 pb-1 text-2xl font-light text-center",
                children: title
              }), description && /*#__PURE__*/(0,jsx_runtime.jsx)(dialog/* Dialog.Description */.V.Description, {
                children: description
              }), children]
            })
          })]
        })
      })
    })
  );
};

GenericModal.Body = function (_ref2) {
  var children = _ref2.children,
      className = _ref2.className;
  return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
    className: (0,utils.cn)('bg-white p-5 rounded-t', className),
    children: children
  });
};

GenericModal.Footer = function (_ref3) {
  var children = _ref3.children,
      className = _ref3.className,
      dark = _ref3.dark;
  return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
    className: (0,utils.cn)('bg-gray-100 p-5 border-t rounded-b', className),
    children: children
  });
};

/* harmony default export */ const components_GenericModal = (GenericModal);
// EXTERNAL MODULE: ./src/lib/common/components/Button/index.js
var Button = __webpack_require__(95673);
// EXTERNAL MODULE: ./node_modules/react-select/dist/react-select.esm.js
var react_select_esm = __webpack_require__(23157);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/SelectReadingFrom/ReadingFromSelector/selectHelpers.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







var noOptionsMessage = function noOptionsMessage(_ref) {
  var inputValue = _ref.inputValue;
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
    className: "mb-0",
    children: ["No unselected views", ' ', (inputValue === null || inputValue === void 0 ? void 0 : inputValue.length) === 0 ? 'remain.' : "match \"".concat(inputValue, "\"")]
  });
};
var formatOptionLabel = function formatOptionLabel(option, _ref2) {
  var context = _ref2.context;
  if (Object.keys(option).length === 0) console.log('formatOptionLabel: option has no keys', option);
  var label = Object.keys(option).includes('taggedUserIds') ? formatOptionLabel_ForTag(option, context) : formatOptionLabel_ForUser(option, context);
  return label || /*#__PURE__*/(0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
    children: option.label
  });
}; // NOTE: Used in the menu AND when selected...

var formatOptionLabel_ForTag = function formatOptionLabel_ForTag(option, context) {
  // Once selected, within the search bar at the top - NOTE: new logic should filter these out -- should NOT ever be called
  if (context === 'value') {
    return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "text-gray-400",
      children: ["#", option.label]
    });
  } // When unselected, in the menu below


  if (context === 'menu') return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: "option p-2 text-gray-800",
    children: ["#", option.label]
  });
}; // NOTE: Used in the menu AND when selected...


var formatOptionLabel_ForUser = function formatOptionLabel_ForUser(option, context) {
  // Once selected, within the search bar at the top
  if (context === 'value') {
    return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "text-gray-700",
      children: ["@", option.label]
    });
  } // When unselected, in the menu below


  if (context === 'menu') {
    var user = option.user;

    var _ref3 = user || {},
        name = _ref3.name;

    return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "option flex items-center p-2",
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)(Avatar/* default */.Z, {
        user: user,
        size: 40,
        className: "mr-2"
      }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "inline-flex flex-col",
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("span", {
          className: "text-blue-500",
          children: (0,utils/* handle */.pr)(user)
        }), (name === null || name === void 0 ? void 0 : name.length) && name !== option.label && /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
          className: "text-gray-500 text-sm ml-1",
          children: name
        })]
      })]
    });
  }
};

var customSelectStyles = {
  // Make menu look like it belongs in the modal (rather than floating above it)
  menu: function menu(provided) {
    return _objectSpread(_objectSpread({}, provided), {}, {
      boxShadow: 'none',
      position: 'relative',
      marginBottom: '10px'
    });
  },
  // Indent options a bit
  option: function option(provided) {
    return _objectSpread(_objectSpread({}, provided), {}, {
      padding: '0',
      display: 'flex',
      alignItems: 'center',
      borderRadius: '5px',
      width: 'auto',
      fontSize: '1rem'
    });
  }
};
// EXTERNAL MODULE: ./node_modules/recoil/es/recoil.js
var es_recoil = __webpack_require__(2804);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/SelectReadingFrom/ReadingFromSelector/index.js
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || ReadingFromSelector_unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return ReadingFromSelector_arrayLikeToArray(arr); }

function ReadingFromSelector_slicedToArray(arr, i) { return ReadingFromSelector_arrayWithHoles(arr) || ReadingFromSelector_iterableToArrayLimit(arr, i) || ReadingFromSelector_unsupportedIterableToArray(arr, i) || ReadingFromSelector_nonIterableRest(); }

function ReadingFromSelector_nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function ReadingFromSelector_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return ReadingFromSelector_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return ReadingFromSelector_arrayLikeToArray(o, minLen); }

function ReadingFromSelector_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function ReadingFromSelector_iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function ReadingFromSelector_arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }







var Filter = function Filter(_ref) {
  var label = _ref.label,
      active = _ref.active,
      onClick = _ref.onClick;
  return active ? /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
    className: "text-gray-500",
    children: label
  }) : /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
    href: "#",
    onClick: onClick,
    children: label
  });
};

 // Only tracked for this modal, but keeps it in sync between SelectActiveUsersModal (where we need to know the value to return it on submit)
// and ReadingFromSelector, which needs to know the value + be able to set it.

var selectedUidsAtom = (0,es_recoil.atom)({
  key: 'selectedUids',
  "default": (0,es_recoil.selector)({
    key: 'selectedUids/Default',
    get: function get(_ref2) {
      var _get = _ref2.get;
      return _get(recoil/* activeUidsAtom */.Ox) || [];
    }
  })
});




var makeOptionForUser = function makeOptionForUser(user) {
  return {
    label: user.handle,
    value: user.id,
    user: user
  };
};

var makeOptionForTag = function makeOptionForTag(tag, taggedUserIds) {
  return {
    label: tag,
    value: tag,
    taggedUserIds: taggedUserIds
  };
};

var ReadingFromSelector = function ReadingFromSelector(_props) {
  var followedUsers = (0,recoil/* useRecoilValue */.sJ)(recoil/* followedUsersAtom */.jL);

  var _useRecoilState = (0,recoil/* useRecoilState */.FV)(selectedUidsAtom),
      _useRecoilState2 = ReadingFromSelector_slicedToArray(_useRecoilState, 2),
      _selectedUids = _useRecoilState2[0],
      setSelectedUids = _useRecoilState2[1]; // TODO: this pattern should be extractable...


  var selectedUids = (0,react.useMemo)(function () {
    return _selectedUids || [];
  }, [_selectedUids]);
  var selectAll = (0,hooks/* useLinkCallback */._P)(function () {
    setSelectedUids(followedUsers.map(function (_ref3) {
      var id = _ref3.id;
      return id;
    }));
  }, [setSelectedUids, followedUsers]);
  var selectNone = (0,hooks/* useLinkCallback */._P)(function () {
    setSelectedUids([]);
  }, [setSelectedUids]); // We directly track the selected options, but need to be able to report on the selected UIDS

  var setSelectedUidsFromOptions = (0,react.useCallback)(function (options) {
    var uids = (0,lodash.uniq)((0,lodash.flatten)((options || []).map(function (option) {
      var taggedUserIds = option.taggedUserIds,
          value = option.value; // If user option selected, add that user. If tag option selected, add ALL users with that tag.

      var valueFromOption = taggedUserIds ? taggedUserIds : value; // If option was already set from previous, it may have just been a uid rather than an option
      // TODO: shouldn't we catch that where setting? and do we need the actual user, not uid, so we can render the label?

      return valueFromOption || option;
    })));
    setSelectedUids(uids);
  }, [setSelectedUids]);
  var userOptions = (0,react.useMemo)(function () {
    return (followedUsers || []).map(makeOptionForUser);
  }, [followedUsers]);
  var followedUidsByTag = (0,react.useMemo)(function () {
    return followedUsers.reduce(function (byTag, user) {
      user.tagged.forEach(function (tag) {
        byTag[tag] = (0,lodash.union)(byTag[tag] || [], [user.id]);
      });
      return byTag;
    }, {});
  }, [followedUsers]); // Note: we only want to return tag options for tags associated with NON-selected uids

  var tagOptions = (0,react.useMemo)(function () {
    var tags = (0,lodash.uniq)((0,lodash.flatten)((followedUsers || []).map(function (_ref4) {
      var _ref4$tagged = _ref4.tagged,
          tagged = _ref4$tagged === void 0 ? [] : _ref4$tagged;
      return tagged;
    })));
    var allTagOptions = tags.map(function (tag) {
      return makeOptionForTag(tag, followedUidsByTag[tag]);
    });
    var tagOptionsForUnselectedUids = allTagOptions.filter(function (opt) {
      return (0,lodash.difference)(opt.taggedUserIds, selectedUids).length > 0;
    });
    return tagOptionsForUnselectedUids;
  }, [followedUsers, followedUidsByTag, selectedUids]);
  var allOptions = (0,react.useMemo)(function () {
    return [].concat(_toConsumableArray((0,lodash.sortBy)(tagOptions, 'label')), _toConsumableArray((0,lodash.sortBy)(userOptions.filter(function (opt) {
      return !selectedUids.includes(opt.value);
    }), 'label')));
  }, [userOptions, tagOptions, selectedUids]);
  var selectedUserOptions = (0,react.useMemo)(function () {
    return userOptions.filter(function (opt) {
      return selectedUids.includes(opt.value);
    });
  }, [userOptions, selectedUids]);
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "mb-1 text-sm flex items-end w-full",
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)("span", {
        className: "mr-1",
        children: "Filters: "
      }), /*#__PURE__*/(0,jsx_runtime.jsx)(Filter, {
        label: "Select All",
        onClick: selectAll,
        active: selectedUids.length === userOptions.length
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
        className: "mx-2 text-gray-500",
        children: "|"
      }), /*#__PURE__*/(0,jsx_runtime.jsx)(Filter, {
        label: "Select None",
        onClick: selectNone,
        active: selectedUids.length === 0
      })]
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(react_select_esm/* default */.ZP, {
      placeholder: "Select views to activate...",
      noOptionsMessage: noOptionsMessage,
      formatOptionLabel: formatOptionLabel,
      styles: customSelectStyles,
      closeMenuOnSelect: false,
      captureMenuScroll: false,
      menuIsOpen: true,
      autoFocus: true,
      isMulti: true,
      options: allOptions,
      value: selectedUserOptions,
      onChange: setSelectedUidsFromOptions
    })]
  });
};

/* harmony default export */ const SelectReadingFrom_ReadingFromSelector = (ReadingFromSelector);
;// CONCATENATED MODULE: ./src/lib/common/hooks/useModalResizing.js

var MARGIN = 20;
var HEADER_HEIGHT = 115; // TODO: load this dynamically

/*
 * useModalResizing - returns onEntered/onExited hooks to add to GenericModal
 * when it's being used in the browser extension context (tries to make the extension window
 * grow to show full modal height, then shrink again when closed).
 *
 * NOTE: this seem functional up to window heights of ~600px, then hit chrome's max sizes
 */

var useModalResizing = function useModalResizing() {
  var onEntered = (0,react.useCallback)(function () {
    if (!window) return true;
    var body = document.querySelector('body');
    var modalElement = body.querySelector('.k-modal-content');
    if (!modalElement) return true;
    var modalHeight = modalElement.scrollHeight + 2 * MARGIN + HEADER_HEIGHT; // console.log('[useModalResizing] ', {
    //   body,
    //   modalElement,
    //   modalHeight,
    // })

    body.style.minHeight = "".concat(modalHeight, "px");
  }, []);
  var onExited = (0,react.useCallback)(function () {
    var body = document.querySelector('body');
    body.style.minHeight = 'initial';
  }, []);
  return {
    onEntered: onEntered,
    onExited: onExited
  };
};

/* harmony default export */ const hooks_useModalResizing = (useModalResizing);
// EXTERNAL MODULE: ./src/lib/common/hooks/useMinExtensionPopupHeight.js
var useMinExtensionPopupHeight = __webpack_require__(70624);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/SelectReadingFrom/SelectActiveUsersModal.js
function SelectActiveUsersModal_slicedToArray(arr, i) { return SelectActiveUsersModal_arrayWithHoles(arr) || SelectActiveUsersModal_iterableToArrayLimit(arr, i) || SelectActiveUsersModal_unsupportedIterableToArray(arr, i) || SelectActiveUsersModal_nonIterableRest(); }

function SelectActiveUsersModal_nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function SelectActiveUsersModal_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return SelectActiveUsersModal_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return SelectActiveUsersModal_arrayLikeToArray(o, minLen); }

function SelectActiveUsersModal_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function SelectActiveUsersModal_iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function SelectActiveUsersModal_arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }












 // Note: ideal to auto-select Submit after all selected, but refs don't work in function components




var SelectActiveUsersModal = function SelectActiveUsersModal(_ref) {
  var show = _ref.show,
      toggleModal = _ref.toggleModal;

  var _useRecoilState = (0,recoil/* useRecoilState */.FV)(recoil/* activeUidsAtom */.Ox),
      _useRecoilState2 = SelectActiveUsersModal_slicedToArray(_useRecoilState, 2),
      activeUids = _useRecoilState2[0],
      setActiveUids = _useRecoilState2[1];

  var selectedUids = (0,recoil/* useRecoilValue */.sJ)(selectedUidsAtom);
  var handleSubmit = (0,hooks/* useLinkCallback */._P)(function () {
    setActiveUids(selectedUids);
    toggleModal(false);
  }, [selectedUids, setActiveUids, toggleModal]);

  var _useToggle = (0,hooks/* useToggle */.OT)(false),
      _useToggle2 = SelectActiveUsersModal_slicedToArray(_useToggle, 2),
      showInfo = _useToggle2[0],
      toggleShowInfo = _useToggle2[1];

  var setMinWindowHeight = (0,useMinExtensionPopupHeight/* default */.Z)(); // TODO: figure out how to check actual modal height
  // TODO: pretty sure not actually taking effect currently

  (0,react.useEffect)(function () {
    setMinWindowHeight(show ? '650px' : 'auto');
  }, [show, setMinWindowHeight]);

  var _useModalResizing = hooks_useModalResizing(),
      onEntered = _useModalResizing.onEntered,
      onExited = _useModalResizing.onExited; // This block resets the modal height when the set of selected options changes (trying to keep it in popup height as much as possible)


  (0,react.useEffect)(function () {
    try {
      show && onEntered();
    } catch (e) {
      console.log('Got an issue:', e);
    }
  }, [show, onEntered, selectedUids]);
  return /*#__PURE__*/(0,jsx_runtime.jsxs)(components_GenericModal, {
    headerHeight: 115 // TODO: load this dynamically
    ,
    closeIcon: true,
    show: show,
    onClose: toggleModal,
    preventIndirectClose: (0,lodash.xor)(activeUids, selectedUids).length === 0 ? true : 'static',
    onEntered: onEntered,
    onExited: onExited,
    title: /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
      children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "",
        children: ["Select Views", /*#__PURE__*/(0,jsx_runtime.jsx)(icons/* InfoIcon */.sz, {
          className: "ml-1 inline text-base text-gray-500",
          onClick: toggleShowInfo
        })]
      }), showInfo && /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "text-left space-y-4 text-base p-4 text-gray-400",
        children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
          children: ["This modal lets you to select precisely which, of all the views you follow, you want to be ", /*#__PURE__*/(0,jsx_runtime.jsx)("em", {
            children: "active"
          }), " right now."]
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
          children: ["Each page you visit will be compared against ratings from", ' ', /*#__PURE__*/(0,jsx_runtime.jsx)("em", {
            children: "the currently active"
          }), " view that you select here."]
        })]
      })]
    }),
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)(components_GenericModal.Body, {
      className: "pb-0",
      children: /*#__PURE__*/(0,jsx_runtime.jsx)(SelectReadingFrom_ReadingFromSelector, {})
    }), /*#__PURE__*/(0,jsx_runtime.jsxs)(components_GenericModal.Footer, {
      className: "bg-gray-100 flex justify-between",
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)(UniversalLink/* default */.Z, {
        href: routes/* default.usersUrl */.Z.usersUrl,
        children: /*#__PURE__*/(0,jsx_runtime.jsx)(Button/* default */.Z, {
          variant: "hover",
          children: "Search Views"
        })
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        className: "w-6"
      }), /*#__PURE__*/(0,jsx_runtime.jsx)(Button/* default */.Z, {
        variant: "primary",
        onClick: handleSubmit,
        children: "Save"
      })]
    })]
  });
};
/* harmony default export */ const SelectReadingFrom_SelectActiveUsersModal = (SelectActiveUsersModal);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/SelectReadingFrom/index.js
function SelectReadingFrom_slicedToArray(arr, i) { return SelectReadingFrom_arrayWithHoles(arr) || SelectReadingFrom_iterableToArrayLimit(arr, i) || SelectReadingFrom_unsupportedIterableToArray(arr, i) || SelectReadingFrom_nonIterableRest(); }

function SelectReadingFrom_nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function SelectReadingFrom_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return SelectReadingFrom_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return SelectReadingFrom_arrayLikeToArray(o, minLen); }

function SelectReadingFrom_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function SelectReadingFrom_iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function SelectReadingFrom_arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }








var SelectReadingFrom = /*#__PURE__*/react.forwardRef(function (_props, ref) {
  var _useToggle = (0,hooks/* useToggle */.OT)(false),
      _useToggle2 = SelectReadingFrom_slicedToArray(_useToggle, 2),
      modal = _useToggle2[0],
      toggleModal = _useToggle2[1];

  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    ref: ref,
    className: "fixed w-full max-w-[420px] shadow-xl border-b",
    style: {
      zIndex: 50
    },
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)(SubnavBar/* default */.Z, {
      children: /*#__PURE__*/(0,jsx_runtime.jsx)(SubnavBar/* default.ActionTitle */.Z.ActionTitle, {
        onClick: toggleModal,
        children: /*#__PURE__*/(0,jsx_runtime.jsx)(SelectReadingFrom_CurrentlyActiveDescription, {})
      })
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(SelectReadingFrom_SelectActiveUsersModal, {
      show: modal,
      toggleModal: toggleModal
    })]
  });
});
SelectReadingFrom.displayName = 'SelectReadingFrom';
/* harmony default export */ const ReadMode_SelectReadingFrom = (SelectReadingFrom);
// EXTERNAL MODULE: ./src/lib/common/components/Alert.js
var Alert = __webpack_require__(5966);
// EXTERNAL MODULE: ./src/lib/common/config/index.js
var config = __webpack_require__(66245);
// EXTERNAL MODULE: ./node_modules/usehooks-ts/dist/esm/index.js + 64 modules
var esm = __webpack_require__(69608);
// EXTERNAL MODULE: ./src/lib/universal-interface/hooks.js
var universal_interface_hooks = __webpack_require__(50731);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/index.js
function ReadMode_slicedToArray(arr, i) { return ReadMode_arrayWithHoles(arr) || ReadMode_iterableToArrayLimit(arr, i) || ReadMode_unsupportedIterableToArray(arr, i) || ReadMode_nonIterableRest(); }

function ReadMode_nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function ReadMode_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return ReadMode_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return ReadMode_arrayLikeToArray(o, minLen); }

function ReadMode_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function ReadMode_iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function ReadMode_arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

















var ReadModeWithoutUsers = function ReadModeWithoutUsers() {
  return /*#__PURE__*/(0,jsx_runtime.jsxs)(Alert/* default */.Z, {
    variant: "info",
    className: "p-3 m-0 rounded-0",
    children: [/*#__PURE__*/(0,jsx_runtime.jsxs)(Alert/* default.Heading */.Z.Heading, {
      children: ["Welcome to ", config/* default.appName */.ZP.appName]
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("strong", {
      children: "Just one more step! "
    }), "This screen will show you how the users you follow have rated the current domain... but first you must\xA0", /*#__PURE__*/(0,jsx_runtime.jsx)(UniversalLink/* default */.Z, {
      href: routes/* default.usersUrl */.Z.usersUrl,
      className: "font-bold",
      text: "follow some users"
    }), "."]
  });
}; // TODO: no real need for a wrapper, just pulled out while trying to avoid duplication in setting default readContext
// ...although actually I really like how it minimized the props for ReadModeContent, so maybe just rename better?


var ReadModeContentWrapper = function ReadModeContentWrapper(_ref) {
  var domainKey = _ref.domainKey,
      address = _ref.address,
      activeUids = _ref.activeUids,
      followedUsers = _ref.followedUsers;
  var domainPackets = (0,recoil/* useRecoilValue */.sJ)((0,recoil/* relevantDomainPacketsSelectorFamily */.I_)(domainKey)); // TODO: why are we not using activeUids somewhere to filter? Seems sketchy.. filtering downstream somewhere?
  // IMPROVE: there's definitely room to lazy load just the one needed first, then the other in the background

  var _useScoreAddressAgain = (0,hooks/* useScoreAddressAgainstDomainPackets */.qd)({
    address: address,
    domainPackets: domainPackets,
    followedUsers: followedUsers
  }),
      reviewsForPage = _useScoreAddressAgain.reviewsForPage,
      reviewsForDomain = _useScoreAddressAgain.reviewsForDomain;

  if (!(domainPackets !== null && domainPackets !== void 0 && domainPackets.length)) return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
    className: "bg-white py-5 flex justify-center",
    children: /*#__PURE__*/(0,jsx_runtime.jsxs)(components_Empty, {
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)("b", {
        children: domainKey
      }), " has no opinions yet ", /*#__PURE__*/(0,jsx_runtime.jsx)("br", {}), /*#__PURE__*/(0,jsx_runtime.jsx)("small", {
        children: "(from your selected view".concat((activeUids === null || activeUids === void 0 ? void 0 : activeUids.length) === 1 ? '' : 's', ")")
      })]
    })
  });
  return /*#__PURE__*/(0,jsx_runtime.jsx)(ReadMode_ReadModeContent, {
    domainKey: domainKey,
    reviewsForPage: reviewsForPage,
    reviewsForDomain: reviewsForDomain
  });
};

var ReadMode = function ReadMode() {
  var _useElementSize = (0,esm/* useElementSize */.h4)(),
      _useElementSize2 = ReadMode_slicedToArray(_useElementSize, 2),
      headerRef = _useElementSize2[0],
      headerHeight = _useElementSize2[1].height;

  var _useRecoilValue = (0,recoil/* useRecoilValue */.sJ)(recoil/* currentAtom */.C),
      domainKey = _useRecoilValue.domainKey,
      address = _useRecoilValue.address;

  var followedUsers = (0,recoil/* useRecoilValue */.sJ)(recoil/* followedUsersAtom */.jL);
  var activeUids = (0,recoil/* useRecoilValue */.sJ)(recoil/* activeUidsAtom */.Ox);
  var currentUserId = (0,universal_interface_hooks/* useCurrentUserId */.dO)();
  if (!(followedUsers !== null && followedUsers !== void 0 && followedUsers.length) || followedUsers.length === 1 && followedUsers[0].id === currentUserId) return /*#__PURE__*/(0,jsx_runtime.jsx)(ReadModeWithoutUsers, {});
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: "relative overflow-y-hidden",
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)(ReadMode_SelectReadingFrom, {
      ref: headerRef
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      className: "relative overflow-y-auto",
      style: {
        marginTop: headerHeight === 0 ? '50px' : headerHeight
      },
      children: (activeUids === null || activeUids === void 0 ? void 0 : activeUids.length) === 0 ? /*#__PURE__*/(0,jsx_runtime.jsx)(Alert/* default */.Z, {
        variant: "info",
        className: "p-3 m-0 rounded-0",
        style: {
          marginTop: headerHeight
        },
        children: "You must activate at least one view to see ratings in this space."
      }) : /*#__PURE__*/(0,jsx_runtime.jsx)(react.Suspense, {
        fallback: /*#__PURE__*/(0,jsx_runtime.jsx)(Loader/* Loader */.aN, {}),
        children: /*#__PURE__*/(0,jsx_runtime.jsx)(ReadModeContentWrapper, {
          domainKey: domainKey,
          address: address,
          activeUids: activeUids,
          followedUsers: followedUsers
        })
      })
    })]
  });
};

/* harmony default export */ const ext_ReadMode = (ReadMode);

/***/ })

}]);