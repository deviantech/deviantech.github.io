"use strict";
(self["webpackChunkvoyd_browser_extension"] = self["webpackChunkvoyd_browser_extension"] || []).push([[253],{

/***/ 89253:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ext_ReadMode)
});

// EXTERNAL MODULE: ./src/lib/common/hooks/index.js
var hooks = __webpack_require__(98415);
// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(85893);
;// CONCATENATED MODULE: ./src/lib/common/components/Empty.js


var Empty = function Empty(_ref) {
  var children = _ref.children;
  return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
    bg: "py-2 bg-gray-200",
    children: /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
      className: "m-2 font-light text-center text-gray-800",
      children: children
    })
  });
};

/* harmony default export */ const components_Empty = (Empty);
// EXTERNAL MODULE: ./src/lib/common/recoil/index.js
var recoil = __webpack_require__(34858);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(67294);
// EXTERNAL MODULE: ./src/lib/common/utils/index.js
var utils = __webpack_require__(37724);
// EXTERNAL MODULE: ./src/lib/common/components/Logo.js
var Logo = __webpack_require__(7144);
;// CONCATENATED MODULE: ./src/lib/common/components/VoteEmote.js



var VoteEmote = function VoteEmote(_ref) {
  var vote = _ref.vote,
      className = _ref.className;

  if (vote === 1) {
    return /*#__PURE__*/(0,jsx_runtime.jsx)(Logo/* default */.ZP, {
      className: className,
      upClassName: "text-green-600",
      downClassName: "text-gray-100"
    });
  } else if (vote === -1) {
    return /*#__PURE__*/(0,jsx_runtime.jsx)(Logo/* default */.ZP, {
      className: (0,utils.cn)(className, 'rotate-180'),
      upClassName: "text-red-600",
      downClassName: "text-gray-100"
    });
  } else {
    return /*#__PURE__*/(0,jsx_runtime.jsx)(Logo/* default */.ZP, {
      className: (0,utils.cn)(className, 'rotate-90'),
      upClassName: "text-gray-400",
      downClassName: "text-transparent"
    });
  }
};
/* harmony default export */ const components_VoteEmote = (VoteEmote);
// EXTERNAL MODULE: ./src/lib/common/components/ReviewCard/index.js + 2 modules
var ReviewCard = __webpack_require__(92153);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/ReadModeContent/OverallRating/index.js
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }










var OverallRating = function OverallRating(_ref) {
  var featuredReview = _ref.featuredReview,
      vote = _ref.vote,
      overallVote = _ref.overallVote;
  var bg = vote > 0 ? 'bg-green-500' : vote < 0 ? 'bg-red-500' : 'bg-gray-500';

  var _ref2 = featuredReview || {},
      review = _ref2.review,
      user = _ref2.user; // TODO: pull this out somewhere cleanly, this is just a proof of concept until we nail down how we're displaying the featured review


  var bylineSuffix = (0,react.useMemo)(function () {
    return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
      children: ["by ", (0,utils/* handle */.pr)(user)]
    });
  }, [user]);

  var _useRecoilState = (0,recoil/* useRecoilState */.FV)(recoil/* readingContextAtom */.$N),
      _useRecoilState2 = _slicedToArray(_useRecoilState, 2),
      readingContext = _useRecoilState2[0],
      setReadingContext = _useRecoilState2[1];

  var toggleReadingContext = (0,react.useCallback)(function () {
    setReadingContext(readingContext === 'domain' ? 'page' : 'domain');
  }, [readingContext, setReadingContext]);
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: (0,utils.cn)(bg),
    children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "p-3 text-center text-xl cursor-pointer text-gray-900",
      onClick: toggleReadingContext,
      children: ["Context: ", readingContext, /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        className: "text-sm text-gray-700",
        children: "Click to toggle"
      })]
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      className: "px-2 pb-8",
      children: /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        className: "p-4 bg-gray-50 mx-5 mb-0 border rounded-md space-y-5",
        children: featuredReview ? /*#__PURE__*/(0,jsx_runtime.jsx)(ReviewCard/* default */.ZP, {
          review: review // Note: intentionally NOT setting user -- we don't want the left UI
          // title={title}
          // className="w-full hover:bg-gray-100 active:bg-gray-200"
          ,
          skipLinks: true,
          bylineSuffix: bylineSuffix
        }) : /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
          className: "text-6xl text-center flex justify-center items-center",
          children: /*#__PURE__*/(0,jsx_runtime.jsx)(components_VoteEmote, {
            vote: overallVote,
            className: "p-1 h-24"
          })
        })
      })
    })]
  });
};

/* harmony default export */ const ReadModeContent_OverallRating = (OverallRating);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/utils/render.js
var render = __webpack_require__(12351);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/hooks/use-id.js
var use_id = __webpack_require__(19946);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/utils/match.js
var match = __webpack_require__(32984);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/keyboard.js
var keyboard = __webpack_require__(61363);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/utils/focus-management.js
var focus_management = __webpack_require__(84575);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/hooks/use-iso-morphic-effect.js
var use_iso_morphic_effect = __webpack_require__(16723);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/hooks/use-sync-refs.js
var use_sync_refs = __webpack_require__(23784);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/hooks/use-resolve-button-type.js
var use_resolve_button_type = __webpack_require__(14157);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/hooks/use-latest-value.js
var use_latest_value = __webpack_require__(3855);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/internal/hidden.js
var internal_hidden = __webpack_require__(46045);
;// CONCATENATED MODULE: ./node_modules/@headlessui/react/dist/internal/focus-sentinel.js
function focus_sentinel_p({onFocus:n}){let[r,o]=(0,react.useState)(!0);return r?react.createElement(internal_hidden/* Hidden */._,{as:"button",type:"button",features:internal_hidden/* Features.Focusable */.A.Focusable,onFocus:a=>{a.preventDefault();let e,u=50;function t(){if(u--<=0){e&&cancelAnimationFrame(e);return}if(n()){o(!1),cancelAnimationFrame(e);return}e=requestAnimationFrame(t)}e=requestAnimationFrame(t)}}):null}

;// CONCATENATED MODULE: ./node_modules/@headlessui/react/dist/components/tabs/tabs.js
var ne=(r=>(r[r.SetSelectedIndex=0]="SetSelectedIndex",r[r.SetOrientation=1]="SetOrientation",r[r.SetActivation=2]="SetActivation",r[r.RegisterTab=3]="RegisterTab",r[r.UnregisterTab=4]="UnregisterTab",r[r.RegisterPanel=5]="RegisterPanel",r[r.UnregisterPanel=6]="UnregisterPanel",r[r.ForceRerender=7]="ForceRerender",r))(ne||{});let re={[0](e,t){let n=e.tabs.filter(u=>{var l;return!((l=u.current)!=null&&l.hasAttribute("disabled"))});if(t.index<0)return{...e,selectedIndex:e.tabs.indexOf(n[0])};if(t.index>e.tabs.length)return{...e,selectedIndex:e.tabs.indexOf(n[n.length-1])};let i=e.tabs.slice(0,t.index),s=[...e.tabs.slice(t.index),...i].find(u=>n.includes(u));return s?{...e,selectedIndex:e.tabs.indexOf(s)}:e},[1](e,t){return e.orientation===t.orientation?e:{...e,orientation:t.orientation}},[2](e,t){return e.activation===t.activation?e:{...e,activation:t.activation}},[3](e,t){return e.tabs.includes(t.tab)?e:{...e,tabs:(0,focus_management/* sortByDomNode */.z2)([...e.tabs,t.tab],n=>n.current)}},[4](e,t){return{...e,tabs:(0,focus_management/* sortByDomNode */.z2)(e.tabs.filter(n=>n!==t.tab),n=>n.current)}},[5](e,t){return e.panels.includes(t.panel)?e:{...e,panels:[...e.panels,t.panel]}},[6](e,t){return{...e,panels:e.panels.filter(n=>n!==t.panel)}},[7](e){return{...e}}},G=(0,react.createContext)(null);G.displayName="TabsContext";let W=(0,react.createContext)(null);W.displayName="TabsSSRContext";function j(e){let t=(0,react.useContext)(W);if(t===null){let n=new Error(`<${e} /> is missing a parent <Tab.Group /> component.`);throw Error.captureStackTrace&&Error.captureStackTrace(n,j),n}return t}function M(e){let t=(0,react.useContext)(G);if(t===null){let n=new Error(`<${e} /> is missing a parent <Tab.Group /> component.`);throw Error.captureStackTrace&&Error.captureStackTrace(n,M),n}return t}function ae(e,t){return (0,match/* match */.E)(t.type,re,e,t)}let oe=react.Fragment,le=(0,render/* forwardRefWithAs */.yV)(function(t,n){let{defaultIndex:i=0,vertical:T=!1,manual:s=!1,onChange:u,selectedIndex:l=null,...r}=t;const c=T?"vertical":"horizontal",b=s?"manual":"auto";let y=(0,use_sync_refs/* useSyncRefs */.T)(n),[a,p]=(0,react.useReducer)(ae,{selectedIndex:l!=null?l:i,tabs:[],panels:[],orientation:c,activation:b}),A=(0,react.useMemo)(()=>({selectedIndex:a.selectedIndex}),[a.selectedIndex]),d=(0,use_latest_value/* useLatestValue */.E)(u||(()=>{})),x=(0,use_latest_value/* useLatestValue */.E)(a.tabs);(0,react.useEffect)(()=>{p({type:1,orientation:c})},[c]),(0,react.useEffect)(()=>{p({type:2,activation:b})},[b]),(0,use_iso_morphic_effect/* useIsoMorphicEffect */.e)(()=>{let f=l!=null?l:i;p({type:0,index:f})},[l]);let R=(0,react.useRef)(a.selectedIndex);(0,react.useEffect)(()=>{R.current=a.selectedIndex},[a.selectedIndex]);let g=(0,react.useMemo)(()=>[a,{dispatch:p,change(f){R.current!==f&&d.current(f),R.current=f,p({type:0,index:f})}}],[a,p]),S=(0,react.useRef)({tabs:[],panels:[]}),_={ref:y};return react.createElement(W.Provider,{value:S},react.createElement(G.Provider,{value:g},react.createElement(focus_sentinel_p,{onFocus:()=>{var f,F;for(let C of x.current)if(((f=C.current)==null?void 0:f.tabIndex)===0)return(F=C.current)==null||F.focus(),!0;return!1}}),(0,render/* render */.sY)({ourProps:_,theirProps:r,slot:A,defaultTag:oe,name:"Tabs"})))}),ie="div",se=(0,render/* forwardRefWithAs */.yV)(function(t,n){let[{selectedIndex:i,orientation:T}]=M("Tab.List"),s=(0,use_sync_refs/* useSyncRefs */.T)(n);return (0,render/* render */.sY)({ourProps:{ref:s,role:"tablist","aria-orientation":T},theirProps:t,slot:{selectedIndex:i},defaultTag:ie,name:"Tabs.List"})}),ue="button",ce=(0,render/* forwardRefWithAs */.yV)(function(t,n){var N,B;let i=`headlessui-tabs-tab-${(0,use_id/* useId */.M)()}`,[{selectedIndex:T,tabs:s,panels:u,orientation:l,activation:r},{dispatch:c,change:b}]=M("Tab"),y=j("Tab"),a=(0,react.useRef)(null),p=(0,use_sync_refs/* useSyncRefs */.T)(a,n,o=>{!o||c({type:7})});(0,use_iso_morphic_effect/* useIsoMorphicEffect */.e)(()=>(c({type:3,tab:a}),()=>c({type:4,tab:a})),[c,a]);let A=y.current.tabs.indexOf(i);A===-1&&(A=y.current.tabs.push(i)-1);let d=s.indexOf(a);d===-1&&(d=A);let x=d===T,R=(0,react.useCallback)(o=>{let E=s.map(X=>X.current).filter(Boolean);if(o.key===keyboard/* Keys.Space */.R.Space||o.key===keyboard/* Keys.Enter */.R.Enter){o.preventDefault(),o.stopPropagation(),b(d);return}switch(o.key){case keyboard/* Keys.Home */.R.Home:case keyboard/* Keys.PageUp */.R.PageUp:return o.preventDefault(),o.stopPropagation(),(0,focus_management/* focusIn */.jA)(E,focus_management/* Focus.First */.TO.First);case keyboard/* Keys.End */.R.End:case keyboard/* Keys.PageDown */.R.PageDown:return o.preventDefault(),o.stopPropagation(),(0,focus_management/* focusIn */.jA)(E,focus_management/* Focus.Last */.TO.Last)}return (0,match/* match */.E)(l,{vertical(){if(o.key===keyboard/* Keys.ArrowUp */.R.ArrowUp)return (0,focus_management/* focusIn */.jA)(E,focus_management/* Focus.Previous */.TO.Previous|focus_management/* Focus.WrapAround */.TO.WrapAround);if(o.key===keyboard/* Keys.ArrowDown */.R.ArrowDown)return (0,focus_management/* focusIn */.jA)(E,focus_management/* Focus.Next */.TO.Next|focus_management/* Focus.WrapAround */.TO.WrapAround)},horizontal(){if(o.key===keyboard/* Keys.ArrowLeft */.R.ArrowLeft)return (0,focus_management/* focusIn */.jA)(E,focus_management/* Focus.Previous */.TO.Previous|focus_management/* Focus.WrapAround */.TO.WrapAround);if(o.key===keyboard/* Keys.ArrowRight */.R.ArrowRight)return (0,focus_management/* focusIn */.jA)(E,focus_management/* Focus.Next */.TO.Next|focus_management/* Focus.WrapAround */.TO.WrapAround)}})},[s,l,d,b]),g=(0,react.useCallback)(()=>{var o;(o=a.current)==null||o.focus()},[a]),S=(0,react.useCallback)(()=>{var o;(o=a.current)==null||o.focus(),b(d)},[b,d,a]),_=(0,react.useCallback)(o=>{o.preventDefault()},[]),f=(0,react.useMemo)(()=>({selected:x}),[x]),F=t,C={ref:p,onKeyDown:R,onFocus:r==="manual"?g:S,onMouseDown:_,onClick:S,id:i,role:"tab",type:(0,use_resolve_button_type/* useResolveButtonType */.f)(t,a),"aria-controls":(B=(N=u[d])==null?void 0:N.current)==null?void 0:B.id,"aria-selected":x,tabIndex:x?0:-1};return (0,render/* render */.sY)({ourProps:C,theirProps:F,slot:f,defaultTag:ue,name:"Tabs.Tab"})}),pe="div",de=(0,render/* forwardRefWithAs */.yV)(function(t,n){let[{selectedIndex:i}]=M("Tab.Panels"),T=(0,use_sync_refs/* useSyncRefs */.T)(n),s=(0,react.useMemo)(()=>({selectedIndex:i}),[i]);return (0,render/* render */.sY)({ourProps:{ref:T},theirProps:t,slot:s,defaultTag:pe,name:"Tabs.Panels"})}),fe="div",Te=render/* Features.RenderStrategy */.AN.RenderStrategy|render/* Features.Static */.AN.Static,be=(0,render/* forwardRefWithAs */.yV)(function(t,n){var R,g;let[{selectedIndex:i,tabs:T,panels:s},{dispatch:u}]=M("Tab.Panel"),l=j("Tab.Panel"),r=`headlessui-tabs-panel-${(0,use_id/* useId */.M)()}`,c=(0,react.useRef)(null),b=(0,use_sync_refs/* useSyncRefs */.T)(c,n,S=>{!S||u({type:7})});(0,use_iso_morphic_effect/* useIsoMorphicEffect */.e)(()=>(u({type:5,panel:c}),()=>u({type:6,panel:c})),[u,c]);let y=l.current.panels.indexOf(r);y===-1&&(y=l.current.panels.push(r)-1);let a=s.indexOf(c);a===-1&&(a=y);let p=a===i,A=(0,react.useMemo)(()=>({selected:p}),[p]),d=t,x={ref:b,id:r,role:"tabpanel","aria-labelledby":(g=(R=T[a])==null?void 0:R.current)==null?void 0:g.id,tabIndex:p?0:-1};return (0,render/* render */.sY)({ourProps:x,theirProps:d,slot:A,defaultTag:fe,features:Te,visible:p,name:"Tabs.Panel"})}),we=Object.assign(ce,{Group:le,List:se,Panels:de,Panel:be});

// EXTERNAL MODULE: ./src/lib/common/routes.js
var routes = __webpack_require__(11147);
// EXTERNAL MODULE: ./src/lib/universal-interface/UniversalLink.js
var UniversalLink = __webpack_require__(84261);
// EXTERNAL MODULE: ./src/lib/common/components/Avatar.js
var Avatar = __webpack_require__(70017);
// EXTERNAL MODULE: ./src/lib/common/components/icons/index.js + 12 modules
var icons = __webpack_require__(61383);
// EXTERNAL MODULE: ./src/lib/common/components/ShareReview/index.js + 3 modules
var ShareReview = __webpack_require__(66330);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/ReadModeContent/Details/ScoredReviewLineItem.js
function ScoredReviewLineItem_slicedToArray(arr, i) { return ScoredReviewLineItem_arrayWithHoles(arr) || ScoredReviewLineItem_iterableToArrayLimit(arr, i) || ScoredReviewLineItem_unsupportedIterableToArray(arr, i) || ScoredReviewLineItem_nonIterableRest(); }

function ScoredReviewLineItem_nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function ScoredReviewLineItem_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return ScoredReviewLineItem_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return ScoredReviewLineItem_arrayLikeToArray(o, minLen); }

function ScoredReviewLineItem_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function ScoredReviewLineItem_iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function ScoredReviewLineItem_arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }













var ScoredReviewLineItem = function ScoredReviewLineItem(_ref) {
  var scored = _ref.scored,
      domainKey = _ref.domainKey,
      targetPageKey = _ref.targetPageKey;
  var reviewType = scored.reviewType,
      review = scored.review,
      domainPacket = scored.domainPacket,
      user = scored.user;

  var _useState = (0,react.useState)(false),
      _useState2 = ScoredReviewLineItem_slicedToArray(_useState, 2),
      showShare = _useState2[0],
      setShowShare = _useState2[1];

  var startSharing = (0,hooks/* useLinkCallback */._P)(function () {
    return setShowShare(true);
  }, [setShowShare]);
  var stopSharing = (0,hooks/* useLinkCallback */._P)(function () {
    return setShowShare(false);
  }, [setShowShare]); // note: page reviews link to specific review, otherwise link to domain review (e.g. rule reviews don't have clear destination, link to base instead)

  var pageKey = reviewType === 'pageReview' ? targetPageKey : null;

  var badge = /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
    className: (0,utils.cn)('text-gray-500 flex flex-col items-end justify-center'),
    children: /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "text-sm",
      children: ["Viewed", ' ', reviewType === 'pageReview' ? 'this page' : reviewType === 'ruleReview' ? 'collection (including this page)' : 'whole site']
    })
  });

  var title = /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: "text-base flex justify-between items-center pl-5 text-gray-600",
    children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "flex items-center text-left leading-tight break-all",
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)(Avatar/* default */.Z, {
        user: user,
        size: 25,
        className: "border rounded-full mr-1"
      }), (0,utils/* handle */.pr)(user)]
    }), badge]
  });

  return /*#__PURE__*/(0,jsx_runtime.jsxs)("li", {
    className: "snap-start relative group w-full",
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)(UniversalLink/* default */.Z, {
      href: routes/* default.reviewUrl */.Z.reviewUrl(user, domainKey, pageKey),
      children: /*#__PURE__*/(0,jsx_runtime.jsx)(ReviewCard/* default */.ZP, {
        review: review,
        title: title,
        className: "w-full hover:bg-gray-100 active:bg-gray-200",
        skipLinks: true,
        skipStaff: true
      })
    }), showShare ? /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      className: "flex absolute inset-0 z-10 bg-gray-400 bg-opacity-90 justify-center items-center p-10",
      style: {
        left: '-25px'
      },
      onClick: stopSharing,
      children: /*#__PURE__*/(0,jsx_runtime.jsx)(ShareReview/* default */.ZP, {
        domainKey: domainKey,
        pageKey: pageKey,
        review: review,
        domainPacket: domainPacket,
        author: user,
        size: 30,
        className: "p-5 flex flex-col space-y-4",
        iconProps: {
          skipLabel: true
        },
        showUrl: true
      })
    }) : /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      onClick: startSharing,
      className: "text-gray-300 hover:text-gray-400 hover:bg-gray-600 hover:bg-opacity-10 rounded-full w-12 h-12 hidden group-hover:flex justify-center items-center absolute bottom-5 right-5 cursor-pointer p-2 pr-3",
      children: /*#__PURE__*/(0,jsx_runtime.jsx)(icons/* ShareIcon */.aA, {
        className: "w-10 h-10"
      })
    })]
  });
};

/* harmony default export */ const Details_ScoredReviewLineItem = (ScoredReviewLineItem);
;// CONCATENATED MODULE: ./src/lib/common/components/VoteArrowWithBadge.js

 // TODO: DRY?




var moodClass = function moodClass(effectiveVote) {
  return effectiveVote > 0 ? 'text-green-600' : effectiveVote < 0 ? 'text-red-600' : 'text-gray-500';
};

var VoteArrowWithBadge = function VoteArrowWithBadge(_ref) {
  var vote = _ref.vote,
      text = _ref.text;
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: (0,utils.cn)('relative', moodClass(vote)),
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      className: "h-full w-full absolute inset-0 flex justify-center items-center z-10 text-xl",
      children: text
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      className: "h-full w-full relative inset-0 flex justify-center items-center",
      children: /*#__PURE__*/(0,jsx_runtime.jsx)(components_VoteEmote, {
        vote: vote,
        className: "h-20"
      })
    })]
  });
};

/* harmony default export */ const components_VoteArrowWithBadge = (VoteArrowWithBadge);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/ReadModeContent/Details/index.js
function Details_slicedToArray(arr, i) { return Details_arrayWithHoles(arr) || Details_iterableToArrayLimit(arr, i) || Details_unsupportedIterableToArray(arr, i) || Details_nonIterableRest(); }

function Details_nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function Details_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return Details_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Details_arrayLikeToArray(o, minLen); }

function Details_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function Details_iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function Details_arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }







 // TODO: DRY?




var bgClass = function bgClass(effectiveVote) {
  return effectiveVote > 0 ? 'border-green-600' : effectiveVote < 0 ? 'border-red-600' : 'border-gray-500';
};

var ScoreSectionTab = function ScoreSectionTab(_ref) {
  var effectiveVote = _ref.effectiveVote,
      scores = _ref.scores;
  return /*#__PURE__*/(0,jsx_runtime.jsx)(we, {
    className: function className(_ref2) {
      var selected = _ref2.selected;
      return (0,utils.cn)('w-full flex flex-col justify-between items-center border-b p-3 space-y-1', selected ? 'bg-gray-100 hover:bg-gray-200' : 'bg-gray-50 hover:bg-gray-200');
    },
    children: /*#__PURE__*/(0,jsx_runtime.jsx)(components_VoteArrowWithBadge, {
      vote: effectiveVote,
      text: scores.length
    })
  });
};

var ScoreSectionPanel = function ScoreSectionPanel(_ref3) {
  var effectiveVote = _ref3.effectiveVote,
      title = _ref3.title,
      scores = _ref3.scores,
      domainKey = _ref3.domainKey,
      targetPageKey = _ref3.targetPageKey;
  var readingContext = (0,recoil/* useRecoilValue */.sJ)(recoil/* readingContextAtom */.$N);
  return /*#__PURE__*/(0,jsx_runtime.jsx)(we.Panel, {
    className: (0,utils.cn)('bg-white', 'border-t-2', bgClass(effectiveVote)),
    children: scores.length === 0 ? /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "py-5 text-center text-xl font-light text-gray-500",
      children: ["No ", title.toLowerCase(), " reviews to show for ", readingContext, "."]
    }) : /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "flex w-full",
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        className: "w-4 flex-shrink-0"
      }), /*#__PURE__*/(0,jsx_runtime.jsx)(ReviewCard/* ReviewStaff */.j0, {
        vote: effectiveVote,
        className: "z-10"
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("ul", {
        className: "snap-y w-full",
        children: scores.map(function (scored, idx) {
          return /*#__PURE__*/(0,jsx_runtime.jsx)(Details_ScoredReviewLineItem, {
            scored: scored,
            domainKey: domainKey,
            targetPageKey: targetPageKey
          }, idx);
        })
      })]
    })
  });
};

var Details = function Details(_ref4) {
  var targetPageKey = _ref4.targetPageKey,
      _ref4$positive = _ref4.positive,
      positive = _ref4$positive === void 0 ? [] : _ref4$positive,
      _ref4$negative = _ref4.negative,
      negative = _ref4$negative === void 0 ? [] : _ref4$negative,
      _ref4$neutral = _ref4.neutral,
      neutral = _ref4$neutral === void 0 ? [] : _ref4$neutral,
      domainKey = _ref4.domainKey;
  // TODO: if showNeutral is ALWAYS true, works as expected. But if one context has neutral and the other doesn't:
  // * activeTabIndex is set correctly
  // * the Tab.List is updated correctly to show the correct tab
  // * the Tab.Panels are NOT updated correctly -- shows context from different section than is selected in tab.list
  //
  // e.g. https://recoiljs.org/docs/api-reference/utils/selectorFamily/ - toggle page > domain > page, shows "No negative reviews for page"
  // despite activeTabIndex getting set correctly, and the actual score section does not match the selected
  var showNeutral = (0,react.useMemo)(function () {
    return neutral.length > 0;
  }, [neutral]);
  var defaultIndex = (0,react.useMemo)(function () {
    var defaultTabValue = positive.length >= negative.length && positive.length >= neutral.length ? 1 : negative.length > neutral.length ? -1 : 0;
    var comparisonTable = showNeutral ? [1, 0, -1] : [1, -1];
    var di = comparisonTable.indexOf(defaultTabValue); // console.log('~~~ Details', {
    //   defaultIndex: di,
    //   defaultTabValue,
    //   comparisonTable,
    //   positive,
    //   negative,
    //   neutral,
    // })

    return di;
  }, [neutral, negative, positive, showNeutral]);

  var _useState = (0,react.useState)(defaultIndex),
      _useState2 = Details_slicedToArray(_useState, 2),
      activeTabIndex = _useState2[0],
      setActiveTabIndex = _useState2[1];

  (0,react.useEffect)(function () {
    setActiveTabIndex(defaultIndex);
  }, [setActiveTabIndex, defaultIndex]);
  return /*#__PURE__*/(0,jsx_runtime.jsx)(we.Group, {
    selectedIndex: activeTabIndex,
    onChange: setActiveTabIndex,
    children: /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      children: [/*#__PURE__*/(0,jsx_runtime.jsxs)(we.List, {
        className: "flex",
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)(ScoreSectionTab, {
          domainKey: domainKey,
          effectiveVote: 1,
          scores: positive
        }), showNeutral ? /*#__PURE__*/(0,jsx_runtime.jsx)(ScoreSectionTab, {
          domainKey: domainKey,
          effectiveVote: 0,
          scores: neutral
        }) : null, /*#__PURE__*/(0,jsx_runtime.jsx)(ScoreSectionTab, {
          domainKey: domainKey,
          effectiveVote: -1,
          scores: negative
        })]
      }), /*#__PURE__*/(0,jsx_runtime.jsxs)(we.Panels, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)(ScoreSectionPanel, {
          domainKey: domainKey,
          targetPageKey: targetPageKey,
          title: "Positive",
          scores: positive,
          effectiveVote: 1
        }), showNeutral ? /*#__PURE__*/(0,jsx_runtime.jsx)(ScoreSectionPanel, {
          domainKey: domainKey,
          targetPageKey: targetPageKey,
          title: "Neutral",
          scores: neutral,
          effectiveVote: 0
        }) : null, /*#__PURE__*/(0,jsx_runtime.jsx)(ScoreSectionPanel, {
          domainKey: domainKey,
          targetPageKey: targetPageKey,
          title: "Negative",
          scores: negative,
          effectiveVote: -1
        })]
      })]
    })
  });
};

/* harmony default export */ const ReadModeContent_Details = (Details);
// EXTERNAL MODULE: ./node_modules/lodash/lodash.js
var lodash = __webpack_require__(96486);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/ReadModeContent/index.js







var ReadModeContent = function ReadModeContent(_ref) {
  var domainKey = _ref.domainKey,
      reviewsForPage = _ref.reviewsForPage,
      reviewsForDomain = _ref.reviewsForDomain;
  var readingContext = (0,recoil/* useRecoilValue */.sJ)(recoil/* readingContextAtom */.$N);

  var _ref2 = readingContext === 'page' ? reviewsForPage : reviewsForDomain,
      targetPageKey = _ref2.targetPageKey,
      positiveReviews = _ref2.positiveReviews,
      negativeReviews = _ref2.negativeReviews,
      neutralReviews = _ref2.neutralReviews,
      delta = _ref2.delta,
      overallVote = _ref2.overallVote;

  var winningReviews = delta === 0 && neutralReviews.length ? neutralReviews : delta < 0 ? negativeReviews : positiveReviews; // Featured review: most recent that has meaningful content... else just most recent

  var featuredReview = (0,lodash.find)(winningReviews, function (_ref3) {
    var review = _ref3.review;
    var comment = review.comment,
        hashtags = review.hashtags;
    return (comment === null || comment === void 0 ? void 0 : comment.length) || (hashtags === null || hashtags === void 0 ? void 0 : hashtags.length);
  }) || winningReviews[0];
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: "flex flex-col",
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)(ReadModeContent_OverallRating, {
      featuredReview: featuredReview,
      vote: overallVote,
      overallVote: overallVote
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(ReadModeContent_Details, {
      positive: positiveReviews,
      negative: negativeReviews,
      neutral: neutralReviews,
      domainKey: domainKey,
      targetPageKey: targetPageKey
    })]
  });
};

/* harmony default export */ const ReadMode_ReadModeContent = (ReadModeContent);
// EXTERNAL MODULE: ./src/lib/common/components/ext/SubnavBar.js
var SubnavBar = __webpack_require__(39257);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/SelectReadingFrom/CurrentlyActiveDescription.js




var Badge = function Badge(_ref) {
  var className = _ref.className,
      children = _ref.children;
  return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
    className: (0,utils.cn)('ml-2 px-2 py-0.5 mb-0.5 rounded-full text-sm', className),
    children: children
  });
};

var CurrentlyActiveDescription = function CurrentlyActiveDescription(_ref2) {
  var activeOptions = _ref2.activeOptions;

  if (!activeOptions || activeOptions.length === 0) {
    return /*#__PURE__*/(0,jsx_runtime.jsx)(Badge, {
      className: "g-yellow-400 text-gray-800 text-uppercase",
      children: "No active views!"
    });
  }

  if (activeOptions.length < 1) {
    return activeOptions.map(function (opt, idx) {
      return /*#__PURE__*/(0,jsx_runtime.jsxs)(Badge, {
        className: "ml-1 bg-blue-100",
        children: ["@", opt.label]
      }, idx);
    });
  }

  return /*#__PURE__*/(0,jsx_runtime.jsx)(Badge, {
    className: "bg-blue-100",
    children: /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
      children: (0,utils/* plur */.Jn)(activeOptions.length, 'active view')
    })
  });
};

/* harmony default export */ const SelectReadingFrom_CurrentlyActiveDescription = (CurrentlyActiveDescription);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/transitions/transition.js + 5 modules
var transition = __webpack_require__(66091);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/utils/bugs.js
var bugs = __webpack_require__(64103);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/hooks/use-server-handoff-complete.js
var use_server_handoff_complete = __webpack_require__(82180);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/hooks/use-event.js
var use_event = __webpack_require__(73781);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/hooks/use-tab-direction.js
var use_tab_direction = __webpack_require__(45662);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/hooks/use-is-mounted.js
var use_is_mounted = __webpack_require__(14879);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/hooks/use-owner.js
var use_owner = __webpack_require__(51074);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/hooks/use-event-listener.js
var use_event_listener = __webpack_require__(14007);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/utils/micro-task.js
var micro_task = __webpack_require__(81021);
;// CONCATENATED MODULE: ./node_modules/@headlessui/react/dist/hooks/use-watch.js
function m(o,t){let r=(0,react.useRef)([]),e=(0,use_event/* useEvent */.z)(o);(0,react.useEffect)(()=>{for(let[u,f]of t.entries())if(r.current[u]!==f){let i=e(t);return r.current=t,i}},[e,...t])}

;// CONCATENATED MODULE: ./node_modules/@headlessui/react/dist/components/focus-trap/focus-trap.js
let N="div";var F=(t=>(t[t.None=1]="None",t[t.InitialFocus=2]="InitialFocus",t[t.TabLock=4]="TabLock",t[t.FocusLock=8]="FocusLock",t[t.RestoreFocus=16]="RestoreFocus",t[t.All=30]="All",t))(F||{});let focus_trap_fe=Object.assign((0,render/* forwardRefWithAs */.yV)(function(l,e){let r=(0,react.useRef)(null),u=(0,use_sync_refs/* useSyncRefs */.T)(r,e),{initialFocus:f,containers:t,features:o=30,...a}=l;(0,use_server_handoff_complete/* useServerHandoffComplete */.H)()||(o=1);let s=(0,use_owner/* useOwnerDocument */.i)(r);V({ownerDocument:s},Boolean(o&16));let O=x({ownerDocument:s,container:r,initialFocus:f},Boolean(o&2));D({ownerDocument:s,container:r,containers:t,previousActiveElement:O},Boolean(o&8));let j=(0,use_tab_direction/* useTabDirection */.l)(),E=(0,use_event/* useEvent */.z)(()=>{let T=r.current;!T||(0,match/* match */.E)(j.current,{[use_tab_direction/* Direction.Forwards */.N.Forwards]:()=>(0,focus_management/* focusIn */.jA)(T,focus_management/* Focus.First */.TO.First),[use_tab_direction/* Direction.Backwards */.N.Backwards]:()=>(0,focus_management/* focusIn */.jA)(T,focus_management/* Focus.Last */.TO.Last)})}),v={ref:u};return react.createElement(react.Fragment,null,Boolean(o&4)&&react.createElement(internal_hidden/* Hidden */._,{as:"button",type:"button",onFocus:E,features:internal_hidden/* Features.Focusable */.A.Focusable}),(0,render/* render */.sY)({ourProps:v,theirProps:a,defaultTag:N,name:"FocusTrap"}),Boolean(o&4)&&react.createElement(internal_hidden/* Hidden */._,{as:"button",type:"button",onFocus:E,features:internal_hidden/* Features.Focusable */.A.Focusable}))}),{features:F});function V({ownerDocument:n},l){let e=(0,react.useRef)(null);(0,use_event_listener/* useEventListener */.O)(n==null?void 0:n.defaultView,"focusout",u=>{!l||e.current||(e.current=u.target)},!0),m(()=>{l||((0,focus_management/* focusElement */.C5)(e.current),e.current=null)},[l]);let r=(0,react.useRef)(!1);(0,react.useEffect)(()=>(r.current=!1,()=>{r.current=!0,(0,micro_task/* microTask */.Y)(()=>{!r.current||((0,focus_management/* focusElement */.C5)(e.current),e.current=null)})}),[])}function x({ownerDocument:n,container:l,initialFocus:e},r){let u=(0,react.useRef)(null);return m(()=>{if(!r)return;let f=l.current;if(!f)return;let t=n==null?void 0:n.activeElement;if(e!=null&&e.current){if((e==null?void 0:e.current)===t){u.current=t;return}}else if(f.contains(t)){u.current=t;return}e!=null&&e.current?(0,focus_management/* focusElement */.C5)(e.current):(0,focus_management/* focusIn */.jA)(f,focus_management/* Focus.First */.TO.First)===focus_management/* FocusResult.Error */.fE.Error&&console.warn("There are no focusable elements inside the <FocusTrap />"),u.current=n==null?void 0:n.activeElement},[r]),u}function D({ownerDocument:n,container:l,containers:e,previousActiveElement:r},u){let f=(0,use_is_mounted/* useIsMounted */.t)();(0,use_event_listener/* useEventListener */.O)(n==null?void 0:n.defaultView,"focus",t=>{if(!u||!f.current)return;let o=new Set(e==null?void 0:e.current);o.add(l);let a=r.current;if(!a)return;let s=t.target;s&&s instanceof HTMLElement?focus_trap_G(o,s)?(r.current=s,(0,focus_management/* focusElement */.C5)(s)):(t.preventDefault(),t.stopPropagation(),(0,focus_management/* focusElement */.C5)(a)):(0,focus_management/* focusElement */.C5)(r.current)},!0)}function focus_trap_G(n,l){var e;for(let r of n)if((e=r.current)!=null&&e.contains(l))return!0;return!1}

// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/utils/owner.js
var owner = __webpack_require__(15466);
;// CONCATENATED MODULE: ./node_modules/@headlessui/react/dist/hooks/use-inert-others.js
let i=new Set,r=new Map;function u(t){t.setAttribute("aria-hidden","true"),t.inert=!0}function l(t){let n=r.get(t);!n||(n["aria-hidden"]===null?t.removeAttribute("aria-hidden"):t.setAttribute("aria-hidden",n["aria-hidden"]),t.inert=n.inert)}function use_inert_others_M(t,n=!0){(0,use_iso_morphic_effect/* useIsoMorphicEffect */.e)(()=>{if(!n||!t.current)return;let o=t.current,a=(0,owner/* getOwnerDocument */.r)(o);if(!!a){i.add(o);for(let e of r.keys())e.contains(o)&&(l(e),r.delete(e));return a.querySelectorAll("body > *").forEach(e=>{if(e instanceof HTMLElement){for(let f of i)if(e.contains(f))return;i.size===1&&(r.set(e,{"aria-hidden":e.getAttribute("aria-hidden"),inert:e.inert}),u(e))}}),()=>{if(i.delete(o),i.size>0)a.querySelectorAll("body > *").forEach(e=>{if(e instanceof HTMLElement&&!r.has(e)){for(let f of i)if(e.contains(f))return;r.set(e,{"aria-hidden":e.getAttribute("aria-hidden"),inert:e.inert}),u(e)}});else for(let e of r.keys())l(e),r.delete(e)}}},[n])}

// EXTERNAL MODULE: ./node_modules/react-dom/index.js
var react_dom = __webpack_require__(73935);
;// CONCATENATED MODULE: ./node_modules/@headlessui/react/dist/internal/portal-force-root.js
let e=(0,react.createContext)(!1);function portal_force_root_l(){return (0,react.useContext)(e)}function portal_force_root_P(o){return react.createElement(e.Provider,{value:o.force},o.children)}

;// CONCATENATED MODULE: ./node_modules/@headlessui/react/dist/components/portal/portal.js
function H(i){let u=portal_force_root_l(),l=(0,react.useContext)(E),e=(0,use_owner/* useOwnerDocument */.i)(i),[r,a]=(0,react.useState)(()=>{if(!u&&l!==null||typeof window=="undefined")return null;let o=e==null?void 0:e.getElementById("headlessui-portal-root");if(o)return o;if(e===null)return null;let t=e.createElement("div");return t.setAttribute("id","headlessui-portal-root"),e.body.appendChild(t)});return (0,react.useEffect)(()=>{r!==null&&(e!=null&&e.body.contains(r)||e==null||e.body.appendChild(r))},[r,e]),(0,react.useEffect)(()=>{u||l!==null&&a(l.current)},[l,a,u]),r}let portal_x=react.Fragment,_=(0,render/* forwardRefWithAs */.yV)(function(u,l){let e=u,r=(0,react.useRef)(null),a=(0,use_sync_refs/* useSyncRefs */.T)((0,use_sync_refs/* optionalRef */.h)(f=>{r.current=f}),l),o=(0,use_owner/* useOwnerDocument */.i)(r),t=H(r),[n]=(0,react.useState)(()=>{var f;return typeof window=="undefined"?null:(f=o==null?void 0:o.createElement("div"))!=null?f:null}),A=(0,use_server_handoff_complete/* useServerHandoffComplete */.H)(),p=(0,react.useRef)(!1);return (0,use_iso_morphic_effect/* useIsoMorphicEffect */.e)(()=>{if(p.current=!1,!(!t||!n))return t.contains(n)||t.appendChild(n),()=>{p.current=!0,(0,micro_task/* microTask */.Y)(()=>{var f;!p.current||!t||!n||(t.removeChild(n),t.childNodes.length<=0&&((f=t.parentElement)==null||f.removeChild(t)))})}},[t,n]),A?!t||!n?null:(0,react_dom.createPortal)((0,render/* render */.sY)({ourProps:{ref:a},theirProps:e,defaultTag:portal_x,name:"Portal"}),n):null}),U=react.Fragment,E=(0,react.createContext)(null),portal_j=(0,render/* forwardRefWithAs */.yV)(function(u,l){let{target:e,...r}=u,o={ref:(0,use_sync_refs/* useSyncRefs */.T)(l)};return react.createElement(E.Provider,{value:e},(0,render/* render */.sY)({ourProps:o,theirProps:r,defaultTag:U,name:"Popover.Group"}))}),portal_X=Object.assign(_,{Group:portal_j});

// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/description/description.js
var description = __webpack_require__(39516);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/internal/open-closed.js
var open_closed = __webpack_require__(16567);
;// CONCATENATED MODULE: ./node_modules/@headlessui/react/dist/internal/stack-context.js
let o=(0,react.createContext)(()=>{});o.displayName="StackContext";var stack_context_p=(e=>(e[e.Add=0]="Add",e[e.Remove=1]="Remove",e))(stack_context_p||{});function stack_context_x(){return (0,react.useContext)(o)}function O({children:c,onUpdate:t,type:e,element:n}){let a=stack_context_x(),r=(0,react.useCallback)((...l)=>{t==null||t(...l),a(...l)},[a,t]);return (0,use_iso_morphic_effect/* useIsoMorphicEffect */.e)(()=>(r(0,e,n),()=>r(1,e,n)),[r,e,n]),react.createElement(o.Provider,{value:r},c)}

// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/hooks/use-outside-click.js
var use_outside_click = __webpack_require__(90292);
;// CONCATENATED MODULE: ./node_modules/@headlessui/react/dist/components/dialog/dialog.js
var Ce=(o=>(o[o.Open=0]="Open",o[o.Closed=1]="Closed",o))(Ce||{}),Oe=(e=>(e[e.SetTitleId=0]="SetTitleId",e))(Oe||{});let Se={[0](a,e){return a.titleId===e.id?a:{...a,titleId:e.id}}},dialog_M=(0,react.createContext)(null);dialog_M.displayName="DialogContext";function dialog_O(a){let e=(0,react.useContext)(dialog_M);if(e===null){let o=new Error(`<${a} /> is missing a parent <Dialog /> component.`);throw Error.captureStackTrace&&Error.captureStackTrace(o,dialog_O),o}return e}function Fe(a,e){return (0,match/* match */.E)(e.type,Se,a,e)}let Le="div",dialog_we=render/* Features.RenderStrategy */.AN.RenderStrategy|render/* Features.Static */.AN.Static,ke=(0,render/* forwardRefWithAs */.yV)(function(e,o){let{open:r,onClose:l,initialFocus:p,__demoMode:c=!1,...g}=e,[m,D]=(0,react.useState)(0),S=(0,open_closed/* useOpenClosed */.oJ)();r===void 0&&S!==null&&(r=(0,match/* match */.E)(S,{[open_closed/* State.Open */.ZM.Open]:!0,[open_closed/* State.Closed */.ZM.Closed]:!1}));let u=(0,react.useRef)(new Set),f=(0,react.useRef)(null),Q=(0,use_sync_refs/* useSyncRefs */.T)(f,o),H=(0,react.useRef)(null),P=(0,use_owner/* useOwnerDocument */.i)(f),W=e.hasOwnProperty("open")||S!==null,B=e.hasOwnProperty("onClose");if(!W&&!B)throw new Error("You have to provide an `open` and an `onClose` prop to the `Dialog` component.");if(!W)throw new Error("You provided an `onClose` prop to the `Dialog`, but forgot an `open` prop.");if(!B)throw new Error("You provided an `open` prop to the `Dialog`, but forgot an `onClose` prop.");if(typeof r!="boolean")throw new Error(`You provided an \`open\` prop to the \`Dialog\`, but the value is not a boolean. Received: ${r}`);if(typeof l!="function")throw new Error(`You provided an \`onClose\` prop to the \`Dialog\`, but the value is not a function. Received: ${l}`);let i=r?0:1,[y,G]=(0,react.useReducer)(Fe,{titleId:null,descriptionId:null,panelRef:(0,react.createRef)()}),R=(0,react.useCallback)(()=>l(!1),[l]),U=(0,react.useCallback)(t=>G({type:0,id:t}),[G]),$=(0,use_server_handoff_complete/* useServerHandoffComplete */.H)()?c?!1:i===0:!1,F=m>1,N=(0,react.useContext)(dialog_M)!==null,X=F?"parent":"leaf";use_inert_others_M(f,F?$:!1),(0,use_outside_click/* useOutsideClick */.O)(()=>{var n,s;return[...Array.from((n=P==null?void 0:P.querySelectorAll("body > *"))!=null?n:[]).filter(T=>!(!(T instanceof HTMLElement)||T.contains(H.current)||y.panelRef.current&&T.contains(y.panelRef.current))),(s=y.panelRef.current)!=null?s:f.current]},()=>{i===0&&(F||R())},use_outside_click/* Features.IgnoreScrollbars */.A.IgnoreScrollbars),(0,use_event_listener/* useEventListener */.O)(P==null?void 0:P.defaultView,"keydown",t=>{t.defaultPrevented||t.key===keyboard/* Keys.Escape */.R.Escape&&i===0&&(F||(t.preventDefault(),t.stopPropagation(),R()))}),(0,react.useEffect)(()=>{var V;if(i!==0||N)return;let t=(0,owner/* getOwnerDocument */.r)(f);if(!t)return;let n=t.documentElement,s=(V=t.defaultView)!=null?V:window,T=n.style.overflow,le=n.style.paddingRight,j=s.innerWidth-n.clientWidth;if(n.style.overflow="hidden",j>0){let ne=n.clientWidth-n.offsetWidth,ie=j-ne;n.style.paddingRight=`${ie}px`}return()=>{n.style.overflow=T,n.style.paddingRight=le}},[i,N]),(0,react.useEffect)(()=>{if(i!==0||!f.current)return;let t=new IntersectionObserver(n=>{for(let s of n)s.boundingClientRect.x===0&&s.boundingClientRect.y===0&&s.boundingClientRect.width===0&&s.boundingClientRect.height===0&&R()});return t.observe(f.current),()=>t.disconnect()},[i,f,R]);let[Z,ee]=(0,description/* useDescriptions */.f)(),te=`headlessui-dialog-${(0,use_id/* useId */.M)()}`,oe=(0,react.useMemo)(()=>[{dialogState:i,close:R,setTitleId:U},y],[i,y,R,U]),Y=(0,react.useMemo)(()=>({open:i===0}),[i]),re={ref:Q,id:te,role:"dialog","aria-modal":i===0?!0:void 0,"aria-labelledby":y.titleId,"aria-describedby":Z,onClick(t){t.stopPropagation()}};return react.createElement(O,{type:"Dialog",element:f,onUpdate:(0,react.useCallback)((t,n,s)=>{n==="Dialog"&&(0,match/* match */.E)(t,{[stack_context_p.Add](){u.current.add(s),D(T=>T+1)},[stack_context_p.Remove](){u.current.add(s),D(T=>T-1)}})},[])},react.createElement(portal_force_root_P,{force:!0},react.createElement(portal_X,null,react.createElement(dialog_M.Provider,{value:oe},react.createElement(portal_X.Group,{target:f},react.createElement(portal_force_root_P,{force:!1},react.createElement(ee,{slot:Y,name:"Dialog.Description"},react.createElement(focus_trap_fe,{initialFocus:p,containers:u,features:$?(0,match/* match */.E)(X,{parent:focus_trap_fe.features.RestoreFocus,leaf:focus_trap_fe.features.All&~focus_trap_fe.features.FocusLock}):focus_trap_fe.features.None},(0,render/* render */.sY)({ourProps:re,theirProps:g,slot:Y,defaultTag:Le,features:dialog_we,visible:i===0,name:"Dialog"})))))))),react.createElement(internal_hidden/* Hidden */._,{features:internal_hidden/* Features.Hidden */.A.Hidden,ref:H}))}),Me="div",_e=(0,render/* forwardRefWithAs */.yV)(function(e,o){let[{dialogState:r,close:l}]=dialog_O("Dialog.Overlay"),p=(0,use_sync_refs/* useSyncRefs */.T)(o),c=`headlessui-dialog-overlay-${(0,use_id/* useId */.M)()}`,g=(0,react.useCallback)(u=>{if(u.target===u.currentTarget){if((0,bugs/* isDisabledReactIssue7711 */.P)(u.currentTarget))return u.preventDefault();u.preventDefault(),u.stopPropagation(),l()}},[l]),m=(0,react.useMemo)(()=>({open:r===0}),[r]);return (0,render/* render */.sY)({ourProps:{ref:p,id:c,"aria-hidden":!0,onClick:g},theirProps:e,slot:m,defaultTag:Me,name:"Dialog.Overlay"})}),Ie="div",xe=(0,render/* forwardRefWithAs */.yV)(function(e,o){let[{dialogState:r},l]=dialog_O("Dialog.Backdrop"),p=(0,use_sync_refs/* useSyncRefs */.T)(o),c=`headlessui-dialog-backdrop-${(0,use_id/* useId */.M)()}`;(0,react.useEffect)(()=>{if(l.panelRef.current===null)throw new Error("A <Dialog.Backdrop /> component is being used, but a <Dialog.Panel /> component is missing.")},[l.panelRef]);let g=(0,react.useMemo)(()=>({open:r===0}),[r]);return react.createElement(portal_force_root_P,{force:!0},react.createElement(portal_X,null,(0,render/* render */.sY)({ourProps:{ref:p,id:c,"aria-hidden":!0},theirProps:e,slot:g,defaultTag:Ie,name:"Dialog.Backdrop"})))}),He="div",We=(0,render/* forwardRefWithAs */.yV)(function(e,o){let[{dialogState:r},l]=dialog_O("Dialog.Panel"),p=(0,use_sync_refs/* useSyncRefs */.T)(o,l.panelRef),c=`headlessui-dialog-panel-${(0,use_id/* useId */.M)()}`,g=(0,react.useMemo)(()=>({open:r===0}),[r]);return (0,render/* render */.sY)({ourProps:{ref:p,id:c},theirProps:e,slot:g,defaultTag:He,name:"Dialog.Panel"})}),Be="h2",Ge=(0,render/* forwardRefWithAs */.yV)(function(e,o){let[{dialogState:r,setTitleId:l}]=dialog_O("Dialog.Title"),p=`headlessui-dialog-title-${(0,use_id/* useId */.M)()}`,c=(0,use_sync_refs/* useSyncRefs */.T)(o);(0,react.useEffect)(()=>(l(p),()=>l(null)),[p,l]);let g=(0,react.useMemo)(()=>({open:r===0}),[r]);return (0,render/* render */.sY)({ourProps:{ref:c,id:p},theirProps:e,slot:g,defaultTag:Be,name:"Dialog.Title"})}),mt=Object.assign(ke,{Backdrop:xe,Panel:We,Overlay:_e,Title:Ge,Description:description/* Description */.d});

;// CONCATENATED MODULE: ./src/lib/common/components/GenericModal.js
function GenericModal_slicedToArray(arr, i) { return GenericModal_arrayWithHoles(arr) || GenericModal_iterableToArrayLimit(arr, i) || GenericModal_unsupportedIterableToArray(arr, i) || GenericModal_nonIterableRest(); }

function GenericModal_nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function GenericModal_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return GenericModal_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return GenericModal_arrayLikeToArray(o, minLen); }

function GenericModal_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function GenericModal_iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function GenericModal_arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }









var GenericModal = function GenericModal(_ref) {
  var show = _ref.show,
      onClose = _ref.onClose,
      preventIndirectClose = _ref.preventIndirectClose,
      title = _ref.title,
      description = _ref.description,
      children = _ref.children,
      closeIcon = _ref.closeIcon,
      onEntered = _ref.onEntered,
      onExited = _ref.onExited,
      _ref$headerHeight = _ref.headerHeight,
      headerHeight = _ref$headerHeight === void 0 ? 0 : _ref$headerHeight;

  // To enable animation on preventing-closing... hackish, much better with react-simple-animate or similar
  var _useState = (0,react.useState)(false),
      _useState2 = GenericModal_slicedToArray(_useState, 2),
      scale = _useState2[0],
      setScale = _useState2[1];

  var triggerScale = (0,hooks/* useLinkCallback */._P)(function () {
    setScale(true);
    setTimeout(function () {
      return setScale(false);
    }, 200);
  }); // TODO: or just pop up a custom modal to confirm clearing...

  var indirectCloseFn = (0,react.useCallback)(function () {
    preventIndirectClose ? triggerScale() : onClose();
  }, [preventIndirectClose]);
  var inExtensionContext = "extension" === 'extension';
  return (
    /*#__PURE__*/
    // Use the `Transition` component + show prop to add transitions... but there's gotta be a cleaner way to manage this.
    (0,jsx_runtime.jsx)(transition/* Transition */.u, {
      show: !!show,
      as: react.Fragment,
      afterEnter: onEntered,
      afterLeave: onExited,
      children: /*#__PURE__*/(0,jsx_runtime.jsx)(mt, {
        "static": true,
        open: !!show,
        onClose: indirectCloseFn,
        className: "fixed inset-0 overflow-y-auto",
        style: {
          zIndex: 20
        },
        children: /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
          className: "flex items-center justify-center min-h-screen",
          children: [/*#__PURE__*/(0,jsx_runtime.jsx)(mt.Overlay, {
            className: "fixed inset-0 bg-black opacity-30"
          }), /*#__PURE__*/(0,jsx_runtime.jsx)(transition/* Transition.Child */.u.Child, {
            as: react.Fragment,
            enter: "ease-out duration-300",
            enterFrom: "opacity-0 scale-95",
            enterTo: "opacity-100 scale-100",
            leave: "ease-in duration-200",
            leaveFrom: "opacity-100 scale-100",
            leaveTo: "opacity-0 scale-95",
            children: /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
              className: (0,utils.cn)('k-modal-content m-5', 'relative z-20 mx-auto bg-white rounded shadow', 'transition duration-600 ease-in-out', scale ? 'scale-105' : 'scale-100', inExtensionContext ? 'max-w-[400px]' : 'max-w-lg'),
              style: {
                marginTop: headerHeight
              },
              children: [closeIcon && /*#__PURE__*/(0,jsx_runtime.jsx)(icons/* CloseIcon */.Tw, {
                className: "absolute text-xl text-gray-200 cursor-pointer hover:text-gray-400 right-2 top-2",
                onClick: onClose
              }), title && /*#__PURE__*/(0,jsx_runtime.jsx)(mt.Title, {
                className: "p-4 pb-1 text-2xl font-light text-center",
                children: title
              }), description && /*#__PURE__*/(0,jsx_runtime.jsx)(mt.Description, {
                children: description
              }), children]
            })
          })]
        })
      })
    })
  );
};

GenericModal.Body = function (_ref2) {
  var children = _ref2.children,
      className = _ref2.className;
  return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
    className: (0,utils.cn)('bg-white p-5 rounded-t', className),
    children: children
  });
};

GenericModal.Footer = function (_ref3) {
  var children = _ref3.children,
      className = _ref3.className,
      dark = _ref3.dark;
  return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
    className: (0,utils.cn)('bg-gray-100 p-5 border-t rounded-b', className),
    children: children
  });
};

/* harmony default export */ const components_GenericModal = (GenericModal);
// EXTERNAL MODULE: ./src/lib/common/components/Alert.js
var Alert = __webpack_require__(5966);
// EXTERNAL MODULE: ./src/lib/common/components/Button/index.js
var Button = __webpack_require__(95673);
// EXTERNAL MODULE: ./node_modules/react-select/dist/react-select.browser.esm.js + 1 modules
var react_select_browser_esm = __webpack_require__(88572);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/SelectReadingFrom/ReadingFromSelector/selectHelpers.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






var noOptionsMessage = function noOptionsMessage(_ref) {
  var inputValue = _ref.inputValue;
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
    className: "mb-0",
    children: ["No unselected views", ' ', (inputValue === null || inputValue === void 0 ? void 0 : inputValue.length) === 0 ? 'remain.' : "match \"".concat(inputValue, "\"")]
  });
}; // NOTE: Used in the menu AND when selected...

var formatOptionLabel = function formatOptionLabel(option, _ref2) {
  var context = _ref2.context;

  // Once selected, within the search bar at the top
  if (context === 'value') {
    return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "text-gray-700",
      children: ["@", option.label]
    });
  } // When unselected, in the menu below


  if (context === 'menu') {
    var user = option.user;

    var _ref3 = user || {},
        name = _ref3.name,
        _ref3$meta = _ref3.meta;

    _ref3$meta = _ref3$meta === void 0 ? {} : _ref3$meta;
    var _ref3$meta$numDomainR = _ref3$meta.numDomainReviews,
        numDomainReviews = _ref3$meta$numDomainR === void 0 ? 0 : _ref3$meta$numDomainR;
    return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "option flex items-center p-2",
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)(Avatar/* default */.Z, {
        user: user,
        size: 40,
        className: "mr-2"
      }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "inline-flex flex-col",
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("span", {
          className: "text-blue-500",
          children: (0,utils/* handle */.pr)(user)
        }), (name === null || name === void 0 ? void 0 : name.length) && name !== option.label && /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
          className: "text-gray-500 text-sm ml-1",
          children: name
        })]
      }), numDomainReviews > 0 ? /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
        className: "m-1 ml-3 rounded-full bg-gray-600 text-gray-100 text-sm font-light py-0.5 px-2",
        children: (0,utils/* plur */.Jn)(numDomainReviews, 'review')
      }) : /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
        className: "ml-3 text-gray-400 text-sm",
        children: "(no reviews yet)"
      })]
    });
  } // Don't think we should get here, but a valid fallback regardless


  return /*#__PURE__*/(0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
    children: option.label
  });
};
var customSelectStyles = {
  // Make menu look like it belongs in the modal (rather than floating above it)
  menu: function menu(provided) {
    return _objectSpread(_objectSpread({}, provided), {}, {
      boxShadow: 'none',
      position: 'relative',
      marginBottom: '10px'
    });
  },
  // Indent options a bit
  option: function option(provided) {
    return _objectSpread(_objectSpread({}, provided), {}, {
      padding: '0',
      display: 'flex',
      alignItems: 'center',
      borderRadius: '5px',
      width: 'auto',
      fontSize: '1rem'
    });
  }
};
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/SelectReadingFrom/ReadingFromSelector/index.js





var ReadingFromSelector = function ReadingFromSelector(_ref) {
  var options = _ref.options,
      selectedUsers = _ref.selectedUsers,
      onChange = _ref.onChange;
  return /*#__PURE__*/(0,jsx_runtime.jsx)(react_select_browser_esm/* default */.ZP, {
    placeholder: "Select views to activate...",
    noOptionsMessage: noOptionsMessage,
    formatOptionLabel: formatOptionLabel,
    styles: customSelectStyles,
    closeMenuOnSelect: false,
    captureMenuScroll: false,
    menuIsOpen: true,
    autoFocus: true,
    isMulti: true,
    options: (0,lodash.sortBy)(options, 'label'),
    value: selectedUsers,
    onChange: onChange
  });
};

/* harmony default export */ const SelectReadingFrom_ReadingFromSelector = (ReadingFromSelector);
;// CONCATENATED MODULE: ./src/lib/common/hooks/useModalResizing.js

var MARGIN = 20;
var HEADER_HEIGHT = 115; // TODO: load this dynamically

/*
 * useModalResizing - returns onEntered/onExited hooks to add to GenericModal
 * when it's being used in the browser extension context (tries to make the extension window
 * grow to show full modal height, then shrink again when closed).
 *
 * NOTE: this seem functional up to window heights of ~600px, then hit chrome's max sizes
 */

var useModalResizing = function useModalResizing() {
  var onEntered = (0,react.useCallback)(function () {
    if (!window) return true;
    var body = document.querySelector('body');
    var modalElement = body.querySelector('.k-modal-content');
    if (!modalElement) return true;
    var modalHeight = modalElement.scrollHeight + 2 * MARGIN + HEADER_HEIGHT;
    console.log('[useModalResizing] ', {
      body: body,
      modalElement: modalElement,
      modalHeight: modalHeight
    });
    body.style.minHeight = "".concat(modalHeight, "px");
  }, []);
  var onExited = (0,react.useCallback)(function () {
    var body = document.querySelector('body');
    body.style.minHeight = 'initial';
  }, []);
  return {
    onEntered: onEntered,
    onExited: onExited
  };
};

/* harmony default export */ const hooks_useModalResizing = (useModalResizing);
// EXTERNAL MODULE: ./src/lib/common/hooks/useMinExtensionPopupHeight.js
var useMinExtensionPopupHeight = __webpack_require__(70624);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/SelectReadingFrom/SelectActiveUsersModal.js
function SelectActiveUsersModal_slicedToArray(arr, i) { return SelectActiveUsersModal_arrayWithHoles(arr) || SelectActiveUsersModal_iterableToArrayLimit(arr, i) || SelectActiveUsersModal_unsupportedIterableToArray(arr, i) || SelectActiveUsersModal_nonIterableRest(); }

function SelectActiveUsersModal_nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function SelectActiveUsersModal_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return SelectActiveUsersModal_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return SelectActiveUsersModal_arrayLikeToArray(o, minLen); }

function SelectActiveUsersModal_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function SelectActiveUsersModal_iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function SelectActiveUsersModal_arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }



















var Filter = function Filter(_ref) {
  var label = _ref.label,
      active = _ref.active,
      onClick = _ref.onClick;
  return active ? /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
    className: "text-gray-500",
    children: label
  }) : /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
    href: "#",
    onClick: onClick,
    children: label
  });
}; // Note: ideal to auto-select Submit after all selected, but refs don't work in function components


var SelectActiveUsersModal = function SelectActiveUsersModal(_ref2) {
  var show = _ref2.show,
      toggleModal = _ref2.toggleModal,
      options = _ref2.options,
      activeOptions = _ref2.activeOptions,
      onSubmit = _ref2.onSubmit;

  var _useState = (0,react.useState)(activeOptions),
      _useState2 = SelectActiveUsersModal_slicedToArray(_useState, 2),
      selectedUserOptions = _useState2[0],
      setSelectedUserOptions = _useState2[1];

  var _useModalResizing = hooks_useModalResizing(),
      onEntered = _useModalResizing.onEntered,
      onExited = _useModalResizing.onExited; // This block resets the modal height when the set of selected options changes (trying to keep it in popup height as much as possible)


  (0,react.useEffect)(function () {
    try {
      show && onEntered();
    } catch (e) {
      console.log('Got an issue:', e);
    }
  }, [show, selectedUserOptions]);
  var handleSubmit = (0,react.useCallback)(function () {
    onSubmit(selectedUserOptions);
  }, [selectedUserOptions.map(function (o) {
    return o.value;
  }).join(':')]); // eslint-disable-line

  var selectAll = (0,hooks/* useLinkCallback */._P)(function () {
    setSelectedUserOptions(options);
  }, [options.length]);
  var selectNone = (0,hooks/* useLinkCallback */._P)(function () {
    setSelectedUserOptions([]);
  }, []);

  var _useToggle = (0,hooks/* useToggle */.OT)(false),
      _useToggle2 = SelectActiveUsersModal_slicedToArray(_useToggle, 2),
      showInfo = _useToggle2[0],
      toggleShowInfo = _useToggle2[1];

  var setMinWindowHeight = (0,useMinExtensionPopupHeight/* default */.Z)(); // TODO: figure out how to check actual modal height
  // TODO: pretty sure not actually taking effect currently

  (0,react.useEffect)(function () {
    setMinWindowHeight(show ? '650px' : 'auto');
  }, [show]);
  return /*#__PURE__*/(0,jsx_runtime.jsxs)(components_GenericModal, {
    headerHeight: 115 // TODO: load this dynamically
    ,
    closeIcon: true,
    show: show,
    onClose: toggleModal,
    preventIndirectClose: selectedUserOptions.length === activeOptions.length ? true : 'static',
    onEntered: onEntered,
    onExited: onExited,
    title: /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
      children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "",
        children: ["Select Views", /*#__PURE__*/(0,jsx_runtime.jsx)(icons/* InfoIcon */.sz, {
          className: "ml-1 inline text-base text-gray-500",
          onClick: toggleShowInfo
        })]
      }), showInfo && /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "text-left space-y-4 text-base p-4 text-gray-400",
        children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
          children: ["This modal lets you to select precisely which, of all the views you follow, you want to be ", /*#__PURE__*/(0,jsx_runtime.jsx)("em", {
            children: "active"
          }), " right now."]
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
          children: ["Each page you visit will be compared against ratings from", ' ', /*#__PURE__*/(0,jsx_runtime.jsx)("em", {
            children: "the currently active"
          }), " view that you select here."]
        })]
      })]
    }),
    children: [/*#__PURE__*/(0,jsx_runtime.jsxs)(components_GenericModal.Body, {
      className: "pb-0",
      children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "mb-1 text-sm flex items-end w-full",
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("span", {
          className: "mr-1",
          children: "Filters: "
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Filter, {
          label: "Select All",
          onClick: selectAll,
          active: selectedUserOptions.length === options.length
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
          className: "mx-2 text-gray-500",
          children: "|"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Filter, {
          label: "Select None",
          onClick: selectNone,
          active: selectedUserOptions.length === 0
        })]
      }), /*#__PURE__*/(0,jsx_runtime.jsx)(SelectReadingFrom_ReadingFromSelector, {
        options: options,
        onChange: setSelectedUserOptions,
        selectedUsers: selectedUserOptions
      })]
    }), /*#__PURE__*/(0,jsx_runtime.jsxs)(components_GenericModal.Footer, {
      className: "bg-gray-100 flex justify-between",
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)(UniversalLink/* default */.Z, {
        href: routes/* default.usersUrl */.Z.usersUrl,
        children: /*#__PURE__*/(0,jsx_runtime.jsx)(Button/* default */.Z, {
          variant: "hover",
          children: "Search Views"
        })
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        className: "w-6"
      }), /*#__PURE__*/(0,jsx_runtime.jsx)(Button/* default */.Z, {
        variant: "primary",
        onClick: handleSubmit,
        children: "Save"
      })]
    })]
  });
};
/* harmony default export */ const SelectReadingFrom_SelectActiveUsersModal = (SelectActiveUsersModal);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/SelectReadingFrom/index.js
function SelectReadingFrom_slicedToArray(arr, i) { return SelectReadingFrom_arrayWithHoles(arr) || SelectReadingFrom_iterableToArrayLimit(arr, i) || SelectReadingFrom_unsupportedIterableToArray(arr, i) || SelectReadingFrom_nonIterableRest(); }

function SelectReadingFrom_nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function SelectReadingFrom_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return SelectReadingFrom_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return SelectReadingFrom_arrayLikeToArray(o, minLen); }

function SelectReadingFrom_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function SelectReadingFrom_iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function SelectReadingFrom_arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }









var makeOptionForUser = function makeOptionForUser(user) {
  return {
    label: user.handle,
    value: user.id,
    user: user
  };
};

var SelectReadingFrom = /*#__PURE__*/react.forwardRef(function (_ref, ref) {
  var activeUids = _ref.activeUids,
      setActiveUids = _ref.setActiveUids,
      followedUsers = _ref.followedUsers;

  var _useToggle = (0,hooks/* useToggle */.OT)(false),
      _useToggle2 = SelectReadingFrom_slicedToArray(_useToggle, 2),
      modal = _useToggle2[0],
      toggleModal = _useToggle2[1];

  var options = (0,react.useMemo)(function () {
    return (followedUsers || []).map(makeOptionForUser);
  }, [followedUsers.length]); // PERF: should probably memoize this - use the whyDidYouRender (?) hook to trace performance implications

  var activeOptions = options.filter(function (opt) {
    return (activeUids || []).includes(opt.value);
  });
  var handleModalSubmission = (0,react.useCallback)(function (chosenUserOptions) {
    var uids = (chosenUserOptions || []).map(function (_ref2) {
      var value = _ref2.value;
      return value;
    });
    setActiveUids(uids);
    console.log('Toggling modal off');
    toggleModal(false);
  }, [setActiveUids, toggleModal]);
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    ref: ref,
    className: "fixed w-full max-w-[420px] shadow-xl border-b",
    style: {
      zIndex: 50
    },
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)(SubnavBar/* default */.Z, {
      children: /*#__PURE__*/(0,jsx_runtime.jsx)(SubnavBar/* default.ActionTitle */.Z.ActionTitle, {
        onClick: toggleModal,
        children: /*#__PURE__*/(0,jsx_runtime.jsx)(SelectReadingFrom_CurrentlyActiveDescription, {
          activeOptions: activeOptions
        })
      })
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(SelectReadingFrom_SelectActiveUsersModal, {
      show: modal,
      toggleModal: toggleModal,
      options: options,
      activeOptions: activeOptions,
      onSubmit: handleModalSubmission
    })]
  });
});
SelectReadingFrom.displayName = 'SelectReadingFrom';
/* harmony default export */ const ReadMode_SelectReadingFrom = (SelectReadingFrom);
// EXTERNAL MODULE: ./src/lib/common/config/index.js
var config = __webpack_require__(66245);
// EXTERNAL MODULE: ./node_modules/usehooks-ts/dist/esm/index.js + 64 modules
var esm = __webpack_require__(69608);
// EXTERNAL MODULE: ./src/lib/universal-interface/hooks.js
var universal_interface_hooks = __webpack_require__(50731);
;// CONCATENATED MODULE: ./src/lib/common/components/ext/ReadMode/index.js
function ReadMode_slicedToArray(arr, i) { return ReadMode_arrayWithHoles(arr) || ReadMode_iterableToArrayLimit(arr, i) || ReadMode_unsupportedIterableToArray(arr, i) || ReadMode_nonIterableRest(); }

function ReadMode_nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function ReadMode_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return ReadMode_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return ReadMode_arrayLikeToArray(o, minLen); }

function ReadMode_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function ReadMode_iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function ReadMode_arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

















var ReadModeWithoutUsers = function ReadModeWithoutUsers() {
  return /*#__PURE__*/(0,jsx_runtime.jsxs)(Alert/* default */.Z, {
    variant: "info",
    className: "p-3 m-0 rounded-0",
    children: [/*#__PURE__*/(0,jsx_runtime.jsxs)(Alert/* default.Heading */.Z.Heading, {
      children: ["Welcome to ", config/* default.appName */.ZP.appName]
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("strong", {
      children: "Just one more step! "
    }), "This screen will show you how the users you follow have rated the current domain... but first you must\xA0", /*#__PURE__*/(0,jsx_runtime.jsx)(UniversalLink/* default */.Z, {
      href: routes/* default.usersUrl */.Z.usersUrl,
      className: "font-bold",
      text: "follow some users"
    }), "."]
  });
}; // TODO: no real need for a wrapper, just pulled out while trying to avoid duplication in setting default readContext
// ...although actually I really like how it minimized the props for ReadModeContent, so maybe just rename better?


var ReadModeContentWrapper = function ReadModeContentWrapper(_ref) {
  var domainKey = _ref.domainKey,
      address = _ref.address,
      activeUids = _ref.activeUids,
      followedUsers = _ref.followedUsers;
  var domainPackets = (0,recoil/* useRecoilValue */.sJ)((0,recoil/* relevantDomainPacketsSelectorFamily */.I_)(domainKey)); // TODO: why are we not using activeUids somewhere to filter? Seems sketchy.. filtering downstream somewhere?
  // IMPROVE: there's definitely room to lazy load just the one needed first, then the other in the background

  var _useScoreAddressAgain = (0,hooks/* useScoreAddressAgainstDomainPackets */.qd)({
    address: address,
    domainPackets: domainPackets,
    followedUsers: followedUsers
  }),
      reviewsForPage = _useScoreAddressAgain.reviewsForPage,
      reviewsForDomain = _useScoreAddressAgain.reviewsForDomain;

  console.log('ReadModeContentWrapper: reviewsForPage', {
    reviewsForPage: reviewsForPage,
    reviewsForDomain: reviewsForDomain,
    domainPackets: domainPackets
  });
  if (!(domainPackets !== null && domainPackets !== void 0 && domainPackets.length)) return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
    className: "bg-white py-5 flex justify-center",
    children: /*#__PURE__*/(0,jsx_runtime.jsxs)(components_Empty, {
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)("b", {
        children: domainKey
      }), " has no opinions yet ", /*#__PURE__*/(0,jsx_runtime.jsx)("br", {}), /*#__PURE__*/(0,jsx_runtime.jsx)("small", {
        children: "(from your selected view".concat((activeUids === null || activeUids === void 0 ? void 0 : activeUids.length) === 1 ? '' : 's', ")")
      })]
    })
  });
  return /*#__PURE__*/(0,jsx_runtime.jsx)(ReadMode_ReadModeContent, {
    domainKey: domainKey,
    reviewsForPage: reviewsForPage,
    reviewsForDomain: reviewsForDomain
  });
};

var ReadMode = function ReadMode() {
  var _useElementSize = (0,esm/* useElementSize */.h4)(),
      _useElementSize2 = ReadMode_slicedToArray(_useElementSize, 2),
      headerRef = _useElementSize2[0],
      headerHeight = _useElementSize2[1].height;

  var _useRecoilValue = (0,recoil/* useRecoilValue */.sJ)(recoil/* currentAtom */.C),
      domainKey = _useRecoilValue.domainKey,
      address = _useRecoilValue.address;

  var _useRecoilState = (0,recoil/* useRecoilState */.FV)(recoil/* activeUidsAtom */.Ox),
      _useRecoilState2 = ReadMode_slicedToArray(_useRecoilState, 2),
      activeUids = _useRecoilState2[0],
      setActiveUids = _useRecoilState2[1];

  var followedUsers = (0,recoil/* useRecoilValue */.sJ)(recoil/* followedUsersAtom */.jL);
  var currentUserId = (0,universal_interface_hooks/* useCurrentUserId */.dO)();
  if (!(followedUsers !== null && followedUsers !== void 0 && followedUsers.length) || followedUsers.length === 1 && followedUsers[0].id === currentUserId) return /*#__PURE__*/(0,jsx_runtime.jsx)(ReadModeWithoutUsers, {});
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: "relative overflow-y-hidden",
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)(ReadMode_SelectReadingFrom, {
      followedUsers: followedUsers,
      activeUids: activeUids,
      setActiveUids: setActiveUids,
      ref: headerRef
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      className: "relative overflow-y-auto",
      style: {
        marginTop: headerHeight === 0 ? '50px' : headerHeight
      },
      children: (activeUids === null || activeUids === void 0 ? void 0 : activeUids.length) === 0 ? /*#__PURE__*/(0,jsx_runtime.jsx)(Alert/* default */.Z, {
        variant: "info",
        className: "p-3 m-0 rounded-0",
        style: {
          marginTop: headerHeight
        },
        children: "You must activate at least one view to see ratings in this space."
      }) : /*#__PURE__*/(0,jsx_runtime.jsx)(ReadModeContentWrapper, {
        domainKey: domainKey,
        address: address,
        activeUids: activeUids,
        followedUsers: followedUsers
      })
    })]
  });
};

/* harmony default export */ const ext_ReadMode = (ReadMode);

/***/ })

}]);