# Set the host name for URL creation
SitemapGenerator::Sitemap.default_host = "https://winelistadvisor.com"

# The remote host where your sitemaps will be hosted
SitemapGenerator::Sitemap.sitemaps_host = "https://s3-us-west-2.amazonaws.com/s3.winelistadvisor.com/"

# The directory to write sitemaps to locally
SitemapGenerator::Sitemap.public_path = 'tmp/'

# Set this to a directory/path if you don't want to upload to the root of your `sitemaps_host`
SitemapGenerator::Sitemap.sitemaps_path = 'sitemaps/'

# The adapter to perform the upload of sitemap files.
SitemapGenerator::Sitemap.adapter = SitemapGenerator::S3Adapter.new({
  fog_provider: 'AWS',
  aws_access_key_id: ENV.fetch('AWS_KEY'),
  aws_secret_access_key: ENV.fetch('AWS_SECRET'),
  fog_directory: 's3.winelistadvisor.com',
  fog_region: 'us-west-2',
})

INCLUDE_NEWS = false

SitemapGenerator::Sitemap.create do
  # Put links creation logic here.
  #
  # The root path '/' and sitemap index file are added automatically for you.
  # Links are added to the Sitemap in the order they are specified.
  #
  # Usage: add(path, options={})
  #        (default options are used if you don't specify)
  #
  # Defaults: :priority => 0.5, :changefreq => 'weekly',
  #           :lastmod => Time.now, :host => default_host
  #
  # Examples:
  #
  # Add '/articles'
  #
  #   add articles_path, :priority => 0.7, :changefreq => 'daily'
  #
  # Add all articles:
  #
  #   Article.find_each do |article|
  #     add article_path(article), :lastmod => article.updated_at
  #   end

  add search_magazine_path, priority: 1
  add search_members_path, priority: 1
  add search_restaurants_path, priority: 1

  Category.for_nav.each do |cat|
    add articles_by_path(category: cat.slug), priority: 0.9
  end

  Pages::ALL_SIBLINGS.each do |slug|
    add page_path(slug), priority: 0.8
  end

  Article.published.find_each do |article|
    opts = {lastmod: article.updated_at}

    if INCLUDE_NEWS
      opts.merge!({
        news: {
          publication_name: 'WineListAdvisor',
          publication_language: "en",
          title: article.title,
          publication_date: article.created_at.strftime("%Y-%m-%d"),
          genres: article.category.name,
        }
      })
    end

    add article_path(article), opts
  end

  Restaurant.find_each do |r|
    add restaurant_path(r), lastmod: r.updated_at
  end

  User.find_each do |u|
    add profile_user_path(u), lastmod: u.updated_at
  end

end