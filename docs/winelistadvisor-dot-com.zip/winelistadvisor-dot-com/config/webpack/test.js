const environment = require('./environment')
const merge = require('webpack-merge')

// Note that we're already calling toWebpackConfig in ./environment!
module.exports = environment
