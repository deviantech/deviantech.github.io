// Note that we're already calling toWebpackConfig in ./environment!
const environment = require('./environment')
const merge = require('webpack-merge')



// const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin
// module.exports = merge(environment, {
//   plugins: [
//     new BundleAnalyzerPlugin({analyzerMode: 'static'})
//   ]
// })


module.exports = environment
