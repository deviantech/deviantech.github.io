// Note that we already toWebpackConfig'ed this in environment.js!
const environment = require('./environment')
const merge = require('webpack-merge')

const imgConfig = {}

module.exports = merge(environment, imgConfig)
