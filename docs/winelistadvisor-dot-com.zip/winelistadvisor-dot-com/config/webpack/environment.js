const { environment } = require('@rails/webpacker')
const path = require('path')
const merge = require('webpack-merge')

const webpack = require('webpack')

// https://github.com/rails/webpacker/issues/1119#issuecomment-352738508
// resolve-url-loader must be used before sass-loader to enable relative sass paths
environment.loaders.get('sass').use.splice(-1, 0, {
  loader: 'resolve-url-loader',
})


environment.plugins.append('Provide', new webpack.ProvidePlugin({
  Popper: ['popper.js', 'default'],
  React: 'react',
}))

environment.plugins.append('Define', new webpack.DefinePlugin({
  ESCAPE_KEY: '27',
}))

environment.loaders.append('useBrowserGlobals', {
  test: /(imagesloaded|node-snackbar|bootstrap-star-rating)/,
  use: "imports-loader?define=>false,module=>false"
})
environment.loaders.append('useThisWIndow', {
  test: /social-share-button-js/,
  use: "imports-loader?this=>window"
})

// Based on: https://gist.github.com/joakimk/90fcd6144ef05478feea9560a87f878f
// Generate undigested assets for use in embedded javascript, emails, etc.
// We previously used non-stupid-digest-assets [https://github.com/alexspeller/non-stupid-digest-assets] for this.
environment.plugins.append("UndigestedAssets", function() {
  this.plugin("emit", function(compilation, compileCallback) {
    var fs = require("fs")
    var path = require("path")
    var manifest = JSON.parse(compilation.assets["manifest.json"].source())

    for(var sourceFile in manifest) {
      if ( sourceFile.match(/\/static\//) ) {
        var targetFile = manifest[sourceFile]
        outputPath = "/" + path.basename(compilation.options.output.path) + "/"
        assetKey = targetFile.replace(outputPath, "")

        // Make output paths for undigested files the same as sprockets so that old links still work.
        outputPath = sourceFile.replace("_/assets/images/", "")
        outputPath = outputPath.replace("_/assets/fonts/", "")
        outputPath = outputPath.replace("_/assets/", "")

        // When an error happens in development, all assets are not compiled, we
        // need to handle that so we don't crash webpack :)
        if(compilation.assets[assetKey]) {
          compilation.assets[outputPath] = compilation.assets[assetKey]
        }
      }
    }

    compileCallback()
  })
})







const root = path.resolve(__dirname, '../../app/webpack/')

const aliasConfig = {
  resolve: {
    alias: {
      'Utils': path.resolve(root, 'src/javascript/utils'),
      'Components': path.resolve(root, 'src/javascript/components'),
      'Lib': path.resolve(root, 'src/javascript/application/lib'),

      // Use preact for performance, at least unless/until it breaks something
      "react": "preact-compat",
      "react-dom": "preact-compat"
    }
  }
}

const externConfig = {
  externals: {
    // require("jquery") is external and available
    //  on the global var jQuery
    "jquery": "jQuery"
  }
}



module.exports = merge(environment.toWebpackConfig(), aliasConfig, externConfig)
