# frozen_string_literal: true

# https://github.com/heroku/rack-timeout
if defined? Rack::Timeout
  Rack::Timeout.timeout = 28  # seconds, must be under Heroku's default 30s timeout (which doesn't free up Puma)
end
