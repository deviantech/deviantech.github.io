# frozen_string_literal: true

# https://github.com/mgsnova/feature
repo = Feature::Repository::YamlRepository.new("#{Rails.root}/config/features.yml")
Feature.set_repository(repo)
