# frozen_string_literal: true

if App.staging?


  Winelist::Application.configure do
    config.action_mailer.show_previews = true
    config.action_mailer.preview_path ||= defined?(Rails.root) ? "#{Rails.root}/spec/mailers/previews" : nil
    config.autoload_paths += [config.action_mailer.preview_path]
    config.consider_all_requests_local = true
  end

  class ::Rails::MailersController
    def local_request?
      true
    end
  end


end
