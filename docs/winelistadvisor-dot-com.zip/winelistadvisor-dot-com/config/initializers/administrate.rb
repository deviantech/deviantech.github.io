# frozen_string_literal: true

# Re-open class to support separate moderation/ and admin/ dashboards
class Administrate::Page::Base

  def resource_name
    @resource_name ||=
      dashboard.class.to_s.sub('Moderation::', '').scan(/(.+)Dashboard/).first.first.underscore
  end

end


# TODO: this could be a PR - allows sorting in the sidebar
class Administrate::Namespace::Resource
  def <=>(other)
    if namespace == other.namespace
      resource <=> other.resource
    else namespace <=> other.namespace
    end
  end

end




require 'administrate/field/associative'

# Allow passing dashboard name directly (e.g. to support moderation dashboards)
class Administrate::Field::Associative < Administrate::Field::Base

  def associated_dashboard
    options[:dashboard] ? options[:dashboard].new : "#{associated_class_name}Dashboard".constantize.new
  end

end
