# frozen_string_literal: true

# config/initializers/pundit.rb
# Extends the ApplicationController to add Pundit for authorization.
# Modify this file to change the behavior of a 'not authorized' error.
# Be sure to restart your server when you modify this file.
module PunditControllerHelper
  extend ActiveSupport::Concern

  included do
    include Pundit
    rescue_from Pundit::NotAuthorizedError, with: :user_not_authorized
  end

  private

  def user_not_authorized
    flash[:danger] = "Access denied."
    store_location_for('user', request.path) if request.get? && !user_signed_in?

    # Avoid potential infinite redirect
    next_link = if request.referrer && (from = Addressable::URI.parse(request.referrer) rescue nil)
      request.referrer unless from.path == request.path
    end

    redirect_to user_signed_in? ? (next_link || user_path(current_user)) : new_user_session_path
  end

end
