# frozen_string_literal: true

# http://www.example.com/about rather than http://www.example.com/pages/about
HighVoltage.configure do |config|
  config.route_drawer = HighVoltage::RouteDrawers::Root
  config.layout = 'pages'
end

module Pages
  POLICIES = %w(content-guidelines contest-rules privacy-policy terms-of-use).sort.freeze
  SUPPORT = %w(for-restaurants for-wineries for-writers for-reviewers social-features help).sort.freeze
  COMPANY = %w(about-us wla-team press contact-us).sort.freeze
  HELP = HighVoltage.page_ids.select {|p| p.index('help/') }
  ALL_SIBLINGS = POLICIES + SUPPORT + COMPANY + HELP

  class << self
    def has_siblings?(page)
      ALL_SIBLINGS.include?(page)
    end

    def sibling_pages(page, short_titles: false)
      if    POLICIES.include?(page) then policy_pages(short_titles: short_titles)
      elsif SUPPORT.include?(page) then support_pages(short_titles: short_titles)
      elsif COMPANY.include?(page) then company_pages(short_titles: short_titles)
      elsif HELP.include?(page) then help_pages(short_titles: short_titles)
      else []
      end
    end

    def help_pages(short_titles: false)
      pages HELP, short_titles
    end

    def company_pages(short_titles: false)
      pages COMPANY, short_titles
    end

    def support_pages(short_titles: false)
      pages SUPPORT, short_titles
    end

    def policy_pages(short_titles: false)
      pages POLICIES, short_titles
    end

    def pages(src, short_titles)
      src.sort.map {|p| [p, short_titles ? short_page_title(p) : page_title(p)] }
    end

    private

    def page_title(page)
      case page
      when /faq/i then 'FAQs'
      when /team/i then 'WLA Team'
      else page.split('/').last.titleize
      end
    end

    def short_page_title(page)
      case page
      when /reward/ then 'Rewards'
      when /faq/i then 'FAQs'
      when /tasting/i then 'Tasting'
      when /profile/i then 'Profiles'
      when /point/i then 'Points'
      when /reviewer/i then 'Reviewers'
      when /review/i then 'Reviews'
      when /article/i then 'Articles'
      when /content/i then 'Content'
      when /contest/i then 'Contest'
      when /privacy/i then 'Privacy'
      when /terms/i then 'Terms'
      when /restaurants/i then 'Restaurants'
      when /wineries/i then 'Wineries'
      when /writers/i then 'Writers'
      when /about/i then 'About'
      when /contact/i then 'Contact'
      when /social/i then 'Social'
      else page_title(page)
      end
    end
  end
end
