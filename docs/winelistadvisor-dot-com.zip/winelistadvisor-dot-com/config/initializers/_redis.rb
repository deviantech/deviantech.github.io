# frozen_string_literal: true

$redis = Redis::Namespace.new("wla", redis: Redis.new(url: App.config[:redis][:url], driver: :hiredis))
