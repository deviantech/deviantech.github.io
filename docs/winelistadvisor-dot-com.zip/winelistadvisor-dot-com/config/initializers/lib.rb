# frozen_string_literal: true

# Manually require files in lib/
require 'mailer_helper'
require 'now_serving_location'
