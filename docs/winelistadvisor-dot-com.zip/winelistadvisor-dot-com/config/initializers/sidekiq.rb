# frozen_string_literal: true

# TODO:ARCHIVED

# Sidekiq.default_worker_options = { queue: "wla_#{App.env}_default" }

# require "sidekiq/throttled"
# Sidekiq::Throttled.setup!
