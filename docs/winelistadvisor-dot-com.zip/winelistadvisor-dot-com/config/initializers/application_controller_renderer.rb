# frozen_string_literal: true

# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: App.domain,
#     https: false
#   )
# end



opts = { host: App.domain }
Rails.application.config.action_mailer.default_url_options = opts
Rails.application.routes.default_url_options = opts


# Rails.application.config.after_initialize {
#   ApplicationController.renderer.defaults = opts
# }
# Can't init doing initialization. Doing in Rails.application.config.after_initialize {} block finds issue with missing user_path class -- from the routing aliases in RouteAliases?
# ApplicationController.renderer.defaults = opts
