# frozen_string_literal: true

module App
  class << self

    # When edit this, also update the static HTML pages (and then upload to S3)
    def s3_asset_link(src)
      "https://s3-us-west-2.amazonaws.com/s3.winelistadvisor.com/#{src}"
    end

    def env
      if staging?
        'staging'
      elsif production?
        'production'
      else Rails.env
      end
    end

    def production?
      Rails.env.production? && ENV.fetch('HEROKU_PIPELINE_STAGE') { nil } == 'production'
    end

    def staging?
      Rails.env.production? && ENV.fetch('HEROKU_PIPELINE_STAGE') { nil } == 'staging'
    end

    def domain
      if Rails.env.production?
        staging? ? 'staging.winelistadvisor.com' : 'winelistadvisor.com'
      else
        'localhost:3000' || 'wladev.localtunnel.me'
      end
    end

    def fb_api_version
      'v2.11'
    end

    def admin_email
      'info@winelistadvisor.com'
    end

    def interal_admin_email
      'leigh@deviantech.com'
    end

    def internal_developer_email
      'kali@deviantech.com'
    end

    def ca_only?
      true # Limits onboarding and yelp restaurant searching to CA - turn off when expand to other states
    end

    def sync_with_mailchimp?
      !Rails.env.test?
    end

    def social_handles
      {
        facebook: 'winelistadvisor',
        twitter: 'winelistadvisor'
      }
    end

    def social
      {
        facebook: "https://www.facebook.com/#{social_handles[:facebook]}/",
        twitter: "https://twitter.com/#{social_handles[:twitter]}",
        google: 'https://plus.google.com/u/0/105556027065010703748',
      }
    end

    def mailchimp
      onboard_id = production? ? '1a25ee7344' : '8f70a9d304'
      newsletter_id = production? ? 2175 : 3423

      return {
        action: "https://winelistadvisor.us17.list-manage.com/subscribe/post?u=d7810498e58d9de217fbd1134&amp;id=#{onboard_id}",
        newsletter_id: newsletter_id,
      }
    end

    def config
      {
        redis: { url: ENV["REDIS_URL"] || ENV["REDISGREEN_URL"] }
      }
    end

  end
end
