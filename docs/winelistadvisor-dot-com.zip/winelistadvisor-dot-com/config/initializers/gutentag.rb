# frozen_string_literal: true

def makeGutentagModeratable
  Gutentag::Tag.include Flaggable
  Gutentag::Tag.extend FriendlyId
  Gutentag::Tag.friendly_id :name, use: [:slugged]

  Gutentag::Tag.send(:define_method, :label) do
    "Tag ##{id}: #{name}"
  end

  Gutentag::ActiveRecord::InstanceMethods.instance_eval do
    # Overriding gutentag to allow assigning string split by , directly in controller
    def tag_names=(names)
      @tag_names = names.is_a?(String) ? names.split(',') : names
    end
  end
end

Rails.application.config.after_initialize do
  makeGutentagModeratable
end

# Attempt to make it rerun when rails updates code in dev mode. Unsure if functional, but haven't run into the previous errors since adding.
Rails.application.config.to_prepare do
  makeGutentagModeratable
end
