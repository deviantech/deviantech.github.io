# frozen_string_literal: true

if Rails.env.production? && App.production?
  Winelist::Application.config.action_mailer.delivery_method = :smtp
  Winelist::Application.config.action_mailer.smtp_settings = {
    address: "email-smtp.us-west-2.amazonaws.com",
    port: 587,
    user_name: ENV["AWS_SES_USER"],
    password: ENV["AWS_SES_PASS"],
    authentication: :login,
    enable_starttls_auto: true
  }

elsif App.staging?
  Winelist::Application.config.action_mailer.perform_deliveries = false
  Winelist::Application.config.action_mailer.raise_delivery_errors = false

elsif Rails.env.test?
  Winelist::Application.config.action_mailer.perform_deliveries = true
  Winelist::Application.config.action_mailer.delivery_method = :test

else
  Winelist::Application.config.action_mailer.perform_deliveries = false
  Winelist::Application.config.action_mailer.raise_delivery_errors = false
end
