# frozen_string_literal: true

CarrierWave.configure do |config|
  config.fog_provider = 'fog/aws'
  config.fog_credentials = {
    provider:              'AWS',
    aws_access_key_id:     ENV.fetch('AWS_KEY'),
    aws_secret_access_key: ENV.fetch('AWS_SECRET'),
    region:                'us-west-2',
  }
  config.fog_directory  = "wla-#{App.env}"
  config.fog_attributes = { 'Cache-Control' => "max-age=#{365.day.to_i}" }
end

if Rails.env.test?
  CarrierWave.configure do |config|
    config.storage = :file
    config.enable_processing = false
  end
end
