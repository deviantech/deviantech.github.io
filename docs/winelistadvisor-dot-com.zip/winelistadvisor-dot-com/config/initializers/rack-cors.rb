# frozen_string_literal: true

if defined? Rack::Cors
  allowed_origins = %w(http https).flat_map do |schema|
    [nil, 'www', 'assets'].flat_map do |possible_subdomain|
      "#{schema}://#{[possible_subdomain, App.domain].compact.join('.')}"
    end
  end

  Rails.configuration.middleware.insert_before 0, Rack::Cors do
    allow do
      origins allowed_origins
      resource '/assets/*'
    end

    allow do
      origins allowed_origins
      resource '/packs/*'
    end
  end
end
