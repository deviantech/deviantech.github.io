# frozen_string_literal: true

# require 'sidekiq/web' # TODO:ARCHIVED

Rails.application.routes.draw do
  get '/robots.txt' => 'visitors#robots'
  get '/sitemap.xml.gz' => 'visitors#sitemap'

  match '/deployed' => 'visitors#deploy_hook', via: [:get, :post]

  unless Rails.env.test?
    # Redirect www to non-www
    constraints(host: /^www\./i) do
      match '(*any)' => redirect { |params, request|
        URI.parse(request.url).tap { |uri| uri.host.sub!(/^www\./i, '') }.to_s
      }, via: [:get, :post, :patch]
    end
  end

  mount ActionCable.server => '/cable'

  # TODO:ARCHIVED
  # authenticate :user, lambda { |u| u.admin? } do
  #   mount Sidekiq::Web => '/sidekiq'
  # end


  resources :attachments, only: [:create, :destroy], controller: :user_images

  namespace :admin do
    root to: "dashboard#index"
    resource :dashboard, only: [:index]
    resources :categories
    resources :users, except: [:new, :create]
    resources :faqs
    resources :comments, except: [:new, :create]
    resources :review_tags


    resources :articles, except: [:new, :create] do
      member do
        patch '/publish',   action: 'publish'
        match '/reject',    action: 'reject', via: [:get, :patch]
      end
      collection do
        get '/pending',     action: :index, scope: 'pending_review'
        get '/processed',   action: :index, scope: 'published'
      end
    end

    resources :restaurants, except: [:new, :create] do
      member do
        patch '/approve',     action: 'approve'
        patch '/reject',      action: 'reject'
        post "/wla_select",   action: :make_wla_select
        delete "/wla_select", action: :remove_wla_select
      end
      collection do
        get '/pending',     action: :index, scope: 'pending_review'
        get '/processed',   action: :index, scope: 'claimed'
      end
    end

    resources :wine_programs, except: [:new, :create, :edit, :update] do
      member do
        patch '/accept',      action: 'accept'
        match '/reject',      action: 'reject', via: [:get, :patch]
      end
      collection do
        get '/pending',     action: :index, scope: 'pending'
        get '/accepted',    action: :index, scope: 'accepted'
      end
    end


    resources :engagement_redemptions, only: [:index, :show] do
      member do
        get   '/mark_paid', action: 'mark_paid'
        patch '/mark_paid', action: 'create_payment'
      end
      collection do
        get '/pending',     action: :index, scope: 'pending'
        get '/processed',   action: :index, scope: 'paid'
      end
    end

    resources :engagement_configs, except: [:new, :create, :destroy], constraints: { id: /.*/ }
    resources :engagement_reward_levels

    namespace :contests do

      concern :contestable do
        member do
          patch '/winner', action: :select_winner
        end
        collection do
          get '/open',        action: :index, scope: 'open'
          get '/pending',     action: :index, scope: 'pending'
          get '/completed',   action: :index, scope: 'completed'
        end
      end

      resources :articles, only: [:index, :show] do
        concerns :contestable
      end

      resources :wine_programs, only: [:index, :show] do
        concerns :contestable
      end
    end
  end

  concern :flaggable do
    member do
      patch '/moderator_hide', action: :moderator_hide
      patch '/moderator_show', action: :moderator_show
      patch '/dismiss_flags', action: :moderator_dismiss_flags
    end
    collection do
      get '/pending', action: :index, scope: 'moderator_pending'
      get '/hidden',  action: :index, scope: 'moderator_hidden'
    end
  end

  namespace :moderation do
    root to: "dashboard#index"
    resource :dashboard, only: [:index]

    resources :flaggings, only: [:index, :show] do
      member do
        patch '/confirm', action: :confirm
        patch '/dismiss', action: :dismiss
      end
    end

    resources :reviews, only: [:index, :show] do
      concerns :flaggable
    end
    resources :tags, only: [:index, :show] do
      concerns :flaggable
    end
    resources :comments, only: [:index, :show] do
      concerns :flaggable
    end
    resources :activities, only: [:index, :show] do
      concerns :flaggable
    end
    resources :articles, only: [:index, :show] do
      concerns :flaggable
    end
  end

  root to: 'visitors#landing'

  devise_for :users, controllers: {
    registrations: 'users/registrations',
    omniauth_callbacks: 'users/omniauth_callbacks',
    passwords: 'users/passwords',
    confirmations: 'users/confirmations',
  }

  # Custom devise middleman to set return_to url, added to registrations to avoid copy/pasting the devise sessions controller
  devise_scope :user do
    get "/sign_in_with_redirection", to: 'users/registrations#sign_in_with_redirection'
    get '/auth/callback/:provider', to: 'users/omniauth_callbacks#callback'
  end

  # Alias for better naming
  get '/users/edit', to: 'users/registrations#edit', as: :edit_user_settings

  get "/categories/:category", to: 'articles#by_category', as: :articles_by
  get '/magazine', to: 'articles#index', as: :magazine

  resources :articles do
    member do
      patch '/submit', action: 'submit'
      get '/preview', action: 'preview'
    end
    resources :comments, except: [:show, :index]
  end

  resources :users, only: [:index, :show, :edit, :update], path: :members do
    member do
      get '/profile',       action: 'profile',  as: :profile
      get '/activity',      action: 'activity', as: :activity
      post '/activity',     action: 'add_post'
      get '/points',        action: 'points'
      get '/wine_programs', action: 'wine_programs'
      get '/restaurants',   action: 'restaurants'
      get '/restaurants/claimed', action: 'claimed_restaurants'

      get '/articles',      action: 'articles'
      get '/articles/all',  action: 'articles', unpublished: true

      post    '/friendship', controller: 'friendship', action: 'create'
      patch   '/friendship', controller: 'friendship', action: 'confirm'
      delete  '/friendship', controller: 'friendship', action: 'decline'
      delete  '/friendship/remove', controller: 'friendship', action: 'remove', as: :remove_friendship
      get '/tasting-preferences' => 'tasting_preferences#show', as: :tasting_profile
    end

    resources :wall_posts, only: [:create, :edit, :update]
    resource :tasting_preference, only: [:edit, :update]


    resource :friends, only: [] do
      get '/', to: 'users/friends#index'
      get '/pending', to: 'users/friends#pending'
      get '/invited', to: 'users/friends#invited'
    end

    resources :conversations, only: [:index]

    # resources :articles, only: [:index] do
    #   collection do
    #     get '/all', action: 'index', unpublished: true
    #   end
    # end

    resources :redemptions, only: [:index, :show], controller: 'engagement_redemptions'
    resources :notifications, only: :index
    resources :identities, only: [:destroy] do
      member do
        patch '/update_setting', action: :update_single_setting, as: :update_single_setting
        patch '/update_all_settings', action: :update_all_settings, as: :update_all_settings
      end
    end
    resources :activities, only: [:show]
  end
  post '/notifications/:id/read', to: 'notifications#read'

  concern :reviewable do |opts|
    resources :bookmarks, only: [:new, :create],  defaults: { bookmarkable_type: opts[:reviewable_type] }
    resources :reviews,   only: [:create, :show],  defaults: { reviewable_type: opts[:reviewable_type] }
    member do
      get "/review", to: 'reviews#new', reviewable_type: opts[:reviewable_type]
    end
  end

  resources :restaurants do
    member do
      match "/claim", action: :claim, via: [:get, :post, :patch]
      get "/menus", action: :menus
      get "/menus/:menu_id", action: :menu, as: :menu
      get "/detail/:detail", action: :view_detail, as: :view_detail
      get "/pdf_menus" => 'pdf_menus#edit', as: :edit_pdf_menus
      patch "/pdf_menus" => 'pdf_menus#update', as: :update_pdf_menus
    end
    collection do
      get "/nearby", action: :nearby, as: :nearby
    end
    concerns :reviewable, reviewable_type: 'Restaurant'
    resources :content_sections, only: [:index, :create, :edit, :update, :destroy] do
      member do
        patch '/publish', action: :publish
        patch '/unpublish', action: :unpublish
      end
    end
    resources :wine_programs, except: [:destroy, :index, :show]
    resources :pdf_menus, only: [:show, :destroy]
  end

  resources :reviews, only: [:edit, :update, :destroy] do
    resources :flaggings, only: [:new], defaults: { flagged_type: 'Review' }
  end
  resources :tags, only: [] do
    resources :flaggings, only: [:new], defaults: { flagged_type: 'Gutentag::Tag' }
  end
  resources :comments, except: [:show, :index] do
    resources :flaggings, only: [:new], defaults: { flagged_type: 'Comment' }
  end
  resources :activities, only: [:destroy] do
    resources :flaggings, only: [:new], defaults: { flagged_type: 'Activity' }
  end
  resources :articles, only: [:destroy] do
    resources :flaggings, only: [:new], defaults: { flagged_type: 'Article' }
  end

  resources :flaggings, except: [:show]
  resources :bookmarks, only: [:destroy, :edit, :update]

  authenticated do
    resources :conversations, only: [:new, :show, :create] do
      resources :messages, only: [:create]
      member do
        get '/add', as: :add_users, action: 'add_user_form'
        post '/add', action: 'add_users'
        post '/drop', as: :remove_users, action: 'kick_users'
        post '/leave', as: :leave, action: 'leave'
      end
    end
  end

  namespace :contests do
    resources :articles, only: :index
  end
  resources :invitations, only: [:new, :create, :show]

  resources :likes, only: [:create, :destroy]

  get '/likes/on/:thing_type/:thing_id' => 'likes#show_likes', as: :show_likes
  get '/invited/by/:id', controller: :invitations, action: :invited_by, as: :invited_by
  get '/location/:id' => 'visitors#set_location', as: :set_location

  get '/wineries' => 'visitors#coming_soon', as: :wineries_coming_soon
  get '/landing' => 'visitors#landing', as: :landing
  get '/home' => 'users#home', as: :user_home

  # put rather than post to avoid conflicting with the CREATE restful action
  match '/magazine', to: 'articles#index', as: :search_magazine, via: [:get, :put]
  match '/members', to: 'users#index', as: :search_members, via: [:get, :put]
  match '/restaurants', to: 'restaurants#index', as: :search_restaurants, via: [:get, :put]
  get '/restaurants_for_reviewing', to: 'restaurants#for_reviewing', as: :restaurants_for_reviewing
end
