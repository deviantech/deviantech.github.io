# frozen_string_literal: true

require 'rails_helper'

RSpec.describe ExternalRestaurantPhoto, type: :model do

  it "strips prefix when adding URL" do
    expect( ExternalRestaurantPhoto.new(url: 'http://google.com').url ).to eq '//google.com'
  end

end
