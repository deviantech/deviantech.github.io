# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Comment, type: :model do
  let(:user) { create :user }
  let(:article) { create :article, :published }

  it "broadcasts on publish" do
    expect(SocialPublishingService).to receive(:call).with(:added_comment, any_args)
    create :comment, commentable: article, user: user
  end

end
