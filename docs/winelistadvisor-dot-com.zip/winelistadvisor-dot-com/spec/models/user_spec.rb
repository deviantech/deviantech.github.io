# frozen_string_literal: true

require 'rails_helper'

describe User do
  describe "name" do
    it "doesn't allow special characters" do
      user = build(:user)
      user.name = 'Test " Name  '
      expect(user.name).to eq 'Test Name'
    end
  end

  describe "friendship" do
    let(:userA) { create :user }
    let(:userB) { create :user }

    it "allows requesting and accepting" do
      expect(userA.pending_friends).not_to include userB

      expect( userA.friend_request(userB) ).to eq true

      expect(userA.reload.pending_friends).to include userB
      expect(userB.requested_friends).to include userA

      expect(SocialPublishingService).to receive(:call).with(:following, any_args).twice
      userB.accept_request(userA)

      expect(userA.reload.friends).to include userB
      expect(userB.friends).to include userA
    end

    it "sends emails for friendship actions" do
      expect {
        expect( userA.friend_request(userB) ).to eq true
      }.to change(ActionMailer::Base.deliveries, :size).by(1)
    end

  end

  describe 'setting defaults' do
    subject { User.create(email: 'test@place.com', password: 'password', name: 'Testing', tos: 1, age: 1) }

    it { expect(subject.level).to eq EngagementRewardLevel::NEW_USER_BADGE }
    it { expect(subject.notification_settings).not_to eq({}) }
    it { expect(subject.newsletter_preferences).not_to eq({}) }
  end

  describe 'searching' do
    let!(:full) { create :user, name: 'Full Match', email: 'person@place.com' }
    let!(:partial) { create :user, name: 'Partial Match', email: 'person@thing.com' }
    let!(:none) { create :user, name: 'NOPE', email: 'person@verb.com' }

    it 'name full words' do
      results = User.search_for('full match')

      expect(results).to include full
      expect(results).to include partial
      expect(results).not_to include none
    end

    it 'email full words' do
      results = User.search_for('person@place.com')

      expect(results).to include full
    end

    it 'name partial words' do
      results = User.search_for('matc')

      expect(results).to include full
      expect(results).to include partial
      expect(results).not_to include none
    end

    it 'email partial words' do
      results = User.search_for('@place.com')

      expect(results).to include full
      expect(results).not_to include partial
      expect(results).not_to include none
    end
  end

end
