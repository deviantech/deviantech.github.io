# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Bookmark, type: :model do
  describe "visited restaurants" do
    subject { user.tried_restaurants }

    let(:user)    { FactoryBot.create :user }
    let(:visited) { FactoryBot.create :restaurant, name: 'Visted' }
    let(:wanted)  { FactoryBot.create :restaurant, name: 'Wanted' }

    before :each do
      user.bookmarks.create(bookmarkable: visited, state: 'tried')
      expect(SocialPublishingService).to receive(:call).with(:wants_to_visit_restaurant, any_args)
      user.bookmarks.create(bookmarkable: wanted)
    end

    it { is_expected.to eq [visited] }
  end
end
