# frozen_string_literal: true

require 'rails_helper'

RSpec.describe EngagementReward, type: :model do
  let!(:user) { create :user, :with_engagements }
  let!(:prev_points) { user.points }
  let!(:prev_level) { user.level }
  let(:l1_trigger) { 5 }
  let!(:config1) { create :engagement_reward_level, kind: 'badge', points: l1_trigger, level: 'better' }
  let(:engagement) { build :engagement, user: user, points: 10, key: 'test.engagement' }

  describe '#points_to_next_reward' do
    let(:l1_trigger) { user.points + 3 }

    context 'from user' do
      subject { EngagementReward.points_to_next_reward(user) }
      it { is_expected.to eq 3 }
    end

    context 'from points' do
      subject { EngagementReward.points_to_next_reward(user.points) }
      it { is_expected.to eq 3 }
    end
  end

  describe '#sync_new_engagement' do

    context 'no reward needed' do
      let(:l1_trigger) { 50 }
      it "doesn't change user attributes" do
        expect(EngagementReward).not_to receive(:issue_engagement_reward)

        expect { engagement.save }.not_to change { user.engagement_rewards.count }

        expect(user.reload.points).to be > prev_points
        expect(user.level).to eq prev_level
      end
    end

    context 'reward needed' do
      it "updates points and level" do
        expect(EngagementReward).to receive(:issue_engagement_reward).and_call_original

        expect { engagement.save }.to change { user.engagement_rewards.count }.by(1)

        expect(user.reload.points).to eq prev_points + engagement.points
        expect(user.level).to eq 'better'
      end
    end

    context 'multiple rewards needed' do
      let!(:config2) { create :engagement_reward_level, kind: 'badge', points: 7, level: 'best' }
      let!(:config3) { create :engagement_reward_level, kind: 'badge', points: 12, level: 'unattainable' }
      let!(:payout1) { create :engagement_reward_level, kind: 'payout', points: 3, face_value: 25, level: nil }
      let!(:payout2) { create :engagement_reward_level, kind: 'payout', points: 8, face_value: 50, level: nil }

      it "assigns last badge and all payouts" do
        expect(EngagementReward).to receive(:issue_engagement_reward).and_call_original

        expect { engagement.save }.to change { user.engagement_rewards.count }.by(4)

        expect(user.reload.points).to eq prev_points + engagement.points
        expect(user.level).to eq 'best'
      end

      it "creates payouts successfully" do
        expect(AdminMailer).to receive(:engagement_redemption_pending).twice.and_call_original

        expect { engagement.save }.to change { user.notifications.count }.by(4)

        expect(user.reload.engagement_redemptions.pending.count).to eq 2

        p2 = user.engagement_rewards.payout.in_order.last
        expect(p2.config).to eq payout2
        expect(p2.engagement_redemption).not_to eq nil

        # Retains payout when template removed
        payout2.destroy
        expect(p2.reload).to be_valid
      end
    end

  end

  describe 'editing' do
    let(:l1_trigger) { 500 } # Ignore for this test
    let!(:reward_level) { create :engagement_reward_level, kind, points: 10 }
    let!(:reward_config) { create :engagement_config, id: 'test.engagement2', points: 10, repeatable: 'any' }
    let!(:rewarded) { EngagementService.call(user, 'test.engagement2') }
    let(:prev_reward) { rewarded.engagement_reward }

    shared_examples_for "doesn't re-award awarded rewards" do
      it do
        expect(user.reload.engagement_rewards.all).to eq([prev_reward]), "User should retain their awarded rewards"

        expect {
          EngagementService.call(user, 'test.engagement2')
        }.to change { user.reload.points }.by(10)

        expect(user.reload.engagement_rewards.all).to eq([prev_reward]), "User shouldn't be re-issued already awarded rewards"
      end
    end

    context 'payouts' do
      let(:kind) { :payout }

      it { expect(user.reload.engagement_rewards.all).to eq [prev_reward] }

      context 'updated to higher required point level' do
        before { reward_level.update points: 15 }
        it_behaves_like "doesn't re-award awarded rewards"
      end

      context 'updated to lower required point level' do
        before { reward_level.update points: 5 }
        it_behaves_like "doesn't re-award awarded rewards"
      end
    end

    context 'badges' do
      let(:kind) { :badge }

      context 'updated to higher required point level' do
        before { reward_level.update points: 15 }
        it_behaves_like "doesn't re-award awarded rewards"
      end

      context 'updated to lower required point level' do
        before { reward_level.update points: 5 }
        it_behaves_like "doesn't re-award awarded rewards"
      end

      context 'updated with different level name' do
        before { reward_level.update level: 'Even Better' }
        it { expect(user.reload.level).to eq 'Even Better' }
      end
    end
  end

end

__END__
Notes: to be added


 Specs:
    Badges:
      if level name/points changed, update for all existing users [if levels drops, send a 'sorry recalibration' notice. if level increases, send a 'congrats, recalibration' notice]
    Payouts:
      just be sure don't re-issue
  ----- ✄ -----------------------
     payout:
       if edited to be lower: already given, fine. if not, fine.
       if edited to be higher: not given yet, fine... already given, then need to handle to avoid giving again
     badge:
       if edited to be lower:
           already given: revert to prev level? don't activity/notify on getting same reward again
           not given: revert to prev level? don't activity/notify on getting same reward again
       if edited to be higher:
           already given: revert to updated level?
           not already: no change (except "xx points to next" emails may be wrong)
       if editing names: update all


Rewards [removed engagement_Redemption engagement key. replace with a whole reward system...]:
     admin: show warning, xxx ppl will retain their current rewards/levels despite not qualifying under the new rules
     admin: show warning, yyy ppl were given notifications to reach a reward level that's now been changed [reward levels changed notification? [if next is this level, and there's a reminder notification for it] reminder notifications data should track which level/id/key it was...]

