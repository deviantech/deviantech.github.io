# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Review, type: :model do
  let(:moderator) { create :user, :moderator }
  let!(:reviewable) { create :restaurant }
  let!(:review) { create :review, reviewable: reviewable, rating: 2, public_notes: true }

  context 'creating' do
    context 'with some details' do
      let!(:review) { build :review, reviewable: reviewable, rating: 2, recommendations: 'Drink', service_rating: 3 }
      it 'does not send reminders' do
        expect(review).not_to be_details_unfilled
        expect(UserMailer).not_to receive(:incomplete_review_reminder)

        review.save
      end
    end

    context 'without details' do
      let!(:review) { build :review, reviewable: reviewable, rating: 2 }
      it 'sends reminder email' do
        expect(review).to be_details_unfilled
        expect(UserMailer).to receive(:incomplete_review_reminder).and_call_original

        expect {
          review.save
        }.to change {
          UserMailer.deliveries.count
        }.by(1)
      end
    end
  end

  it "should update counter caches" do
    expect(SocialPublishingService).to receive(:call).with(:added_review, any_args)

    create :review, reviewable: reviewable, rating: 4
    reviewable.reload
    expect(reviewable.member_ratings_count).to eq 2
    expect(reviewable.member_rating).to eq 3.0

    reviewable.reviews.where(rating: 4).first.destroy
    reviewable.reload
    expect(reviewable.member_ratings_count).to eq 1
    expect(reviewable.member_rating).to eq 2

    reviewable.reviews.last.update(rating: 5)
    reviewable.reload
    expect(reviewable.member_rating).to eq 5
  end

  context "with sufficient flagging" do
    it "should hide public notes" do
      expect( review.public_notes? ).to be true
      expect( review.show?(:body) ).to be true

      Review.hide_at_n_flags.times do
        create(:flagging, user: create(:user), flagged: review)
      end

      expect( review.reload.show?(:body) ).to be false
    end
  end

  context "when moderator marked moderated" do
    it "should require bang version to persist state machine changes" do
      expect { review.moderator_hide moderator }.to raise_error
    end

    it "should hide public notes" do
      review.moderator_hide! moderator
      expect( review.public_notes? ).to be true
      expect( review.show?(:body) ).to be false
    end
  end

  describe ".moderator_dismiss_flags!" do
    before(:each) do
      Review.hide_at_n_flags.times do
        create(:flagging, user: create(:user), flagged: review)
      end
    end

    it "should do nothing unless called by a moderator" do
      review.moderator_dismiss_flags!(review.user)
      expect(review.flag_count).to eq Review.hide_at_n_flags
    end

    it "should clear all flags" do
      review.moderator_dismiss_flags!(moderator)
      expect(review.reload.flag_count).to eq 0
    end

  end

end
