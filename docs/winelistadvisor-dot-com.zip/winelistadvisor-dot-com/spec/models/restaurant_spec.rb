# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Restaurant, type: :model do
  let(:restaurant)  { create :restaurant }
  let(:user)        { create :user }
  let(:admin)       { build :user, :admin }

  it { expect(WineProgram.all).to be_empty }

  context 'default avatar' do
    let(:restaurant) { build :restaurant }
    let(:avt) { restaurant.avatar }
    it 'handles for main' do
      expect(restaurant.avatar?).to eq false
      expect(avt).to receive(:external_image_url).and_return('URL')
      expect(avt.url).to eq 'URL'
    end

    it 'handles for versions' do
      # Because internally Carrierwave generates a new subclass
      allow_any_instance_of(avt.class).to receive(:external_image_url).and_return('URL')
      expect(avt.url(:s100)).to eq 'URL'
      expect(avt.s200.url).to eq 'URL'
    end
  end

  shared_examples "it handles claim acceptance" do
    let(:program)     { restaurant.submitted_wine_programs.by_user(user).last }

    before(:each) do
      restaurant.submit_claim!(user, claimant_phone: '5554442323')
      program.update_attributes!(discounts: 'MONEYMONEY', contact_name: 'Fred', contact_phone: '5551112222', contact_position: 'Wine Guy', contact_email: 'guy@place.com')
    end

    it "when claim is pending it should create wine program but not attach them" do
      expect(program.user).to eq user
      expect(restaurant.wine_program).not_to eq program
    end
  end

  context "without other submissions" do
    it { expect(restaurant.submitted_wine_programs.count).to eq 0 }
    it_should_behave_like 'it handles claim acceptance'
  end

  context "with pending submissions" do
    let(:other_program) { create :wine_program, restaurant: restaurant }

    before(:each) do
      other_program.submit!
    end

    it { expect(restaurant.submitted_wine_programs.pending.count).to eq 1 }
    it { expect(restaurant.wine_program).to be nil }
    it_should_behave_like 'it handles claim acceptance'
  end

  context "with accepted submissions" do
    let(:other_program) { create :wine_program, restaurant: restaurant }

    before(:each) do
      expect( other_program.submit! ).to be true
      other_program.accept!(admin)
    end

    it { expect(restaurant.submitted_wine_programs.accepted.count).to eq 1 }
    it { expect(restaurant.wine_program).to eq other_program }
    it_should_behave_like 'it handles claim acceptance'
  end

end
