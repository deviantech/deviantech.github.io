# frozen_string_literal: true

require 'rails_helper'
require_relative 'contestable_specs'

RSpec.describe Contests::WineProgram, type: :model do
  it_behaves_like "can run contests", WineProgram
end
