# frozen_string_literal: true

shared_examples "can run contests" do |base_klass|

  let(:entry_klass_kind) { base_klass.name.underscore }
  let(:klass) { "Contests::#{base_klass.name}".constantize }
  let(:instance_factory_name) { "contests_#{base_klass.name.underscore}".to_sym }

  let(:user)        { create :user }
  let(:admin)       { create :user, :admin }
  let(:last_month)  { Date.current.beginning_of_month - 5.days }
  let(:manually_update_contests) { false }

  describe '.ensure_up_to_date!' do
    subject { klass.first }

    before(:each) do
      klass.ensure_up_to_date! unless manually_update_contests
    end

    context "with none saved" do
      it { is_expected.to be_persisted }
      it { is_expected.to be_running }
      it { expect(klass.count).to eq 2 }

      it "creates for the current month" do
        current = klass.first
        expect(current.start_on).to be <= Date.today
        expect(current).to be_running
        expect(current.winner).to be_nil
      end

      context "with entries" do
        let!(:entryA) { create entry_klass_kind, :published, reviewed_by: admin, reviewed_at: last_month }
        let!(:entryB) { create entry_klass_kind, :published, reviewed_by: admin, reviewed_at: last_month }
        let!(:other)  { create entry_klass_kind, created_at: last_month }
        let(:manually_update_contests) { true }

        it "creates for the previous month" do
          klass.ensure_up_to_date!
          prev = klass.last
          expect(prev.start_on).to be < 1.month.ago
          expect(prev).to be_pending
          expect(prev.winner).to be_nil
        end
      end

      context "without entries" do
        it "creates for the previous month" do
          klass.ensure_up_to_date!
          prev = klass.last
          expect(prev.start_on).to be < 1.month.ago
          expect(prev).to be_completed
          expect(prev.winner).to be_nil
        end
      end
    end

    context "with one saved already" do
      it "cannot create a second for same month" do
        second = build instance_factory_name
        expect(second.save).to be false
        expect(second).to be_invalid
      end
    end

  end


  describe "#select_winner!" do
    let(:p)      { klass.last }
    let!(:entryA) { create entry_klass_kind, :published, reviewed_by: admin, reviewed_at: (Date.today.beginning_of_month - 5.days) }
    let!(:entryB) { create entry_klass_kind, :published, reviewed_by: admin, reviewed_at: (Date.today.beginning_of_month - 5.days) }
    let(:expects_social_broadcast) { false }

    context "with entry" do
      before(:each) do
        if expects_social_broadcast
          expect(SocialPublishingService).to receive(:call).with("#{entry_klass_kind}_contest_won".to_sym, any_args)
        end

        klass.ensure_up_to_date!
      end

      context do
        let(:expects_social_broadcast) { entry_klass_kind == 'article' }
        it "should work" do
          expect(p).to be_pending
          expect(p.entries.to_a.sort).to eq [entryA, entryB].sort
          p.select_winner!(admin, entryA)
          expect(p.reload).to be_completed
          expect(p.winner_selected_by).to eq admin
          expect(p.winner).to eq entryA
        end
      end

      context "without admin" do
        it "should not work" do
          expect(p).to be_pending
          p.select_winner!(nil, entryA)
          expect(p).to be_pending
        end
      end

      context "without entry" do
        it "should not work" do
          expect(p).to be_pending
          expect( p.select_winner(admin, nil) ).to be false
          expect(p).to be_pending
          expect(p.errors.full_messages.join).to eq "The selected winner isn't one of the contest's entries"
        end
      end

      it "should send user notification" do
        expect {
          p.select_winner!(admin, entryA)
          expect(p).to be_completed
        }.to change(ActionMailer::Base.deliveries, :size).by(1)
      end
    end

    context "with no entries" do
      let!(:entryA) { nil }
      let!(:entryB) { nil }
      it "should close without notifying anyone" do
        expect {
          klass.ensure_up_to_date!
        }.to change(ActionMailer::Base.deliveries, :size).by(0)
        expect(p.entries.count).to eq 0
        expect(p).to be_completed
      end
    end

    context "with one entry" do
      let!(:entryB) { nil }
      it "should automatically select the winner" do
        expect {
          klass.ensure_up_to_date!
        }.to change(ActionMailer::Base.deliveries, :size).by(1)
        expect(p.entries.count).to eq 1
        expect(p).to be_completed
        expect(p.winner).to eq entryA
      end
    end
  end

  describe "entries" do
    let(:dec1)          { Date.new(2017, 12, 1) }
    let(:contest_range) { klass.send :contest_range, dec1 }
    let(:range_start)   { contest_range[:start_on] }
    let(:range_finish)  { contest_range[:finish_on] }
    let!(:contest)       { create instance_factory_name, start_on: range_start, finish_on: range_finish }

    context 'with multiple entries' do
      let!(:yep1) { create entry_klass_kind, :published, reviewed_at: range_start.to_time + 1.hour }
      let!(:yep2) { create entry_klass_kind, :published, reviewed_at: range_finish.to_time }
      let!(:nope1) { create entry_klass_kind, :published, reviewed_at: range_finish + 1.day }

      context 'in zone' do
        [
          ['same day local and UTC', "Thu, 01 Feb 2018 14:00:00 PST -08:00", :same],
          ['same local day but next day in UTC', "Thu, 01 Feb 2018 20:00:00 PST -08:00", :differing],
        ].each do |label, timestamp, key|
          context label do
            let(:acting_zone) { 'Pacific Time (US & Canada)' }
            let(:now) { Time.parse(timestamp) }
            before {
              Timecop.freeze(now)
              @prev_zone = Time.zone
              Time.zone = acting_zone
            }
            after { Timecop.return; Time.zone = @prev_zone }

            context 'UTC' do
              let(:acting_zone) { 'UTC' }
              it { expect(contest.entries.count).to eq 2 }
            end

            context 'other' do
              let(:acting_zone) { 'Pacific Time (US & Canada)' }
              it "counts entries on the end dates" do
                expect(contest.entries.count).to eq 2
              end
            end

          end
        end

        context 'same local day but next day in UTC' do
          let(:now) { Time.parse("Thu, 01 Feb 2018 20:00:00 PST -08:00") }
        end
      end

    end

    it { expect( klass.for(dec1).first ).to eq contest }

    context "different periods" do
      before(:each) do
        expect(klass).to receive(:period_type).and_return(:week)
      end

      it { expect(contest.name).to eq "#{base_klass.name.titleize} Contest: December 1 - December 31, 2017" }
    end
  end

end
