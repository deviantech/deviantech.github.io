# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Conversation::AbstractMessage, type: :model do
  let(:conversation) { create :conversation, :with_users }
  let(:userA) { conversation.users[0] }
  let(:userB) { conversation.users[1] }
  let(:msg) { type.new(conversation: conversation, topic: topic, type: type) }
  let(:type) { nil }
  let(:topic) { 'text' }

  context "message" do
    let(:type) { Conversation::Message }

    it "requires user and body" do
       expect( msg.valid? ).to eq false
       msg.body = 'testing'
       msg.user = userA
       expect( msg.valid? ).to eq true
    end
  end

  context "event" do
    let(:type) { Conversation::Event }
    %w(users_added users_removed).each do |event|
      context event do
        let(:topic) { event }
        it "requires meta" do
          expect( msg.valid? ).to eq false
          msg.meta = {user_ids: userA.id}
          expect( msg.valid? ).to eq true
        end
      end
    end
  end
end
