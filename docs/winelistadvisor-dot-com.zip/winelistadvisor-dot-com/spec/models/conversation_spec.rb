# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Conversation, type: :model do

  let(:user) { create :user }
  let(:friend) { create :user }
  let(:stranger) { create :user }

  before do
    make_friends user, friend
  end

  context "starting" do

    it "doesn't allow creating with external users" do
      conv = Conversation.converse_with(user, ['', stranger.id])

      expect(conv).not_to be_persisted
      expect(conv.errors.full_messages).to eq ['You can only begin conversations with your friends']
    end

    it "allows creating with friend" do
      conv = Conversation.converse_with(user, ['', friend.id.to_s])

      expect(conv).to be_persisted
    end

    it "requires at least two users" do
      conv = Conversation.converse_with(user, [user.id])

      expect(conv).not_to be_persisted
    end

    context "with existing conversation" do
      let!(:conversation) { Conversation.converse_with(user, [friend.id]) }

      it "returns the same conversation" do
        user.reload

        conv = Conversation.converse_with(user, [friend.id])
        expect(conv).to eq conversation
      end
    end

  end

  context "actions with a conversation" do
    let!(:conversation) { Conversation.converse_with(user, [friend.id]) }
    let(:fof) { create :user }

    before do
      make_friends friend, fof
    end

    def expect_event(val, who, topic)
      expect(val).to be_a Conversation::Event

      expect( conversation.all_messages.last ).to eq val
      expect( val.topic ).to eq topic
      expect( val.meta['user_ids'] ).to eq Array(who).map(&:id)
    end

    def expect_removed(val, who)
      expect_event(val, who, 'users_removed')
    end

    def expect_added(val, who)
      expect_event(val, who, 'users_added')
    end

    def expect_left(val, who)
      expect_event(val, who, 'user_left')
    end

    context '.add_message' do
      it "connects properly" do
        msg = conversation.add_message(user, "Testing")
        expect(msg).to be_persisted
      end

      it "doesn't allow messages from external users" do
        val = conversation.add_message(create(:user), "Testing")
        expect(val).to eq false
      end

      it "can't add user multiple times" do
        cp = ConversationParticipation.create(conversation: conversation, user: friend)
        expect(cp).not_to be_persisted
      end
    end

    context ".add_users" do

      it "allows adding friends" do
        val = conversation.add_users(friend, fof)
        expect_added(val, fof)
      end

      it "can only add to your own conversations" do
        conversation.conversation_participations.find_by(user_id: friend.id).destroy
        conversation.reload

        val = conversation.add_users(friend, fof)
        expect(val).to eq false
      end

      it "doesn't allow adding friends of friends" do
        val = conversation.add_users(user, fof)
        expect(val).to eq false
      end

      it "handles adding only some" do
        other_friend = make_friends(user, create(:user))
        val = conversation.add_users(user, [fof, other_friend])
        expect(val).to be_a Conversation::Event
        expect( val.meta['user_ids'] ).to eq [other_friend.id]
      end

      it "handles if adding friends would made conversation have same UIDs as another" do
        pending "need to implement"
      end
    end

    context ".remove_users" do

      before do
        conversation.add_users(friend, fof)
      end

      def expect_removed(val, who)
        expect(val).to be_a Conversation::Event

        expect( conversation.all_messages.last ).to eq val
        expect( val.topic ).to eq  'users_removed'
        expect( val.meta['user_ids'] ).to eq Array(who).map(&:id)
      end

      it "can remove self" do
        val = conversation.remove_users(fof, fof)
        expect_removed(val, fof)
      end

      it "initiator can remove anyone" do
        val = conversation.remove_users(user, fof)
        expect_removed(val, fof)
      end

      it "other user can't remove anyone" do
        val = conversation.add_users(fof, friend)
        expect(val).to eq false
      end

      it "can't remove last two users" do
        pending "need to implement"
      end

      it "handles if removing friends would made conversation have same UIDs as another" do
        pending "need to implement"
      end
    end

    context ".user_left" do

      it "initiator can leave" do
        val = conversation.user_left(user)
        expect_left(val, user)
      end

      it "other user can leave" do
        val = conversation.user_left(friend)
        expect_left(val, friend)
      end

      it "can't leave if not already conversing" do
        val = conversation.user_left(fof)
        expect(val).to eq false
      end

      it "can't leave if one of last two users" do
        pending "need to implement"
      end

      it "handles if leaving would made conversation have same UIDs as another" do
        pending "need to implement"
      end
    end

    context "destroying users" do
      before do
        conversation.add_message(user, "Testing")
      end

      it "retains conversation when user destroyed" do
        user.destroy

        expect(ConversationParticipation.count).to eq 1
        expect(conversation.reload.users).to eq [friend]
        expect(conversation.messages.count).to eq 1
      end
    end
  end
end
