# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Activity, type: :model do
  context "meta" do
    it "has :add for each supported topic" do
      described_class::VALID_TOPICS.each do |topic|
        expect(described_class).to respond_to(topic)
      end
    end

    it "decorator handles headline for each supported topic" do
      expect { build(:activity, topic: 'fake_topic').decorate.headline }.to raise_error(ActivityDecorator::UnknownTopicError)

      described_class::VALID_TOPICS.each do |topic|
        act = Activity.new(topic: topic)
        act = act.decorate

        expect { act.headline }.not_to raise_error(ActivityDecorator::UnknownTopicError)
      end
    end

    it "has partials for topics with custom UI" do
      expect(ActivityDecorator::PARTIAL_TOPICS.sort).to eq %w(comment review wall_post)
    end

  end

  context "methods" do
    let!(:user) { create :user }
    let(:admin) { build :user, :admin }
    let(:friend)   { make_friends(user, create(:user)) }
    let(:fof)      { make_friends(friend, create(:user)) }

    context "social broadcast" do
      before { friend } # Need to create first so we track the right social broadcast

      it "fired for wall posts on own wall" do
        expect(SocialPublishingService).to receive(:call).with(:posted, any_args)
        Activity.add_wall_post(user, user, body: "Test Post on own wall")
      end

      it "not fired for wall posts on others' wall" do
        expect(SocialPublishingService).not_to receive(:call).with(:posted, any_args)
        Activity.add_wall_post(friend, user, body: "Test Post on friend's wall")
      end
    end

    it "removes comments when deleted" do
      act = Activity.add_wall_post(friend, user, body: "Test Post")
      act.comments.create(body: 'test', user: fof)
      expect(Comment.count).to eq 1

      act.destroy
      expect { act.reload }.to raise_error
      expect(Comment.count).to eq 0
    end

    context "feeds" do
      let!(:users)      { [user, friend, fof] }
      let!(:articles)   { users.each_with_object({}) {|u, obj| obj[u] = create :article, :pending_review, user: u } }

      before do
        Activity.delete_all
        articles.values.map {|a| a.publish!(admin) }
        [user, fof].each    {|u| Activity.add_wall_post(friend, u, body: "Testing") }
        [user, friend].each {|u| Activity.add_wall_post(u, u, body: "Self-post") }
      end

      def stream_includes(topic, who, thing = nil)
        expect(
          subject.any? {|a| a.topic == topic && a.user == who && (thing.nil? || a.thing == thing) }
        ).to eq(true), "#{who} missed a #{topic} it was supposed to have"
      end

      def stream_excludes(topic, who, thing = nil)
        expect(
          subject.none? {|a| a.topic == topic && a.user == who && (thing.nil? || a.thing == thing) }
        ).to eq(true), "#{who} had a #{topic} it wasn't supposed to have"
      end

      describe '#home_feed_for' do
        subject { Activity.home_feed_for(user) }

        it "contains activities of friends + wall posts directed at user" do
          stream_includes 'published_article', friend
          stream_excludes 'published_article', fof
          stream_excludes 'published_article', user

          stream_includes 'wall_post', friend, user
          stream_includes 'wall_post', friend, fof
          stream_includes 'wall_post', user, user
          stream_includes 'wall_post', friend, friend
        end
      end

      describe '#activity_feed_for' do
        subject { Activity.activity_feed_for(user) }

        it "contains activities of user + wall posts directed at user" do
          stream_includes 'published_article', user
          stream_excludes 'published_article', friend
          stream_excludes 'published_article', fof

          stream_includes 'wall_post', friend, user
          stream_includes 'wall_post', user, user
          stream_excludes 'wall_post', friend, fof
          stream_excludes 'wall_post', friend, friend
        end

      end
    end

    describe '- adding:' do
      let(:last_month)  { Date.today.beginning_of_month - 5.days }
      let(:other_user) { create :user }

      context "between users" do
        subject { Activity.add_wall_post(user, other_user, {body: "Hello there!"}) }

        it "saves with valid information" do
          is_expected.to be_persisted
          expect(subject.body).to eq 'Hello there!'
        end
      end

      ensure_tested_all_key_triggers(Activity::VALID_TOPICS) do
        # note only creates one activity, so e.g. comments are consolidated
        triggers('friendship') { make_friends(other_user, user) }

        context 'restaurant -' do
          let(:r) { create(:restaurant, :claim_pending, claimed_by: user) }

          triggers('review') { user.reviews.create(reviewable: r) }
          triggers('claimed_restaurant') { r.approve(admin) }

          context 'owned -' do
            let(:r) { create(:restaurant, :claim_accepted, claimed_by: user) }
            let(:p) { create(:wine_program, :by_owner, restaurant: r, user: user) }
            triggers('updated_restaurant_profile') { p.update_attributes corkage_fee: 'Millions' }
          end
        end

        context 'article' do
          let(:article) { create :article, :pending_review, user: user }
          triggers('published_article') { article.publish!(admin) }
        end

        triggers('article_contest_winner') do
          create(:article, :published, user: user, reviewed_at: last_month)
          Contests::Article.ensure_up_to_date!
        end

        triggers('wine_program_contest_winner') do
          r = create(:wine_program, :published, user: user, reviewed_at: last_month)
          Contests::WineProgram.ensure_up_to_date!
          expect(Activity.by_key('wine_program_contest_winner').first.data).to eq({'restaurant_id' => r.restaurant_id})
        end

        context 'tasting_profile' do
          let(:partial) { {seeking: 1} }
          let(:full) { build(:tasting_profile, :completed).attributes }

          triggers('completed_tasting_profile') { user.update_attributes(tasting_profile_attributes: full) }
          does_not_trigger('completed_tasting_profile') do
            user.update_attributes(tasting_profile_attributes: partial)
            expect(user.tasting_profile.seeking).to be_present
          end
        end

        triggers('updated_user_profile') { user.update_attributes(about: 'Updated!') }
        triggers('updated_user_profile', 'and stores attribute changed') do
          old_name = user.name

          user.update_attributes(name: 'NewName')

          expect(Activity.by_key('updated_user_profile').first.data['name']).to eq([old_name, 'NewName'])
        end

        does_not_trigger('updated_user_profile', 'for untracked field') { user.update_attributes(slug: 'Renamed') }
        context "doesn't create if another already created on same day" do
          before { user.update_attributes(about: 'Initial update') }
          does_not_trigger('updated_user_profile') { user.update_attributes(about: 'Secondary update') }
        end

        triggers('comment', 'on article') { create :comment, commentable: create(:article), user: user }
        does_not_trigger('comment', 'on activity') do
          act = Activity.add_wall_post(other_user, user, body: "From other to user")
          create(:comment, commentable: act, user: user)
        end

        triggers('wall_post') { Activity.add_wall_post(other_user, user, body: "From other to user") }
        triggers('wall_post', 'from user to self') { Activity.add_wall_post(user, user, body: "From user to self") }

        context 'rewarding engagement' do
          before do
            create :engagement_reward_level, opts.merge(points: 5)
            create :engagement_config, id: 'good.thing', points: 10, repeatable: 'any'
          end

          context 'badge' do
            let(:opts) { {kind: 'badge', level: 'Awesome'} }
            triggers('engagement_reward') { EngagementService.call user, 'good.thing', user }
          end

          context 'payout' do
            let(:opts) { {kind: 'payout', face_value: 25, level: nil} }
            does_not_trigger('engagement_reward') { EngagementService.call user, 'good.thing', user }
          end
        end
      end

    end
  end
end
