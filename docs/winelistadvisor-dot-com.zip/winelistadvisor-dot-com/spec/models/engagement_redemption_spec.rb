# frozen_string_literal: true

require 'rails_helper'

RSpec.describe EngagementRedemption, type: :model do

  describe "#mark_paid!" do
    let!(:config) { create :engagement_config, id: 'member.joined' }
    let(:r)      { create :engagement_redemption, user: user }
    let!(:user)  { create :user }
    let(:admin)  { build :user, :admin }
    let(:code)   { '123abc' }

    it "should mark paid" do
      expect(r).to be_pending
      expect { r.mark_paid!(admin, code) }.to change { user.reload.notifications.count }.by(1)
      expect(r.reload).to be_paid
      expect(r.marked_paid_by).to eq admin
      expect(r.order_number).to eq code
    end

    context "without admin" do
      let (:admin) { nil }
      it "should not mark paid" do
        expect(r).to be_pending
        r.mark_paid!(admin, code)
        expect(r).to be_pending
      end
    end

    context "without confirmation code" do
      let (:code) { nil }
      it "should not mark paid" do
        expect(r).to be_pending
        r.mark_paid(admin, code)
        expect(r).to be_pending
      end
    end

    it "should send user notification" do
      r # sends an email, define it before the block below
      expect {
        r.mark_paid!(admin, code)
      }.to change(ActionMailer::Base.deliveries, :size).by(1)
    end

    it "should store code but already have amount set" do
      expect(r.order_number).to eq nil
      expect(EngagementRedemption::VALID_REDEMPTION_DOLLAR_VALUES).to include r.face_value

      r.mark_paid!(admin, code)

      expect(r.order_number).not_to eq nil
    end

  end

end
