# frozen_string_literal: true

require 'rails_helper'

RSpec.describe WineProgram, type: :model do
  let(:user)            { build :user }
  let(:admin)           { build :user, :admin }

  describe "user submittable to restaurant" do
    let(:restaurant)   { create :restaurant }
    let(:program)       { create :wine_program, state: 'pending', restaurant: restaurant, user: user }
    let(:claimant)      { create :user, name: 'Restaurant Claimer' }
    let(:other_program)  { submissions.detect {|p| p != program} }
    let(:columns_to_check) { WineProgram.member_submittable_columns }
    let(:non_boolean_columns_to_check) {
      columns_to_check.select { |col|
        (col = WineProgram.columns.detect {|c| c.name == col}) && :boolean != col.type
      }
    }
    let(:submissions)          { restaurant.submitted_wine_programs }
    let(:restaurants_program)  { restaurant.wine_program }

    let(:with_other) { false }
    let!(:other_submission) { with_other ? create(:wine_program, state: 'pending', restaurant: restaurant, user: create(:user)) : nil }


    context "submitted by a normal member" do

      it "becomes one of the submitted ones" do
        expect( submissions ).to include program
      end

      it "can be rejected back to draft status" do
        program.reject!(admin)
        expect(program.reload).to be_draft
        expect(restaurants_program).to be_nil
      end

      it "can be accepted" do
        program.accept!(admin)
        expect(program.reload).to be_accepted
        expect(restaurants_program).to eq program
      end

      context "when user has already submitted one" do

        it "does not allow submission" do
          program
          second = build(:wine_program, state: 'pending', restaurant: restaurant, user: user)
          expect(second.save).to be false
        end

      end

      context "with one already accepted" do
        before(:each) do
          restaurant.update_attribute :wine_program, create(:wine_program, state: 'accepted', restaurant: restaurant)
        end

        it "cannot be accepted" do
          expect( program.accept!(admin) ).to eq false
          expect(program.reload).to be_pending
          expect(restaurants_program).not_to be_nil
          expect(restaurants_program).not_to eq program
        end

        it "returns info about which guard failed" do
          expect( program.accept!(admin) ).to eq false
          expect( program ).not_to be_valid
          expect(program.errors.full_messages.join).to include "restaurant already has an accepted"
        end

      end
    end


    context "with failures" do

      before(:each) do
        program.accept!(admin)
      end

      it "should roll back claim if user associations fail" do
        expect(WineProgram).to receive(:create_copy_for).and_raise("Pretending we were unable to save in create_copy_for")
        expect { restaurant.submit_claim!(claimant, claimant_phone: '5554441234') }.to raise_exception
        expect(restaurant).to be_unclaimed
      end

      it "should roll back claim acceptance if user associations fail" do
        restaurant.submit_claim!(claimant, claimant_phone: '5554441234')
        expect_any_instance_of(WineProgram).to receive(:mark_as_owners!).and_raise("Pretending we failed to mark as owner's")
        expect { restaurant.approve!(admin) }.to raise_exception
        expect(restaurant).to be_pending_review
      end

    end


    context "with accepted version" do

      before(:each) do
        program.update_attribute :highlights, "Checking to see if copied"
        program.accept!(admin)
        restaurant.submit_claim!(claimant, claimant_phone: '5554441234')
      end

      context "when restaurant ownership claim is submitted" do

        it "copies accepted version for new owner" do
          expect(restaurants_program).to eq program
          expect(submissions.count).to eq 2

          expect(other_program.user).to eq claimant
          columns_to_check.each do |attrib|
            expect(other_program.send(attrib)).to eq program.send(attrib)
          end

          # To allow giving credit down the line
          expect(other_program.based_on).to eq (program)
        end

      end

      context "when restaurant ownership is approved" do
        before(:each) do
          expect(restaurant.wine_program).to eq program
          restaurant.approve!(admin)
          expect(restaurant.wine_program).not_to eq program
        end

        it "switches to the owners program" do
          expect(restaurants_program).to eq other_program
          expect(program.state).to eq 'accepted'
          expect(other_program.state).to eq 'owners'
        end

        it "no longer shows the others as pending" do
          expect(restaurant.submitted_wine_programs.pending.count).to eq 0
          expect(restaurant.submitted_wine_programs.obsoleted.count).to eq 1
          expect(restaurant.submitted_wine_programs.owners.count).to eq 1
        end
      end


      context "by the claimant" do
        let(:claimant) { program.user }

        it "doesn't bother making new copy" do
          expect(restaurants_program).to eq program
          expect(submissions.count).to eq 1
        end

        context "when restaurant ownership is approved" do
          before(:each) do
            restaurant.approve!(admin)
          end

          it "switches status to indicate ownership" do
            expect(program.reload.state).to eq 'owners'
          end

          it "no longer shows the others as pending" do
            expect(submissions.pending.count).to eq 0
          end
        end

      end
    end



    context "with pending version" do
      let(:with_other) { true }
      let(:from_submission) { submissions.pending_ownership_claim.first }

      before(:each) do
        program # instantiate it before doing the rest

        expect(submissions.count).to eq 2
        program.update_attribute :highlights, "Checking to see if copied"
        restaurant.submit_claim!(claimant, claimant_phone: '5554441234')
      end

      it "does not copy any versions - new owner starts with blank" do
        expect(restaurants_program).to be nil
        expect(submissions.pending.count).to eq 2
        expect(from_submission).not_to eq program
        expect(other_program.based_on).to be nil
        expect(from_submission.user).to eq claimant
        expect(from_submission.highlights).not_to eq program.highlights
      end

      it "still shows the others as pending" do
        expect(submissions.pending_ownership_claim.count).to eq 1
        expect(submissions.pending.count).to eq 2
      end
    end

    describe "accepting" do
      context "when accepted" do

        before(:each) do
          program.accept!(admin)
        end

        context "with others pending" do
          let(:with_other) { true }

          it "marks the others passed over" do
            expect(program.restaurant.submitted_wine_programs.pending.count).to eq 0
            expect(program.restaurant.submitted_wine_programs.passed_over.count).to eq 1
            expect(program.restaurant.submitted_wine_programs.accepted.count).to eq 1
          end

        end
      end
    end

  end


  describe "user submissions" do
    let(:submission) { create :wine_program, state: 'draft', restaurant: restaurant }

    context "when restaurant is unclaimed" do
      let(:restaurant) { create :restaurant }

      it "wine program can be submitted" do
        expect(submission.submit).to be true
      end

      it "wine program can be accepted" do
        expect(submission.submit).to be true
        expect(submission.accept(admin)).to be true
      end
    end

    context "when restaurant claim is pending" do
      let(:restaurant) { create :restaurant, :claim_pending }

      it "wine program can be submitted" do
        expect(submission.submit).to be true
      end

      it "submitted wine program cannot be accepted" do
        expect(submission.submit).to be true
        expect(submission.accept(admin)).to be false
      end
    end

    context "when restaurant claim is accepted" do
      let(:restaurant) { create :restaurant, :claim_accepted }

      it "wine program cannot be submitted" do
        expect(submission.submit).to be false
      end

      it "wine program cannot be accepted" do
        submission.update_attribute :state, :pending
        allow(submission).to receive(:current_state).and_return(:pending)
        expect(submission).to be_pending # Make it pretend to have been submitted somehow

        expect(submission.accept(admin)).to be false
      end
    end
  end

end

