# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Flagging, type: :model do
  let(:admin)     { create :user, :admin }
  let(:user)      { create :user }
  let(:flaggable) { create(:review, reviewable: create(:restaurant)) }

  it "only flags once per user/flaggable combo" do
    create(:flagging, user: user, flagged: flaggable )
    second = build(:flagging, user: user, flagged: flaggable )
    expect(second.save).to be false

    second = build(:flagging, user: create(:user), flagged: flaggable )
    expect(second.save).to be true

    Flagging.first.update_attribute(:flagged_type, 'Article')
    second = build(:flagging, user: user, flagged: flaggable )
    expect(second.save).to be true
  end

  context "admin review" do
    let!(:flagging) { create(:flagging, user: user, flagged: flaggable ) }

    it "should be dismissable" do
      expect(flagging).to be_pending
      flagging.dismiss!(admin)
      expect(flagging).to be_dismissed
      expect(flagging.reviewed_by).to eq admin
      expect(flagging.reviewed_at).to be_present
    end

    it "doesn't allow user to transition" do
      flagging.confirm!(user)
      expect(flagging).to be_pending
    end
  end

  context "counter cache resets when admin marks cleared" do
    let!(:flagging) { create(:flagging, user: user, flagged: flaggable ) }

    it "counter caches" do
      expect(flaggable.flag_count).to eq 1
    end

    it "doesn't count dismissed" do
      second = nil
      expect {
        second = create(:flagging, user: create(:user), flagged: flaggable )
        }.to change { flaggable.responsible_user.notifications.count }.by (1)
      expect(flaggable.flag_count).to eq 2

      flagging.dismiss!(admin)
      second.confirm!(admin)
      expect(flaggable.flag_count).to eq 1

      third = create(:flagging, user: create(:user), flagged: flaggable )
      expect(flaggable.flag_count).to eq 2

      second.destroy
      expect(flaggable.flag_count).to eq 1

      third.user.destroy
      expect(flaggable.reload.flag_count).to eq 0
    end
  end

  context "moderation" do
    subject { flaggable }
    it { is_expected.to be_visible }

    it "hiding and showing" do
      expect {
        flaggable.moderator_hide!(admin)
      }.to change { flaggable.responsible_user.notifications.count }.by(1)
      flaggable.reload

      expect(flaggable).not_to be_visible
      expect(flaggable).to be_moderator_hidden
      expect(flaggable.moderator_hidden_at).not_to eq nil

      expect {
        flaggable.moderator_show!(admin)
      }.to change { flaggable.responsible_user.notifications.count }.by(1)
      flaggable.reload

      expect(flaggable).to be_visible
      expect(flaggable.moderator_hidden_at).to eq nil
    end
  end

end
