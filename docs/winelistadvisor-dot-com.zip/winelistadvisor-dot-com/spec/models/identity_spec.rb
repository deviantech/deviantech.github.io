# frozen_string_literal: true

require 'rails_helper'

include OmniauthMacros

RSpec.describe Identity, type: :model do
  let(:user) { create :user }
  let(:data) { mocked_auth_hash }

  describe '.label' do # TODO: update to test against the actual returned values from each network
    Identity::SUPPORTED_NETWORKS.each do |network|
      context network do
        subject { build(:identity, provider: network).label }
        it { is_expected.to be_present }
      end
    end
  end

  describe '#build_from_omniauth', :vcr do
    subject { Identity.build_from_omniauth(data, user) }

    context "with logged in user" do

      it "builds for the user" do
        is_expected.to be_valid
        expect( subject.user ).to eq user
        is_expected.to be_valid
      end

    end

    context "without logged in user" do
      let(:user) { nil }

      context "with new remote email provided" do
        it "builds and builds the user" do
          is_expected.to be_valid
          expect(subject.user).to be_valid
          expect(subject.save).to eq true
          expect(subject.user.reload).to be_persisted
        end
      end

      context "with existing remote email provided" do
        let(:other_user) { create :user }
        let(:data) { mocked_auth_hash.tap {|h| h.info.email = other_user.email }}
        it "builds and connects existing" do
          is_expected.to be_valid
          expect(subject.user).to be_valid
          expect(subject.save).to eq true
          expect(subject.user.reload).to eq other_user
        end
      end

      context "without remote email provided" do
        let(:data) { mocked_auth_hash.tap {|h| h.info.email = nil }}

        it "builds and builds the user" do
          is_expected.to be_valid
          expect(subject.user).not_to be_valid
        end
      end
    end
  end

  describe "#destroy" do

    context "with other identities" do
    end

    context "as last identity" do
    end

    context "as last identity without password set" do
    end

  end

end
