# frozen_string_literal: true

require 'rails_helper'

RSpec.describe EngagementConfig, type: :model do
  let(:repeatable) { 'thing' }
  let(:max_per_month) { nil }
  let(:user_action) { false }
  let!(:config) { create(:engagement_config, id: 'restaurant.reviewed', repeatable: repeatable, max_per_month: max_per_month, user_action: user_action, points: 1, first_bonus: 10 ) }

  let(:user) { create :user }
  let(:r) { create :restaurant }

  context "user_action" do
    describe "true" do
      let(:user_action) { true }
      it do
        expect(EngagementBroadcastJob).not_to receive(:perform_later)
        create(:review, reviewable: r, user: user)
      end
    end

    describe "false" do
      let(:user_action) { false }
      it do
        expect(EngagementBroadcastJob).to receive(:perform_later)
        create(:review, reviewable: r, user: user)
      end
    end
  end

  context "max_per_month" do
    let(:repeatable) { 'any' }

    describe 'unlimited' do
      let(:max_per_month) { nil }
      it do
        expect { create(:review, reviewable: r, user: user) }.to change { Engagement.count }.by 1
        expect { create(:review, reviewable: r, user: user) }.to change { Engagement.count }.by 1
        Engagement.update_all created_at: 1.year.ago
        expect { create(:review, reviewable: r, user: user) }.to change { Engagement.count }.by 1
      end
    end

    describe 'limited' do
      let(:max_per_month) { 1 }
      it do
        expect { create(:review, reviewable: r, user: user) }.to change { Engagement.count }.by 1
        expect { create(:review, reviewable: r, user: user) }.to change { Engagement.count }.by 0
        Engagement.update_all created_at: 1.year.ago
        expect { create(:review, reviewable: r, user: user) }.to change { Engagement.count }.by 1
      end

      describe 'thing repeatable' do
        let(:max_per_month) { 2 }
        let(:repeatable) { 'thing' }
        it do
          expect { create(:review, reviewable: r, user: user) }.to change { Engagement.count }.by 1
          expect { create(:review, reviewable: r, user: user) }.to change { Engagement.count }.by 0
          expect { create(:review, reviewable: create(:restaurant), user: user) }.to change { Engagement.count }.by 1
          expect { create(:review, reviewable: create(:restaurant), user: user) }.to change { Engagement.count }.by 0
          Engagement.update_all created_at: 1.year.ago
          expect { create(:review, reviewable: r, user: user) }.to change { Engagement.count }.by 0
          expect { create(:review, reviewable: create(:restaurant), user: user) }.to change { Engagement.count }.by 1
          expect { create(:review, reviewable: create(:restaurant), user: user) }.to change { Engagement.count }.by 1
          expect { create(:review, reviewable: create(:restaurant), user: user) }.to change { Engagement.count }.by 0
        end
      end
    end
  end

  context "first_bonus" do

    it "first_bonus applies "do
      r1 = create :review, reviewable: create(:restaurant), user: user
      e1 = Engagement.last
      r2 = create :review, reviewable: create(:restaurant), user: user
      e2 = Engagement.last

      expect(e1.points).to eq 11
      expect(e2.points).to eq 1
    end

  end

  context "repeatable:" do
    describe "none" do
      let(:repeatable) { 'none' }
      it do
        expect { create(:review, reviewable: create(:restaurant), user: user) }.to change { Engagement.count }.by 1
        expect { create(:review, reviewable: create(:restaurant), user: user) }.to change { Engagement.count }.by 0
      end
    end

    describe "any" do
      let(:repeatable) { 'any' }
      it do
        r1 = create :restaurant
        r2 = create :restaurant
        expect { create(:review, reviewable: r1, user: user) }.to change { Engagement.count }.by 1
        expect { create(:review, reviewable: r1, user: user) }.to change { Engagement.count }.by 1
        expect { create(:review, reviewable: r2, user: user) }.to change { Engagement.count }.by 1
      end
    end

    describe "thing" do
      let(:repeatable) { 'thing' }
      it do
        r1 = create :restaurant
        r2 = create :restaurant
        expect { create(:review, reviewable: r1, user: user) }.to change { Engagement.count }.by 1
        expect { create(:review, reviewable: r1, user: user) }.to change { Engagement.count }.by 0
        expect { create(:review, reviewable: r2, user: user) }.to change { Engagement.count }.by 1
      end
    end
  end

end
