# frozen_string_literal: true

require 'rails_helper'

RSpec.describe EngagementRewardLevel, type: :model do
  context 'with levels' do
    let!(:l10) { create :engagement_reward_level, points: 10, level: 'first' }
    let!(:l20) { create :engagement_reward_level, points: 20, level: 'second' }

    describe '#possible_rewards' do
      it {
        expect( EngagementRewardLevel.possible_rewards(9,21).pluck(:id) ).to eq [l10.id,l20.id]
        expect( EngagementRewardLevel.possible_rewards(10,21).pluck(:id) ).to eq [l20.id]
        expect( EngagementRewardLevel.possible_rewards(10,20).pluck(:id) ).to eq [l20.id]
        expect( EngagementRewardLevel.possible_rewards(10,10).pluck(:id) ).to eq []
      }
    end

    describe '#next_for_points' do
      it {
        lvl = described_class.next_for_points(8)
        expect(lvl).to eq l10
        expect(lvl.points_away).to eq 2
      }

      it {
        lvl = described_class.next_for_points(13)
        expect(lvl).to eq l20
        expect(lvl.points_away).to eq 7
      }

      it {
        lvl = described_class.next_for_points(0)
        expect(lvl).to eq l10
        expect(lvl.points_away).to eq 10
      }

      it {
        lvl = described_class.next_for_points(28)
        expect(lvl).to eq nil
        expect(lvl.points_away).to eq nil
      }
    end
  end

  describe 'label' do
    let(:level) { nil }
    subject { level.label }

    context 'badge' do
      let(:level) { build(:engagement_reward_level, points: 10) }
      it { is_expected.to include 'Badge: Contributor' }
    end

    context 'payout' do
      let(:level) { build :engagement_reward_level, points: 10, kind: :payout, face_value: 25 }
      it { is_expected.to include 'Payout: $25' }
    end
  end
end
