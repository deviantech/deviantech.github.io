# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Invitation, type: :model do

  it "sends email on creation" do # TODO: better way to turn on inline jobs for specific rspec metadata
    adapter = ActiveJob::Base.queue_adapter
    ActiveJob::Base.queue_adapter = :inline
    begin

      invite = create :invitation
      expect( NotificationMailer.deliveries.last.to ).to eq [invite.email]

      from_token = Invitation.find_by_token(invite.token)
      expect(from_token).to eq invite

    ensure
      ActiveJob::Base.queue_adapter = adapter
    end
  end

end
