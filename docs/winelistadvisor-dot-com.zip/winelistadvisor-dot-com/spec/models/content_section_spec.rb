require 'rails_helper'

RSpec.describe ContentSection, type: :model do
  let(:content) { create :content_section }

  context "for normal user" do
    let(:user) { build :user }
    it "does not publish" do
      content.publish!(user)
      expect(content).not_to be_published
    end
  end

  context "for content writer" do
    let(:user) { build :user, :content_writer }
    it "publishes" do
      content.publish!(user)
      expect(content).to be_published
      expect(content.published_at).to be_present
    end

    it "doesn't published without title" do
      content.title = nil
      content.publish!(user)
      expect(content).not_to be_published
    end
  end

end
