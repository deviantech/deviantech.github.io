# frozen_string_literal: true

require 'rails_helper'

describe User, type: :model do
  let(:nsets) { {'email' => {'friend_request:accepted' => '0'}} }
  let(:user) { build :user, notification_settings: nsets }
  let(:channel) { :email }
  let(:key) { 'friend_request:accepted' }

  describe "notify_via? defaults to true unless explicitly opted out" do
    subject { user.notify_via?(channel, key) }

    context "unknown channel" do
      let(:channel) { :pigeon }
      it { is_expected.to eq true }
    end

    context "known channel, unknown key" do
      let(:key) { 'article.commented_on' }
      it { is_expected.to eq true }
    end

    context "known key, known channel" do
      it { is_expected.to eq false }
    end

  end

end

describe Notification, type: :model do
  let(:user_name) { 'UniqueName' }
  let(:user) { create :user, name: user_name }
  let(:admin) { build :user, :admin }
  let(:other_user) { create :user, name: 'The Other' }
  let(:debug) { true }
  let(:article) { create :article, user: user }

  ensure_tested_all_key_triggers(Notification::NOTIFICATIONS.keys, covered_elsewhere: %w(system.points.expired system.points.expiring_soon)) do

    triggers('content.liked', skip_email: true) { create :like, user: create(:user), thing: article }
    context "article" do
      triggers('article.commented_on') { Comment.create(user: other_user, commentable: article, body: 'Hullo') }
      context 'with aliased author' do
        before { article.update_attribute(:author_alias, 'Hemmingway')}
        does_not_trigger('article.commented_on') { Comment.create(user: other_user, commentable: article, body: 'Hullo') }
        does_not_trigger('content.liked') { create :like, user: create(:user), thing: article }
      end

      triggers "article.contest:won" do
        allow_any_instance_of(Contests::Article).to receive(:entries).and_return([article])
        Contests::Article.ensure_up_to_date!
      end

      context 'pending review' do
        let(:article) { create :article, :pending_review, user: user }
        triggers('article.published') { article.publish!(admin) }
        triggers('article.rejected')  { article.reject!(admin)  }
      end
    end

    context 'with comment thread' do
      let!(:article) { create :article, :pending_review, user: other_user }
      let!(:comment) { Comment.create(user: user, commentable: article, body: 'Hullo') }
      triggers('comment.on_comment_thread') {
        Comment.create(user: other_user, commentable: article, body: 'Hullo')
      }
    end

    describe 'engagement redemption' do
      let(:r) { create :engagement_redemption, user: user }
      triggers('engagement_redemption:paid') { r.mark_paid!(admin, 'abc123') }
    end

    triggers('friend_request:pending') { other_user.friend_request(user) }

    context 'with request' do
      before { user.friend_request(other_user) }
      triggers('friend_request:accepted') { other_user.accept_request(user) }
    end

    triggers('wall_post.created') { Activity.add_wall_post(other_user, user, body: "From other to user") }
    does_not_trigger('wall_post.created') { Activity.add_wall_post(user, user, body: "From user to self") }

    context 'with post' do
      let!(:post) { Activity.add_wall_post(other_user, user, body: "From other to user") }
      triggers('wall_post.commented_on') { Comment.create user: create(:user), commentable: post, body: 'Hello' }
    end

    context "restaurant" do
      let(:restaurant) { create :restaurant, :claim_pending }
      let(:user) { restaurant.claimed_by.tap {|u| u.update(name: user_name) } }

      triggers('restaurant.claim_approved') { restaurant.approve(admin) }
      triggers('restaurant.claim_rejected') { restaurant.reject(admin) }
      does_not_trigger('restaurant.reviewed') { Review.create user: other_user, reviewable: restaurant, rating: 4 }

      describe 'accepted' do
        let(:restaurant) { create :restaurant, :claim_accepted }
        triggers('restaurant.reviewed') { Review.create user: other_user, reviewable: restaurant, rating: 4 }
      end
    end


    context "wine program" do
      let(:program) { create :wine_program, :pending, user: user }

      triggers('wine_program:accepted') { program.accept(admin) }
      triggers('wine_program:not_accepted', 'when rejecting') { program.reject(admin) }
      triggers('wine_program:not_accepted', 'when passing over') { program.pass_over(admin) }
      triggers('wine_program:not_accepted', 'when obsoleting') { program.obsolete(admin) }

      describe 'published' do
        let(:program) { create :wine_program, :published, user: user }
        before { allow_any_instance_of(Contests::WineProgram).to receive(:entries).and_return([program]) }

        triggers('wine_program.contest:won') { Contests::WineProgram.ensure_up_to_date! }
      end
    end

    context "conversation" do
      let(:conversation) { create :conversation, :with_users }
      let(:user) { conversation.users.first.tap {|u| u.update(name: user_name) } }
      let(:other_user) { conversation.users.last }

      triggers 'conversation.message_received' do
        conversation.add_message other_user, 'Wootlesticks'
        note = Notification.by_key('conversation.message_received').last
        expect(note.still_ready_for_notification?).to eq true
      end

      describe 'seen when created' do # don't send email when already seen
        before { allow_any_instance_of(Conversation::Message).to receive(:seen_by?).and_return(true) }

        does_not_trigger 'conversation.message_received' do
          conversation.add_message other_user, 'Wootlesticks'
        end
      end
    end


    context "moderation" do
      let(:comment) { create :comment, user: user, commentable: article }

      triggers('moderation:flagged') { create :flagging, user: other_user, flagged: comment }
      triggers('moderation:hidden') { comment.moderator_hide! admin }

      it "requires bang version to enforce persistence with state machine transitions" do
        expect { comment.moderator_hide admin }.to raise_error
      end

      describe 'hidden' do
        before { comment.moderator_hide! admin }
        triggers('moderation:shown') { comment.moderator_show! admin }
      end

      describe "from flags" do
        before do
          (Comment.hide_at_n_flags - 1).times { create :flagging, flagged: comment }
        end
        triggers('moderation:hidden:from_flags') { create :flagging, flagged: comment }

        describe 'hidden' do
          let!(:last) { create :flagging, flagged: comment }
          triggers('moderation:shown:from_flags') { last.destroy }
          triggers('moderation:shown:from_flags') { last.dismiss!(admin) }
        end
      end
    end

    context 'rewarding engagement' do
      before do
        create :engagement_reward_level, opts.merge(points: 5)
        create :engagement_config, id: 'good.thing', points: 10, repeatable: 'any'
      end

      context 'badge' do
        let(:opts) { {kind: 'badge', level: 'Awesome'} }
        triggers('engagement_reward.earned.badge') { EngagementService.call user, 'good.thing', user }
      end

      context 'payout' do
        let(:opts) { {kind: 'payout', face_value: 25, level: nil} }
        triggers('engagement_reward.earned.payout') { EngagementService.call user, 'good.thing', user }
      end
    end

    triggers('system.web_message', unscoped: true, skip_email: true) { create :user }
    triggers('system.social.autopost_network_connected') { create :identity, provider: 'twitter', user: user }

    describe 'user account confirmation' do
      let!(:user) { User.create(age: 1, tos: 1, name: 'Test', email: 'test@wla.com', password: 'password', password_confirmation: 'password')}
      does_not_trigger('system.account_email_confirmation.reminder') {
        AccountEmailConfirmationReminderJob.perform_now(user)
        expect(user.reload.confirmation_resent_at).to eq nil
      }
      context 'week after signing up' do
        let(:remindable) { Time.now + Devise.allow_unconfirmed_access_for - 1.day }
        before { Timecop.freeze(remindable) }
        after { Timecop.return }

        triggers('system.account_email_confirmation.reminder') {
          AccountEmailConfirmationReminderJob.perform_now(user)
          expect(user.reload.confirmation_resent_at).not_to eq nil
        }
      end
    end
  end
end
