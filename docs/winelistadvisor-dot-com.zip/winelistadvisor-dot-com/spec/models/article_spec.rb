# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Article, type: :model do

  context "submit" do
    let(:article) { create :article }

    it "without sufficient length" do
      article = create :article, body: 'only a couple words here ...'
      expect( article.submit! ).to eq false
      expect(article.draft?).to eq true
    end


    context "using AASM" do # always use the bang version of AASM transitions (whiny_transitions: false) in order to be sure success callbacks run correctly

      it "submit raises error (bang version required)" do
        expect(article.submitted_at).to be_nil
        expect { article.submit }.to raise_error
      end


      it "submit! saves timestamps" do
        expect(article.submitted_at).to be_nil
        article.submit!
        expect(article.submitted_at).not_to be_nil
        article.reload
        expect(article.submitted_at).not_to be_nil
      end

    end
  end

  context "publishing" do
    let(:article) { create :article, :pending_review, author_alias: author }
    let(:author) { nil }
    let(:admin) { create :user, :admin }
    let!(:pub_config) { create :engagement_config, id: 'article.published', points: 10, repeatable: 'any' }

    it "broadcasts on publish" do
      expect(SocialPublishingService).to receive(:call).with(:article_published, article)
      article.publish!(admin)
      expect(article.reload.reviewed_by).to eq admin
      expect(article.reload.reviewed_at).not_to eq nil
    end

    context 'with author alias' do
      let(:author) { 'Hemingway, The' }

      %w(activities notifications engagements).each do |thing|
        it "does not broadcast or save #{thing} on publish" do
          expect(SocialPublishingService).not_to receive(:call).with(:article_published, article)
          expect { article.publish!(admin) }.not_to change {
            article.user.send(thing).count
          }
          expect(article.reload.reviewed_by).to eq admin
          expect(article.reload.reviewed_at).not_to eq nil
        end

        context 'published' do
          before { article.publish!(admin) }
          it "does not broadcast or save #{thing} on editing" do
            expect { article.update(title: "Something new") }.not_to change {
              article.user.send(thing).count
            }
          end
        end
      end

    end

  end

  context "published article" do
    let(:article) { create :article, :published }

    it "can be liked" do
      expect(SocialPublishingService).to receive(:call).with(:liked, any_args)
      create :like, thing: article
    end
  end

  context "summernote field" do
    let(:article) { build :article, body: html + script }
    let(:html) { 'Test <span class="test">words</span> <b>and</b> <h3>titles</h3> and <table><thead><tr><th>Label</th></tr></thead><tbody><tr><td>tables</td></tr></tbody></table>' }
    let(:script) { "<script>#{script_text}</script><iframe/>" }
    let(:script_text) { 'alert(1)' }

    it "should sanitize html" do
      expect(article.body.gsub(/\n/,'')).to eq [html, script_text].join
    end
  end

end
