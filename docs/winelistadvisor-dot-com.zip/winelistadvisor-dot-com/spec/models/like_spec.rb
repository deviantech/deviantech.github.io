# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Like, type: :model do

  context "liking friendship activity" do
    let!(:userA) { create :user }
    let!(:userB) { create :user }
    let!(:userC) { create :user }

    before do
      make_friends(userA, userB)
    end

    it "notifies both friends" do
      act = Activity.first
      expect(act.topic).to eq 'friendship'

      expect {
        Like.create(user: userC, thing: act)
      }.to change { Notification.count }.by 2
    end

  end

end
