# frozen_string_literal: true

require 'spec_helper'
require_relative '../presentable_api_spec'

describe SinglePlatform::Api, vcr: true do
  let(:known_id)    { 'katsuya' }
  let(:api)         { described_class }

  it_behaves_like "a presentable API",
    get: [:known_id, :singular],
    updated_since: [Restaurant, ->(binding) {
      binding.allow_any_instance_of(SinglePlatform::RestaurantPresenter).to binding.receive(:within_geo_area?).and_return(true)
      binding.allow_any_instance_of(SinglePlatform::RestaurantPresenter).to binding.receive(:restaurant_has_alcohol?).and_return(true)
    }]

  describe '.get' do
    let(:result) { api.get(known_id) }

    it "onboards associated classes" do
      nested_count = result.to_h.dig(:sp_menus_attributes, 0, :sp_menu_sections_attributes, 0, :sp_menu_items_attributes).length
      expect( nested_count ).to be > 5, 'to_h should show attributes for the nested models'

      model = result.call
      expect(model.sp_menus.length).to be > 0, "call should build the actual nested models"
      expect(model.sp_menus.first.sp_menu_sections.length).to be > 0
      expect(model.sp_menus.first.sp_menu_sections.first.sp_menu_items.length).to be > 0

      saved = result.onboard!

      expect(SpMenu.count).to be > 0, "onboard should actually create the nested models"
      expect(SpMenuItem.count).to be > 0
      expect(ExternalRestaurantPhoto.count).to be > 0
      expect(saved.sp_menus.first.sp_menu_sections.first.sp_menu_items.length).to be > 0
    end

    context "with existing records" do
      let!(:katsuya) { create :restaurant, :katsuya }
      let!(:menu_to_remove) { create :sp_menu, restaurant: katsuya }
      let!(:menu_to_update) { create :sp_menu, id: 940631, restaurant: katsuya, name: 'Test Name' }
      let!(:sp_photo) { create :external_restaurant_photo, restaurant: katsuya, source: 'single_platform' }
      let!(:yelp_photo) { create :external_restaurant_photo, restaurant: katsuya, source: 'yelp' }

      it "onboards properly" do
        result.onboard!

        expect(katsuya.reload.sp_menus.length).to (be > 2), 'Adds the new associated records'
        expect(menu_to_update.reload.name).to eq('Dinner Starters'), 'Updates existing associated records'
        expect( SpMenu.where(id: menu_to_remove.id).first ).to be_nil, 'Removes previous-but-unlinked associated records'
        expect(katsuya.external_photos).to include yelp_photo
        expect(katsuya.external_photos).not_to include sp_photo
        expect { sp_photo.reload }.to raise_error, 'Should delete the unwanted photos, not leave them orphaned'
      end
    end
  end

  describe ".details_for" do
    subject { api.details_for(known_id) }

    it "returns details" do
      expect(subject.keys.sort).to eq ["location", "menus", "photos"]
    end

    let(:wine_menu)   { subject['menus'].detect {|m| m['name'] == 'Wine'} }
    let(:wines)       { wine_menu['sections'].flat_map {|s| s['items'] } }

    it "returns wine menu" do
      expect(wines.count).to be > 60
    end

  end

end
