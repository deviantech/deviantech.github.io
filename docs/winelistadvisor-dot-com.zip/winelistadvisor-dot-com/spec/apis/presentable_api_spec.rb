# frozen_string_literal: true

shared_examples_for "expects collection results" do

  it "returns presented collection" do
    expect( result ).to be_present
    expect( result ).to be_a ApiSupport::CollectionPresenter

    expect( result.count ).to be > 0
    expect( result.first ).to be_a ApiSupport::ApiPresenter

    unless result.total_count.nil?
      expect( result.total_count ).to be > result.count
    end
  end

  it "presents its data" do
    presented_array = result.call
    expect(presented_array.count).to be > 0

    presented_array.each do |presented|
      expect(presented).to be_a result.first.presents_as
      expect(presented).to be_valid
    end
  end

end

shared_examples_for "expects singular results" do

  it "returns presented object" do
    expect( result ).to be_present
    expect( result ).to be_a ApiSupport::ApiPresenter
  end

  it "has data for presented object" do
    hash = result.to_h

    expect( hash.keys.count ).to be > 5
    data_col = "#{result.using_namespace}_data".to_sym
    expect( hash.keys ).to include(data_col), "should have #{data_col} column to track source of all data"

    extra = hash[data_col]
    raise "shouldn't have any child _attributes fields defined in the cache hash" if extra.keys.map(&:to_s).any? {|k| k.end_with?('_attributes') }
    raise "should only store attributes with values" unless extra.values.all? {|v| v.present? }

    unless result.class.no_primary_key?
      expect( hash[data_col][:id] ).to be_present, "#{result.presents_as.name}'s #{data_col} should have the ID field set"
    end
  end

  it "presents its data" do
    presented = result.call

    expect(presented).to be_a result.presents_as
    expect(presented).to be_valid
  end

end

shared_examples_for "updated_since" do |created_klass, context_proc|

  describe do
    before(:each) do
      context_proc&.call(self)
    end

    context 'without a block' do
      let(:max_pages) { 10 } # Note: when reset VCR, sometimes e.g. 4 is low enough -- it'll depend on how long it takes to filter through SP data to find an actual in-business restaurant to work with
      subject { api.updated_since(Date.new(2017,9,9), batch_size: 1, max_pages: max_pages) }

      it { is_expected.to be_a Enumerator::Lazy }

      it "returns a mapped array" do
        expect( subject.to_a.length ).to eq max_pages
      end

      describe "each result" do
        let(:result) { subject.detect {|s| s.send(:data).present? } }

        it { expect(result).not_to eq(nil), "It should have at least one parsable result" }
        it_behaves_like "expects singular results"
      end

    end

    context 'with a block' do

      it "processes elements as they're received" do
        retval = api.updated_since(1.year.ago, batch_size: 1, max_pages: 4) do |presented|
          presented.onboard!
          raise StopIteration
        end

        expect(created_klass.count).to eq 1
        expect(retval).to be nil
      end
    end

  end
end

shared_examples_for "a get method" do |method_options|
  it_behaves_like "expects singular results"
  context "when presenting" do
    let(:result) { api.get( known_id ) }

    it "handles IDs correctly" do
      obj = result.call
      expect(obj.send(external_id_field)).to eq(known_id), "presenter should set external ID (expected #{known_id}, was '#{obj.send(external_id_field)}')"
      expect(obj.id).to be_nil, "presenter should allow #{obj.class.name} to set its own ID"
    end

    it "onboards without existing records" do
      expect( result.presents_as.count ).to eq 0
      result.onboard!
      expect( result.presents_as.count ).to eq 1
    end

  end
end

shared_examples_for "a presentable API" do |expected_methods|
  let(:external_id_field) { "#{described_class.name.split('::').first.underscore}_id" }

  unless expected_methods.any? {|name, opts| name == :get }
    it "checks :get" do
      pending "# IMPLEMENTATION NEEDED: #{described_class.name} doesn't have a get method. Check search?"
      raise NotImplementedError
    end
  end

  expected_methods.each do |method_name, method_options|
    describe ".#{method_name}" do
      let(:param)   { send( method_options[0] ) }
      let(:result)  { api.send(method_name, param) }

      it "handles no timestamp" do
        val = api.send(method_name, nil) rescue nil
        expect(val).to be_blank
      end

      case method_name
      when :updated_since then it_behaves_like("updated_since", method_options)
      when :get then it_behaves_like("a get method", method_options)
      else
        it_behaves_like "expects #{method_options[1]} results"
      end
    end
  end

end
