# frozen_string_literal: true

require 'spec_helper'
require_relative '../presentable_api_spec'

describe Yelp::Api, vcr: true do
  let(:known_term)  { 'coffee' }
  let(:known_id)    { 'urban-curry-restaurant-san-francisco' }
  let(:api)         { described_class }

  it_behaves_like "a presentable API",
    search: [:known_term, :collection],
    get: [:known_id, :singular]

  describe '.get' do
    let(:result) { api.get(known_id) }

    it "onboards associated classes" do
      model = result.onboard!

      expect(Restaurant.count).to eq 1
      expect(ExternalRestaurantPhoto.count).to eq 3
    end

    context "with existing records" do
      let!(:existing) { create :restaurant, name: 'Old Name', yelp_id: known_id }
      let!(:menu_to_ignore) { create :sp_menu, restaurant: existing }
      let!(:sp_photo) { create :external_restaurant_photo, restaurant: existing, source: 'single_platform' }
      let!(:yelp_photo) { create :external_restaurant_photo, restaurant: existing, source: 'yelp' }

      it "onboards properly" do
        model = result.onboard!
        existing.reload

        expect(existing.sp_menus.length).to eq(1), 'Leaves untouched, previously existing associations alone'
        expect(existing.yelp_image_url).not_to be_blank, 'Updates existing model'
        expect(existing.external_photos).to include sp_photo
        expect(existing.external_photos).not_to include yelp_photo
        expect { yelp_photo.reload }.to raise_error, 'Should delete the unwanted photos, not leave them orphaned'
      end
    end
  end

end
