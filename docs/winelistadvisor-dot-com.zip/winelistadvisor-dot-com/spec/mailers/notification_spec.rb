# frozen_string_literal: true

require "rails_helper"

RSpec.describe NotificationMailer, type: :mailer do

  describe "meta" do
    it "has mailer templates for all notification keys" do
      Notification::NOTIFICATIONS.each do |key, config|
        next if config[:skip_channels] && config[:skip_channels].include?(:email)
        has_template = File.exists?("app/views/notification_mailer/#{ Notification.underscored_key(key) }.html.haml")
        expect(has_template).to eq(true), "NotificationMailer missing template for key: #{key}"
      end
    end
  end


end
