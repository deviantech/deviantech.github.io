# frozen_string_literal: true

class ApplicationPreview < ActionMailer::Preview

  private

  def preview(what)
    action = caller[0].scan(/\`(.+?)'/)[0][0]
    raise "Unable to test '#{action}' mailer: No record found in the local database to test with" unless what

    mailer.send(action, what)
  end

  def mailer
    self.class.name.sub('Preview', 'Mailer').constantize
  end

end
