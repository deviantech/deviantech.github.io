# frozen_string_literal: true

# Preview all emails at http://localhost:3000/rails/mailers/user
class UserPreview < ApplicationPreview

  def invitation
    preview Invitation.first
  end

  def incomplete_review_reminder
    preview Review.limit(100).detect {|r| r.details_unfilled? }
  end

end
