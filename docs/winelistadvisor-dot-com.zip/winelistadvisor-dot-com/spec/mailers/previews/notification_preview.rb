# frozen_string_literal: true

# Preview all emails at http://localhost:3000/rails/mailers/notification
class NotificationPreview < ApplicationPreview

  Notification::NOTIFICATIONS.keys.each do |raw|
    key = Notification.underscored_key(raw)
    define_method key do
      if notification = Notification.send(key).first
        NotificationMailer.send(key, notification, preview: true)
      else
        raise "Unable to test mailer: No notification found in the local database for key '#{raw}'"
      end
    end
  end

end
