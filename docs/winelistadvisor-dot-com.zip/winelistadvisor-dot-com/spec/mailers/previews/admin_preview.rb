# frozen_string_literal: true

# Preview all emails at http://localhost:3000/rails/mailers/admin
class AdminPreview < ApplicationPreview

  def restaurant_pending_review
    preview Restaurant.first
  end

  def wine_program_pending_review
    preview WineProgram.first
  end

  def article_pending_review
    preview Article.first
  end

  def engagement_redemption_pending
    preview EngagementRedemption.first
  end

  def contest_pending
    contest = Contests::Article.pending.first || Contests::WineProgram.pending.first || Contests::Article.first
    preview contest
  end

  def system_alert
    AdminMailer.system_alert("Some custom system alert message here", 'string', 42, [1,2,3,4], 'extra variables' => true, arbitrary_data: :yep, other: 123, oh_yeah: true)
  end

  def weekly_report
    AdminMailer.weekly_report
  end

  def weekly_points_report
    AdminMailer.weekly_points_report(min_points: 1, show_top: 10)
  end

end
