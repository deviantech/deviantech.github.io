# frozen_string_literal: true

require 'spec_helper'

describe ApiSupport::Normalizer::Restaurant do

  {
    {yelp_categories_hash: {"Coffee & Tea"=>"coffee", 'Venues & Event Spaces' => 'events'}} => {yelp_categories_hash: {"Coffee & Tea"=>"coffee"}},
    {single_platform_categories: ['American (New)', 'American - Contemporary', 'American - Traditional']} => {single_platform_categories: ['American (Contemporary)', 'American (New)', 'American (Traditional)']},
    {description: " as “Jocy’s Mexican Restaurant“."} => {description: %q{as "Jocy's Mexican Restaurant".}},
  }.each do |(orig, checkable)|

    describe checkable.keys.join(', ') do
      subject { described_class.new(orig).call }

      it "normalizes" do
        checkable.each do |(k,v)|
          expect(subject[k]).to eq v
        end
      end
    end
  end


end
