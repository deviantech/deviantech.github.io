# frozen_string_literal: true

feature 'Restaurant Claiming', js: true, vcr: true do
  let(:user)        { create :user }
  let(:admin)       { create :user, :admin }
  let(:restaurant)  { create :restaurant }

  context "not logged in" do
    scenario 'cannot see claim form' do
      visit restaurant_path(restaurant)
      expect(page).not_to have_css '.spec-claim-restaurant'
    end
  end

  context "with logged in user" do
    before(:each) do
      login_as(user, scope: :user) # Warden test helper to fake being logged in already
    end

    it "has link from search results" do
      pending "Pending only because runs an API query that slows down tests. TODO: stub that out."
      raise "Keep while pending"

      visit restaurants_path
      fill_in 'restaurant_search[q]', with: 'cake'
      find('input[type=submit]').click
      expect(page).to have_css '.spec-claim-restaurant'
    end

    scenario 'can submit claim form' do
      visit restaurant_path(restaurant)

      # From view page, fill in claim page
      find('.spec-claim-restaurant').click

      # errors with no phone
      fill_in 'restaurant[claimant_phone]', with: 'nophone'
      find('input[type=submit]').click
      expect(page).to have_css '.has-error .help-block'

      # works with proper data
      fill_in 'restaurant[claimant_phone]', with: '1234567890'
      find('input[type=submit]').click

      # Is taken to an edit-info form....
      expect(page).to have_text 'Edit Wine Program Information'
      expect( all('input[type=text], textarea').map {|a| a['value'] }.uniq ).to eq [''] # starts blank
      fill_in 'wine_program[highlights]', with: 'All the wines are tasty and highlightable'
      fill_in 'wine_program[contact_name]', with: 'Some Name'
      fill_in 'wine_program[contact_position]', with: 'Wine Guy'
      fill_in 'wine_program[contact_phone]', with: '1231231231'
      find_and_click('input[type=submit]')
      expect(page).to have_css '.alert-success'

      # ... but can't yet view restaurant edit page
      visit edit_restaurant_path(restaurant)
      expect(page).to have_css '.alert-danger'
    end

    context "claiming" do
      subject { find('#wine_program_discounts')['value'] }

      def submit_claim
        visit claim_restaurant_path(restaurant)
        fill_in 'restaurant[claimant_phone]', with: '1234567890'
        find('input[type=submit]').click
        expect(page).to have_css('legend', text: 'Wine Program Highlights')
      end

      def submit_claim_form
        fill_in 'wine_program[contact_name]', with: 'Frank'
        fill_in 'wine_program[contact_position]', with: 'Wine Answerer'
        fill_in 'wine_program[contact_phone]', with: '5554445454'
        fill_in 'wine_program[discounts]', with: 'MUCHO DINERO'
        find('input[type=submit]').click
      end

      shared_examples_for "submits claim form" do |prepopulates: true|
        before do
          submit_claim
        end

        it "#{prepopulates ? 'prepopulates' : 'does not prepopulate'} form" do
          is_expected.send(prepopulates ? :to : :not_to, eq('MONEYMONEY'))
        end

        it "submits the info form" do
          submit_claim_form

          expect(page).to have_text 'Updates saved'
          expect(page).to have_text 'Pending Review'

          # Show user info about their pending submission
          visit restaurant_path(restaurant)
          expect(page).to have_text 'You may edit program information while you wait'

          # Can't edit restaurant until approved
          visit edit_restaurant_path(restaurant)
          expect(current_path).to eq '/' # Access denied
        end
      end

      context "without previous program information" do
        it_should_behave_like 'submits claim form', prepopulates: false
      end

      context "with program information" do
        let!(:program) { create :wine_program, state: 'pending', restaurant: restaurant, user: program_user, discounts: 'MONEYMONEY' }


        context "from claimant" do
          let(:program_user) { user }

          context "pending" do
            it_should_behave_like 'submits claim form'
          end

          context "accepted" do
            before do
              program.accept!(admin)
            end

            it_should_behave_like 'submits claim form'

            context "once claim submitted" do

              before do
                restaurant.submit_claim!(user, claimant_phone: '5554441234')
              end

              it "cannot edit restaurant until after acceptance" do
                visit edit_restaurant_path(restaurant)
                expect(current_path).to eq('/'), 'Should not be able to edit restaurant itself yet'

                visit restaurants_claimed_user_path(user)
                table = page.find('table.table')
                expect(table).to have_text 'Pending Review'
                table.click_link 'Edit'
                expect(current_path).not_to eq edit_restaurant_path(restaurant)

                restaurant.approve!(admin)

                visit restaurants_claimed_user_path(user)
                table = page.find('table.table')
                expect(table).to have_text 'Claimed'
                table.click_link 'Edit'
                expect(current_path).to eq edit_restaurant_path(restaurant)

                expect(page).to have_css('.panel-heading', text: 'Imported Information', wait: 30)
              end
            end

          end
        end


        context "from other user" do
          let(:program_user) { build :user }

          context "pending" do
            it_should_behave_like 'submits claim form', prepopulates: false
          end

          context "accepted" do
            before do
              program.accept!(admin)
            end

            it_should_behave_like 'submits claim form'

            context "once claim accepted, program user" do
              before do
                restaurant.submit_claim!(user, claimant_phone: '5554441234')
                restaurant.approve!(admin)

                login_as(program_user, scope: :user) # Warden test helper to fake being logged in already
              end

              it "sees based_on thanks" do
                visit restaurant_path(restaurant)

                expect(page).to have_text('Thank you for providing an early version of the Wine Program information below')
                expect(page).to have_text("Thanks to #{program_user.name} for providing an early version of this information")
              end

              it "still sees engagement points" do
                visit points_user_path(program_user)

                expect(page).to have_text("Successfully submitted information about the Wine Program at #{restaurant.name} + 5 5")
              end
            end
          end
        end

      end
    end
  end

  context "with logged in admin" do
    before(:each) do
      login_as(admin, scope: :user) # Warden test helper to fake being logged in already
    end

    def accept_claim
      visit pending_admin_restaurants_path

      click_link 'Approve'
      page.driver.browser.switch_to.alert.accept
      sleep 3

      restaurant.reload
    end

    context "accepting claims" do
      let(:program) { WineProgram.by_user(user).first }

      context "with no complications" do
        before do
          restaurant.submit_claim!(user, claimant_phone: '5554442323')
          program.update_attributes!(discounts: 'MONEYMONEY', contact_name: 'Fred', contact_phone: '5551112222', contact_position: 'Wine Guy')

          expect(restaurant.wine_program_id).to be_blank
        end

        it 'works for simple case' do
          accept_claim

          expect(restaurant.wine_program_id).to eq program.id
        end
      end

    end
  end
end
