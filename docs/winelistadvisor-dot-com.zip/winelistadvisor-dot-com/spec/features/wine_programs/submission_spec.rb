# frozen_string_literal: true

feature 'Wine Program Submission', js: true, vcr: true do
  let(:user)        { create :user }
  let(:admin)       { create :user, :admin }
  let(:restaurant)  { create :restaurant }


  context "while logged in" do
    before(:each) do
      login_as(user, scope: :user) # Warden test helper to fake being logged in already
    end

    context "restaurant page with accepted program submission" do
      let(:program)       { create :wine_program, :valid_submission, restaurant: restaurant, user: program_user }

      before(:each) do
        program.accept!(admin)
        visit restaurant_path(restaurant)
        expect(page).not_to have_css '.spec-submit-wine-info'
      end

      context "by current user" do
        let(:program_user)  { user }

        it "shows 'this info from you' banner" do
          expect(page).to have_text "Info thanks to #{program_user.name}"
          expect(page).to have_text "Thank you for providing the Wine Program information"
        end
      end

      context "by other user" do
        let(:program_user)  { build :user }

        it "shows 'thanks to xx user' banner" do
          expect(page).to have_text "Info thanks to #{program_user.name}"
        end
      end
    end

    context "submitting wine program information" do

      def can_submit_wine_program(restaurant)
        visit restaurant_path(restaurant)

        expect(page).to have_css('.alert .spec-submit-wine-info')
        page.find('.alert .spec-submit-wine-info').click

        expect(page.find('.page-header small').text).to eq 'Submit Wine Program'
        fills_out_wine_info_form
        shows_submission_status

        visit restaurant_path(restaurant)
        expect(page).to have_text 'Thank you for your contribution! Admins are currently reviewing your wine program submission.'
      end

      scenario "navigates the form requirements" do
        can_submit_wine_program restaurant
      end

      context "with pending restaurant claim" do
        let(:claimant) { create :user }
        before do
          restaurant.submit_claim!(claimant, claimant_phone: '5554441234')
        end

        scenario "still allows submitting program info" do
          can_submit_wine_program restaurant
        end

      end
    end

  end

  context "admin" do
    before(:each) do
      login_as(admin, scope: :user) # Warden test helper to fake being logged in already
    end

    scenario "manages submitted wine programs from index page" do
      create :wine_program, :valid_submission
      create :wine_program, :valid_submission

      visit admin_root_path
      click_pending_sidebar "Pending Wine Programs"

      # Has index w/ action buttons
      expect(page).to have_css('#page-title')
      expect(find('#page-title').text).to include 'Wine Programs'
      expect(all('.js-table-row').length).to eq 2
      expect(find('.js-table-row:first-of-type td:last-of-type').text.strip).to eq 'Reject Accept'

      reject_pending_program
      accept_pending_program
    end

    context "with multiple submissions" do
      let!(:prog1) { create :wine_program, :valid_submission, restaurant: restaurant }
      let!(:prog2) { create :wine_program, :valid_submission }
      let!(:prog3) { create :wine_program, :valid_submission, restaurant: restaurant }

      scenario 'handles multiple for one restaurant' do
        visit pending_admin_wine_programs_path

        expect(all('.js-table-row').length).to eq 3
        accept_pending_program # accepting one should reject the other from the same restaurant

        visit pending_admin_wine_programs_path
        expect(all('.js-table-row').length).to eq 1
        expect(prog3.reload.review_feedback).to eq 'Another submission was already accepted.'
      end
    end

    context "with pending restaurant claim" do
      let(:claimant) { create :user }

      before do
        create :wine_program, :valid_submission, restaurant: restaurant, user: claimant
        restaurant.submit_claim!(claimant, claimant_phone: '5554441234')
        create :wine_program, :valid_submission, restaurant: restaurant
      end

      scenario "cannot approve submission until claim managed" do
        visit pending_admin_wine_programs_path

        # No action items available until restaurant claim managed
        expect(all('.js-table-row td:last-of-type a').length).to eq 0
      end

    end
  end

  private

  def fills_out_wine_info_form
    submit
    expect(page.all('.alert-danger').length).to eq 2

    fill_in 'wine_program_highlights', with: "This wine program was created programmatically. Programatic. Program... 'By Computer.'"
    submit

    expect(page).to have_css('.alert-success')
  end

  def shows_submission_status
    expect(page.all('table.table tr').length).to eq 2
    expect(page.find('table.table').text).to include 'Pending admin review'
  end

  def submit
    find_and_click('input[type=submit]')
  rescue
    sleep 2
    find_and_click('input[type=submit]')
  end





  # Admin - should have submitted menu photos...
  def click_pending_sidebar(label)
    shows_pending = all('.sidebar__link').detect {|l| l.text.strip =~ /(\d+) #{label}/ }
    expect(shows_pending).not_to be nil
    shows_pending.click
  end

  def reject_pending_program
    prev_pending_count = all('.js-table-row').length
    prev_draft_count = WineProgram.draft.count

    expect(page).not_to have_css '#modal-via-ajax'
    within('.js-table-row:first-of-type') do
      click_link 'Reject'
    end
    expect(page).to have_css '#modal-via-ajax'
    within('#modal-via-ajax') do
      fill_in 'wine_program[review_feedback]', with: 'AutoAdmin says not yet.'
      click_button 'Reject'
      sleep 2
    end

    expect(all('.js-table-row').length).to eq(prev_pending_count-1)
    expect(WineProgram.draft.count).to eq(prev_draft_count+1)
  end

  def accept_pending_program
    prev_accepted_count = WineProgram.accepted.count

    within('.js-table-row:first-of-type') do
      page.accept_confirm {
        click_link 'Accept'
      }
      sleep 1
    end

    expect(page).to have_css '.alert-success'
    expect(WineProgram.accepted.count).to eq(prev_accepted_count+1)
  end

end
