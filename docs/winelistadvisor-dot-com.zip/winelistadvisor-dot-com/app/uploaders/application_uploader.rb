# frozen_string_literal: true

class ApplicationUploader < CarrierWave::Uploader::Base
  include CarrierWave::MiniMagick
  MAIN_WIDTH = 1200 # FB recommended minimum
  class_attribute :w_to_h
  self.w_to_h = 1

  # Choose what kind of storage to use for this uploader:
  storage(Rails.env.development? || Rails.env.test? ? :file : :fog)

  # All photos get autorotated as necessary
  process :auto_orient

  # Override the directory where uploaded files will be stored.
  # This is a sensible default for uploaders that are meant to be mounted:
  def store_dir
    "uploads/#{model.class.to_s.underscore}/#{mounted_as}/#{model.id}"
  end

  def content_type_whitelist
    [/image\//]
  end

  # Override the filename of the uploaded files:
  # Avoid using model.id or version_name here, see uploader/store.rb for details.
  def filename # https://github.com/carrierwaveuploader/carrierwave/wiki/how-to:-create-random-and-unique-filenames-for-all-versioned-files
    if original_filename.present?
      if model && model.read_attribute(mounted_as).present?
        model.read_attribute(mounted_as)
      else
        "#{secure_token}.#{file.extension}"
      end
    end
  end

  private

  # Rotates the image based on the EXIF Orientation
  def auto_orient
    manipulate! do |image|
      image.tap(&:auto_orient)
    end
  end


  def secure_token
    var = :"@#{mounted_as}_secure_token"
    model.instance_variable_get(var) or model.instance_variable_set(var, SecureRandom.uuid)
  end

  def store_dimensions
    return unless file && model && model.respond_to?("#{mounted_as}_width") && model.respond_to?("#{mounted_as}_height")
    w, h = ::MiniMagick::Image.open(file.file)[:dimensions]

    model.send("#{mounted_as}_width=",  w)
    model.send("#{mounted_as}_height=", h)
  end

  def self.dimensions_from_width(width, w_to_h_ratio = w_to_h)
    [width, (width / w_to_h_ratio).round]
  end

  def versioned_default_filename
    [version_name, "default.jpg"].compact.join('_')
  end

end
