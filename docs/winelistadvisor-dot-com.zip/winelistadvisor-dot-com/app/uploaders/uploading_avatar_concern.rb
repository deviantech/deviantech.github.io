# frozen_string_literal: true

# Interestingly, if Carrierwave's uploader A < B, and versions are instantiated in A,
# while b.url will be processed by b, b.url(:some_size) will pull up the version as a class of **A**,
# not the expected B, so the default_url method definition in subclasses would only apply to the main
# URL if we used inheritance instead of this compositional approach.
module UploadingAvatarConcern
  extend ActiveSupport::Concern

  included do
    version :main do
      process :resize_to_limit => dimensions_from_width(ApplicationUploader::MAIN_WIDTH)
      process :store_dimensions
    end

    version :s200, from_version: :main do
      process :resize_to_fill => [200,200]
    end

    version :s100, from_version: :s200 do
      process :resize_to_fill => [100,100]
    end

    version :s50, from_version: :s100 do
      process :resize_to_fill => [50,50]
    end
  end

  # Provide a default URL as a default if there hasn't been a file uploaded:
  def default_url
    local_fallback
  end


  protected

  def local_fallback
    fallback_asset_url = ActionController::Base.helpers.asset_pack_url("src/images/fallback/avatar/#{model.class.name.underscore}/#{versioned_default_filename}", protocol: 'https')
    base = Addressable::URI.parse( fallback_asset_url )
    base.host = App.domain
    base.scheme = Rails.env.production? ? 'https' : 'http'

    URI.escape base.to_s
  end

end
