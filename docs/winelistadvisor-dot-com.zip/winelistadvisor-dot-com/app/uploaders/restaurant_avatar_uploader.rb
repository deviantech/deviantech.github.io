# frozen_string_literal: true

class RestaurantAvatarUploader < ApplicationUploader
  include UploadingAvatarConcern

  # Provide a default URL as a default if there hasn't been a file uploaded:
  def default_url
    url = yelp_image_url
    url = external_image_url unless url.present?
    url = local_fallback unless url.present?
    url
  end

  protected

  def yelp_image_url
    return unless model.respond_to?(:yelp_image_url)
    model.yelp_image_url
  end

  def external_image_url
    return unless model.respond_to?(:external_photos)
    model.external_photos.first&.url
  end
end
