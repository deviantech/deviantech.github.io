# frozen_string_literal: true

class FeaturedImageUploader < ApplicationUploader
  self.w_to_h = 1.91

  MAIN_HEIGHT = dimensions_from_width(MAIN_WIDTH)[1]

  process :store_dimensions

  version :main do
    process :resize_to_fill => [MAIN_WIDTH, MAIN_HEIGHT]
  end

  version :s200, from_version: :main do
    process :resize_to_fill => dimensions_from_width(200)
  end

  version :s100, from_version: :s200 do
    process :resize_to_fill => dimensions_from_width(100)
  end

  version :s50, from_version: :s100 do
    process :resize_to_fill => dimensions_from_width(50)
  end

  # Provide a default URL as a default if there hasn't been a file uploaded:
  def default_url
    ActionController::Base.helpers.asset_pack_url "src/images/fallback/featured_image/" + versioned_default_filename, protocol: 'https'
  end

end
