# frozen_string_literal: true

class UserAvatarUploader < ApplicationUploader
  include UploadingAvatarConcern

  # Provide a default URL as a default if there hasn't been a file uploaded:
  def default_url
    size = case version_name
    when :s200 then 200
    when :s100 then 100
    when :s50  then 50
    else 300
    end

    gravatar_fallback_url(size)
  end

  protected

  def gravatar_fallback_url(size)
    model.gravatar_url({
      secure: true,
      filetype: 'png',
      size: size,
      default: gravatar_default_fallback_url,
    })
  end

  def gravatar_default_fallback_url
    # return :identicon

    local_fallback
  end
end
