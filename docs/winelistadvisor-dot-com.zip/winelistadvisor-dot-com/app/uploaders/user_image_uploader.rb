# frozen_string_literal: true

class UserImageUploader < ApplicationUploader
  process :store_dimensions
  process :save_content_type_and_size_in_model

  version :thumb do
    process resize_to_limit: [200,200]
  end

  def save_content_type_and_size_in_model
    model.content_type = file.content_type if file.content_type
    model.file_size = file.size
  end

end
