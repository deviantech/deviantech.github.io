# frozen_string_literal: true

class ApplicationMailer < ActionMailer::Base
  default from: 'advisor@winelistadvisor.com'
  layout 'mailers/application'
  helper ApplicationHelper
  helper MailerHelper
end
