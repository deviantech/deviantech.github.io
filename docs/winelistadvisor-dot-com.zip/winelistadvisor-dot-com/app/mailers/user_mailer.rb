# frozen_string_literal: true

class UserMailer < ApplicationMailer
  layout 'mailers/user'

  def invitation(invitation)
    @invitation = invitation
    return unless @invitation.email.present? && @invitation.user

    mail to: @invitation.email, subject: "#{@invitation.user.name} has invited you to WineListAdvisor.com"
  end

  def incomplete_review_reminder(review)
    @review = review
    @user = @review.user
    return unless @review.details_unfilled? && @review.user&.email

    mail to: @user.email, subject: "Want to add details to your review of #{@review.reviewable.name}?"
  end

end
