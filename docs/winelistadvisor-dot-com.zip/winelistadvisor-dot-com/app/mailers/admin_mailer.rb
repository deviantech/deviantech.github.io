# frozen_string_literal: true

class AdminMailer < ApplicationMailer
  layout 'mailers/admin'

  def restaurant_pending_review(restaurant)
    @restaurant = restaurant

    mail_admin subject: "Restaurant pending review: #{restaurant.name}"
  end

  def wine_program_pending_review(wine_program)
    @wine_program = wine_program
    @user = wine_program.user
    @restaurant = wine_program.restaurant

    mail_admin subject: "Wine Program Submission pending review for: #{@restaurant&.name}"
  end

  def article_pending_review(article)
    @article = article

    mail_admin subject: "Article pending review: #{article.title}"
  end

  def engagement_redemption_pending(redemption)
    @redemption = redemption

    return unless redemption.user

    mail_admin subject: "#{redemption.user.name} has earned a Gift Card!"
  end

  def contest_pending(contest)
    @contest = contest

    mail_admin subject: "#{@contest.contest_name} is ready for you to pick a winner!"
  end

  def system_alert(msg = nil, *raw, **labelled)
    @msg, @raw, @labelled = msg, raw, labelled
    return unless [@msg, @raw, @labelled].any?(&:present?)

    mail to: App.internal_developer_email, subject: labelled[:subject] || 'System Alert'
  end

  def weekly_report
    mail_admin subject: "Weekly report for #{Time.now.strftime('%B %e, %Y')}"
  end

  def weekly_points_report(min_points: 10, show_top: 10)
    base = Engagement.where('points > 0').where('created_at > ?', 1.week.ago).group(:user).order('sum_points DESC')
    @top_earners = base.limit(show_top).sum('points')
    @min_points = min_points
    @other_high_earners = base.where.not(user_id: @top_earners.map {|u,p| u.id}).having('sum(points) > ?', @min_points).sum('points')

    mail_admin subject: "Weekly Wine Points report for #{Time.now.strftime('%B %e, %Y')}"
  end

  private

  def mail_admin(opts)
    mail opts.merge(to: App.interal_admin_email, cc: App.internal_developer_email)
  end
end
