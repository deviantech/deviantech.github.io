# frozen_string_literal: true

class NotificationMailer < ApplicationMailer
  layout 'mailers/notification'

  Notification::NOTIFICATIONS.keys.each do |key|
    underscored = Notification.underscored_key(key)
    define_method underscored do |notification, opts = {}|
      return unless notification
      send_notification_email(notification, opts)
    end
  end

  private

  def send_notification_email(notification, opts = {})
    @user = notification.user
    @notification = notification
    @thing = notification.thing
    @thing_context = notification.thing_context
    @data = notification.data

    return unless @user&.email.present?
    return unless notification.email_subject.present?
    return unless opts[:preview] || notification.still_ready_for_notification?

    mail to: @user.email, subject: notification.email_subject
  end
end
