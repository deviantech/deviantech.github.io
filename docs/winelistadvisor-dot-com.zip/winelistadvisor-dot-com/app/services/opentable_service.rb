# frozen_string_literal: true

require 'opentable_service/client'

class OpentableService
  SEARCH_ATTRIBUTES = %w(name city state country zip)

  def self.get_opentable_id(restaurant)
    params = restaurant.attributes.slice(*SEARCH_ATTRIBUTES)

    url   = opentable_id_search( params.merge('address' => restaurant.address.first) )
    url ||= opentable_id_search( params )
  end

  private

  def self.opentable_id_search(params)
    possibilities = OpenTable::Client.new.restaurants( params )
    return possibilities['restaurants'][0]['id'] if possibilities && possibilities['total_entries'] == 1
  end
end
