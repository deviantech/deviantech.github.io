# frozen_string_literal: true

# https://gist.github.com/sosedoff/2504683
# https://github.com/sosedoff/opentable
# Until we get actual API access, at least connect restaurants to their OT reservation URL.
module OpenTable
  class Error < StandardError ; end

  module Request
    API_BASE = "http://opentable.herokuapp.com"

    def connection
      connection = Faraday.new(API_BASE) do |c|
        c.use(Faraday::Request::UrlEncoded)
        c.use(Faraday::Response::ParseJson)
        c.adapter(Faraday.default_adapter)
      end
    end

    def request(method, path, params={}, raw=false)
      headers = {
        'Accept' => 'application/json',
        'X-Api-Token' => ENV.fetch('OPENTABLE_API_TOKEN')
      }
      path = "/api#{path}"
      response = nil

      begin
        response = connection.send(method, path, params) do |request|
          request.url(path, params)
        end
      rescue Faraday::ParsingError => e # https://rollbar.com/WineListAdvisor/WineListAdvisor-Production/items/6/occurrences/36421009419/
        Rollbar.error(e) unless e.to_s =~ /retry later/i
        return nil
      end

      if [404, 403, 400].include?(response.status)
        raise OpenTable::Error, response.body["error"]
      end

      raw ? response : response.body
    end

    def get(path, params={})
      request(:get, path, params)
    end
  end

  class Client
    include Request

    def countries
      get("/countries")
    end

    def cities(country=nil)
      get("/cities")
    end

    def restaurants(options={})
      get("/restaurants", options)
    end

    def restaurant(id)
      get("/restaurants/#{id}")
    end
  end
end
