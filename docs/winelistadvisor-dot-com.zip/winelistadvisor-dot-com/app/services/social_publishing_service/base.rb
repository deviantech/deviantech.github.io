# frozen_string_literal: true

module SocialPublishingService
  class Base
    delegate :dom_id, to: ActionView::RecordIdentifier
    include Rails.application.routes.url_helpers
    include UrlHelpers

    attr_reader :key, :identity, :user, :thing, :ctx

    def initialize(key, identity:, user:, thing:, ctx: nil)
      @identity = identity
      @user = user
      @thing = thing
      @ctx = ctx
      @key = key
    end

    def call
      prepublish if respond_to?(:prepublish)

      external_id = perform
      post = ExternalSocialPost.create(external_id: external_id, identity: identity, link: link)
      post.save
    end

    private

    # TODO: it's awkward to have to download the image to upload it again -- possible to just post the URL?
    def get_from_url(base_url)
      return unless base_url.present?

      # Handle local URLs
      url = URI.parse(base_url)

      unless url.absolute?
        url.scheme ||= 'http'
        url.host ||= App.domain.sub(':3000', '')
      end

      uri = URI.parse(url.to_s)

      uri&.open rescue nil
    end

    def external_id_from(api_response)
      api_response['id']
    end

    def link
      case key
      when :added_review              then view_review_url(thing)
      when :wants_to_visit_restaurant then restaurant_url(thing)
      when :added_comment             then view_comment_url(thing)
      when :article_published, :article_contest_won then article_url(thing)
      when :posted                    then view_activity_url(thing)
      when :following                 then profile_user_url(thing)
      when :liked                     then view_liked_url(thing)
      else raise "Unknown key: #{key}"
      end
    end

  end
end
