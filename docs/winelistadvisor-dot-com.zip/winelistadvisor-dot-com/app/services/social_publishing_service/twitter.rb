# frozen_string_literal: true

module SocialPublishingService
  # TODO: add place_id support for restaurants
  class Twitter < Base
    MAX_TWEET_LENGTH = 280
    LINK_DIVIDER = ' - '
    EXTRA_DIVIDER = ' '
    EXTRA = "@#{App.social_handles[:twitter]}"

    def call
      return unless msg = message

      mthd = media_file? ? :update_with_media : :update
      args = media_file? ? [msg, media_file] : [msg]
      api.send(mthd, *args) # TODO: return the ID
    end

    private

    def message
      link_len = link.length + LINK_DIVIDER.length
      max = MAX_TWEET_LENGTH - link_len

      if msg = truncate_message(full_message, max)
        append_extra [msg, link].join(LINK_DIVIDER)
      end
    end

    def append_extra(msg)
      if (msg + EXTRA_DIVIDER + EXTRA).length <= MAX_TWEET_LENGTH
        [msg, EXTRA].join(EXTRA_DIVIDER)
      else
        msg
      end
    end

    def truncate_message(full, max)
      return full unless full.to_s.length > max
      full[0, max - 1] + '…'
    end

    def full_message
      case key
      when :added_review then "#{ctx.reviewable_name} Review: #{thing.rating_num}/5"
      when :wants_to_visit_restaurant then "Interested in visiting #{thing.name}"
      when :added_comment then "#{ctx.label} comment: #{thing.body}"
      when :article_published then "WineListAdvisor published my article #{thing.title}!"
      when :article_contest_won then "My article #{thing.title} won a contest"
      when :posted then "Post on WineListAdvisor: #{thing.body}"
      when :liked
        case thing.thing
        when Article then "Just liked article #{thing.thing.name} on WLA"
        when Restaurant then "Just liked restaurant #{thing.thing.name} on WLA"
        end
      else raise "Unknown key: #{key}"
      end
    end

    def api
      @api ||= ::Twitter::REST::Client.new do |config|
        config.consumer_key        = ENV.fetch('TWITTER_APP_KEY')
        config.consumer_secret     = ENV.fetch('TWITTER_APP_SECRET')
        config.access_token        = identity.token
        config.access_token_secret = identity.secret
      end
    end

    def media_file?
      media_file.present?
    end

    def media_file
      @media_file ||= get_from_url(media_file_url)
    end

    def media_file_url
      case key
      when :added_review then ctx.avatar.url
      when :wants_to_visit_restaurant then thing.avatar.url
      when :article_published, :article_contest_won then thing.featured_image.url
      when :posted then thing.images.first&.image&.url
      when :liked
        thing.is_a?(Article) ? thing.featured_image.url : nil
      end
    end

  end
end
