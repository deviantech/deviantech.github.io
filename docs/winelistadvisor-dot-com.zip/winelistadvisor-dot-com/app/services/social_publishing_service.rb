# frozen_string_literal: true

# Thin wrapper to handle the social publishing logic in a background job
module SocialPublishingService

  PUBLISHABLE_PROVIDERS = %w(twitter)
  ALL_SOCIAL_NOTIFICATIONS = {
    added_review: "I leave a review on a restaurant",
    wants_to_visit_restaurant: "I indicate I want to visit a restaurant",
    added_comment: "I leave a comment on WLA (e.g. on an article or a post on someone's wall)",
    article_published: "One of my articles is published",
    article_contest_won: "One of my articles wins a contest",
    posted: "I leave a post on WLA",
    following: "I become friends with another user",
    liked: "I like something on WLA (e.g. an article or a review)",
  }

  UNPUBLISHABLE_FOR = {
    'twitter' => [:following]
  }

  class << self

    def call(key, object)
      thing, user, ctx = extract_context(key, object)

      SocialPublishingServiceJob.perform_later(key.to_s, user: user, thing: thing, ctx: ctx)
    end

    def supported_social_notifications(provider)
      return {} unless PUBLISHABLE_PROVIDERS.include?(provider)
      ALL_SOCIAL_NOTIFICATIONS.reject {|k,v| (UNPUBLISHABLE_FOR[provider] || []).include?(k) }
    end

    private

    def extract_context(key, obj)
      case key
      when :posted, :article_published  then [obj, obj.user]
      when :wants_to_visit_restaurant   then [obj.bookmarkable, obj.user, obj]
      when :added_comment               then [obj, obj.user, obj.commentable]
      when :liked                       then [obj.thing, obj.user, obj]
      when :added_review                then [obj, obj.user, obj.reviewable]
      when :following                   then [obj.friend, obj.friendable, obj]
      when :article_contest_won         then [obj.winner, obj.winning_user, obj]

      else raise "[Social Publishing Service] Unknown key: #{key}"
      end
    end
  end

end
