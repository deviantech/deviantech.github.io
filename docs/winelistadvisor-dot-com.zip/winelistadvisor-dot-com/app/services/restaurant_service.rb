# frozen_string_literal: true

class RestaurantService
  autoload 'ResultSet', 'restaurant_service/result_set'
  autoload 'Searcher',  'restaurant_service/searcher'

  class << self

    def get_local(identifier)
      return unless identifier.present?
      Restaurant.reorder(nil).find_by(id: identifier) || Restaurant.reorder(nil).find_by(slug: identifier)
    end

    # Return a restaurant representation (updating DB if saved and refresh needed) of the given yelp business
    def get(identifier, allow_unsaved: false)
      return unless identifier.present?

      if r = get_local(identifier)
        # SP updates are brought in daily via the onboarding job, but for Yelp we check when the record is accessed
        Api::UpdateRecordJob.perform_later(r, 'yelp') if r.yelp_id && r.data_outdated?(:yelp)
        return r
      end

      # If we're given a slug that doesn't already exist in our DB, it's from a Yelp search
      if raw = Yelp::Api.get(identifier)
        allow_unsaved ? raw.as_unsaved_model : raw.onboard!
      end
    end

  end
end
