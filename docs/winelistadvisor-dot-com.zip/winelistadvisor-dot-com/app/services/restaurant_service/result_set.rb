# frozen_string_literal: true

class RestaurantService::ResultSet
  include Enumerable
  attr_accessor :name, :results

  def initialize(name, results)
    @name, @results = name, results
  end

  def call
    case name
    when :local then results
    when :yelp
      result_yelp_ids = results.map(&:yelp_id)
      known_yelp_ids  = Restaurant.where(yelp_id: result_yelp_ids).pluck(:yelp_id)

      # NOTE: IF we tracked which results we've already shown on the page, instead of removing here
      # we could replace remote w/ existing local (in case of e.g. Slim's Koffee Haus comes up in yelp search
      # for "coffee", but not in local search), so in effect reviewing remote restaurant on search page has change
      # of reloading page without the restaurant visible anymore.

      results.reject {|r| known_yelp_ids.include?(r.yelp_id) }
    else
      raise "Unknown RestaurantService::ResultSet name: #{name}"
    end
  end

  def each
    results.each {|i| yield(i )}
  end

end
