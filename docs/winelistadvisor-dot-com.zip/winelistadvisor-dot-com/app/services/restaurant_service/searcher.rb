# frozen_string_literal: true

class RestaurantService::Searcher

  attr_accessor :term, :page, :scope, :prices, :geo

  def initialize(term, price_ranges: [], page: 1, geo: nil, scope: :local, per_page: nil)
    @page   = page.to_i < 1 ? 1 : page.to_i
    @prices = Array(price_ranges).map(&:to_s).select(&:present?).join(',')
    @geo = geo
    @per_page = per_page
    @scope = scope || :local

    if term.present? # Remove word "restaurant" from yelp search
      @term = term.sub(/\brestaurant\b/i, '').strip
    end
  end

  def call
    send("#{scope}_search").call
  end

  private

  def per_page
    [@per_page, scope == :local ? 50 : Yelp::Api.max_per_page].compact.min
  end

  # Local search (geocode gem) accepts #near argument as either string placename or as array w/ [latitude,longitude]
  def geo_for_local
    if geo.respond_to?(:key?) && geo.key?(:latitude) && geo.key?(:longitude)
      geo.values_at(:latitude, :longitude)
    else
      geo
    end
  end

  # Yelp::Api accepts location as either string placename or as hash w/ latitude/longitude keys
  def geo_for_remote
    geo
  end

  def local_search
    @local_search ||= begin
      base = Restaurant.search_by_name(term).in_price_ranges( prices.split(',') )
      results = geo.present? ? base.near(geo_for_local, 25) : base

      RestaurantService::ResultSet.new(:local, results.page(page).per(per_page).to_a)
    end
  end

  def remote_search
    result = Yelp::Api.search(term, price_ranges: prices, page: page, per_page: per_page, location: geo_for_remote)
    RestaurantService::ResultSet.new(:yelp, result.map {|r| r.as_unsaved_model })
  end

end
