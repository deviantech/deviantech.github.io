# frozen_string_literal: true

class EngagementService

  IGNORE_MISSING_IN_TESTS = %w(member.joined)

  def self.call(user, key, thing = nil, data = {})
    unless config = config_for(key)
      msg = "Unconfigured Engagement key: #{key}"
      raise msg unless Rails.env.test?

      warn(msg) unless IGNORE_MISSING_IN_TESTS.include?(key)
      return
    end

    new(config: config, user: user, thing: thing, data: data).send(:call)
  end

  def self.config_for(key)
    EngagementConfig.find_by(id: key)
  end

  def initialize(config:, user:, thing: nil, data: {})
    @config, @user, @thing, @data = config, user, thing, data
  end

  private

  attr_reader :config, :user, :thing, :data

  def call
    enforce_data_validity!
    return unless more_repetitions_allowed?

    pts = calculate_points_for
    return if pts.zero? # We have other activity streams now, so don't bother creating no-point engagements.

    fields = { thing: thing, key: config.id, points: pts, repeat: prev_scope.count > 0 }
    fields[:data] = data if data.present?

    user.engagements.create!(fields)
  end

  def enforce_data_validity!
    return true unless config.thing_required? && thing.blank?

    raise "Unable to record engagement without provided thing for key #{config.id}"
  end

  def more_repetitions_allowed?
    case config.repeatable
    when 'none'
      return false if prev_scope.any?
    when 'thing'
      return false if prev_scope.any?
      return false if config.max_per_month && prev_type_scope.this_month.count >= config.max_per_month
    when 'any'
      return false if config.max_per_month && prev_type_scope.this_month.count >= config.max_per_month
    end

    true
  end

  def prev_type_scope
    user.engagements.where(key: config.id)
  end

  def prev_type_and_thing_scope
    user.engagements.where(key: config.id, thing: thing) # better thought of as 'once-per-thing'
  end

  def prev_scope
    case config.repeatable
    when 'none'   then prev_type_scope
    when 'thing'  then prev_type_and_thing_scope
    else user.engagements.none
    end
  end

  def key_parts
    config.id.split('.')
  end

  def key_base
    key_parts[0]
  end

  def calculate_points_for
    from_system = recalculate_system_points if 'system' == key_base
    return from_system if from_system.present?

    pts = config.points

    if config.first_bonus > 0
      pts += config.first_bonus if first_of_type?
    end

    if pts > 0
      prev_pts = pts
      if user.points_this_month >= EngagementConfig::MAX_POINTS_PER_MONTH
        msg = "You would normally receive #{prev_pts} point#{prev_pts == 1 ? '' : 's'} #{config.description.uncapitalize}, but as you've already reached the monthly maximum of #{EngagementConfig::MAX_POINTS_PER_MONTH} points the engagement was discarded."
        user.system_notify msg, details: "You will not receive additional Wine Experience Points until #{(Date.today + 1.month).strftime("%B %Y")}."

        pts = 0
      elsif user.points_this_month + pts >= EngagementConfig::MAX_POINTS_PER_MONTH
        pts = EngagementConfig::MAX_POINTS_PER_MONTH - user.points_this_month
        msg = "You would normally receive #{prev_pts} point#{prev_pts == 1 ? '' : 's'} #{config.description.uncapitalize}, but as you're running up against the '#{EngagementConfig::MAX_POINTS_PER_MONTH} max points per month' rule you only received #{pts}."
        user.system_notify msg, details: "You will not receive additional Wine Experience Points until #{(Date.today + 1.month).strftime("%B %Y")}."
      end
    end

    pts
  end

  def first_of_type?
    return @first_of_type if defined?(@first_of_type)
    @first_of_type = prev_type_scope.none?
  end

  def recalculate_system_points
    case config.id
    when 'system.pending_points_expired' then EngagementReward.points_from_prev_reward(user) * -1
    end
  end

end
