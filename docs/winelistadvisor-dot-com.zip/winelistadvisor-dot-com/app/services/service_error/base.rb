# frozen_string_literal: true

module ServiceError
  class Base < ::RuntimeError
    attr_reader :args
    def initialize(msg = "Service Error", *args)
      @args = args
      super(msg)
    end
  end
end
