# frozen_string_literal: true

module ServiceError
  class BackendMisconfigured < Base; end
end
