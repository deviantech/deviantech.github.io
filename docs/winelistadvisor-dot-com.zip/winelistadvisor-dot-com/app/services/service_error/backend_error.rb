# frozen_string_literal: true

module ServiceError
  class BackendError < Base; end
end
