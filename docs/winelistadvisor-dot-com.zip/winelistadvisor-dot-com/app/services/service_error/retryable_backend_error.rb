# frozen_string_literal: true

module ServiceError
  class RetryableBackendError < Base; end
end
