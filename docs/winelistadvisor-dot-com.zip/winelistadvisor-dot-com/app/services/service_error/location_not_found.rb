# frozen_string_literal: true

module ServiceError
  class LocationNotFound < Base; end
end
