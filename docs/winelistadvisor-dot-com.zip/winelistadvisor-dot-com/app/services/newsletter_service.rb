# frozen_string_literal: true

module NewsletterService
  LIST_ID = App.production? ? '1a25ee7344' : '8f70a9d304'
  GROUP_ID_KEY = 'service:newsletter:group_id'.freeze
  MAPPING_KEY  = 'service:newsletter:group_mapping'.freeze

  EMAIL_FREQUENCY = 'twice weekly'

  class << self

    def reset_caches!
      $redis.del(GROUP_ID_KEY)
      $redis.del(MAPPING_KEY)
    end

    def newsletters_group_id
      @@newsletters_group_id ||= begin
        if $redis.exists(GROUP_ID_KEY) then $redis.get(GROUP_ID_KEY)
        else
          raw = list.interest_categories.retrieve.body['categories'].detect {|c| c['title'] == 'Newsletters'}['id']
          raw.tap { |v| $redis.set(GROUP_ID_KEY, v) }
        end
      rescue StandardError => e
        raise "NewsletterService.newsletters_group_id Misconfigured: #{e}"
      end
    end

    def newsletters_mapping
      @@newsletters_mapping ||= begin
        if $redis.hlen(MAPPING_KEY) > 0 then $redis.hgetall(MAPPING_KEY)
        else
          raw = list.interest_categories( newsletters_group_id ).interests.retrieve.body['interests'].each_with_object({}) { |interest, hash| hash[interest['name']] = interest['id'] }
          raw.tap { |v| $redis.hmset(MAPPING_KEY, *v.to_a) }
        end
      rescue StandardError => e
        raise "NewsletterService.newsletters_mapping Misconfigured: #{e}"
      end
    end

    def sync_member(user)
      mid = upsert_member(user, preferences(user))
      user.update_attribute(:mailchimp_id, mid) unless user.mailchimp_id == mid
    end

    private

    def preferences(user)
      preferences = (user.newsletter_preferences || {}).transform_values {|v| v != '0' }

      newsletters_mapping.values.each_with_object({}) do |id, hash|
        hash[id] = preferences.has_key?(id) ? preferences[id] : true
      end
    end

    def upsert_member(user, newsletters)
      member(user).upsert(body: data(user, newsletters)).body['id']
    end

    def data(user, newsletters)
      {
        email_address: user.email,
        status: "subscribed",
        merge_fields: {
          FNAME: user.first_name,
          FULL_NAME: user.name,
        },
        interests: newsletters,
      }
    end

    def member(user)
      list.members( user.mailchimp_id || Digest::MD5.hexdigest(user.email) )
    end

    def list
      api.lists(LIST_ID)
    end

    def api
      Gibbon::Request.new(api_key: ENV.fetch('MAILCHIMP_KEY'), debug: Rails.env.development?)
    end

  end

end
