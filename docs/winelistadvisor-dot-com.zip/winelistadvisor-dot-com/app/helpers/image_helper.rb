module ImageHelper

  def image_url(name)
    asset_pack_url("src/images/#{name}")
  end

  def webpack_image_tag(name, opts = {})
    image_tag image_url(name), opts
  end

  def blazyBG(bg_image)
    ext = File.extname(bg_image)
    base = bg_image.sub(/#{ext}$/, '')

    {
      data: {
        :src         => image_url(bg_image),
        :'src-480'   => image_url( [base, '_480', ext].join ),
        :'src-1200'  => image_url( [base, '_1200', ext].join ),
      },
      class: 'blazy-bg',
    }
  end

  def blazy_image(src, alt: nil)
    ext = File.extname(src)
    base = src.sub(/#{ext}$/, '')

    opts = {
      data: {
        :src         => image_url(src),
        :'src-480'   => image_url( [base, '_480', ext].join ),
        :'src-1200'  => image_url( [base, '_1200', ext].join ),
      },
      alt: alt,
      class: 'blazy-img',
    }

    webpack_image_tag [base, '_placeholder', ext].join, opts
  end

end