# frozen_string_literal: true

module RestaurantsHelper

  def new_restaurant_review_path(r, bookmark_id: nil)
    # Hook to implement manually passing external IDs (yelp, single platform) if necessary
    review_restaurant_path(r, bookmark_id: bookmark_id)
  end

  def progress_bar(count:, percent:, color:)
    content_tag(:div, class: 'progress') do
      [
        content_tag(:div, '', class: "progress-bar progress-bar-#{color}", aria: {valuemax: 100, valuemin: 0, valuenow: percent}, role: 'progressbar', style: "width: #{percent}%"),
        content_tag(:span, pluralize(count, 'review'), class: 'progress-label text-right')
      ].join.html_safe
    end
  end

  def rating_breakdown(row_label, row_data)
    [
      content_tag(:div, class: "col-xs-3 col-md-3 text-right") do
        content_tag(:span, row_label, class: "glyphicon glyphicon-star")
      end,
      content_tag(:div, progress_bar(row_data), class: "col-xs-8 col-md-9")
    ]
  end

  def review_breakdown(reviewable)
    total = reviewable.reviews.by_members.count.to_f
    data = Hash.new {|hash, key| hash[key] = {count: 0, percent: 0}}

    reviewable.reviews.by_members.select{|r| r.persisted?}.each do |r|
      data[r.rating.to_f.ceil][:count] += 1
    end

    data.keys.each do |k|
      data[k][:percent] = (data[k][:count] / total * 100).round
    end

    [:success, :primary, :info, :warning, :danger].each.with_index do |color, idx|
      data[5 - idx][:color] = color
    end

    data.sort.reverse.map do |row_label, row_data|
      rating_breakdown row_label, row_data
    end.flatten.join.html_safe
  end

end
