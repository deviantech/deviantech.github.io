# frozen_string_literal: true

module ApplicationHelper
  include UrlHelpers
  include SharingHelpers
  include SocialNetworkLogos
  include CacheHelper
  include ImageHelper

  def dropzone_data(context:, existing:)
    {
      url: '/attachments',
      uploaded: Array(existing).map {|p| [p.id, p['image'], p.file_size, p.image.url(:thumb)]},
      context: context.select {|k,v| v.present?}.to_json
    }
  end

  def wall_post_dropzone_data(activity)
    base_images = activity.persisted? ? activity.images : user_signed_in? ? Current.user.user_images.pending_for_any_wall_post : []
    dropzone_data existing: base_images, context: {
      kind: 'wall_post',
      activity_id: activity.id,
    }
  end

  def lightbox_link(thumb_url, full_url, title: nil, gallery: nil, hidden: false, thumb_class: nil, text: false)
    data = gallery ? {'lightbox-gallery': gallery} : {lightbox: 'image'}
    data[:title] = title if title

    img = hidden ? '' : text ? thumb_url : image_tag(thumb_url, class: ['image-thumb', thumb_class].compact.join(' '))
    link_to img, full_url, data: data, class: hidden ? 'hide' : ''
  end

  def daniel_email
    mail_to 'daniel@winelistadvisor.com'
  end

  def daniel_phone
    link_to "(415) 391-9476", "tel:4153919476"
  end

  def daniel_website
    link_to 'dfederlaw.com', 'http://www.dfederlaw.com', target: '_blank'
  end

  def likes_modal_link(target)
    if target.likes_count.zero?
      return Current.user ? 'Not yet liked' : ''
    end
    klass = target.class.name.sub('Decorator', '')

    link_to_modal pluralize(target.likes_count, 'like'), show_likes_url(klass, target.id)
  end

  def meta_tags_for_display
    (@og_meta ||= set_og(website_og_meta)).merge(site: 'WineListAdvisor')
  end

  def define_canonical_url
    if url = @og_meta.dig(:og, :url)
      %Q{<link rel="canonical" href="#{url}" />}.html_safe
    end
  end

  def website_og_meta
    {
      type: 'website',
      url: root_url,
      title: 'WineListAdvisor',
      description: "WLA is an exciting and fun community of epicurean enthusiasts dedicated to connecting with each other through digital media.",
      image: {
        url: App.s3_asset_link('logo-black.png'),
        alt: "WineListAdvisor",
        height: 300,
        width: 300,
      },
      _: {
        fb: {
          pages: [App.social[:facebook]]
        }
      }
    }
  end

  def set_og(hash)
    top_level = hash.delete(:_)
    @og_meta = {}.merge(top_level).merge(og: hash)
    @og_meta[:fb] ||= {}
    @og_meta[:fb][:app_id] = ENV.fetch('FACEBOOK_APP_ID')

    if @og_meta.dig(:og, :image).present?
      if @og_meta[:og][:image].is_a?(Array)
        @og_meta[:og][:image].each_with_index do |img, idx|
          @og_meta[:og][:image][idx][:url] = absolutize_url(img[:url])
        end
      else
        @og_meta[:og][:image][:url] = absolutize_url(@og_meta[:og][:image][:url])
      end
    end

    @og_meta
  end

  def fb_share_url(url:, return_to: user_home_url)
    u = Addressable::URI.parse("http://www.facebook.com/dialog/send")
    u.query_values = {
      app_id: ENV.fetch('FACEBOOK_APP_ID'),
      link: url,
      redirect_uri: return_to
    }

    u.to_s
  end

  # Link needs to be an join w/ auto-friend request
  def invite_fb_friends_url
    return unless user_signed_in?
    fb_share_url(url: invited_by_url(Current.user.token))
  end

  def like_link(target, opts = {})
    render 'likes/like', opts.merge(target: target)
  end

  # capitalize: by default capitalizes names but downcases 'You/My'. false downcases all, true upcases all.
  def user_name(user, context: nil, capitalize: :default, personalize_to_you: true, me_or_you: :you, first: false)
    if user.nil?
      txt = :possessive == context ? "someone's" : 'someone'
      true == capitalize ? txt.capitalize : txt
    elsif personalize_to_you && Current.user && Current.user == user
      txt = if :you == me_or_you
        :possessive == context ? 'your' : 'you'
      else
        :possessive == context ? 'my' : 'me'
      end
      true == capitalize ? txt.capitalize : txt
    else
      base_name = first ? user.first_name : user.name
      :possessive == context ? "#{base_name}'s" : base_name
    end
  end

  def user_possessive_it(user)
    user == Current.user ? 'your' : "their"
  end

  def user_link(user, **args)
    text = args.delete(:text) || user_name(user, args)

    return text unless user
    link_to text, profile_user_path(user)
  end

  def remove_from_conversation_link(users, conversation: @conversation)
    users = Array(users)
    msg = "Are you sure you want to kick #{users.map(&:name).to_sentence} from this conversation?"
    link_to 'x', remove_users_conversation_path(conversation, conversation: {user_ids: users.map(&:id)}), remote: true, method: :post, class: 'close', data: {confirm: msg}
  end

  def leave_conversation_link(conversation: @conversation, link_class: '')
    msg = 'Are you sure you want to leave this conversation?'
    link_to 'Leave', leave_conversation_path(conversation), method: :post, class: link_class, data: {confirm: msg}
  end

  def user_avatar(user, size: 50, shape: :circle, link: false, **opts)
    klass = [opts[:class], 'avatar', "s#{size}"].join(' ')
    klass = "#{klass} img-hover" if link
    img = image_tag user.avatar.url("s#{size}"), {alt: user.name}.merge(opts).merge(class: "img-#{shape} #{klass}")

    link ? link_to(img, link == true ? user : link) : img
  end

  # Merge two hashes, joining any duplicated keys (e.g. link options, duplicate rather than override classes)
  def string_combining_merge(hash, other)
    other.keys.each do |key|
      if (val = hash[key]).present?
        hash[key] = (val.split + other[key].split).uniq.join(' ')
      else
        hash[key] = other[key]
      end
    end

    hash
  end

  def show_field_errors(f, field)
    return unless f.object.errors[field].any?
    f.error_notification message: f.object.errors[field].join('<br>')
  end

  def link_to_modal(text, url, opts = {}, &block)
    opts[:data] = opts[:data] || {}
    opts[:data][:toggle] = 'remote-modal'
    opts[:remote] = true

    if sz = opts.delete(:modal_size)
      opts[:data]['modal-size'] = sz
    end

    block_given? ? link_to(url, opts, &block) : link_to(text, url, opts)
  end

  # Centralized to enable adding icons or other chrome consistently
  def flag_link(flaggable, button: true)
    return unless user_signed_in?

    returnable = if Current.user&.moderator?
      content_tag :div, class: 'flag_link' do
        concat( content_tag(:span, "Moderator Hidden", class: 'text-danger') ) if flaggable.moderator_hidden?
        concat( content_tag(:span, "Flags: #{flaggable.flag_count}", class: 'flags_count') ) unless flaggable.flag_count.zero?
      end
    else ''
    end

    unless flaggable.moderator_hidden?
      css_classes = button ? 'btn btn-xs btn-danger' : 'text-danger'

      returnable += if flag = Current.user && Current.user.flaggings.on(flaggable).first
        link_to_modal "Update Flag", edit_flagging_path(flag), class: css_classes
      else
        link_to_modal "Flag #{flaggable.flaggable_name}", send(flaggable.flagging_path_name, flaggable), class: css_classes
      end
    end

    returnable.html_safe
  end

  def show_dollars(num)
    return 'n/a' unless num.to_f > 0
    return '< $1' unless num.to_i > 0
    number_to_currency num.to_f, precision: 0
  end

  def save_button(to_save, opts = {})
    singular = to_save.class.name.underscore.sub(/_decorator/, '')
    plural = singular.pluralize

    render "#{plural}/save_button", opts.merge(singular.to_sym => to_save)
  end

  def link_if_user(text, url=nil, &url_generator)
    return text unless user_signed_in?
    link_to text, url || url_generator.call
  end

  def glyph(name, opts = {})
    content_tag('i', nil, add_class_to_hash(opts, "glyphicon glyphicon-#{name}"))
  end

  def icon(name, opts = {})
    webpack_image_tag "icons/#{name}.png", {class: "icon #{name}", alt: "Icon - #{name.capitalize}"}.merge(opts)
  end

  def show_flash(kind, msg = nil, untrusted_message: nil, close: false, &block)
    msg = capture(&block) if block_given?
    msg = msg.present? ? msg.html_safe : untrusted_message

    render 'shared/flash', kind: kind, msg: msg, close: close
  end

  def show_star_rating(rateable, field: nil, size: 'xs', with_count: false)
    return unless rateable
    field ||= rateable.respond_to?(:member_rating) ? :member_rating : :rating

    rating = rateable.send(field)
    rating_count = with_count && rateable.respond_to?(:member_ratings_count) ? rateable.member_ratings_count : 0
    rating_count = rating_count > 0 ? %Q{<span class="rating-count">(#{rating_count})</span>} : nil

    %Q{<div class="rating-wrapper"><input id="#{dom_id(rateable, :rating)}" data-display-only="true" type="number" value="#{rating}" class="rating" min=0 max=5 step=0.5 data-size="#{size}">#{rating_count}</div>}.html_safe
  end

  def submit_link(article, opts = {})
    txt = 'Submit for Publication'
    opts[:class] = ['btn btn-primary', opts.delete(:class)].compact.join(' ')
    msg = "Are you sure you're ready to submit this article for review?"
    msg += " We strongly recommend uploading a high quality featured image if possible..." unless article.featured_image?
    link_to txt, submit_article_path(article), opts.merge(method: :patch, data: { confirm: msg })
  end

  def nav_link(text, path = nil, active_fn: nil, badge: nil, **opts, &block)
    path = text if block_given?

    opts[:class] ||= ['nav-link', opts.delete(:muted) ? 'muted' : nil].compact.join(' ')
    is_active = current_page?(path) || active_fn&.call
    li_class = [opts.delete(:li_class), 'nav-item', is_active ? 'active' : nil].compact.join(' ')

    link = if block_given?
      link_to path, opts, &block
    else
      if badge.to_i > 0
        text = content_tag(:span) do
          concat text
          concat content_tag(:span, badge, class: 'badge badge-default')
        end
      end
      link_to content_tag(:span, text), path, opts
    end

    content_tag(:li, link, class: li_class)
  end

  def action_link(text, path, opts = {})
    nav_link(text, path, opts.merge(li_class: 'action'))
  end

  # Override administrate page names for articles
  def display_resource_name(name)
    case name.to_s
    when 'engagement_redemptions' then 'Gift Cards'
    when 'tag', 'gutentag/tag' then 'Tags'
    when 'faqs' then 'FAQs'
    else
      super rescue name.to_s.titleize
    end
  end

  def sanitized_order_params
    params.permit(:search, :id, :order, :page, :per_page, :direction, :orders, :scope)
  end

  def clear_search_params
    params.except(:search, :page).permit(:order, :direction, :per_page, :scope)
  end

  private

  def add_class_to_hash(hash, klazz)
    (hash || {}).tap do |h|
      h[:class] = [h[:class], klazz].join(' ')
    end
  end

  def absolutize_url(img)
    return img unless img.starts_with?('/')

    u = Addressable::URI.parse(img)
    u.host ||= Rails.application.config.action_mailer.default_url_options[:host]
    u.scheme ||= 'https'
    u.to_s
  end

end
