# frozen_string_literal: true

module UrlHelpers

  def view_flagged_url(flagged)
    case flagged
    when Comment  then view_comment_url(flagged)
    when Review   then view_review_url(flagged)
    when Activity then view_activity_url(flagged)
    else raise(NotImplementedError)
    end
  end

  def view_review_url(review)
    case review.reviewable
    when Restaurant then restaurant_review_url(review.reviewable, review)
    else raise(NotImplementedError)
    end
  end

  def view_reviewable_url(reviewable)
    case reviewable
    when Restaurant then restaurant_url(reviewable)
    else raise(NotImplementedError)
    end
  end

  def view_comment_url(comment)
    case comment.commentable
    when Article  then article_url(comment.commentable, anchor: dom_id(comment))
    when Activity then view_activity_url(comment.commentable, anchor: dom_id(comment))
    else raise(NotImplementedError)
    end
  end

  def view_liked_url(like)
    thing = like.is_a?(Like) ? like.thing : like
    case thing
    when Activity   then view_activity_url(thing)
    when Article    then article_url(thing)
    when Restaurant then restaurant_url(thing)
    when Review     then view_review_url(thing)
    else raise(NotImplementedError)
    end
  end

  def view_activity_url(activity, opts={})
    user_activity_url(activity.user, activity, opts)
  end

end
