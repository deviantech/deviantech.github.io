# frozen_string_literal: true

module SocialNetworkLogos

  def social_network_icon(network, label: nil, size: :normal, path: nil)
    label ||= network.to_s.titleize
    path ||= send("user_#{network}_omniauth_authorize_path")

    content_tag :a, href: path, class: "social-network-icon #{network} #{size}" do
      concat(inline_svg("logos/#{network}"))
      concat content_tag(:span, label)
    end
  end

  # based on https://robots.thoughtbot.com/organized-workflow-for-svg
  # need inlining to be able to style with CSS
  def inline_svg(filename, options = {})
    return if Rails.env.test?
    protocol = "http#{Rails.env.development? ? '' : 's'}"
    file = asset_pack_url("src/images/#{filename}.svg", protocol: protocol, host: "#{protocol}://#{App.domain}")
    doc = Nokogiri::HTML::DocumentFragment.parse open(file).read.force_encoding("UTF-8")
    svg = doc.at_css "svg"

    if options[:class].present?
     svg["class"] = options[:class]
    end

    raw svg
  end

end
