# frozen_string_literal: true

module AdminHelper

  # NOTE: this is reaching into administrate internals in order to render our custom actions when we're showing a resource nested
  def render_contest_entries_collection(page:, resource:)
    field = page.send(:attribute_field, page.send(:dashboard), resource, :entries, :show)
    render "collection",
      collection_presenter: field.associated_collection,
      resources: field.resources,
      custom_actions_path: 'entry_actions',
      custom_actions_locals: { contest: resource }
  end

  def dashboard_link
    url = namespace == 'moderation' ? moderation_root_path : admin_root_path
    link_to 'Dashboard', url, class: "navigation__link navigation__link--#{'in' unless controller_name == 'dashboard'}active"
  end

  def resource_pending_count(resource)
    klass = resource_klass(resource)
    resource.namespace == 'moderation' ? klass.moderator_pending.count : klass.pending.count
  end

  def resource_klass(resource)
    r = resource.respond_to?(:resource) ? resource.resource : resource
    r == 'tags' ? Gutentag::Tag : r.to_s.classify.constantize
  end

  def source_link(resource)
    decorated = resource.decorate rescue nil
    decorated ? decorated.source_link : resource.label
  end

  # Workaround to damn ActsAsTaggableOn::Tag/Gutentag::Tag namespacing
  def action_url(resource, action = nil)
    resource_klass_name = resource.class.name.split('::').last.underscore
    route_name = [action, 'moderation', resource_klass_name, 'path'].compact.join('_')

    send(route_name, resource.id)
  end

  def contests_nav_link_state(resource)
    request.path.include?('/contests/') && request.path.include?( resource.to_s ) ? :active : :inactive
  end


end
