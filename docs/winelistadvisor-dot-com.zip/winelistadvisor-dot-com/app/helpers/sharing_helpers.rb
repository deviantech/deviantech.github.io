# frozen_string_literal: true

module SharingHelpers

  def restaurant_menu_social_share_button(menu_or_restaurant)
    menu, restaurant = if menu_or_restaurant.is_a?(SpMenu)
      [menu_or_restaurant, menu_or_restaurant.restaurant]
    else
      [nil, menu_or_restaurant]
    end

    if menu
      title = "#{restaurant.name}'s Menu: #{menu.name}"
      title = "#{restaurant.name}'s Menu" if menu.name == restaurant.name
      show_share_btns title: title, url: menu_restaurant_url(restaurant, menu)
    else
      show_share_btns title: "#{restaurant.name}'s Menus", url: menus_restaurant_url(restaurant)
    end
  end

  def tasting_profile_social_share_button(profile)
    owner = profile.user
    who = owner == Current.user ? "My" : "#{owner.name}'s"

    title = "#{who} Wine Tasting Profile"
    show_share_btns title, url: tasting_profile_user_url(owner)
  end

  def article_social_share_button(article)
    show_share_btns "Article #{article.title}", url: article_url(article)
  end

  def comment_social_share_button(comment)
    commentable = comment.commentable

    who = comment.user == Current.user ? 'My' : "#{comment.user.name}'s"

    what = case commentable
    when Article  then %Q{article "#{commentable.name}"}
    when Activity then "#{user_name(commentable.user, context: :possessive, me_or_you: :me)} activity"
    else commentable.label
    end

    title = "#{who} comment on #{what}"
    anchor = comment ? "##{dom_id(comment)}" : ''
    show_share_btns title, url: url_for(commentable) + anchor
  end

  def activity_social_share_button(activity)
    return unless activity.topic == 'wall_post'

    title = "#{user_name activity.user, context: :possessive, me_or_you: :me} posting"

    show_share_btns title, url: view_activity_url(activity)
  end

  def restaurant_social_share_button(restaurant)
    title = "Restaurant #{restaurant.name}"

    show_share_btns title, url: view_reviewable_url(restaurant)
  end

  def review_social_share_button(review)
    reviewable = review.reviewable

    who = user_name review.user, context: :possessive, me_or_you: :me
    title = "#{who} review of #{reviewable.reviewable_name}: #{review.rating_num}/5"

    show_share_btns title: title, url: review ? view_review_url(review) : view_reviewable_url(reviewable)
  end

  def member_social_share_button(user)
    who = user_name(user, context: :possessive, me_or_you: :me)
    title = "#{who} profile on WineListAdvisor.com"

    show_share_btns title: title, url: profile_user_url(user)
  end

  private

  # If title passed as string, "on WineListAdvisor" will be appended. To avoid, pass directly as title: option.
  def show_share_btns(title = nil, opts)
    title = title.present? ? "#{title} on WineListAdvisor" : opts.delete(:title)

    social_share_button_tag title, opts.merge(via: App.social_handles[:twitter])
  end

end
