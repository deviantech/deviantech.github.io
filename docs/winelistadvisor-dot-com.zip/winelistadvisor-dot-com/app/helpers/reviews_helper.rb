# frozen_string_literal: true

module ReviewsHelper

  def bookmarks_path(bookmarkable, opts = {})
    opts = opts.merge(bookmarkable_id: bookmarkable.id)
    named_path = "#{bookmarkable.class.name.sub('Decorator', '').underscore}_bookmarks_path"

    send(named_path, bookmarkable, opts)
  end

  def reviews_path(reviewable, opts = {})
    opts = opts.merge(reviewable_id: reviewable.id, reviewable_type: reviewable.class.name)
    named_path = "#{reviewable.class.name.sub('Decorator', '').underscore}_reviews_path"

    send(named_path, reviewable, opts)
  end

  def review_dropzone_data(review)
    base_images = review.persisted? ? review.images : user_signed_in? ? Current.user.user_images.pending_for_review_of(review.reviewable) : []
    dropzone_data existing: base_images, context: {
      kind: 'review',
      restaurant_id: review.reviewable.id,
      review_id: review.id,
    }
  end

end
