# frozen_string_literal: true

module CacheHelper

  def cache_for_anonymous(*keys, &block)
    cache_if current_user.blank? && Current.user.blank?, keys, &block
  end

end
