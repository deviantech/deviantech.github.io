const createChannel = (app) => {

  const initConversation = (conversation) => {
    let $conversation = $(conversation)
    const conversation_id = $conversation.data('conversationId')
    let $messages = $conversation.find('.messages')
    const $input = $conversation.find('#message_body')
    const $form = $input.parents('form').first()
    const $uid = WLA.currentUser()

    const checkTyping = () => {
      return $input.val().length > 0
    }
    let $isTyping = checkTyping()

    const messagesToBottom = () => {
      $messages.scrollTop($messages.prop("scrollHeight"))
    }
    messagesToBottom()

    app.conversations = app.conversations || {}
    app.conversations[conversation_id] = app.cable.subscriptions.create({
        channel: "ConversationChannel",
        conversation_id: conversation_id
      }, {
        connected() {
          this.install()
        },
        disconnected() {
          this.uninstall()
        },
        rejected() {
          this.uninstall()
        },
        received(data) {
          this[`received_${data['topic']}`](data)
        },

        received_typing(data) {
          // TODO: add this to the UI
          // TODO: pass user's name (escaped!) along w/ the data, render it w/ react somewhere
          if (data['who'] == $uid) return
          console.log(`Someone's typing status updated`, data)
          WLA.show('success', `${data['who']} ${data['typing'] ? ' is typing' : ' stopped typing'}`)
        },

        received_message(data) {
          // NOTE: message gets rendered as current user, so we add logic here to check whether the author matches who we're showing it to.
          let side = data['who'] == $uid ? 'right' : 'left'
          let body = $( data['message'] ).removeClass('message-right').addClass(`message-${side}`)
          WLA.append($messages, body, {cb: () => messagesToBottom()});
        },

        update_typing_indicator() {
          let val = checkTyping()
          if ($isTyping != val) {
            $isTyping = val
            return this.perform('set_typing_indicator', {typing: val, who: $uid});
          }
        },

        send_message(message) {
          WLA.clearForm($form)
          $input.focus()
          return this.perform('send_message', {message})
        },

        install() {
          $input.on('keyup.conversation', () => this.update_typing_indicator())
          $input.parents('form').on('submit.conversation', (e) => {
            e.preventDefault()
            e.stopPropagation()

            this.send_message( $input.val() )
          })
        },

        uninstall() {
          $(document).off(".conversation")
        },
    });

  }

  app.tell({
    pageIn: () => {
      $('.conversation').each((idx, conv) => initConversation(conv, app))
      $('.conversation .message_body input').first().focus()
    }
  })

}

export default createChannel