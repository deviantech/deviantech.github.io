const createChannel = (app) => {
  app.cable.subscriptions.create("WebNotificationsChannel", {
    received: (data) => {
      if ('notification' == data['topic']) {
        if ($('.dropdown-notifications #notification_'+data['notification_id']).length == 0) {
          $('.dropdown-notifications ul.notifications').prepend(data['body'])
          WLA.notifications.increment_unread()

          WLA.show(data['kind'], $(data['body']).find('.notification-title').html())
        }
      } else if ('engagement' == data['topic']) {
        WLA.show(data['kind'], data['body'])
      } else {
        WLA.show(data['kind'], data['body'])
      }
    }
  })
}
export default createChannel