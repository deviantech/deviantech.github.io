import ActionCable from 'actioncable'

import createConversations from './channels/conversation'
import createNotifications from './channels/web_notification'

const createCable = (app) => {
  app.cable = ActionCable.createConsumer()
  createNotifications(app)
  createConversations(app)
}

export default createCable