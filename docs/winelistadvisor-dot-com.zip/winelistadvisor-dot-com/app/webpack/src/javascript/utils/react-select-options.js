export const convertToInternalOption = (ext) => {
  if (typeof(ext) == 'object') {
    if (ext.length == 2) {
      return {value: ext[0], label: ext[0], description: ext[1]}
    }
    return {value: ext[0], label: ext[1], description: ext[2]}
  }

  return {value: ext, label: ext}
}

export const optionRenderer = (option) => {
  if (option.description) {
    return <div>
      <dt>
        <strong className="select-item-label">{option.label}</strong>
      </dt>
      <dd>
        <span className="select-item-description">{option.description}</span>
      </dd>
    </div>
  } else {
    return option.value
  }
}


const handlePropOptions = (option) => {
  if (typeof(option) == 'string') {
    return convertToInternalOption(option)
  } else if (typeof(option) == 'object') {
    return option.map((tag) => convertToInternalOption(tag))
  } else {
    console.log(`Got unhandled option: ${option}`)
    return ''
  }
}

const handlePropSelected = (ids, multi = false) => {
  if (!ids) {
    return multi ? [] : ''
  } else if (typeof(ids) == 'object') {
    return multi ? ids : ids.join(',')
  } else {
    return ids
  }
}

export const initialSelectState = (props) => {
  // Convert provided array of tags to the [{value: x, label: x}] format react-select expects
  return {
    options: handlePropOptions(props.options),
    values: handlePropSelected(props.selected),
  }
}

export default initialSelectState