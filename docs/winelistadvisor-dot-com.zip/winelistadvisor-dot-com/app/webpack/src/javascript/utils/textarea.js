// Grow textarea as content is added: http://jsfiddle.net/C8e4w/1/
const autogrowTextareasIn = (target) => {
  $(target).on( 'change keyup keydown paste cut', 'textarea', function (){
    $(this).height(0).height(this.scrollHeight)
  }).find( 'textarea' ).change()
}


export default autogrowTextareasIn