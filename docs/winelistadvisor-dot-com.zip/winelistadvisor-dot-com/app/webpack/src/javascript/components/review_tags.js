import Select from 'react-select'
import { convertToInternalOption, optionRenderer } from 'Utils/react-select-options'

class ReviewTags extends React.Component {
  state = {
    creatable: this.props.creatable,
    // Convert provided array of tags to the [{value: x, label: x}] format react-select expects
    options: this.props.options.map((tag) => convertToInternalOption(tag)),
    values: this.props.selected.map((tag) => convertToInternalOption(tag)),
  }

  handleChange = (newVals) => {
    this.setState({values: newVals})
  }

  promptTextCreator = (label) => `Create new tag: ${label}`

  onInputChange = (input) => {
    return input.toLowerCase()
  }

  render() {
    if (this.state.creatable) {
      return <Select.Creatable
          name='review[tag_names]'
          placeholder='Enter any desired badges...'
          multi={true}
          joinValues={true}
          value={this.state.values}
          options={this.state.options}
          onChange={this.handleChange}
          promptTextCreator={this.promptTextCreator}
          onInputChange={this.onInputChange}
          optionRenderer={optionRenderer}
        />;
    } else {
      return <Select
          name='review[tag_names]'
          placeholder="Badge the restaurant's Wine Program..."
          multi={true}
          joinValues={true}
          openOnClick={true}
          openOnFocus={true}
          value={this.state.values}
          options={this.state.options}
          onChange={this.handleChange}
          optionRenderer={optionRenderer}
        />;
    }
  }
}

export default ReviewTags