import Select from 'react-select'
import {initialSelectState, optionRenderer} from 'Utils/react-select-options'

class SelectWithDescription extends React.Component {
  state = initialSelectState(this.props)

  handleChange = (newVals) => {
    this.setState({values: newVals})
  }

  onInputChange = (input) => {
    return input.toLowerCase()
  }

  render() {
    return <Select
        name={this.props.name}
        placeholder={this.props.placeholder}
        multi={!!this.props.multi}
        joinValues={!!this.props.multi}
        openOnClick={true}
        openOnFocus={true}
        value={this.state.values}
        options={this.state.options}
        onChange={this.handleChange}
        optionRenderer={optionRenderer}
      />;
  }
}

export default SelectWithDescription