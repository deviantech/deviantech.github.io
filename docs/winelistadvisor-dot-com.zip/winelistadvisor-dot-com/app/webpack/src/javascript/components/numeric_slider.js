import InputRange from 'react-input-range'

class NumericSlider extends React.Component {
  static defaultProps = {
    minValue: 1,
    maxValue: 10,
    minLabel: "Don't like at all",
    maxLabel: "Absolutely love it!",
    singleValue: true,
    disabled: false,
  }

  state = {
    value: this.props.value || (this.props.singleValue ? this.props.minValue : { min: this.props.minValue, max: this.props.maxValue })
  }

  formatLabel = (value, type) => {
    if ('min' === type) return this.props.minLabel ? `${value} - ${this.props.minLabel}` : value
    if ('max' === type) return this.props.maxLabel ? `${value} - ${this.props.maxLabel}` : value
    return value
  }

  render() {
    return <InputRange
      minValue={this.props.minValue}
      maxValue={this.props.maxValue}
      value={this.state.value}
      name={this.props.name}
      formatLabel={this.props.formatLabel || this.formatLabel}
      onChange={value => this.setState({ value })}
      disabled={this.props.disabled}
    />
  }
}

export default NumericSlider