import NumericSlider from './numeric_slider';
import PropTypes from 'prop-types'

class PriceRange extends React.Component {
  static defaultProps = {
    minValue: 20,
    maxValue: 100,
    singleValue: false,
    disabled: false,
  }

  static propTypes = {
    name: PropTypes.string.isRequired
  }

  state = {
    value: this.props.value || { min: this.props.minValue, max: this.props.maxValue }
  }

  formatLabel = (value, type) => {
    if ('min' === type) return `< $${value}`
    if ('max' === type) return `$${value}+`
    return `$${value}`
  }

  render() {
    return <NumericSlider
      minValue={this.props.minValue}
      maxValue={this.props.maxValue}
      value={this.state.value}
      name={this.props.name}
      formatLabel={this.formatLabel}
      onChange={value => this.setState({ value })}
      disabled={this.props.disabled}
    />
  }
}

export default PriceRange