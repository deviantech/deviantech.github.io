// Hooks for react-rails' render_component calls from Rails
import WebpackerReact from 'webpacker-react'

global.ReviewTags = require( 'Components/review_tags' ).default;
global.SelectWithDescription = require( 'Components/select_with_description' ).default;
global.NumericSlider = require( 'Components/numeric_slider' ).default;
global.PriceRange = require( 'Components/price_range' ).default;

var componentRequireContext = require.context("../components", true)
var ReactRailsUJS = require("react_ujs")
ReactRailsUJS.useContext(componentRequireContext)


const allComponents = { ReviewTags, SelectWithDescription, NumericSlider, PriceRange }
WebpackerReact.setup(allComponents)


