// core application.js logic
require('Lib/rollbar')

import WlaFactory from './_wla'

window.WLA = WlaFactory()