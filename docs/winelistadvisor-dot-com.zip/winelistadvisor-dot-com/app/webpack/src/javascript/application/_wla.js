import debounce from 'Utils/debounce'

// Listeners can optionally respond to the following:
//      runOnce
//        called: ONCE, not called on subsequent turbolinks loads.
//        use: attach listeners to document (note NOT body, which changes per turbolinks page)
//
//      pageIn
//        called: EACH PAGE LOAD, including turbolinks cache navigation
//        use: direct manipulation
//        notes: must UNDO anything that's not already IDEMPOTENT via 'pageOut'
//
//      pageOut
//        called: just before turbolinks caches the page before navigating away
//        use: undo any non-itempotent changes taken in pageIn
//             (e.g. initializing summernote applies to the element directly, not via an event listener)
//
//      apply
//        called: When new HTML is inserted into the DOM, called on that selector (e.g. WLA.[update/prepend/append])
//        use: direct manipulation. NO EVENT HANDLERS.
//        notes: must UNDO anything that's not already IDEMPOTENT via the page's pageOut
//
// Our own libs - events or internal-to-module only
import ReviewForm from 'Lib/review-form'
import Summernote from 'Lib/summernote'
import OurDropZone from 'Lib/dropzone'
import Modal from 'Lib/modal'
import Lightbox from 'Lib/lightbox'
import ShowOnChange from 'Lib/show-on-change'
import ShowOnClick from 'Lib/show-on-click'
import Search from 'Lib/search'
import Forms from 'Lib/forms'
import Masonry from 'Lib/masonry'
import Scroller from 'Lib/scroller'
import Analytics from 'Lib/analytics'
import Bootstrap from 'Lib/bootstrap'
import ReactRails from 'Lib/react-rails'
import StarRating from 'Lib/star-rating-tweaks'
import CacheSupport from 'Lib/cache-support'
import Images from 'Lib/images'
import NavMenu from 'Lib/nav-menu'

// Our own libs - externally-accessible references to be stored as well
import notifications from 'Lib/notifications'
import restaurant from 'Lib/restaurant'
import prefs from 'Lib/prefs'

// Others, not using our event-based flow
import attachCable from '../cable'

// Autonomous modules we're stacking together to form centralized WLA object
import Flash from 'Lib/flash'
import Geo from 'Lib/geo'
import DomData from 'Lib/dom-data'
import DomUpdates from 'Lib/dom-updates'
import EventLifecycleHandlers from 'Lib/lifecycle'

// Using a factory to ensure we run the event handler connections once when first loaded
const WlaFactory = () => {

  let wla = {
    ...DomUpdates,
    ...DomData,
    ...Flash,
    ...Geo,
    ...EventLifecycleHandlers,

    listeners: [
      Analytics, ReactRails, OurDropZone, Masonry, Scroller, Bootstrap,
      Modal, Search, Forms, Lightbox, StarRating, CacheSupport, Geo,
      ReviewForm, Summernote, ShowOnChange, ShowOnClick,
      Images, NavMenu,

      notifications, restaurant,
    ],

    notifications,
    restaurant,
    prefs,
  }

  attachCable(wla)

  $(document).ready((e) => wla._runOnce())
  $(document).on('turbolinks:load', () => wla._pageIn())
  $(document).on('turbolinks:before-cache', () => wla._pageOut())
  $(window).on('resize orientationchange', debounce(() => wla._resized(), 250))

  return wla
}

export default WlaFactory
