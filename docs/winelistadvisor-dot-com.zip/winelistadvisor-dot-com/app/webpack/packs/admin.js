// Styles
import '../src/stylesheet/admin/index'

// Load in images so we can use webpack instead of sprockets there
// Loading in admin so we can possibly avoid reprocessing on every dev build of application.js
require.context('../src/images/', true, /\.(gif|jpg|png|svg)$/i)