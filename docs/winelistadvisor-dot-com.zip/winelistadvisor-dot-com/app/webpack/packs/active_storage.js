import * as ActiveStorage from "activestorage"
import 'Utils/direct_uploads.js'

ActiveStorage.start()

import '../src/stylesheet/shared/contrib/direct_uploads'