/* eslint no-console:0 */
// This file is automatically compiled by Webpack, along with any other files
// present in this directory. You're encouraged to place your actual application logic in
// a relevant structure within app/javascript and only use these pack files to reference
// that code so it'll be compiled.
//
// To reference this file, add <%= javascript_pack_tag 'application' %> to the appropriate
// layout file, like app/views/layouts/application.html.erb

// Trying to figure out how to load jquery plugins in such a way that the modified $.fn will be returned to the other modules...
window.$ = window.jQuery = require('jquery')
require('jquery.scrollto')
require('magnific-popup')

import Rails from 'rails-ujs';
import Turbolinks from 'turbolinks';


require('bootstrap-sass')
require('select2')
require('bootstrap-star-rating')

require('../src/javascript/application/contrib/social-share-button-js') // Note named w/ -js so imports-loader doesn't wrap .svg files
require('../src/javascript/application/contrib/summernote-without-codemirror') // Note named w/ -js so imports-loader doesn't wrap .svg files

require('../src/javascript/application/index')
require('../src/stylesheet/application/index')

Rails.start()
Turbolinks.start()

require('../src/javascript/shared/react_rails_config') // Call it AFTER turbolinks has been init'ed to hook into turbo events