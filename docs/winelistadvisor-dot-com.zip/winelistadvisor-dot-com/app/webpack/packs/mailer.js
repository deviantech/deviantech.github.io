// Styles for mailer

import '../src/stylesheet/mailer/index'