# frozen_string_literal: true

class Contests::ArticlesController < ApplicationController

  def index
    @page_title = 'Article Contests'
    @contests = Contests::Article.completed.order('id DESC').page(params[:page]).per(params[:per])
  end

  def show
    @contest = Contests::Article.find(params[:id])
  end

end
