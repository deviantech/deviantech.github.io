# frozen_string_literal: true

class RestaurantsController < ApplicationController
  include ProvidesFeaturedAndSearching
  before_action :get_yelp_restaurant, only: [:claim, :show, :view_detail, :menus, :menu, :edit, :update]
  before_action :pull_geo_from_session, only: [:index]

  def for_reviewing
    flash.keep
    flash['info'] = %Q{<h3>Search. Find. Review.</h3> To rate a restaurant, type the restaurant's name and location in the search box below, click the "Leave Review" button, then rate your overall experience and complete the review.}
    redirect_to restaurants_path
  end

  def pull_geo_from_session
    return unless session[:show_restaurants_near]
    lat, lng = session.delete(:show_restaurants_near).to_s.split(',')

    if lng
      params[:latitude] = lat
      params[:longitude] = lng
    end
  end

  def nearby
    # Using geocoder
    if ll = request.location
      if ll.latitude.to_f > 0 || ll.longitude.to_f > 0
        session[:show_restaurants_near] = [ll.latitude, ll.longitude].join(',')
        where = ll.address.present? ? ll.address : [ll.latitude, ll.longitude].join(', ')
        flash[:info] = "Based on your IP address, we're searching near #{where}"
        redirect_to(search_restaurants_path) and return
      end
    end

    @page_title = "Restaurants Near You"
  end

  def show
    @article = Article.get_featured
    render layout: 'restaurant'
  end

  def view_detail
    case params[:detail]
    when 'hours'
      @page_title = @restaurant.sp_hours.present? && @restaurant.model.time_zone ? "Open Hours (#{@restaurant.time_zone})" : 'Open Hours'
    when 'map'
      @page_title = 'Location'
    when 'pairing-guide'
      @page_title = 'Food & Wine Pairing Guide'
    else
      render(nothing: true) and return
    end

    render layout: 'restaurant'
  end

  def menus
    unless @restaurant.sp_menus.any?
      flash[:warning] = "This restaurant doesn't currently have any menus uploaded."
      redirect_to(restaurant_path(@restaurant)) and return
    end

    @page_title = "Menus"
    render layout: 'restaurant'
  end

  def menu
    @menu = MenuDecorator.decorate @restaurant.sp_menus.find(params[:menu_id])
    @page_title = "Menu: #{@menu.name}"
    render 'menus', layout: 'restaurant'
  end

  def claim
    @page_title = "Claim Your Restaurant"

    if @restaurant.claimed?
      flash[:warning] = "This restaurant has already been claimed."
      redirect_to(restaurant_path(@restaurant)) and return
    end

    authorize @restaurant

    render(layout: 'restaurant') and return unless !request.get? &&
      @restaurant.submit_claim!(current_user, claim_params)

    if program = @restaurant.submitted_wine_programs.pending_ownership_claim.by_user(current_user).first
      flash[:success] = "Your claim has been submitted! You will receive a followup email when our admins have reviewed your claim. In the meantime, you may start filling out details about your Wine Program."
      redirect_to edit_restaurant_wine_program_path(@restaurant, program)
    else
      flash.now[:danger] = "There was an error completing your claim"
    end
  end

  def edit
    @page_title = "Edit Restaurant Details"
    authorize @restaurant
    render layout: 'restaurant'
  end

  def update
    authorize @restaurant
    @page_title = "Edit Restaurant Details"

    if @restaurant.update( restaurant_params )
      msg = "Updated restaurant details"
      msg += " (changes will not be visible until your claim has been approved)" unless @restaurant.claimed?
      flash[:success] = msg

      redirect_to restaurant_url(@restaurant)
    else
      flash[:warning] = "Unable to save updates"
      render 'edit', layout: 'restaurant'
    end
  end

  private

  def claim_params
    params.require(:restaurant).permit(:claimant_phone)
  end

  def restaurant_params
    permitted = [:avatar, :avatar_cache, :remove_avatar, wine_program_attributes: WineProgram.permitted_attributes_for(:owner)]
    permitted += [pdf_menus: []] if Current.user&.admin? || policy(@restaurant).update?

    params.require(:restaurant).permit(permitted)
  end

  def title_for_breadcrumb
    "Selected restaurants near #{NowServingLocation.label(@now_serving, short: false)}"
  end

  def title_for_header
    'Great Wine Experiences Start Here.'
  end

  def text_for_leader
    'Discover new and exciting wine experiences! Start now by clicking the restaurants listed below or entering restaurant name and location in search box above.'
  end

  def cta_section_for_footer
    'member_benefits'
  end

end
