# frozen_string_literal: true

class EngagementRewardsController < ApplicationController
end
