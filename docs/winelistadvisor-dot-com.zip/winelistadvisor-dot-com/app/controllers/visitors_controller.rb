# frozen_string_literal: true

class VisitorsController < ApplicationController
  skip_before_action :verify_authenticity_token, only: [:deploy_hook]

  def landing
    if user_signed_in? && !request.url.include?('landing')
      redirect_to user_home_url
    end
  end

  def set_location
    if loc = NowServingLocation.parse( params[:id] )
      session[:geo] = loc
    else
      flash[:warning] = "Unable to parse requested Now Serving location"
    end

    redirect_back unless: /location\//
  end

  # Hook to make sure heroku is started up after deploy
  def deploy_hook
    flash[:success] = "Site was deployed!"
    redirect_to root_path
  end

  def robots
    robots = File.read(Rails.root + "config/robots.#{App.env}.txt")
    render plain: robots
  end

  def sitemap
    redirect_to 'https://s3-us-west-2.amazonaws.com/s3.winelistadvisor.com/sitemaps/sitemap.xml.gz'
  end

end
