# frozen_string_literal: true

class FlaggingsController < ApplicationController
  before_action :get_flagged, only: [:new]
  before_action :get_flagging, only: [:edit, :update, :destroy]

  def new
    @page_title = "Flag this #{flagged_name}"
    @flagging = current_user.flaggings.build(flagged: @flagged, reason: 'inappropriate')
    render 'form'
  end

  def create
    @flagging = current_user.flaggings.create(flagging_params)
  end

  def edit
    @page_title = "Edit flagging of #{flagged_name}"
    render 'form'
  end

  def update
    @flagging.update(flagging_params)
  end

  def destroy
    @flagging.destroy
  end

  private

  def flagging_params
    params.require(:flagging).permit(:flagged_type, :flagged_id, :reason, :notes)
  end

  def get_flagged
    klass = params[:flagged_type].constantize
    klass = klass.friendly if klass.respond_to?(:friendly)
    @flagged = klass.find(params["#{params[:flagged_type].split('::').last.downcase}_id"])
  end

  def get_flagging
    @flagging = current_user.flaggings.find(params[:id])
  end

  def flagged_name
    @flagged ? @flagged.flaggable_name : 'item'
  end
  helper_method :flagged_name

end
