# frozen_string_literal: true

class TastingPreferencesController < ApplicationController
  layout 'users'
  before_action :get_user

  def show
    @page_title = 'Tasting Preferences'
  end

  def edit
    @page_title = 'Edit Tasting Preferences'
  end

  def update
    profile_was_completed = @user.tasting_profile_completed?
    if @user.update(tasting_params)
      msg = if @user.tasting_profile_completed? && !profile_was_completed
        <<-EOT
          <h4>Congrats on completing your Wine Tasting Preferences!</h4>
          Thirsty for wine tips from your friends?
          Get amazing wine recommendations made just for you by #{helpers.link_to 'sharing your Wine Tasting Profile on Facebook', helpers.fb_share_url(url: tasting_profile_user_url(@user))}!
        EOT
      else 'Updated tasting preferences'
      end
      redirect_to tasting_profile_user_path(@user), notice: msg
    else
      edit
      render :edit
    end
  end

  private

  def get_user
    @subnav = 'users/profile_subnav'
    @user = User.find(params[:user_id] || params[:id])
    @user.build_tasting_profile unless @user.tasting_profile || action_name == 'show'
    authorize @user
  end

  def tasting_params
    if params[:user]
      # Because e.g. collection_radio_buttons is inflexible in accepting different input field names, easier to normalize here than in form view
      if (incorrect_params = params.delete(:tasting_profile)).present?
        params[:user][:tasting_profile_attributes] ||= {}
        params[:user][:tasting_profile_attributes] = params[:user][:tasting_profile_attributes].to_unsafe_h.merge(incorrect_params.to_unsafe_h)
      end
    end

    params.require(:user).permit(tasting_profile_attributes: TastingProfile::ALL_VALID_PARAMS)
  end

end
