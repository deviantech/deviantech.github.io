# frozen_string_literal: true

class BookmarksController < ApplicationController
  before_action :get_bookmarkable, only: [:new, :create]
  before_action :get_bookmark, only: [:destroy, :edit, :update]
  before_action :make_bookmark, only: [:new, :create]
  before_action :update_bookmark, only: [:update]
  before_action :authenticate_user!

  def new
    @page_title = "Your bookmark of #{@bookmarkable.label}"
    render '_form'
  end

  def edit
    @page_title = "Edit your bookmark of #{@bookmark.bookmarkable.label}"
    render '_form'
  end

  def create
    @bookmark.mark_tried if params[:tried]
    @bookmark.save
  end

  def destroy
    @bookmark.destroy
    respond_to do |format|
      format.html { redirect_back( restaurants_user_path(current_user) ) }
      format.js
    end
  end

  private

  def get_bookmark
    @bookmark = current_user.bookmarks.find(params[:id])
  end

  def make_bookmark
    @bookmark = current_user.bookmarks.find_or_initialize_by(bookmark_params).tap {|b| b.notes = params.dig('bookmark', 'notes') }
  end

  def update_bookmark
    @bookmark.update notes: params.dig('bookmark', 'notes')
  end

  def get_bookmarkable
    bid = params[:bookmarkable_id] || params["#{params[:bookmarkable_type]&.underscore}_id"]
    @bookmarkable = RestaurantService.get( bid )

    head(:bad_request) unless @bookmarkable
  end

  def bookmark_params
    {
      bookmarkable_id: @bookmarkable.id,
      bookmarkable_type: @bookmarkable.class.name,
    }
  end
end
