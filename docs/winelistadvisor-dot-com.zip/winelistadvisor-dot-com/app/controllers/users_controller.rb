# frozen_string_literal: true

class UsersController < ApplicationController
  include ProvidesFeaturedAndSearching
  before_action :require_user, except: [:index, :show, :profile, :articles]
  before_action :get_user, only: [:show, :edit, :update, :destroy, :points, :profile, :articles]
  before_action :require_self_or_admin, except: [:home, :index, :show, :profile, :activity, :articles]
  before_action :require_self_or_friend, only: [:activity]


  def home
    set_current_user
    @page_title = 'Home'
    @subnav = 'activity_subnav'
    @activity = ActivityDecorator.decorated_feed_for(:home, @user, params[:page], params[:per_page])

    render action: 'activity'
  end

  def activity
    authorize @user, :friend?
    @page_title = "#{helpers.user_name @user, context: :possessive, capitalize: true, first: true} Activities"
    @subnav = 'activity_subnav'
    @activity = ActivityDecorator.decorated_feed_for(:activity, @user, params[:page], params[:per_page])
  end

  def profile
    @page_title = 'Member Profile'
    @subnav = 'profile_subnav'
  end

  def show
    flash.keep

    if request.path != user_path(@user) # Handle friendly-id history
      redirect_to user_path(@user), status: :moved_permanently
    elsif policy(@user).friend?
      redirect_to activity_user_path(@user)
    else
      redirect_to profile_user_path(@user)
    end
  end

  def edit
    authorize @user
    @page_title = @user.tasting_profile_completed? ? 'Edit Profile' : "Welcome, #{@user.first_name}"
    @subnav = 'profile_subnav'
  end

  def update
    authorize @user

    respond_to do |format|
      if @user.update(user_params)
        format.html { redirect_to profile_user_path(@user), notice: 'Profile was successfully updated.' }
        format.json { render :show, status: :ok, location: @user }
      else
        format.html { render :edit }
        format.json { render json: @user.errors, status: :unprocessable_entity }
      end
    end
  end

  def articles
    @subnav = if policy(@user).edit? then 'users/articles_subnav'
    elsif policy(@user).friend? then nil
    else 'users/profile_subnav' # Edge case, looking at stranger's profile can also see published articles
    end

    if user_signed_in? && (current_user == @user) && params[:unpublished]
      @include_unpublished = true
      @articles = @user.articles
      @page_title = 'All Articles'
    end

    @page_title ||= 'Published Articles'
    @articles ||= @user&.published_articles.without_aliased_articles
    @articles = @articles.order('reviewed_at DESC, updated_at DESC').page(params[:page]).per(params[:per_page])

    render @include_unpublished ? 'all_articles' : 'articles'
  end


  # Additional user-only (+admin) profile endpoints (eventually consider making #index action on nested resources):

  def restaurants
    # Based on mockup: https://www.dropbox.com/home/wlx%20web%20final%20files?preview=wlx-profile-restaurants-edit-notes-final.jpg
    @page_title = "Restaurants"
    @subnav = 'restaurants_subnav'

    @want = @user.restaurant_bookmarks.not_tried.preload(:bookmarkable).order('updated_at DESC').page(params[:wanted_page]).per(params[:per_page])
    @done = @user.restaurant_bookmarks.tried.order('id DESC').includes(:bookmarkable, review: [:reviewable, :user]).page(params[:done_page]).per(params[:per_page])
  end

  def claimed_restaurants
    @page_title = "Claimed Restaurants"
    @subnav = 'restaurants_subnav'

    @restaurants = RestaurantDecorator.decorate_collection @user&.claimed_restaurants.page(params[:page]).per(params[:per_page])
  end

  def points
    @page_title = 'Wine Points'
    @subnav = 'activity_subnav'

    @engagements = @user.engagements.page(params[:page]).per(params[:per_page])
  end

  def wine_programs
    @page_title = "Wine List Profiles"
    @subnav = 'restaurants_subnav'

    @wine_programs = @user.submitted_wine_programs.page(params[:page]).per(params[:per_page])
  end

  private

  def get_user
    @user = User.find(params[:id]).decorate
  end

  def user_params
    params.require(:user).permit(:name, :slug, :email, :about, :avatar, :remove_avatar, :avatar_cache, :city, :state)
  end

  def load_featured_scoping_customizations
    @resource_name = 'Members'
    @resource_path_name = 'Users'
  end

  def title_for_breadcrumb
    'Top Contributors'
  end

  def title_for_header
    'Discover Epicureans. Get Connected.'
  end

  def text_for_leader
    msg = <<~EOT
      Connect with leading voices of the epicurean lifestyle.
      Develop relationships with key influencers in the Wine List Advisor community.
      #{user_signed_in? ? "<span class='leader-button-wrapper'>#{helpers.link_to_modal('Invite your friends', new_invitation_path, class: 'btn btn-primary btn-lg center')}</span>" : ''}
    EOT

    msg.html_safe
  end

  def cta_section_for_footer
    'wine_points'
  end

end
