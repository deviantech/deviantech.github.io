# frozen_string_literal: true

class EngagementRedemptionsController < ApplicationController

  def index
  end

  def show 
  end
  
end
