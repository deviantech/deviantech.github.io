# frozen_string_literal: true

module WlaSelect

  private

  def set_wla_select(value, msg)
    if requested_resource.update wla_select: value
      flash[value ? :success : :info] = msg
    else
      flash[:warning] = "Unable to modify 'WLA Select' setting - please try again."
    end

    redirect_to requested_resource
  end

end

