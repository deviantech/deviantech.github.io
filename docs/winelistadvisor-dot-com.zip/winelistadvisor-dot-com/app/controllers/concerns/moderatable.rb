# frozen_string_literal: true

module Moderatable
  extend ActiveSupport::Concern

  included do
    include AdministrateScopedResources
  end

  def moderator_hide
    transitioned_ok = true
    begin
      requested_resource.moderator_hide!(current_user)
      flash[:success] = "Set moderation status to hidden for #{requested_resource.label}"
    rescue ActiveRecord::RecordInvalid
      flash[:warning] = "Error setting moderation status to hidden for #{requested_resource.label}"
      transitioned_ok = false
    end

    redirect_after_action(success: transitioned_ok)
  end


  def moderator_show
    transitioned_ok = true
    begin
      requested_resource.moderator_show!(current_user)
      flash[:success] = "Unhid #{requested_resource.label}"
    rescue ActiveRecord::RecordInvalid
      flash[:warning] = "Error clearing moderation hiding for #{requested_resource.label}"
      transitioned_ok = false
    end

    redirect_after_action(success: transitioned_ok)
  end

  def moderator_dismiss_flags
    begin
      requested_resource.moderator_dismiss_flags!(current_user)
      flash[:success] = "Dismissed all flags on #{requested_resource.label}"
    rescue ActiveRecord::RecordInvalid
      flash[:warning] = "Error dismissing all flags on #{requested_resource.label}"
    end

    redirect_back
  end


  protected

  def valid_base_scopes
    %w(moderator_pending moderator_hidden)
  end
end
