# frozen_string_literal: true

# Requires _featured_result, _search_result, _search_sidebar partials, a Searcher for the containing class,
# and a :featured scope.
module ProvidesFeaturedAndSearching
  extend ActiveSupport::Concern

  included do
    helper_method :overrides_featured_with, :title_for_breadcrumb, :title_for_header, :text_for_leader, :cta_section_for_footer
  end

  def index
    load_featured_scoping_customizations
    @page_title = title_for_breadcrumb if title_for_breadcrumb.present?

    @search = searcher_klass.new(current_user, page: params[:page], scope: params[:scope], params: search_params, now_serving: @now_serving)

    if request.xhr? && (params[:page].to_i > 1 || params[:scope] == 'remote')
      render partial: 'search_result', collection: @search.results, as: entity_name, layout: false
    else
      render 'searchable/index', layout: 'application'
    end
  end

  private

  def searcher_klass
    "Searchers::#{entity_name.classify}".constantize
  end

  def entity_name
    self.class.name.sub('Controller', '').singularize.underscore
  end

  def param_name
    searcher_klass.name.underscore.sub('/', '_')
  end

  def search_params
    params[param_name] ||= {} if params.has_key?(:latitude)
    move_params :latitude, :longitude, to: param_name

    params.require(param_name).permit( *searcher_klass.permitted_fields )
  end

  def move_params(*param_names, to:)
    params[to] ||= {}
    param_names.each do |n|
      params[to][n] = params.delete(n)
    end
  end

  def load_featured_scoping_customizations
  end

  def overrides_featured_with
  end

  def title_for_breadcrumb
  end

  def title_for_header
  end

  def text_for_leader
  end

  def cta_section_for_footer
  end

end
