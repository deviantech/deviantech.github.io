# frozen_string_literal: true

module RouteAliases
  extend ActiveSupport::Concern

  included do

    %w(path url).each do |kind|
      ROUTE_ALIASES.each do |route_new, route_old|
        alias_method "#{route_new}_#{kind}", "#{route_old}_#{kind}"
        helper_method "#{route_new}_#{kind}"
      end
    end

  end

  private

  ROUTE_ALIASES = {
    # For automatic URL creation via Engagement, profile_path must exist, but currently it's just the user's path
    profile: :user,
  }

end
