# frozen_string_literal: true

module BaseControllerLogic
  extend ActiveSupport::Concern

  included do
    include PunditControllerHelper
    include ModalSupport
    before_action :attempt_token_login
    before_action :set_context


    # Enable server_timing gem for admins only in production
    # before_action do
    #   if current_user&.admin? || Rails.env.development?
    #     ServerTiming::Auth.ok!
    #     Rack::MiniProfiler.authorize_request
    #   else
    #     ServerTiming::Auth.deny!
    #   end
    # end
  end

  private

  # Save some keystrokes
  def redirect_back(fallback = nil, **args)
    if args[:unless]
      if referer = request.headers["Referer"]
        if referer =~ args[:unless]
          return redirect_to fallback || root_path
        end
      end
    end

    super(fallback_location: fallback || root_path)
  end

  def set_current_user
    @user = current_user
  end

  def require_user
    return true if user_signed_in?

    if request.get?
      flash[:warning] = 'You must be logged in to access that resource'
      redirect_to new_user_session_path
    else
      raise Pundit::NotAuthorizedError
    end
  end

  def set_context
    @now_serving = NowServingLocation.parse(session[:geo]) || NowServingLocation.default
    Current.user = current_user
  end


  def attempt_token_login
    return true unless params[:auto_login_token]
    return true if user_signed_in?

    if user = User.find_by_token(params[:auto_login_token])
      sign_in(user, scope: :user)
      if request.get?
        redirect_to url_for( params.to_unsafe_h.except(:auto_login_token) )
      end
    end
  end

end
