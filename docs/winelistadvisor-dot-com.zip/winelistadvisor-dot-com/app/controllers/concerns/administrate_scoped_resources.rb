# frozen_string_literal: true

module AdministrateScopedResources
  extend ActiveSupport::Concern

  included do
    helper_method :base_scope, :valid_base_scopes
  end

  private

  def uses_aasm?
    false
  end

  def reject
    if request.get?
      @submission = requested_resource
      @page_title = "Rejecting #{@submission.user.first_name}'s Submission"
    else
      state_transition(:reject)
    end
  end


  # Hook: allow passing extra options to specific actions
  def extra_action_params; {}; end

  # Ensure create action sets the author properly
  def resource_params
    # Would be "extra_action_params.merge( super )" if pundit didn't also have a permitted_attributes method
    extra_action_params.merge( params.require(resource_name).permit(*dashboard.permitted_attributes) )
  end

  def valid_base_scopes
    super || raise("valid_base_scopes must be implemented in controller including AdministrateScopedResources")
  end

  # base_scope and resource_resolver allow us to override administrate defaults and show, rather
  # than ALL resources, just those in a specific base scope (e.g. separating out published and
  # submitted articles, but using the same controller for both)
  def valid_base_scope?(scope)
    valid_base_scopes.include?(scope)
  end

  def base_scope
    @base_scope ||= begin
      # On index page, default to the first valid scope if none provided, but the show page has to find regardless of scope.
      fallback = 'index' == action_name ? valid_base_scopes.first : :all
      valid_base_scope?(params[:scope]) ? params[:scope] : fallback
    end
  end

  def scoped_resource
    resource_class.send(base_scope)
  end

  def state_field
    :state
  end

  def dashboard
    # Moderation doesn't require scope-specific attributes, because we've already overwritten the views entirely...
    return super if 'moderation' == namespace

    # ... but for admin views, we need to pass the current scope to the ScopedResourcesDashboard
    # dashboard subclass so we can customize what attributes to show based on the current scope.
    # Collections view can use base_scope, but for show we need to pull the current state from the resource itself.
    scope = base_scope || requested_resource&.send(state_field)
    @_dashboard ||= resource_resolver.dashboard_class.new(scope)
  end

  def state_transition(transition_name, label: (transition_name.to_s + 'ed').capitalize, attributes: review_attributes)
    label = label.sub(/eed$/, 'ed')
    transitioned_ok = if uses_aasm?
      requested_resource.attributes = attributes
      requested_resource.send("#{transition_name}!", current_user)
    else
      requested_resource.send(transition_name, current_user)
      requested_resource.update_attributes(attributes)
    end

    if transitioned_ok
      flash[:success] = "#{label} #{requested_resource} - ##{requested_resource.id}"
    else
      flash[:warning] = "Unable to #{transition_name} #{requested_resource} - #{requested_resource.errors.full_messages.to_sentence}"
    end

    redirect_after_action(success: transitioned_ok)
  end

  def review_attributes
    param_name = requested_resource.class.name.underscore
    return {} unless params[param_name]
    params.require(param_name).permit(:review_feedback)
  end

  # Pull name of state machine's status field
  def state_machine_field_name
    requested_resource.class.get_state_machine.attribute_name
  end

  def requested_resources_current_state
    if requested_resource.respond_to?(:current_state_scope)
      requested_resource.current_state_scope
    else
      requested_resource.send( state_machine_field_name )
    end
  end

  def redirect_after_action(success:)
    if success
      scope = valid_base_scope?( requested_resources_current_state ) ? requested_resources_current_state : base_scope

      if request.xhr?
        render inline: %Q{document.location = "#{url_for(action: :index, scope: scope)}"}, type: :haml
      else
        redirect_to action: :index, scope: scope
      end
    else
      redirect_back
    end
  end

end
