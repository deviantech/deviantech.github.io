# frozen_string_literal: true

module Featurable
  extend ActiveSupport::Concern

  # keep track of what classes have included this concern:
  module IncludedIn
    extend self
    @included_in ||= []

    def add(klass)
      @included_in << klass
    end

    def included_in
      @included_in
    end
  end

  included do
    scope :featurable, -> { respond_to?(:published) ? published : all }
    scope :featured, -> { featurable.where.not(featured: nil).order( Arel.sql('featured DESC, random()') ) }
    IncludedIn.add self
  end

  module ClassMethods

    def get_featured(n=1)
      n == 1 ? featured.first : featured.limit(n)
    end

  end
end
