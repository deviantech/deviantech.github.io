# frozen_string_literal: true

module Moderation
  class TagsController < Moderation::ApplicationController
    include Moderatable
  end
end
