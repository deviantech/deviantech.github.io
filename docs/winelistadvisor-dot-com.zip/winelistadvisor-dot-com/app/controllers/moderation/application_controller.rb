# frozen_string_literal: true

module Moderation
  class ApplicationController < Admin::ApplicationController
    before_action :set_context

    private

    def set_context
      @moderation_context = true
      Current.user = current_user
    end

    def authenticate_access
      authenticate_moderator
    end

  end
end
