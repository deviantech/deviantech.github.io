# frozen_string_literal: true

module Moderation
  class ActivitiesController < Moderation::ApplicationController
    include Moderatable
  end
end
