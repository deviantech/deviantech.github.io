# frozen_string_literal: true

module Moderation
  class FlaggingsController < Moderation::ApplicationController

    def dismiss
      do_action :dismiss
    end

    def confirm
      do_action :confirm
    end

   private

   def do_action(act)
    what = "#{requested_resource.user.name}'s flag"

    begin
      requested_resource.send("#{act}!", current_user)
      flash[:success] = "#{what} has been #{act}ed"
    rescue ActiveRecord::RecordInvalid
      flash[:warning] = "Error #{act}ing #{what}"
    end

    redirect_back
   end

  end
end
