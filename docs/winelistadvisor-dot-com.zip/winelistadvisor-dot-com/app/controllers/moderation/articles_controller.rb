# frozen_string_literal: true

module Moderation
  class ArticlesController < Moderation::ApplicationController
    include Moderatable
  end
end
