# frozen_string_literal: true

module Moderation
  class DashboardController < Moderation::ApplicationController

    def index
    end

  end
end
