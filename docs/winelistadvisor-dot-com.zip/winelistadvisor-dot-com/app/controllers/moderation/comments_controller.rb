# frozen_string_literal: true

module Moderation
  class CommentsController < Moderation::ApplicationController
    include Moderatable
  end
end
