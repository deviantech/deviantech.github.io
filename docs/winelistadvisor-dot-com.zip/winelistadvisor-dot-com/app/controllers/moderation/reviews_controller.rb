# frozen_string_literal: true

module Moderation
  class ReviewsController < Moderation::ApplicationController
    include Moderatable
  end
end
