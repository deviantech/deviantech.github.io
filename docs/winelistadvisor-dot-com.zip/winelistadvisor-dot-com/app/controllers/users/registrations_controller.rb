# frozen_string_literal: true

class Users::RegistrationsController < Devise::RegistrationsController
  layout :determine_layout
  before_action :authorize_pundit, only: [:edit, :update]
  before_action :set_page_title, only: [:edit, :update]
  helper_method :default_name, :default_email
  before_action :decorate_user


  def sign_in_with_redirection
    if user_signed_in?
      redirect_to(root_path)
    else
      @action_stored = store_location_for(:user, params[:return_to]).present?
      flash[:info] = "You'll need to log in to access that functionality"
      redirect_to new_user_session_path
    end
  end

  protected

    # Only require current password if editing password
    def update_resource(resource, munged_params)
      if params[:password].present? || params[:password_confirmation].present?
        @passwords_edited = true
        super(resource, my_update_params)
      else
        resource.update_without_password(my_update_params)
      end
    end


    def my_update_params
      ok_newsletter = NewsletterService.newsletters_mapping.map {|name, id| id }
      ok_settings = Notification::CHANNELS.each_with_object({}) {|channel, hash| hash[channel] = Notification::NOTIFICATIONS.keys }

      basics = %i{email password password_confirmation birthday(1i) birthday(2i) birthday(3i)}
      basics += [:current_password] if params[:password].present? || params[:password_confirmation].present?
      basics += [
        newsletter_preferences: ok_newsletter,
        notification_settings: ok_settings,
        identities_attributes: [:id, notify_on: SocialPublishingService::ALL_SOCIAL_NOTIFICATIONS.keys]
      ]

      params.require(:user).permit( *basics )
    end

    def sign_up_params
      params.require(:user).permit(:name, :email, :password, :age, :tos)
    end

    def account_update_params
      params.require(:user).permit(:password, :password_confirmation, :current_password, :email, :birthday)
    end

    def set_page_title
      @page_title = "Edit Account"
      @subnav = 'users/profile_subnav'
    end

    def authorize_pundit
      @user = resource
      authorize @user
    end

    def after_update_path_for(resource)
      user_home_url
    end

    # def after_sign_up_path_for(resource)
    #   user_path(resource)
    # end

    def determine_layout
      user_signed_in? ? 'users' : 'application'
    end

    def default_name
      if resource.name.present?
        resource.name
      elsif session['devise.omniauth_data']
        session['devise.omniauth_data'].dig('info', 'name')
      end
    end

    def default_email
      if resource.email.present?
        resource.email
      elsif session['devise.omniauth_data']
        session['devise.omniauth_data'].dig('info', 'email')
      elsif session['invitation_token']
        @invitation = Invitation.find_by_token(session['invitation_token'])
        @invitation&.email
      end
    end

    def decorate_user
      return unless @user
      @user = @user.decorate
    end
end
