# frozen_string_literal: true

class Users::FriendsController < ApplicationController
  before_action :get_user, :set_subnav
  before_action :require_self_or_friend, only: :index
  before_action :require_self_or_admin, except: :index
  layout 'users'

  def index
    @page_title = "Wine Friends"
    @friends = @user.friends.page(params[:page]).per(params[:per_page])
  end

  def pending
    @page_title = "Pending Friendships"
    @requests = @user.requested_friends
  end

  def invited
    @page_title = "Friendship Invitations"
    @pending_emailed_invitations = @user.invitations.pending.page(params[:emailed_page])
    @pending_internal_invitations = @user.pending_friends.page(params[:internal_page])
  end

  private

  def set_subnav
    @subnav = 'users/friends_subnav' if @user == current_user
  end
end
