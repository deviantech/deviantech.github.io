# frozen_string_literal: true

class Users::OmniauthCallbacksController < Devise::OmniauthCallbacksController

  def callback
    @identity = Identity.update_from_omniauth(request.env["omniauth.auth"])
    @identity ? callback_with_existing_identity : callback_with_new_identity
  end

  Identity::SUPPORTED_NETWORKS.each do |network|
    alias_method network, :callback
  end

  def failure
    Rollbar.warning("Reached failure endpoint in omniauth callbacks controller", request.env["omniauth.auth"])
    flash[:danger] = "Error attempting to connect with external authentication provider - please try again later"
    redirect_to root_path
  end

  private

  # If the identity already exists, then:
  #   If not logged in: log in.
  #   If logged in already: confirm ident not already connected to another user, otherwise success
  def callback_with_existing_identity
    if !user_signed_in?
      @identity.user.update_from_omniauth(request.env["omniauth.auth"])
      @identity.user.save
      flash[:success] = "Logged in via #{@identity.label}"
      sign_in_and_redirect @identity.user
    else
      if @identity.user != current_user
        flash[:danger] = "Another WLA member account has already authorized with this #{action_name} account"
      else
        sign_in @identity.user
        flash[:success] = "Refreshed #{@identity.label}"
      end
      redirect_to networks_path
    end
  end

  # If no current identity, then:
  #   If logged in: try creating new identity for user
  #   Else: try creating new identity AND user
  def callback_with_new_identity
    @identity = Identity.build_from_omniauth(request.env["omniauth.auth"], current_user)

    if @identity.valid?
      if @identity.user.valid? && @identity.save
        @identity.user.update_from_omniauth(request.env["omniauth.auth"])
        @identity.user.save
        if user_signed_in?
          flash[:success] = "Successfully connected external network to your account"
          redirect_to networks_path
        else
          flash[:success] = "Welcome to Wine List Advisor!"
          sign_in_and_redirect @identity.user
        end
      else
        flash[:warning] = "Please complete your membership account details"
        session["devise.omniauth_data"] = request.env["omniauth.auth"].except(:extra) # Avoid overflows
        redirect_to new_user_registration_url
      end
    else
      flash[:danger] = "Unable to create account: #{@identity.errors.full_messages.to_sentence}"
      Rollbar.warn("Invalid data from Omniauth", request.env["omniauth.auth"], @identity, @identity.errors)
      redirect_to user_signed_in? ? networks_path : new_user_session_path
    end
  end

  def networks_path
    edit_user_settings_path(anchor: 'networks')
  end

end
