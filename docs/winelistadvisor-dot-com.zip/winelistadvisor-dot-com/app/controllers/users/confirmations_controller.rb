# frozen_string_literal: true

class Users::ConfirmationsController < Devise::ConfirmationsController
end
