# frozen_string_literal: true

class InvitationsController < ApplicationController
  before_action :get_invitation, only: :show
  before_action :build_invitation, except: [:show, :invited_by]
  before_action :require_user, only: [:new, :create]

  def new
  end

  def create
    @invitation.save
  end

  def show
    if @invitation
      session['invitation_token'] = @invitation.token
      flash[:success] = "You're almost there! Please fill out this form to join #{@invitation.user.name} on WineListAdvisor."
      redirect_to new_user_registration_path
    else
      msg = "No pending invitations match the token code provided"
      msg += " (but you're still welcome to sign up!)" unless user_signed_in?
      flash[:danger] = msg
      redirect_to user_signed_in? ? root_path : new_user_registration_path
    end
  end

  def invited_by
    if inviter = User.find_by_token(params[:id])
      session['invited_by_token'] = params[:id]
      flash[:notice] = "Please create an account to accept <b>#{inviter.name}</b>'s invitation"
    else
      flash[:warning] = "Unable to find your specific invitation, but you're still welcome to join!"
    end

    redirect_to new_user_registration_path
  end

  private

  def get_invitation
    @invitation = Invitation.pending.find_by_token(params[:id])
  end

  def build_invitation
    @page_title = "Invite Friends to WLA"
    @invitation = BulkInvitation.new( invitation_params.merge(user: current_user) ) if user_signed_in?
  end

  def invitation_params
    if params[:bulk_invitation]
      params.require(:bulk_invitation).permit(:emails, :message)
    else
      {}
    end
  end
end
