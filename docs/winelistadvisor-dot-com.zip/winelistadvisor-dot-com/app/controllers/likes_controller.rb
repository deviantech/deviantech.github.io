# frozen_string_literal: true

class LikesController < ApplicationController
  before_action :require_user, except: :show_likes
  before_action :get_thing, only: :create
  before_action :get_like, only: :destroy

  def create
    @like = current_user.likes.of_thing(@thing).create
  end

  def destroy
    @like.destroy
  end

  def show_likes
    @thing = if Like::LIKEABLE_CLASSES.include?(params[:thing_type])
      params[:thing_type].constantize.find(params[:thing_id])
    end
    @page_title = "Liking Details"

    render nothing: true unless @thing
  end

  private

  def get_thing
    @thing = Like.get_likeable(params[:thing_type], params[:thing_id])
  end

  def get_like
    @like = current_user.likes.find(params[:id])
  end

end
