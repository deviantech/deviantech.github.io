# frozen_string_literal: true

module Admin
  class ReviewTagsController < Admin::ApplicationController
  end
end
