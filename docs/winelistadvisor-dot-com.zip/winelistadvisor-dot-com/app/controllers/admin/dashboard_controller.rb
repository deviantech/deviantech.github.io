# frozen_string_literal: true

module Admin
  class DashboardController < Admin::ApplicationController

    def index
    end

  end
end
