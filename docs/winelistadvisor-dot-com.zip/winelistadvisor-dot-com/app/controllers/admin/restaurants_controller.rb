# frozen_string_literal: true

module Admin
  class RestaurantsController < Admin::ApplicationController
    include AdministrateScopedResources
    include WlaSelect

    def approve
      state_transition(:approve)
    end

    def reject
      state_transition(:reject)
    end

    def make_wla_select
      set_wla_select true, "This restaurant has been awarded the WLA Certificate of Excellence"
    end

    def remove_wla_select
      set_wla_select false, "Removed 'WLA Certificate of Excellence' designation from this restaurant."
    end

    private

    def valid_base_scopes
      %w(pending_review claimed)
    end

    def find_resource(identifier)
      RestaurantService.get_local(identifier)
    end

  end
end
