# frozen_string_literal: true

module Admin
  class FaqsController < Admin::ApplicationController
  end
end
