# frozen_string_literal: true

# All Administrate controllers inherit from this `Admin::ApplicationController`,
# making it the ideal place to put authentication logic or other
# before_filters.
#
# If you want to add pagination or other controller-level concerns,
# you're free to overwrite the RESTful controller actions.
module Admin
  class ApplicationController < Administrate::ApplicationController
    include BaseControllerLogic

    before_action :require_user
    before_action :authenticate_access
    helper :all

    private

    # Use this in place of params when generating links to Excel etc.
    # See https://github.com/rails/rails/issues/26289
    def safe_url_params
      params.except(:host, :port, :protocol).permit!
    end
    helper_method :safe_url_params

    def authenticate_access
      authenticate_admin
    end

    def authenticate_admin
      authorize current_user, :admin?
    end

    def authenticate_moderator
      authorize current_user, :moderate?
    end

    # Override this value to specify the number of elements to display at a time
    # on index pages. Defaults to 20.
    def records_per_page
      params[:per_page] || 20
    end

    def resource_resolver
      @_resource_resolver ||= Administrate::NestableResourceResolver.new(controller_path)
    end

    def valid_action?(name, resource = resource_name)
      # Contests::Article -> contests__article, we search routes for 'articles'
      target_controller = resource.to_s.pluralize.split('__').last

      !!routes.detect do |controller, action|
        controller == target_controller && action == name.to_s
      end
    end

    def set_context
      @admin_context = true
      Current.user = current_user
    end

  end


end
