# frozen_string_literal: true

module Admin
  class CategoriesController < Admin::ApplicationController
  end
end
