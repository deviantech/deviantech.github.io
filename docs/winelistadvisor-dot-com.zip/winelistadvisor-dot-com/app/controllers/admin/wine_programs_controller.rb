# frozen_string_literal: true

module Admin
  class WineProgramsController < Admin::ApplicationController
    before_action :set_default_sort, only: :index
    include AdministrateScopedResources

    def accept
      if transitioned_ok = requested_resource.accept!(current_user)
        flash[:success] = "Accepted Wine Program Submission!"
      else
        flash[:warning] = "Unable to accept Wine Program Submission: #{requested_resource.errors.full_messages.to_sentence}"
      end

      redirect_after_action(success: transitioned_ok)
    end

    public :reject

    private

    def valid_base_scopes
      %w(pending accepted)
    end

    # TODO: make these params actually do something (i.e. make administrate scoped resources actually sort)
    def set_default_sort # By default group restaurants together
      params[:order] ||= 'restaurant'
      params[:direction] ||= 'asc'
    end
  end
end
