# frozen_string_literal: true

module Admin
  class ArticlesController < Admin::ApplicationController
    include AdministrateScopedResources

    def publish
      state_transition(:publish)
    end

    public :reject

    private

    def uses_aasm?
      true
    end

    def state_field
      :review_status
    end

    def extra_action_params
      case params[:action]
      when 'create' then {user: current_user, review_status: 'pending_review'}
      else {}
      end
    end

    def valid_base_scopes
      %w(pending_review published)
    end
  end
end
