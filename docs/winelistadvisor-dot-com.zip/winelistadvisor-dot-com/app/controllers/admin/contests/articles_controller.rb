# frozen_string_literal: true

module Admin
  module Contests
    class ArticlesController < BaseController
    end
  end
end
