# frozen_string_literal: true

module Admin
  module Contests
    class BaseController < ::Admin::ApplicationController
      include AdministrateScopedResources
      before_action :ensure_up_to_date, only: [:index, :show]

      def select_winner
        @entry = requested_resource.entries.find(params[:entry_id])

        if transitioned_ok = requested_resource.select_winner!(current_user, @entry)
          flash[:success] = "Contest winner selected!"
        else
          flash[:warning] = "Unable to save contest winner"
        end

        redirect_after_action(success: transitioned_ok)
      end

      private

      def ensure_up_to_date
        resource_resolver.resource_class.ensure_up_to_date!
      end

      def valid_base_scopes
        %w(all running pending completed)
      end
    end
  end
end
