# frozen_string_literal: true

module Admin
  module Contests
    class WineProgramsController < BaseController
    end
  end
end
