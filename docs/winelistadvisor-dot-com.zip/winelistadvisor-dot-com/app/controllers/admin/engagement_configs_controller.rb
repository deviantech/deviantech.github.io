# frozen_string_literal: true

module Admin
  class EngagementConfigsController < Admin::ApplicationController
  end
end
