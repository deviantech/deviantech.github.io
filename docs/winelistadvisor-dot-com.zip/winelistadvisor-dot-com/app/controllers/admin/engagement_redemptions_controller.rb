# frozen_string_literal: true

module Admin
  class EngagementRedemptionsController < Admin::ApplicationController
    include AdministrateScopedResources
    before_action :get_engagements, only: [:show]
    before_action :get_gift_card, only: [:mark_paid, :create_payment]

    def mark_paid
      @page_title = "Mark #{@gift_card.user.first_name}'s Gift Card Paid"
    end

    def create_payment
      @gift_card.mark_paid!(current_user, action_params[:order_number])
    end

    private

    def action_params
      params.require(:engagement_redemption).permit(:order_number)
    end

    def get_gift_card
      @gift_card = requested_resource
    end

    def valid_base_scopes
      %w(pending paid)
    end

    def get_engagements
      @engagements = requested_resource.user.engagements.page(params[:page]).per(params[:per_page])
    end

  end
end
