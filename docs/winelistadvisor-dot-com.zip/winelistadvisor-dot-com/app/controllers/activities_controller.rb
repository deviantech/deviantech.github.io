# frozen_string_literal: true

class ActivitiesController < ApplicationController
  before_action :require_user, only: :destroy
  before_action :get_user, only: :show
  before_action :get_activity

  def show
    @page_title = 'Member Activity'
    @subnav = 'users/activity_subnav'
    render layout: 'users'
  end

  def destroy
    authorize @activity
    @activity.destroy
  end

  private

  def get_activity
    @activity = (@user ? @user.activities : Activity).find(params[:id])&.decorate
  end

  def get_user
    @user = User.find( params[:user_id] )&.decorate
  end

end
