# frozen_string_literal: true

class ApplicationController < ActionController::Base
  include BaseControllerLogic
  include RouteAliases

  after_action :store_action

  before_action :configure_permitted_parameters, if: :devise_controller?

  rescue_from ServiceError::Base, with: :handle_restaurant_backend_down


  protected

  def get_conversation
    @conversation = Conversation.find(params[:conversation_id] || params[:id])
    authorize @conversation, :show?
  end

  def get_yelp_restaurant
    if @restaurant = RestaurantService.get( params[:restaurant_id] || params[:id] )
      @restaurant = @restaurant.decorate
    end

    unless @restaurant
      flash[:warning] = "Unable to locate specified restaurant!"
      redirect_back
    end
  end

  def after_sign_in_path_for(user)
    unless user.tasting_profile_completed?
      flash[:warning] = "Please #{ActionController::Base.helpers.link_to 'complete your profile', edit_user_path(user)} to help friends and family better suggest wines that particularly appeal to your custom tastes!"
    end

    loc = stored_location_for(user)
    loc = '/' if loc.to_s.starts_with?('/invitations') # Don't try redirecting back to invitation path
    loc = '/' if loc.to_s.match(/\/confirmation\//) # Don't try redirecting back to confirmation path

    request.env['omniauth.origin'] || loc || user_home_url
  end

  def require_self
    get_user
    raise Pundit::NotAuthorizedError unless user_signed_in? && (current_user == @user)
  end

  def require_self_or_admin
    get_user
    raise Pundit::NotAuthorizedError unless user_signed_in? && (current_user.admin? || current_user == @user)
  end

  def require_self_or_friend
    get_user
    raise Pundit::NotAuthorizedError unless user_signed_in? && policy(@user).friend?
  end

  def require_admin
    raise Pundit::NotAuthorizedError unless user_signed_in? && current_user.admin?
  end

  def configure_permitted_parameters
    devise_parameter_sanitizer.permit(:sign_up, keys: [:name])
    devise_parameter_sanitizer.permit(:account_update, keys: [:name])
  end

  def get_user
    @user ||= User.find( params[:user_id] ) if params[:user_id]
  end

  def handle_restaurant_backend_down(exception)
    flash[:danger] = "We apologize for the interruption, but we're having difficulty connecting to our 3rd party data provider. Please try again in a few moments."
    redirect_back
  end

  # Devise return to prev page after sign in. https://github.com/plataformatec/devise/wiki/How-To:-Redirect-to-a-specific-page-on-successful-sign-in-out
  def store_action
    return unless request.get?
    return if @action_stored # Added this to allow manually overriding

    if (request.path != "/users/sign_in" &&
        request.path != "/users/sign_up" &&
        request.path != "/users/password/new" &&
        request.path != "/users/password/edit" &&
        request.path != "/users/confirmation" &&
        request.path != "/users/sign_out" &&
        !request.xhr?) # don't store ajax calls
      store_location_for(:user, request.fullpath)
    end
  end

  # For ActiveJob: https://www.stefanwienert.de/blog/2016/04/05/using-rails-5-new-renderer-with-authentication-gems-like-clearance-or-devise/
  def self.render_with_signed_in_user(user, *args)
    ActionController::Renderer::RACK_KEY_TRANSLATION['warden'] ||= 'warden'
    proxy = Warden::Proxy.new( {}, Warden::Manager.new({}) ).tap do |i|
      user.confirmed_at ||= Time.now # Ensure counts as confirmed?
      i.set_user(user, scope: :user)
    end

    # Yes, warden must be a string and http_host must be a symbol here...
    renderer_opts = {'warden' => proxy, :http_host => App.domain, https: Rails.env.production?}

    renderer = self.renderer.new(renderer_opts)
    renderer.render(*args)
  end

end
