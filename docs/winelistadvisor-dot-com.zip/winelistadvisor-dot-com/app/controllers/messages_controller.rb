# frozen_string_literal: true

class MessagesController < ApplicationController
  before_action :require_user
  before_action :get_conversation

  def create
    if message_body.blank?
      render :ok and return
    end

    @message = MessageDecorator.decorate @conversation.add_message(current_user, message_body)
  end

  private

  def message_body
    message_params[:body]
  end

  def message_params
    params.require(:message).permit(:body)
  end
end
