# frozen_string_literal: true

class WineProgramsController < ApplicationController
  layout 'restaurant'
  before_action :require_user
  before_action :get_yelp_restaurant

  before_action :make_new_wine_program,       only: [:new, :create]
  before_action :get_specified_wine_program,  only: [:edit, :update]

  # Note on flows: user submitting wine program will go new/create, then edit/update if rejected.
  # User submitting claim will have program created for them, so will go edit/update only. Therefore edit/update flows
  # need to detect which context they're in, which they do based on the program state.

  def new
    @page_title = "Submit Wine Program"
    handle_editing_wine_program
  end

  def create
    @page_title = "Submit Wine Program"
    handle_saving_wine_program
  end

  def edit
    @page_title = (@wine_program.pending_ownership_claim? || @wine_program.owners?) ? "Edit Wine Program Information" : 'Submit Wine Program'
    handle_editing_wine_program
  end

  def update
    @page_title = (@wine_program.pending_ownership_claim? || @wine_program.owners?) ? "Edit Wine Program Information" : 'Submit Wine Program'
    handle_saving_wine_program
  end

  private

  def get_specified_wine_program
    @wine_program = @restaurant.submitted_wine_programs.find(params[:id])
    authorize @wine_program, :edit?
  end

  def make_new_wine_program
    if existing = @restaurant.submitted_wine_programs.by_user(current_user).first
      flash[:warning] = "You've already submitted a wine program for #{@restaurant}"
      redirect_back '/'
    else
      @wine_program = @restaurant.submitted_wine_programs.by_user(current_user).build
      authorize @wine_program, :edit?
    end
  end

  def program_params(context: :member)
    params.require(:wine_program).permit( *WineProgram.permitted_attributes_for(context) )
  end

  def handle_editing_wine_program
    if (@wine_program.pending? || @wine_program.accepted?) && !current_user.admin?
      msg = "Thank you for submitting this wine program! You won't be able to make any edits "
      msg += @wine_program.pending? ? 'while admins are reviewing your submission' : "now that it's been published"
      msg += ". If you noticed something out of date, please <a href=\"mailto:#{App.admin_email}?subject=Wine Program at #{@restaurant.to_param}\">contact us</a> directly."
      flash[:notice] = msg
      redirect_to(@restaurant) and return
    elsif @wine_program.owners?
      redirect_to([:edit, @restaurant]) and return
    end

    authorize @wine_program
    render 'new'
  end

  def handle_saving_wine_program
    saved_ok = if @wine_program.draft?
      @wine_program.attributes = program_params
      [@wine_program.save, @wine_program.submit, @wine_program.save].all?
    else
      @wine_program.update_attributes program_params(context: (@wine_program.pending_ownership_claim? || @wine_program.owners?) ? :owner : :member)
    end

    if saved_ok
      flash[:success] = @wine_program.pending? ? "Thanks for your submission!" : 'Updates saved!'
      to_restaurant = (@wine_program.accepted? || @wine_program.owners?) && @wine_program.restaurant.wine_program == @wine_program
      destination = if @wine_program.pending_ownership_claim? then restaurants_claimed_user_path(current_user)
      else to_restaurant ? restaurant_path(@wine_program.restaurant) : wine_programs_user_path(current_user)
      end

      redirect_to destination
    else
      flash.now[:danger] = "Unable to #{@wine_program.new_record? ? 'accept submission' : 'save updates'} - please see errors below."
      render 'new'
    end
  end

end
