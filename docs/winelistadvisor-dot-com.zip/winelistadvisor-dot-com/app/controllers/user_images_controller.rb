# frozen_string_literal: true

class UserImagesController < ApplicationController
  before_action :require_user

  def create
    @upload = current_user.user_images.build(upload_params)

    if @upload.save
      render json: { url: @upload.image.url, id: @upload.id }
    else
      render json: {error: @upload.errors.full_messages}, status: :bad_request
    end
  end

  def destroy
    @image = current_user.user_images.find_by(id: params[:id])

    render json: {}, status: @image&.destroy ? :ok : :bad_request
  end

  private

  def upload_params
    params.require(:upload).permit(:image, context: UserImage::VALID_CONTEXT_FIELDS)
  end

end
