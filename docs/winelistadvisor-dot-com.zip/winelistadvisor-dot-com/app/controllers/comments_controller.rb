# frozen_string_literal: true

class CommentsController < ApplicationController
  before_action :authenticate_user!, except: [:index, :show]
  before_action :get_commentable, only: [:new, :create]
  before_action :get_comment,  only: [:edit, :update, :destroy, :show]

  def new
    @page_title = "Add Comment"
    @page_subtitle = "on #{@commentable.label}"
    render "comments/_form"
  end

  def edit
    authorize @comment
    @page_title = "Editing Comment"
    @page_subtitle = "on #{@commentable.label}"
    render "comments/_form"
  end

  def destroy
    authorize @comment
    @comment.destroy
  end

  def update
    authorize @comment
    @comment.update(comment_params)
  end

  def create
    @comment = current_user.comments.create(comment_params)
  end

  private

  def get_comment
    @comment = Comment.find(params[:id])
    @commentable = @comment.commentable
  end

  def comment_params
    params.require(:comment).permit(*permitted_params)
  end

  def permitted_params
    permitted  = [:body, :commentable_type, :commentable_id]
  end

  def get_commentable
    # Handle either nested (e.g. update) or inline (e.g. new)
    type = params[:comment] ? params[:comment][:commentable_type] : params[:commentable_type]
    id   = params[:comment] ? params[:comment][:commentable_id]   : params[:commentable_id]

    unless @commentable = type.present? && type.constantize.where(id: id).first
      flash[:danger] = "Invalid object passed for comment"

      respond_to do |wants|
        wants.html { redirect_to user_path(current_user) }
        wants.js { head(:unprocessable_entity) }
      end
    end
  end

end
