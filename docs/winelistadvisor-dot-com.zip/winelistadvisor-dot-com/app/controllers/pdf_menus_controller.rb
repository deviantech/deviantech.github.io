# frozen_string_literal: true

class PdfMenusController < ApplicationController
  before_action :get_yelp_restaurant
  before_action :get_pdf_menu, only: [:destroy, :show]

  def edit
    authorize @restaurant, :admin?

    @page_title  = "Manage Menus"
    @page_subtitle = "for #{@restaurant.name}"
  end

  def update
    authorize @restaurant, :update_pdf_menus?
    @success = menu_params && @restaurant.update(menu_params)
  end

  def destroy
    authorize @restaurant, :update_pdf_menus?

    @success = @pdf_menu&.destroy
  end

  def show
    @page_title = "Wine Menu"
    idx = @restaurant.pdf_menus.to_a.index(@pdf_menu)
    @prev_pdf = idx > 0 && @pdf_menus[idx - 1]
    @next_pdf = @pdf_menus[idx + 1]
    render layout: 'restaurant'
  end

  private

  def get_pdf_menu
    @pdf_menus = @restaurant.pdf_menus.to_a
    @pdf_menu = @pdf_menus.detect {|m| m.id.to_s == params[:id].to_s }
  end

  def menu_params
    return unless params[:restaurant]
    params.require(:restaurant).permit(:external_menu_url, pdf_menus: [])
  end

end
