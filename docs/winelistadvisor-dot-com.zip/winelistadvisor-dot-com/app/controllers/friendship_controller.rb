# frozen_string_literal: true

class FriendshipController < ApplicationController
  before_action :require_user
  before_action :get_user

  def create
    @ok = current_user && @user && @user != current_user
    @ok = @ok && current_user.friend_request(@user)
  end

  def confirm
    if current_user.accept_request(@user)
      redirect_to user_friends_path(current_user), notice: "Accepted friend request from #{@user.name}"
    else
      redirect_to user_friends_path(current_user), alert: "Error accepting friend request from #{@user.name}"
    end
  end

  def decline
    if current_user.decline_request(@user)
      redirect_to user_friends_path(current_user), notice: "Declined friend request from #{@user.name}"
    else
      redirect_to user_friends_path(current_user), alert: "Error declining friend request from #{@user.name}"
    end
  end

  def remove
    if current_user.remove_friend(@user)
      redirect_to user_friends_path(current_user), notice: "Removed friendship with #{@user.name}"
    else
      redirect_to user_friends_path(current_user), alert: "Error removing friendship with #{@user.name}"
    end
  end

  private

  def get_user
    @user ||= User.find(params[:id])
  end

end
