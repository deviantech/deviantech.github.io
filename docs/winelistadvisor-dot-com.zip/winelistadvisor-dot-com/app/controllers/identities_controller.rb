# frozen_string_literal: true

class IdentitiesController < ApplicationController
  before_action :require_user
  before_action :get_identity

  def destroy
    if @identity.destroy
      if current_user.identities.count > 0
        flash[:info] = "Removed #{@identity.label}"
      else
        flash[:warning] = "Removed #{@identity.label} -- going forward you'll need to log in via email/password, so please make sure those are set correctly below. <br><br>If your account was originally created via an external network, your password is set to a random string -- you'll need to use the Forgot Password flow to reset it next time you wish to log in."
      end
    else
      flash[:warning] = "Unable to remove #{@identity.label}"
    end
    redirect_to edit_user_settings_path(anchor: 'networks')
  end

  def update_single_setting
    k,v = single_notification_setting.to_a[0]
    @identity.notify_on[k] = v
    @identity.save
  end

  def update_all_settings
    @identity.supported_social_notifications.each do |k, desc|
      @identity.notify_on[k.to_s] = params[:toggle] == 'true' ? '1' : '0'
    end
    @identity.save
  end

  private

  def get_identity
    @identity = current_user.identities.find(params[:id])
  end

  def single_notification_setting
    if params[:user]
      base = params.to_unsafe_h.dig('user', 'identities_attributes')
      base[base.keys.first]['notify_on']
    else # Unchecking box doesn't send full params -- https://github.com/rails/jquery-ujs/issues/440 for details
      {params[:key] => '0'}
    end
  end

end
