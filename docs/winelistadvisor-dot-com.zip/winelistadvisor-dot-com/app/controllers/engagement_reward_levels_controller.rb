# frozen_string_literal: true

class EngagementRewardLevelsController < ApplicationController
end
