# frozen_string_literal: true

class NotificationsController < ApplicationController
  before_action :require_user
  before_action :get_user, only: :index
  after_action :mark_read, only: :index
  layout 'users'

  def index
    @page_title = 'Notifications'
    @notifications = NotificationDecorator.decorate_collection @user.notifications.page(params[:page]).per(params[:per_page])
  end

  def read
    mark_read [ current_user.notifications.find(params[:id]) ]
    head :ok
  end

  private

  def mark_read(notes = @notifications)
    Notification.mark_read notes
  end

end
