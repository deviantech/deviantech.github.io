# frozen_string_literal: true

class ReviewsController < ApplicationController
  before_action :authenticate_user!, except: [:index, :show]
  before_action :get_reviewable, only: [:new, :create]
  before_action :get_review,  only: [:edit, :update, :destroy, :show]

  def new
    @page_title = "Your review of #{@reviewable.label}"
    render "reviews/_form"
  end

  def show # view specific review on a reviewable page
    @article = Article.get_featured
    @page_title = "View Review"
    klass = @review.reviewable_type.underscore
    instance_variable_set "@#{klass}", @review.reviewable.decorate
    render "#{klass.pluralize}/show", layout: klass
  end

  def edit
    authorize @review
    @page_title = "Editing review of #{@reviewable.label}"
    render "reviews/_form"
  end

  def destroy
    authorize @review
    @review.destroy
  end

  def update
    authorize @review
    @review.update(review_params)
  end

  def create
    @review = current_user.reviews.build(review_params)

    # If we're adding a review to a specific bookmark, do so rather than creating a new bookmark record
    if params[:bookmark_id] && @bookmark = current_user.bookmarks.find_by(id: params[:bookmark_id])
      @review.bookmark = @bookmark
    end

    @review.save
  end

  private

  def review_params
    params.require(:review).permit(*permitted_params)
  end

  def permitted_params
    permitted  = [:rating, :title, :body, :recommendations, :public_notes, :reviewable_type, :reviewable_id]
    permitted += [:service_rating, :wines_rating, :value_rating, :tag_names]
    permitted += Review::VALID_DATA_FIELDS

    permitted += [:by_staff] if policy(Review).leave_staff_review?

    permitted
  end

  def get_review
    @review = Review.find(params[:id])
    @reviewable = @review.reviewable
  end

  def get_reviewable
    # Handle either nested (e.g. update) or inline (e.g. new)
    type = params[:review] ? params[:review][:reviewable_type] : params[:reviewable_type]
    id = params[:id] || params[:reviewable_id] || params["#{type.underscore}_id"]

    @reviewable = if type == 'Restaurant'
      RestaurantService.get(id)
    elsif Review::VALID_TYPES.include?(type)
      type.constantize.find(id)
    end

    @reviewable = @reviewable.decorate if @reviewable.respond_to?(:decorate)

    unless @reviewable
      flash[:danger] = "Invalid object passed for review"

      respond_to do |wants|
        wants.html { redirect_to user_path(current_user) }
        wants.js { head(:unprocessable_entity) }
      end
    end
  end

end
