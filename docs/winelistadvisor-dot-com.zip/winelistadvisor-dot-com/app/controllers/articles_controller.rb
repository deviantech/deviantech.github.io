# frozen_string_literal: true

class ArticlesController < ApplicationController
  include ProvidesFeaturedAndSearching
  before_action :get_category, only: [:by_category]
  before_action :set_article, only: [:show, :preview, :edit, :update, :destroy, :submit]
  before_action :require_user, except: [:index, :by_category, :show]
  before_action :set_search_path, only: :index

  def by_category
    @articles = @category.published_articles.newest_first.page(params[:page]).per(params[:per_page])
    @index_path = magazine_path
    index
  end

  def show
    if !@article.published? && policy(@article).edit?
      redirect_to preview_article_path(@article) and return
    end

    authorize @article

    if @article.hidden_by_flags?
      flash[:warning] = "The requested article has been deemed inappropriate by moderators or the WLA community and is no longer viewable"
      redirect_to magazine_path
    else
      render layout: 'published_article'
    end
  end

  def preview
    if @article.published?
      redirect_to article_path(@article) and return
    end

    @page_title = "Preview Article"
    @subnav = "users/articles_subnav"
    render 'show', layout: 'users'
  end

  def new
    @page_title = "Write Article"
    @subnav = "users/articles_subnav"
    @article = current_user.articles.new
    @user    = current_user
    render layout: 'users'
  end

  def edit
    authorize @article
    @page_title = "Edit Article"
    @subnav = "users/articles_subnav"
    render layout: 'users'
  end

  def submit
    authorize @article

    if @article.submit!
      flash[:success] = "Submitted article for review."
    else
      flash[:warning] = "Unable to submit article for review: #{@article.errors.full_messages.to_sentence}"
    end

    redirect_to article_path(@article)
  end

  def create
    @article = current_user.articles.new(article_params)
    if @article.save
      redirect_to @article, notice: 'Article was successfully created.'
    else
      set_current_user
      render :new, layout: 'users'
    end
  end

  def update
    authorize @article
    if @article.update(article_params)
      redirect_to @article, notice: 'Article was successfully updated.'
    else
      render :edit, layout: 'users'
    end
  end

  def destroy
    authorize @article

    @article.destroy
    redirect_to articles_user_url(current_user), notice: 'Article was successfully destroyed.'
  end

  private

  def overrides_featured_with
    @category ? 'featured_by_category' : 'featured_results'
  end

  def set_article
    @article = Article.includes(comments: :user).find(params[:id]).decorate
    @user ||= @article.user&.decorate
  end

  # Never trust parameters from the scary internet, only allow the white list through.
  def article_params
    allowed_params = [:title, :body, :category_id, :summary, :featured_image, :remove_featured_image, :featured_image_cache]
    allowed_params += [:author_alias] if Current.user&.admin?
    params.require(:article).permit(allowed_params)
  end

  def get_category
    @category = Category.find_by( slug: params[:category] )
  end

  def title_for_breadcrumb
    @category ? @category.name : 'Wine & Dine Magazine'
  end

  def title_for_header
    @category ? "#{@category.name}<small>Wine & Dine Magazine</small>".html_safe : 'Wine & Dine Magazine<small>Articles Poured Daily</small>'.html_safe
  end

  def text_for_leader
  end

  def set_search_path
    if request.get? && request.url.match(/\/articles/)
      flash.keep
      redirect_to magazine_path
    else
      @index_path = magazine_path
    end
  end

end
