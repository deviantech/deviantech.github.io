# frozen_string_literal: true

class WallPostsController < ApplicationController
  before_action :require_user
  before_action :get_user
  before_action :get_post, except: [:create]
  before_action :require_self_or_friend

  def create
    authorize @user, :friend?
    @post = Activity.add_wall_post(current_user, @user, wall_post_params)
  end

  def edit
    authorize @user, :self?
    authorize @post

    @page_title = "Editing Post"
    who = @post.thing == Current.user ? 'your' : "#{@post.thing.name}'s"
    @page_subtitle = "on #{who} wall"
    render "wall_posts/_form"
  end

  def update
    authorize @user, :self?
    authorize @post

    @post.update wall_post_params
  end

  private


  def wall_post_params
    params.require(:activity).permit(:body)
  end

  def get_user
    @user = User.find(params[:user_id])
  end

  def get_post
    @post = Activity.wall_posts_involving(@user).find(params[:id])
  end

end
