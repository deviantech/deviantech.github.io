class ContentSectionsController < ApplicationController
  layout 'restaurant'
  before_action :get_yelp_restaurant
  before_action :prep_form, only: [:index, :create]
  before_action :prep_action, except: [:index, :create]

  def index
    @page_title = "Manage Restaurant Custom Content"
  end

  def create
    conclude_with @content_section.save, "Unable to save custom content -- please resolve errors in the form below."
  end

  def publish
    handle_action :publish!
  end

  def unpublish
    handle_action :unpublish!
  end

  def destroy
    conclude_with @content_section.destroy, "Unable to delete custom content."
  end

  def edit
    @page_title = "Editing content section"
    render "content_sections/_form"
  end

  def update
    conclude_with @content_section.update(content_params), "Unable to update content section."
  end

  private

  def content_params
    if params[:content_section]
      params.require(:content_section).permit(:title, :body)
    else
      {}
    end
  end

  def prep_form
    authorize @restaurant, :manage_content?
    @content_section ||= @restaurant.content_sections.build(content_params)
    @content_section.user ||= current_user
  end

  def prep_action
    authorize @restaurant, :manage_content?
    @content_section = @restaurant.content_sections.find(params[:id])
  end

  def handle_action(which_act)
    conclude_with @content_section.send(which_act, current_user), "Unable to update publish status on custom content."
  end

  def conclude_with(is_okay, err)
    if is_okay
      redirect_to restaurant_content_sections_path(@restaurant)
    else
      flash.now[:error] = err
      render 'index'
    end
  end

end
