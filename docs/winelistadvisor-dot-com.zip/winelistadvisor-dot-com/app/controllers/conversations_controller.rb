# frozen_string_literal: true

class ConversationsController < ApplicationController
  before_action :require_user
  before_action :get_conversation, except: [:new, :create, :index]
  before_action :set_current_user, only: [:index, :show]

  def index
    @page_title = "Private Messages"
    @conversations = current_user.conversations.includes(:users)
    render layout: 'users'
  end

  def new
    @page_title = "New Message"
    @conversable = current_user.friends
  end

  def create
    @conversation = Conversation.converse_with(current_user, conversation_params[:user_ids])
  end

  def show
    authorize @conversation
    @page_title = @conversation.name_for(current_user)
    render layout: 'users'
  end

  def add_user_form
    @page_title = "Add Friends to Conversation"
    @conversable = current_user.friends - @conversation.users
  end

  def add_users
    authorize @conversation, :manage?
    do_event :add_users, :adding
  end

  def kick_users
    authorize @conversation, :manage?
    do_event :remove_users, :removing
  end

  def leave
    authorize @conversation, :show?
    if @message = @conversation.user_left(current_user)
      redirect_to user_conversations_path(current_user), notice: "Left conversation"
    else
      redirect_to conversation_path(@conversation), alert: "Error leaving conversation"
    end
  end

  private

  def do_event(kind, action_label)
    potentials = User.where(id: conversation_params[:user_ids])
    @message = @conversation.send(kind, current_user, potentials)
    @message = MessageDecorator.decorate(@message) if @message
    missed_ids = potentials.map(&:id) - (@message ? @message.meta['user_ids'] : [])
    @missed_names = potentials.select {|p| missed_ids.include?(p.id) }.map(&:name)

    render partial: 'user_event', locals: { action_label: action_label }
  end

  def conversation_params
    @conversation_params ||= params.require(:conversation).permit(user_ids: [])
  end

end
