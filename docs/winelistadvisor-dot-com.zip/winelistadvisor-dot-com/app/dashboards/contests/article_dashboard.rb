# frozen_string_literal: true

class Contests::ArticleDashboard < ScopedResourcesDashboard
  include ::Contests::ContestableDashboardConcern

  ATTRIBUTE_TYPES = attribute_types
  COLLECTION_ATTRIBUTES = collection_attributes
  SHOW_PAGE_ATTRIBUTES = show_page_attributes
end
