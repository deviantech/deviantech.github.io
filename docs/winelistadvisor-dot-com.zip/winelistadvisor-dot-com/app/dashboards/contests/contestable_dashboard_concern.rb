# frozen_string_literal: true

module Contests::ContestableDashboardConcern
  extend ActiveSupport::Concern

  def collection_attributes_for_scope(scope)
    all_but_pending = [:winner, :winning_user, :winner_selected_by]

    case scope
    when 'all'        then [:state] + all_but_pending
    when 'pending'    then [:finish_on]
    else all_but_pending
    end
  end

  def display_resource(contest)
    "#{contest.name} [#{contest.state.titleize}]"
  end

  module ClassMethods

    def contestable_klass
      self.name.split('::').last.sub('Dashboard', '')
    end

    def attribute_types
      {
        winner: Administrate::Field::BelongsTo.with_options(class_name: contestable_klass),
        entries: Administrate::Field::HasMany.with_options(class_name: contestable_klass),

        winning_user: Administrate::Field::BelongsTo.with_options(class_name: "User"),
        winner_selected_by: Administrate::Field::BelongsTo.with_options(class_name: "User"),
        id: Administrate::Field::Number,
        start_on: Administrate::Field::DateTime,
        finish_on: Administrate::Field::DateTime,
        winner_selected_at: Administrate::Field::DateTime,
        winner_id: Administrate::Field::Number,
        winner_selected_by_id: Administrate::Field::Number,
        state: TitleizedString.with_options(searchable: false),
        name: Administrate::Field::String.with_options(searchable: false),
        num_entries: Administrate::Field::Number,
        created_at: Administrate::Field::DateTime,
        updated_at: Administrate::Field::DateTime,
      }.freeze
    end

    def collection_attributes
      [
        :name,
        :num_entries
      ].freeze
    end

    def show_page_attributes
      [
        :name,
        :num_entries,
        :state,
        :start_on,
        :finish_on,
        :created_at,
        :updated_at,
      ].freeze
    end

  end

end
