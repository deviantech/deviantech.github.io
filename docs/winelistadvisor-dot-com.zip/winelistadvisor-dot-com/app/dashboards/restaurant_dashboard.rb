# frozen_string_literal: true

class RestaurantDashboard < ScopedResourcesDashboard
  def custom_actions?; true; end

  # ATTRIBUTE_TYPES
  # a hash that describes the type of each of the model's fields.
  #
  # Each different type represents an Administrate::Field object,
  # which determines how the attribute is displayed
  # on pages throughout the dashboard.
  ATTRIBUTE_TYPES = {
    submitted_wine_programs: Field::HasMany.with_options(class_name: "WineProgram"),
    wine_program: Field::BelongsTo,
    claimed_by: Field::BelongsTo.with_options(class_name: "User"),
    claimant_phone: Field::String.with_options(searchable: false),
    reviewed_by: Field::BelongsTo.with_options(class_name: "User"),
    id: Field::String,
    name: Field::String,
    yelp_rating: Field::String.with_options(searchable: false),
    yelp_rating_count: Field::Number,
    yelp_url: Field::String.with_options(searchable: false),
    display_address: Field::String.with_options(searchable: false),
    address: Field::String.with_options(searchable: false),
    city: Field::String,
    state: Field::String,
    country: Field::String,
    zip: Field::String,
    neighborhoods: Field::String.with_options(searchable: false),
    latitude: Field::String.with_options(searchable: false),
    longitude: Field::String.with_options(searchable: false),
    phone: Field::String.with_options(searchable: false),
    phone_for_display: Field::String.with_options(searchable: false),
    categories: Field::String.with_options(searchable: false),
    yelp_image_url: Field::String.with_options(searchable: false),

    avatar: UploadedImageField.with_options(searchable: false),

    claimed_by_id: Field::Number,
    claimed_at: Field::DateTime,
    reviewed_at: Field::DateTime,
    reviewed_by_id: Field::Number,
    claim_status: TitleizedString.with_options(searchable: false),
    created_at: Field::DateTime,
    rating: StarRating,
    reviews_count: Field::Number,
  }.freeze

  # COLLECTION_ATTRIBUTES
  # an array of attributes that will be displayed on the model's index page.
  #
  # By default, it's limited to four items to reduce clutter on index pages.
  # Feel free to add, remove, or rearrange items.
  COLLECTION_ATTRIBUTES = [
    :avatar,
    :name,
    :submitted_wine_programs,
  ].freeze

  def collection_attributes_for_scope(scope)
    case scope
    when 'pending_review' then [:claimed_by, :claimant_phone]
    when 'claimed'        then [:rating, :reviews_count]
    else []
    end
  end


  # SHOW_PAGE_ATTRIBUTES
  # an array of attributes that will be displayed on the model's show page.
  SHOW_PAGE_ATTRIBUTES = [
    :claimed_by,
    :claimant_phone,
    :reviewed_by,
    :id,
    :name,
    :yelp_rating,
    :yelp_rating_count,
    :yelp_url,
    :display_address,
    :address,
    :city,
    :state,
    :country,
    :zip,
    :neighborhoods,
    :latitude,
    :longitude,
    :phone,
    :phone_for_display,
    :categories,
    :yelp_image_url,

    :avatar,
    :claimed_by_id,
    :claimed_at,
    :reviewed_at,
    :reviewed_by_id,
    :claim_status,
    :created_at,
    :rating,
    :reviews_count,
    :wine_program,
    :submitted_wine_programs,
  ].freeze

  def yelp_attribute_names
    @yan ||= [
      :name,
      :yelp_rating,
      :yelp_rating_count,
      :yelp_url,
      :display_address,
      :address,
      :city, :state, :country, :zip,
      :neighborhoods,
      :latitude,
      :longitude,
      :phone, :phone_for_display,
      :categories,
    ].map(&:to_s)
  end

  def claimant_attribute_names
    @can ||= [
      :claimant_phone,
    ].map(&:to_s)
  end

  def system_attribute_names
    @san ||= [
      :wine_program,
      :claimed_by,
      :claimed_at,
      :reviewed_at,
      :reviewed_by,
      :claim_status,
      :created_at,
      :submitted_wine_programs,
    ].map(&:to_s)
  end

  # FORM_ATTRIBUTES
  # an array of attributes that will be displayed
  # on the model's form (`new` and `edit`) pages.
  FORM_ATTRIBUTES = [
    :avatar,
  ].freeze

  # Overwrite this method to customize how restaurants are displayed
  # across all pages of the admin dashboard.
  #
  def display_resource(restaurant)
    "Restaurant #{restaurant.name}"
  end
end
