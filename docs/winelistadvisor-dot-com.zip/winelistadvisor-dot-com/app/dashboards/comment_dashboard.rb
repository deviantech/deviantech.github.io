# frozen_string_literal: true

class CommentDashboard < ApplicationDashboard
  ATTRIBUTE_TYPES = {
    moderator_hidden_by: Field::BelongsTo.with_options(class_name: "User"),
    user: Field::BelongsTo,
    commentable: Field::Polymorphic,
    commentable_label: Field::String,
    commentable_type: Field::String,
    commentable_id: Field::Number,
    id: Field::Number,
    body: Field::Text,
    created_at: Field::DateTime,
    updated_at: Field::DateTime,
    flag_count: Field::Number,
    moderator_hidden_by_id: Field::Number,
    moderator_hidden_at: Field::DateTime,
    moderation_status: Field::String,
  }.freeze

  COLLECTION_ATTRIBUTES = [
    :user,
    :commentable_label,
    :body,
  ].freeze

  SHOW_PAGE_ATTRIBUTES = [
    :id,
    :user,
    :commentable_label,
    :commentable_type,
    :commentable_id,
    :body,
    :created_at,
    :updated_at,
    :flag_count,
    :moderator_hidden_by,
    :moderator_hidden_by_id,
    :moderator_hidden_at,
    :moderation_status,
  ].freeze

  FORM_ATTRIBUTES = [
    :body,
  ].freeze

end
