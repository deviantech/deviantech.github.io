# frozen_string_literal: true

# Needed in production to load the moderation application_dashboard we inherit from before we load rest of this file
require 'moderation/application_dashboard'

module Moderation
  class ActivityDashboard < ApplicationDashboard
    ATTRIBUTE_TYPES = flaggable_fields.merge({
      comments: Field::HasMany,
      commenting_users: Field::HasMany.with_options(class_name: "User"),
      user: Field::BelongsTo.with_options(class_name: "User"),
      thing: Field::Polymorphic,
      thing_context: Field::Polymorphic,
      id: Field::Number,
      user_id: Field::Number,
      topic: TitleizedString,
      body: Field::String.with_options(searchable: false),
      data: Field::String.with_options(searchable: false),
      created_at: Field::DateTime,
      updated_at: Field::DateTime,
    }).freeze

    COLLECTION_ATTRIBUTES = [
      :user,
      :topic,
      :body,
      :comments,
    ].freeze

  end
end
