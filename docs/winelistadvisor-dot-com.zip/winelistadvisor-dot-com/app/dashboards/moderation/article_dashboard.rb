# frozen_string_literal: true

module Moderation
  class ArticleDashboard < ApplicationDashboard

  ATTRIBUTE_TYPES = flaggable_fields.merge({
      user: Field::BelongsTo,
      reviewed_by: Field::BelongsTo.with_options(class_name: "User"),
      category: Field::BelongsTo,
      id: Field::Number,
      title: Field::String,
      summary: Field::Text,
      reviewed_by_id: Field::Number,
      review_status: TitleizedString,
      reviewed_at: Field::DateTime,
      created_at: Field::DateTime,
      updated_at: Field::DateTime,
      body: SummernoteField,
      featured_image: UploadedImageField,
    }).freeze

    # COLLECTION_ATTRIBUTES
    # an array of attributes that will be displayed on the model's index page.
    #
    # By default, it's limited to four items to reduce clutter on index pages.
    # Feel free to add, remove, or rearrange items.
    COLLECTION_ATTRIBUTES = [
      :id,
      :title,
      :summary,
    ].freeze
  end
end
