# frozen_string_literal: true

require "administrate/base_dashboard"

module Moderation
  class ApplicationDashboard < ::ApplicationDashboard

    SHOW_PAGE_ATTRIBUTES = [
      :pending_flaggings,
      :confirmed_flaggings,
      :dismissed_flaggings,
    ].freeze

    FORM_ATTRIBUTES = [].freeze

    private

    def self.flaggable_fields
      {
        flag_count: Field::Number,
        moderator_hidden_by_id: Field::Number,
        moderator_hidden_at: Field::DateTime,
        flaggings: FlaggableField,
        pending_flaggings: FlaggableField,
        confirmed_flaggings: FlaggableField,
        dismissed_flaggings: FlaggableField,
        flagging_users: Field::HasMany.with_options(class_name: "User"),
        moderator_hidden_by: Field::BelongsTo.with_options(class_name: "User"),
      }
    end

  end
end
