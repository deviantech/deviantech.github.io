# frozen_string_literal: true

module Moderation
  class CommentDashboard < ApplicationDashboard
    ATTRIBUTE_TYPES = flaggable_fields.merge({
      flagging_users: Field::HasMany.with_options(class_name: "User"),
      user: Field::BelongsTo,
      commentable: Field::Polymorphic,
      id: Field::Number,
      body: Field::Text,
      created_at: Field::DateTime,
      updated_at: Field::DateTime,
    }).freeze

    COLLECTION_ATTRIBUTES = [
      :id,
      :body,
      :user,
    ].freeze
  end
end
