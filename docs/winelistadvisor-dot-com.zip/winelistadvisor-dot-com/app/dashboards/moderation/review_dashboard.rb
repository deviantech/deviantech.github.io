# frozen_string_literal: true

module Moderation
  class ReviewDashboard < ApplicationDashboard

    # ATTRIBUTE_TYPES
    # a hash that describes the type of each of the model's fields.
    #
    # Each different type represents an Administrate::Field object,
    # which determines how the attribute is displayed
    # on pages throughout the dashboard.
    ATTRIBUTE_TYPES = flaggable_fields.merge({
      user: Field::BelongsTo,
      id: Field::Number,
      label: Field::String.with_options(searchable: false),
      rating: Field::String.with_options(searchable: false),
      notes: Field::Text,
      public_notes: Field::Boolean,
    }).freeze

    COLLECTION_ATTRIBUTES = [
      :id,
    ].freeze
  end
end
