# frozen_string_literal: true

class UserDashboard < ApplicationDashboard
  # ATTRIBUTE_TYPES
  # a hash that describes the type of each of the model's fields.
  #
  # Each different type represents an Administrate::Field object,
  # which determines how the attribute is displayed
  # on pages throughout the dashboard.
  ATTRIBUTE_TYPES = {
    id: Field::Number,
    email: Field::String,
    role: Field::Enum.with_options(collection: User::VALID_ROLES),
    encrypted_password: Field::String.with_options(searchable: false),
    password: Field::String.with_options(searchable: false),
    password_confirmation: Field::String.with_options(searchable: false),
    reset_password_token: Field::String.with_options(searchable: false),
    reset_password_sent_at: Field::DateTime,
    remember_created_at: Field::DateTime,
    sign_in_count: Field::Number,
    current_sign_in_at: Field::DateTime,
    last_sign_in_at: Field::DateTime,
    current_sign_in_ip: Field::String.with_options(searchable: false),
    last_sign_in_ip: Field::String.with_options(searchable: false),
    created_at: Field::DateTime,
    updated_at: Field::DateTime,
    name: Field::String,
    confirmation_token: Field::String.with_options(searchable: false),
    confirmed_at: Field::DateTime,
    confirmation_sent_at: Field::DateTime,
    unconfirmed_email: Field::String,
    own_published_articles: Field::HasMany.with_options(class_name: 'Article'),
    about: SummernoteField,
    city: Field::String,
    state: Field::String,
    slug: Field::String,
    points: Field::Number,
    avatar: UploadedImageField,
  }.freeze

  # COLLECTION_ATTRIBUTES
  # an array of attributes that will be displayed on the model's index page.
  #
  # By default, it's limited to four items to reduce clutter on index pages.
  # Feel free to add, remove, or rearrange items.
  COLLECTION_ATTRIBUTES = [
    :id,
    :avatar,
    :name,
    :slug,
    :email,
    :current_sign_in_at,
    :own_published_articles,
  ].freeze

  # SHOW_PAGE_ATTRIBUTES
  # an array of attributes that will be displayed on the model's show page.
  SHOW_PAGE_ATTRIBUTES = [
    :id,
    :role,
    :avatar,
    :email,
    :unconfirmed_email,
    :name,
    :slug,
    :points,
    :sign_in_count,
    :created_at,
    :confirmed_at,
    :current_sign_in_ip,
    :current_sign_in_at,
    :last_sign_in_ip,
    :last_sign_in_at,
    :about,
    :city,
    :state,
    :own_published_articles,
  ].freeze

  # FORM_ATTRIBUTES
  # an array of attributes that will be displayed
  # on the model's form (`new` and `edit`) pages.
  FORM_ATTRIBUTES = [
    :email,
    :name,
    :slug,
    :about,
    :city,
    :state,
    :role,
  ].freeze

  # Overwrite this method to customize how users are displayed
  # across all pages of the admin dashboard.
  #
  def display_resource(user)
    "#{user.name} [##{user.id}]"
  end
end
