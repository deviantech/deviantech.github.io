# frozen_string_literal: true

class EngagementRewardLevelDashboard < ApplicationDashboard
  def index_message
    %q{When a user reaches the appropriate point level, they'll automatically be rewarded as per this table. <em>Remember that to maintain the stated goal of lots of rewards early on while limiting overall costs, you'll want to be very careful to make sure later rewards have larger deltas between their point triggers than earlier ones.</em>}
  end

  ATTRIBUTE_TYPES = {
    engagement_rewards: Field::HasMany,
    id: Field::Number,
    points: Field::Number,
    kind: Field::Enum.with_options(collection: EngagementReward::VALID_KINDS),
    level: Field::String.with_options(hint: "Badge name - only applicable if kind is 'badge'"),
    label: Field::String.with_options(searchable: false),
    face_value: Field::CollectionSelect.with_options(collection: -> { EngagementRedemption::VALID_REDEMPTION_DOLLAR_VALUES.map {|n| ["$#{n}.00", n]} }, value_method: :last, text_method: :first, options: {include_blank: true}, multiple: false, label: 'Repeatable'),
    created_at: Field::DateTime,
    updated_at: Field::DateTime,
  }.freeze

  COLLECTION_ATTRIBUTES = [
    :points,
    :kind,
    :label,
    :engagement_rewards,
  ].freeze

  SHOW_PAGE_ATTRIBUTES = [
    :label,
    :id,
    :points,
    :kind,
    :level,
    :face_value,
    :created_at,
    :updated_at,
  ].freeze

  FORM_ATTRIBUTES = [
    :points,
    :kind,
    :level,
    :face_value,
  ].freeze


  def display_resource(obj)
    obj.label
  end
end
