# frozen_string_literal: true

class EngagementConfigDashboard < ApplicationDashboard
  def index_message
    "The following engagement events are hard-coded to fire at the appropriate times. This section allows you to control what (if anything -- set points to zero and they'll never be created) happens when each event is triggered."
  end

  ATTRIBUTE_TYPES = {
    id: Field::String,
    description: Field::String,
    points: Field::Number,
    repeatable: Field::CollectionSelect.with_options(collection: -> { EngagementConfig::VALID_REPEATABLE_OPTIONS_FOR_SELECT }, value_method: :last, text_method: :first, options: {}, multiple: false, label: 'Repeatable'),
    user_action: Field::Boolean,
    thing_required: Field::Boolean,
    first_bonus: Field::Number,
    max_per_month: Field::Number,
    created_at: Field::DateTime,
    updated_at: Field::DateTime,
  }.freeze

  COLLECTION_ATTRIBUTES = [
    :id,
    :description,
    :points,
    :first_bonus,
    :max_per_month,
  ].freeze

  SHOW_PAGE_ATTRIBUTES = [
    :id,
    :description,
    :points,
    :repeatable,
    :user_action,
    :thing_required,
    :first_bonus,
    :max_per_month,
  ].freeze

  FORM_ATTRIBUTES = [
    :description,
    :points,
    :repeatable,
    :first_bonus,
    :max_per_month,
  ].freeze

  def display_resource(o)
    "Engagement Config: #{o.id}"
  end
end
