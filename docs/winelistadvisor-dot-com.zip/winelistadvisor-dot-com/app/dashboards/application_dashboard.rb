# frozen_string_literal: true

require "administrate/base_dashboard"

class ApplicationDashboard < Administrate::BaseDashboard

  def display_resource(resource)
    resource.label
  end

end
