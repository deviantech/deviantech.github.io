# frozen_string_literal: true

# W/ administrate 0.8.1 scoped controllers were supported directly, but still patching to allow
# showing different attributes depending on the current scope.
class ScopedResourcesDashboard < ApplicationDashboard

  def initialize(current_scope=nil)
    @current_scope = current_scope
  end

  def collection_attributes
    super + collection_attributes_for_scope(@current_scope)
  end

  def collection_attributes_for_scope(scope)
    []
  end

  def show_page_attributes
    super + show_page_attributes_for_scope(@current_scope)
  end

  def show_page_attributes_for_scope(scope)
    []
  end

end
