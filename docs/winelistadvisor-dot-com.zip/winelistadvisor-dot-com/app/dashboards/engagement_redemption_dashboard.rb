# frozen_string_literal: true

class EngagementRedemptionDashboard < ScopedResourcesDashboard
  def custom_actions?; true; end
  def custom_show?; true; end

  # ATTRIBUTE_TYPES
  # a hash that describes the type of each of the model's fields.
  #
  # Each different type represents an Administrate::Field object,
  # which determines how the attribute is displayed
  # on pages throughout the dashboard.
  ATTRIBUTE_TYPES = {
    user: Field::BelongsTo,
    marked_paid_by: Field::BelongsTo.with_options(class_name: "User"),
    engagement_reward: Field::BelongsTo,
    id: Field::Number,
    marked_paid_at: Field::DateTime,
    created_at: Field::DateTime,
    updated_at: Field::DateTime,
    points: Field::Number,
    face_value: Field::Number,
    order_number: Field::String,
    user_email: Field::String.with_options(searchable: false),
  }.freeze

  # COLLECTION_ATTRIBUTES
  # an array of attributes that will be displayed on the model's index page.
  #
  # By default, it's limited to four items to reduce clutter on index pages.
  # Feel free to add, remove, or rearrange items.
  COLLECTION_ATTRIBUTES = [
    :id,
    :user,
    :face_value,
  ].freeze

  def collection_attributes_for_scope(scope)
    case scope
    when 'pending' then [:user_email, :created_at]
    when 'paid'    then [:marked_paid_at, :order_number]
    else []
    end
  end

  # SHOW_PAGE_ATTRIBUTES
  # an array of attributes that will be displayed on the model's show page.
  SHOW_PAGE_ATTRIBUTES = [
    :id,
    :user,
    :user_email,
    :face_value,
    :points,
    :created_at,
    :updated_at,
  ].freeze

  def show_page_attributes_for_scope(scope)
    case scope
    when 'pending' then []
    when 'paid'    then [:marked_paid_by, :marked_paid_at, :order_number]
    else []
    end
  end

  FORM_ATTRIBUTES = [].freeze

  def display_resource(redemption)
    "#{redemption&.user&.name} #{redemption.pending? ? 'Pending' : 'Paid'} Gift Card [##{redemption.id}]"
  end
end
