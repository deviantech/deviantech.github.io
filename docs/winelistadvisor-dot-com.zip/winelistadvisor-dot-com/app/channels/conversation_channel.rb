# frozen_string_literal: true

class ConversationChannel < ApplicationCable::Channel

  def subscribed
    @conversation = Conversation.find(params[:conversation_id])
    stream_for @conversation
  end

  def send_message(data)
    @conversation.add_message(current_user, data['message'])
  end

  def set_typing_indicator(data)
    self.class.broadcast_to @conversation, data.merge(topic: 'typing')
  end

end
