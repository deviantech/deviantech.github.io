# frozen_string_literal: true

require "administrate/field/base"

class Link < Administrate::Field::String
  def to_s
    data.to_s
  end
end
