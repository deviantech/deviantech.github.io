# frozen_string_literal: true

require "administrate/field/base"

class FlaggableField < Administrate::Field::HasMany

  def initialize(*args)
    super
    @options[:dashboard] = Moderation::FlaggingDashboard
  end

  def data
    FlaggableFieldDecorator.decorate_collection(super)
  end

end
