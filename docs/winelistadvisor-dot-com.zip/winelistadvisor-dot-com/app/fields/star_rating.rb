# frozen_string_literal: true

require "administrate/field/base"

class StarRating < Administrate::Field::Number
  def to_s
    data.to_s
  end
end
