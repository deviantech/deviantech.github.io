# frozen_string_literal: true

require "administrate/field/base"

class SummernoteField < Administrate::Field::Base
  def to_s
    data.to_s.html_safe
  end
end
