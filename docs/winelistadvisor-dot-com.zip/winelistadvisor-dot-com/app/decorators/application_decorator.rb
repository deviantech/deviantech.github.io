# frozen_string_literal: true

class ApplicationDecorator < Draper::Decorator
  delegate_all
  delegate :content_tag, :concat, :pluralize, :url_for, :link_to, :user_name, :image_tag, :dom_id, :user_signed_in?, :current_user, :restaurant_path, :article_path, :glyph, :icon, to: :h

  def self.collection_decorator_class
    PaginatingDecorator
  end

  def tr(field, label = field.to_s.titleize)
    return unless (value = send(field)).present?
    content_tag :tr do
      concat content_tag(:th, label)
      concat content_tag(:td, value)
    end
  end

  private

  def has_any_field?(fields)
    Array(fields).any? do |field|
      send(field).present?
    end
  end

  def user_link(user, **args)
    return h.user_link(user, args) if user
    args[:context] == :possessive ? "a member (since removed)'s" : "a member, since removed,"
  end

end
