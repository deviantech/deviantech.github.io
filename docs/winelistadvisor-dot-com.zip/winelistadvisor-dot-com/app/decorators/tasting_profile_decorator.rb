# frozen_string_literal: true

class TastingProfileDecorator < ApplicationDecorator

  def og_meta_tags
    user&.decorate&.og_meta_tags(context: :tasting_preferences)
  end

  def has_other_preferences?
    has_any_field? %w(memorable_experiences favorite_wineries favorite_wines)
  end

  def display_enum(key)
    val = case key
    when :seeking
      seeking.present? && TastingProfile::SEEKING_OPTIONS.detect {|k,v| k.to_s == seeking }
    when :purchase_influences
      purchase_influences.present? && TastingProfile::PURCHASE_INFLUENCES_OPTIONS.detect {|k,v| k.to_s == purchase_influences }
    else
      raise "Unknown enum key: #{key}"
    end

    val ? val[1] : 'Not answered'
  end

end
