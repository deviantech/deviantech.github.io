# frozen_string_literal: true

class NotificationDecorator < ApplicationDecorator
  class UnknownTopicError < StandardError; end

  PARTIAL_TOPICS = (Dir.entries(Rails.root + 'app/views/notifications').grep(/^_/).map {|f| f.sub(/^_/, '').split('.').first } - ['notification']).freeze

  def self.decorated_for(user, num_to_show)
    decorate_collection user.notifications.includes(:thing, :thing_context).limit(num_to_show)
  end

  def has_partial?
    PARTIAL_TOPICS.include?(key)
  end

  def when
    if created_at > 1.day.ago
      raw = h.time_ago_in_words(created_at).gsub(/ minutes/, 'm').gsub(/ hours/, 'h').sub(/about /, '')
      raw.match(/second/) ? '< 1m' : raw
    else
      created_at.strftime("%m/%e").sub(/\s+/, '')
    end
  end

  def headline
    msg = case key
    when 'content.liked'
      if thing
        who  = user_link(thing.user)
        decorated = thing.decorate

        "#{who} liked #{decorated.label}"
      else
        "Someone liked a piece of your content (since unliked)"
      end
    when 'friend_request:pending' then "Friendship request received from %s" % user_link(thing_context)
    when 'friend_request:accepted'
      template = if data['status_was'] == 'requested'
        "You are now friends with %s"
      else
        "%s accepted your friend request"
      end
      template % user_link(thing_context)

    when "wall_post.created"
      link = (thing && thing.user) ? link_to('posted', h.user_home_url(anchor: dom_id(thing))) : 'posted (since removed)'
      "#{user_link(thing_context)} %s on your profile" % link
    when "wall_post.commented_on"
      who  = user_link(thing&.user)
      what = thing ? link_to("your post", h.view_comment_url(thing)) : 'your post (since removed)'
      where = thing_context && case thing_context.thing
      when Current.user then 'your wall'
      when thing.user then 'their wall'
      else  "#{user_link thing_context.thing}'s wall"
      end

      msg = "#{who} commented on #{what}"
      where ? [msg, where].join(' on ') : msg


    when /moderation:hidden/  then thing ? "Moderators have hidden your #{link_to thing, thing}" : "Moderators felt the need to hide something you posted (since removed)"
    when /moderation:shown/   then thing ? "Moderators have unhidden your #{link_to thing, thing}" : "Moderators un-hid something you'd posted (since removed)"
    when "moderation:flagged" then thing ? "Someone flagged your #{link_to thing, thing} #{(r = thing_context&.reason) ? %Q{as #{r.humanize.downcase}} : ''}" : "Someone flagged something you'd posted (since removed) #{(r = thing_context&.reason) ? %Q{as #{r.humanize.downcase}} : ''}"

    when "comment.on_comment_thread"
      who = user_link( User.find_by(id: data['commenter_id']) )
      owner = user_link(thing_context.responsible_user, context: :possessive)
      what = thing ? h.view_comment_url(thing) : 'posting (since removed)'

      "#{who} also commented on #{owner} #{what}"
    when "article.commented_on"
      who  = user_link(thing&.user)
      cmnt = thing ? 'commented on' : 'commented on (since removed)'
      what = thing_context ? link_to("your article", h.article_url(thing_context, anchor: thing ? dom_id(thing) : nil)) : 'your article (since removed)'

      "#{who} #{cmnt} #{what}"
    when "activity.commented_on"
      who  = user_link(thing&.user)
      cmnt = thing ? 'commented on' : 'commented on (since removed)'
      what = thing_context ? link_to("an activity item", h.view_activity_url(thing_context)) : 'an activity item (since removed)'

      "#{who} #{cmnt} #{what}"
    when "article.published"    then thing ? "Your article #{link_to(thing, thing)} was published in #{thing.category.name}" : 'Your article (since removed) was published'
    when "article.rejected"     then thing ? "Your article #{link_to(thing, thing)} was declined for publication in #{thing.category.name}" : 'Your article (since removed) was declined for publication'
    when "article.contest:won"  then
      what = thing_context ? "article #{link_to(thing_context, thing_context)}" : 'article (since removed)'
      "Your #{what} won %s" % thing.name
    when "restaurant.reviewed"
      what = thing_context ? "your restaurant #{link_to thing_context, thing_context, anchor: thing ? dom_id(thing) : nil}" : "your restaurant (since removed)"
      action = thing ? 'reviewed' : 'reviewed (review since removed)'
      "#{user_link(thing&.user)} #{action} #{what}"
    when "restaurant.claim_approved"  then thing ? "Your ownership claim was approved for #{link_to thing, thing}" : 'Your ownership claim was approved for a restaurant (since removed)'
    when "restaurant.claim_rejected"  then thing ? "Your ownership claim was declined for #{link_to thing, thing}" : 'Your ownership claim was declined for a restaurant (since removed)'
    when "wine_program.contest:won"
      what = user_wine_program_link(thing)
      target = user_wine_program_target(thing_context)
      "Your #{what} for #{target} won %s" % thing.name
    when "wine_program:accepted"
      what = user_wine_program_link(thing)
      target = user_wine_program_target(thing)
      "Your #{what} was approved for #{target}"
    when "wine_program:not_accepted"
      what = user_wine_program_link(thing)
      target = user_wine_program_target(thing)
      extra = 'draft' == data['state'] ? nil : WineProgram.display_state( data['state'] ).downcase

      ["Your #{what} was declined for #{target}", extra].compact.join(': ')
    when 'engagement_reward.earned.badge' then "You have earned a new badge for your engagement on the site!"
    when 'engagement_reward.earned.payout'
      msg = "You have earned a $#{thing.face_value} gift card for your engagement on the site"
      msg += ", which will be issued shortly" if thing&.engagement_redemption&.pending?
      msg += ", which was issued on #{thing.engagement_redemption.marked_paid_at.strftime("%B %e, %Y")}" if thing&.engagement_redemption&.paid?
      msg
    when "engagement_redemption:paid"
      thing ? "You have been issued a $#{thing.face_value} gift card for your engagement on the site!" : "You were issued a gift card (since removed) for your engagement on the site"
    when "conversation.message_received"
      # Note: cannot use thing_context, because we've got a UUID that won't stay in the ID field
      what = thing ? link_to('a message', h.conversation_url(thing.conversation_id, anchor: dom_id(thing))) : 'a message (since removed)'
      "#{user_link(thing.user)} sent you #{what}"
    when 'system.social.autopost_network_connected'
      if thing
        all_disabled = thing.notify_on.none? {|k,v| v == '1'}
        settings_link = link_to all_disabled ? 'enable autoposting here' : 'edit autoposting here', h.edit_user_registration_path(anchor: dom_id(thing))
        "Your newly-connected <b>#{thing.provider.titleize}</b> account (<em>#{thing.account_label}</em>) can automatically post certain activity you take on WineListAdvisor to #{thing.provider.titleize}. You may wish to #{settings_link}!"
      else
        "You connected an external network that supported autoposting, but the connection has since been removed."
      end
    when 'system.points.expiring_soon'
      expiry = DateTime.parse(data['expiry_date'])

      had_have = expiry < Time.now ? 'had' : 'have'
      chrono = expiry < Time.now ? 'set to expire' : 'that will expire'

      "You #{had_have} #{pluralize data['points'], 'wine point'} #{chrono} #{expiry.strftime("%B %e, %Y")}"
    when 'system.points.expired'
      "You had #{pluralize data['points'], 'wine point'} expire on #{created_at.strftime("%B %e, %Y")}"
    when 'system.account_email_confirmation.reminder'
      # TODO: add way to hide no-longer-relevant notifications like acted-on reminders (simplest: just delete them once no longer relevant)
      if user.confirmed_at then "You were reminded to confirm your account email address (since completed)"
      else
        url = h.confirmation_url(user, confirmation_token: user.confirmation_token)
        "<b>Reminder</b>: in order to continue accessing the site you must #{link_to 'confirm your email address', url} before <b>#{(created_at + Devise.allow_unconfirmed_access_for).strftime("%B %e, %Y")}</b>"
      end
    when 'system.web_message'
      data['msg']
    else
      raise UnknownTopicError, "Unknown notification topic: #{key}"
    end

    msg.sub(/\,\s*$/, '').html_safe
  end

  def details
    str = case key
    when 'content.liked'
      case thing_context
      when Activity
        case thing_context.topic
        when 'wall_post' then thing_context.body
        when 'friendship'
          friends = [thing_context.user, thing_context.thing_context] - [user]
          if friends.length == 2
            "Friendship between #{friends[0].name} and #{friends[1].name}"
          else
            "Your friendship with #{friends[0].name}"
          end
        end
      end
    when /comment/, 'wall_post.created', 'conversation.message_received' then thing&.body
    when 'article.rejected' then thing.review_feedback
    when 'system.web_message' then data['details']
    when 'engagement_reward.earned.badge' then "New level: #{thing.level}"
    end

    str.present? ? h.truncate(str, length: 200) : nil
  end

  def image(size: 50)
    url = case key_parts.first
    when 'article'
      if key == 'article.commented_on'
        thing&.user&.avatar&.url("s#{size}")
      else
        what = key =~ /contest/ ? thing_context : thing
        what.featured_image.url("s#{size}")
      end
    when 'comment', 'conversation', 'wall_post', 'content.liked' then thing&.user&.avatar&.url("s#{size}")
    when 'friend_request' then thing_context.avatar.url("s#{size}")
    when 'restaurant' then (thing.respond_to?(:reviewable) ? thing.reviewable : thing)&.avatar&.url
    end

    url ? h.image_tag(url) : nil
  end


  private

  def user_wine_program_link(program)
    return "wine program submission (since removed)" unless program

    link_to('wine program submission', h.wine_programs_user_url(Current.user, anchor: dom_id(program)))
  end

  def user_wine_program_target(target)
    target ? "restaurant #{link_to(target.restaurant, target.restaurant)}" : 'a restaurant (since removed)'
  end

end
