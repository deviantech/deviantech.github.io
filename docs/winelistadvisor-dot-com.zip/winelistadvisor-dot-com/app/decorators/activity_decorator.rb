# frozen_string_literal: true

class ActivityDecorator < ApplicationDecorator
  class UnknownTopicError < StandardError; end

  def self.decorated_feed_for(context, user, page, per_page)
    base_scope = case context
    when :home then Activity.home_feed_for(user)
    when :activity then Activity.activity_feed_for(user)
    else raise ArgumentError, "Unknown context: #{context}"
    end

    decorate_collection base_scope.visible.includes(:user, :thing, :thing_context, :images, comments: :user).page(page).per(per_page)
  end

  PARTIAL_TOPICS = (Dir.entries(Rails.root + 'app/views/activities').grep(/^_/).map {|f| f.sub(/^_/, '').split('.').first } - ['activity']).freeze
  FLAGGABLE_TOPICS = %w(wall_post).freeze

  def og_meta_tags
    return unless topic == 'wall_post'

    img = images.blank? ? nil : images.map do |image|
      {
        url: image.image.url.sub('localhost:3000', 'wladev.localtunnel.me'),
        height: image.respond_to?(:image_height) && image.image_height,
        width: image.respond_to?(:image_width) && image.image_width,
        alt: "Shared image"
      }.delete_if {|k,v| v.blank? }
    end

    {
      type: 'article',
      url: h.view_activity_url(model),
      title: "#{img ? 'Images posted' : 'Posting'} by #{user_name user, personalize_to_you: false}",
      description: body.present? ? body : "Shared by #{user_name user}",
      image: img,
      _: {
        article: {
          published_time: created_at,
          publisher: App.social[:facebook],
          section: 'Wall Post'
        }
      }
    }
  end


  def has_partial?
    PARTIAL_TOPICS.include?(topic)
  end

  def flaggable?
    FLAGGABLE_TOPICS.include?(topic)
  end

  def users_for_headshots
    case topic&.to_sym
    when :friendship
      [user, thing_context].compact.sort {|a,b| Current.user == a ? -1 : 1 }
    else [user]
    end.compact
  end

  def headline
    msg = case topic&.to_sym
    when :wall_post
      if user == thing then 'posted'
      elsif thing then "posted on #{user_link thing, context: :possessive, capitalize: false} profile"
      else "posted on another member's profile (since removed)"
      end
    when :friendship
      users = [user, thing_context].compact.sort {|a,b| Current.user == a ? -1 : 1 }
      return "#{h.user_link(users[0])} became friends with #{users[1] ? h.user_link(users[1]) : 'another member (since removed)'}".html_safe
    when :review
      if thing_context
        what = link_to thing_context.name, h.restaurant_path(thing_context, anchor: thing ? dom_id(thing) : nil)
        what += ' (review since removed)' unless thing
        "reviewed #{what}"
      else
        "reviewed an entity that has since been removed"
      end
    when :comment
      if thing_context
        what = link_to thing_context.name, thing_context, anchor: thing ? dom_id(thing) : nil
        what += ' (comment since removed)' unless thing
        "commented on #{what}"
      else
        "commented on an entity that has since been removed"
      end
    when :published_article
      if thing then "published #{link_to thing.title, thing}"
      else "published an article (since removed)"
      end
    when :claimed_restaurant
      thing ? "claimed the restaurant #{link_to thing.name, thing}" : "claimed a restaurant that has since been removed"
    when :updated_user_profile
      "updated #{Current.user && Current.user == user ? 'your' : 'their'} #{link_to('profile', h.profile_user_path(user))}"
    when :updated_restaurant_profile
      thing ? "updated restaurant profile for #{link_to thing.name, thing}" : "updated profile for a restaurant that has since been removed"
    when :article_contest_winner
      "won the #{thing_context.name} with #{thing ? link_to(thing.name, thing) : 'an article that has since been removed'}"
    when :wine_program_contest_winner
      base = "won the #{thing_context.name}"
      if data['restaurant_id'] && r = Restaurant.find(data['restaurant_id'])
        base += " with information for #{link_to r.name, r}"
      end
      base
    when :engagement_reward
      "earned a new badge: <b>#{thing.level}</b>"
    when :completed_tasting_profile
      "completed #{h.user_possessive_it(user)} #{link_to 'Wine Tasting Preferences', h.tasting_profile_user_path(user)}"
    else
      raise UnknownTopicError, "Unknown activity topic: #{topic}"
    end

    [h.user_link(user), msg.sub(/\,\s*$/, '')].join(' ').html_safe
  end

  def details
    str = case topic&.to_sym
    when :updated_user_profile then data&.keys&.length > 0 ? "Changed: #{data.keys.map(&:humanize).to_sentence}" : nil
    when :published_article then "Posted in: #{link_to thing_context.name, h.articles_by_path(category: thing_context.slug)}".html_safe
    when :completed_tasting_profile
      if thing&.red_wine.present? && thing&.white_wine.present?
        "Overall rating is #{thing.red_wine}/10 for reds and #{thing.white_wine}/10 for whites."
      end
    end

    str.present? ? h.truncate(str, length: 200) : nil
  end

  # For Administrate
  def source_link
    raise "source_url not defined for non-flaggable activities" unless flaggable?

    link_to(activity, h.activity_user_path(thing, anchor: dom_id(activity)), target: '_blank')
  end

end
