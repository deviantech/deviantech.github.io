# frozen_string_literal: true

class CommentDecorator < ApplicationDecorator

  def source_link
    h.link_to comment.label, source_url, target: '_blank'
  end

  def source_url
    [h.url_for(comment.commentable), h.dom_id(comment)].join('#')
  end

  def body
    if hidden_by_flags?
      h.content_tag(:div, '[This comment has been hidden by moderators.]', class: 'moderated-notice')
    else
      model.body
    end
  end

end
