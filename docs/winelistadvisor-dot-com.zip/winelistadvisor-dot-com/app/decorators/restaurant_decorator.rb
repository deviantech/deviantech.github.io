# frozen_string_literal: true

class RestaurantDecorator < ApplicationDecorator

  def og_meta_tags
    img = {
      url: avatar.url,
      alt: "Featured Image for #{name}"
    }

    {
      type: 'restaurant.restaurant',
      url: h.restaurant_url(model),
      title: name,
      image: img,
      description: description.present? ? h.truncate(description, length: 300) : "Restaurant profile on WineListAdvisor.",
      _: {
        restaurant: {
          category: categories,
          price_rating: price_range.to_i < 1 ? nil : (price_range > 4 ? 4 : price_range),
          contact_info: {
            email: email,
            phone_number: phone,
            website: website,
            street_address: address.join(', '),
            locality: city,
            region: state,
            postal_code: zip,
            country_name: country
          },
          menu: sp_menus.map {|m| h.menu_restaurant_url(model, m) }
        },
        place: {
          location: {
            latitude: latitude,
            longitude: longitude
          }
        }
      }
    }
  end

  def wine_menu_link
    url = if wm = sp_menus.detect {|m| m.name =~ /wine/i }
      h.menu_restaurant_path(model, wm)
    elsif pdf_menus.any?
      h.restaurant_pdf_menu_path(model, pdf_menus.first)
    end

    return link_to('View Wine Menu', url, class: 'btn btn-block btn-primary') if url

    return unless external_menu_url.present?

    link_to('View External Wine Menu', external_menu_url, class: 'btn btn-block btn-primary', target: '_blank', rel: :nofollow, data: {toggle: 'tooltip'}, title: external_menu_url)
  end

  def show_overview_title?
    return false unless wine_program
    return true if wine_program.contact_email.present?
    %w(regional_specialty highlights discounts awards).each do |field|
      return true if wine_program.send(field).present?
    end

    nil
  end

  def show_details?
    info_fields(with_program_info: true).present?
  end

  def view_detail(detail)
    case detail
    when 'hours' then display_hours
    when 'map'   then google_map_link
    when 'pairing-guide' then display_pairing_guide
    end
  end

  def show_item(*path, **opts)
    val = model
    path.each {|part| val = val&.send(part) }
    return unless val.present?

    klasses = opts.delete(:class)
    label = opts[:label] || path.last.to_s.titleize

    content_tag(:div, class: "masonry-item #{klasses}") do
      concat content_tag(:h6, "#{label}: ")
      concat content_tag(:p, val)
    end
  end

  def google_map_modal_link
    return unless latitude.present?
    h.link_to_modal h.glyph(:globe) + 'View on Google Maps', h.view_detail_restaurant_path(model, 'map')
  end

  # https://developers.google.com/maps/documentation/static-maps/intro
  def google_map_link(link_text: :image)
    return unless latitude.present?
    loc = "#{latitude},#{longitude}"
    txt = if link_text == :image
      width, height = 640, 640
      h.image_tag "https://maps.googleapis.com/maps/api/staticmap?center=#{loc}&zoom=15&scale=false&size=#{width}x#{height}&maptype=roadmap&key=#{ENV.fetch('GOOGLE_MAPS_KEY')}&format=png&visual_refresh=true&markers=size:mid%7Ccolor:0xff0000%7Clabel:%7C#{loc}", alt: "Google Map of #{name}", class: 'static-map'
    else link_text
    end

    link_to txt, "https://www.google.com/maps/place/#{loc}/", target: '_blank', rel: 'nofollow', class: 'text-center'
  end

  def display_phone(as: :icon, prefix: nil)
    return unless phone && phone_for_display
    base = :text == as ? [prefix, phone_for_display].compact.join(': ') : glyph(:phone)
    h.link_to base, "tel:#{phone}", title: phone_for_display
  end

  def display_email(as: :icon, prefix: nil)
    return unless email
    base = :text == as ? [prefix, email].compact.join(': ') : glyph(:envelope)
    h.link_to base, "mailto:#{email}", title: email
  end

  def website_domain
    uri = website && Addressable::URI.parse(website) rescue nil
    uri.host
  end

  def display_website(as: :icon, prefix: nil)
    return unless website
    base = if :text == as
      [prefix, website_domain].compact.join(': ')
    else glyph(:home)
    end
    h.link_to base, website, title: website, target: '_blank', rel: 'nofollow'
  end

  def foursquare_id
    foreign_ids && foreign_ids['foursquare']
  end

  def foursquare_url
    foursquare_id && "https://foursquare.com/v/#{foursquare_id}"
  end

  def display_foursquare(as: :icon)
    return unless foursquare_id

    base = :text == as ? 'Foursquare' : glyph(:cloud)
    h.link_to base, foursquare_url, title: 'Foursquare', target: '_blank', rel: 'nofollow'
  end

  def display_zagat(as: :icon)
    return # TODO: figure out how to use the zagat ID to link to the zagat profile (then add it to the info_fields section)
    return unless fid = foreign_ids['zagat_web']

    base = 'Zagat'
    h.link_to base, "https://www.zagat.com/r/#{fid}", title: 'Zagat', target: '_blank', rel: 'nofollow'
  end

  def categories
    (yelp_categories_hash.keys + single_platform_categories).sort.uniq
  end

  def neighborhoods
    (self['neighborhoods'] || []).sort
  end

  def display_header_photos
    (avt, photos, total) = photos_for_restaurant
    avt_thumb, avt_full = [(avt.respond_to?(:main) ? avt.main : avt).url, avt.url]

    render = -> {
      h.content_tag :div, class: 'header-photos' do
        h.concat h.lightbox_link avt_thumb, avt_full, gallery: id, title: total > 1 ? "#{name} Photos: 1/#{total}" : avatar? ? "#{name}: Avatar" : "No avatar for #{name}, using default placeholder."
        photos.each.with_index do |photo, idx|
          title = "#{name} Photos: #{idx+2}/#{total}"
          title += " (#{photo.kind})" if photo.kind
          h.concat h.lightbox_link(photo.url, photo.url, gallery: id, title: title, hidden: true)
        end
      end
    }

    if model.persisted?
      Rails.cache.fetch([model, "header_photos"]) { render.call }
    else
      render.call
    end
  end

  def display_photo_thumbs
    (avt, photos, total) = photos_for_restaurant
    return if total.zero?

    render = -> {
      h.content_tag :div, class: 'photos-thumbs' do
        h.concat h.lightbox_link h.glyph(:picture) + h.pluralize(total, 'photo'), avt.url, gallery: id, title: total > 1 ? "#{name} Photos: 1/#{total}" : avatar? ? "#{name}: Avatar" : "No avatar for #{name}, using default placeholder.", text: true
        photos.each.with_index do |photo, idx|
          title = "#{name} Photos: #{idx+2}/#{total}"
          title += " (#{photo.kind})" if photo.kind
          h.concat h.lightbox_link(photo.url, photo.url, gallery: id, title: title, hidden: true)
        end
      end
    }

    if model.persisted?
      Rails.cache.fetch([model, "photos_thumbs"]) { render.call }
    else
      render.call
    end
  end

  def opentable_widget(theme: :standard)
    return unless opentable_id?
    "<script type='text/javascript' src='//www.opentable.com/widget/reservation/loader?rid=#{opentable_id}&domain=com&type=standard&theme=#{theme}&lang=en&overlay=false&iframe=true'></script>".html_safe
  end

  def yelp_rating_stars_local_assets_url
    main, fraction = yelp_rating.to_f.to_s.split('.')
    starname = [main, fraction == "5" ? 'half' : nil].compact.join('_')

    "yelp-assets/small/small_#{starname}.png"
  end

  def price_range_display
    return if price_range.to_i.zero?
    '$' * price_range.to_i
  end

  def contacts?
    (phone && phone_for_display) || website || email
  end

  def display_contacts
    [display_phone, display_email, display_website, display_foursquare].compact.join(' ').html_safe
  end

  def show_wine_program_submission_flash
    return unless user_signed_in?
    msg, type = get_wine_program_submission_flash

    if msg
      content_tag(:div, h.show_flash(type || :notice, msg.html_safe))
    elsif wine_program
      attrib = if wine_program.user_id  != claimed_by_id
        "Info thanks to #{user_link wine_program.user}!"
      elsif orig_user = wine_program.based_on&.user
        "Thanks to #{user_link orig_user} for providing an early version of this information!"
      end

      content_tag(:div, attrib.html_safe, class: 'program-attribution') if attrib
    end
  end

  def details?
    return true if contacts?
    [alcohol_service, meals_served, sp_services_offered, payment_types_accepted].any?(&:present?)
  end


  def info_fields(with_program_info: false)
    cork_notes = if p = with_program_info && wine_program
      if p.corkage? && p.corkage_notes.present?
        glyph('info-sign', data: {toggle: 'popover', content: h.escape_javascript(h.strip_tags(p.corkage_notes))}, title: 'Notes on Corkage')
      end
    end


    [
      wla_select? ? ['Special Awards', "#{icon 'crown'} <strong>WLA Certificate of Excellence!</strong>".html_safe] : nil,
      ['Alcohol',           alcohol_service],
      p ? ['Sommelier',     p.sommelier ? "#{icon 'guy'} Yes".html_safe : 'None available'] : nil,
      p ? ['Corkage Fee',   p.corkage? ? [h.number_to_currency(p.corkage_fee), cork_notes].join(' ').html_safe : 'None'] : nil,
      ['Contact',           display_contacts],
      ['Meals',             Array(meals_served).join(', ')],
      ['Services',          Array(sp_services_offered).map(&:humanize).join(', ')],
      ['Payment Accepted',  Array(payment_types_accepted).join(', ')],
      ['Wine Pairing',      h.lightbox_link('Food and Wine Pairing Tips', h.image_url('wf/wine-folly-food-wine-pairing-infographic.png'), title: "Food & Wine Pairing Guide - Source: http://winefolly.com/review/simple-food-and-wine-pairing/", text: true)],
    ].select {|k,v| v&.present?}
  end

  def has_hours?
    sp_hours.present? || yelp_hours.present?
  end

  def display_hours
    return unless has_hours?
    h.render("restaurants/#{sp_hours.present? ? 'sp_hours' : 'yelp_hours'}", r: self)
  end

  def yelp_hours_by_day
    (yelp_hours || []).group_by {|d| Date::DAYNAMES[ d['day'] ]}
  end

  GUIDED_CATEGORIES = Dir.entries(Rails.root + 'app/views/restaurants/pairing_guides').
    select {|f| f.starts_with?('_') }.
    select {|f| !(f =~ /attribution/) }.
    map { |f| f.split('.')[0].sub(/^_/, '') }

  def pairing_guide?
    GUIDED_CATEGORIES.detect do |g|
      categories.any? {|cat| cat =~ /#{g}/i }
    end
  end

  def guide_for
    return unless guide = pairing_guide?
    categories.detect {|cat| cat =~ /#{guide}/i } || guide.titleize
  end

  def display_pairing_guide
    return unless guide = pairing_guide?
    h.render("restaurants/pairing_guides/#{guide}")
  end

  private

  def get_wine_program_submission_flash
    if claimed?
      if wine_program&.based_on&.user_id == Current.user.id
        <<~EOM
          <b>Thank you for providing an early version of the Wine Program information below!</b>
          Although the restaurant has since been claimed by its owner, your contributions have actively
          benefited all your fellow members and are greatly appreciated.
        EOM
      end
    else
      if pending_review? && claimed_by_id == Current.user.id
        base = "<strong>Your ownership claim for this restaurant is under review.</strong>"
        if program = submitted_wine_programs.pending_ownership_claim.by_user(Current.user).first
          base += <<~EOM
            <br/>You may #{link_to 'edit program information', h.edit_restaurant_wine_program_path(model, program)}
            while you wait, but those edits won't be visible to members until your claim has been approved.
          EOM
        end
        base
      elsif wine_program
        if wine_program.accepted? && wine_program.user_id == Current.user.id
          "<b>Thank you for providing the Wine Program information below!</b> Your contributions are actively benefiting all your fellow members."
        end
      else
        if submitted = submitted_wine_programs.by_user(Current.user).first
          if submitted.draft?
            if submitted.reviewed_at?
              ["Your wine program submission was not accepted. #{link_to 'Click here', h.edit_restaurant_wine_program_path(model, submitted)}
              to edit and resubmit.", :warning]
            else
              ["Your wine program information has not yet been submitted. #{link_to 'Click here', h.edit_restaurant_wine_program_path(model, submitted)}
              to finalize and submit.", :warning]
            end
          elsif submitted.pending?
            '<b>Thank you for your contribution!</b> Admins are currently reviewing your wine program submission.'
          end
        elsif !wine_program_id
          <<~EOM
            <strong>Help our community grow!</strong> This restaurant still needs someone to submit
            #{link_to 'information about its wine program', h.new_restaurant_wine_program_path(model), class: 'spec-submit-wine-info'}.
            <small>If your contributions are accepted, you'll receive
            #{link_to 'Wine Points', h.page_path('help/wine-points'), target: '_blank'}
            in thanks!</small>
          EOM
        end
      end
    end
  end

  def photos_for_restaurant
    (avt, photos, total) = if avatar?
      avatar_path = Addressable::URI.parse(avatar.url).path
      photos = external_photos.of_restaurant.to_a.delete_if {|p| p.url.include?(avatar_path) }

      [avatar, photos, photos.length + 1]
    else
      photos = external_photos.of_restaurant.to_a
      avt = photos.shift

      [avt || avatar, photos, photos.length + (avt ? 1 : 0)]
    end

    [avt, photos, total]
  end

end
