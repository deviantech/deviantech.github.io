# frozen_string_literal: true

class EngagementConfigDecorator < ApplicationDecorator
  delegate_all

  def user_action_link
    case id
    when 'friends.joined_from_invitation'   then h.link_to_modal 'Invite Friends', h.new_invitation_path, class: btns
    when 'article.published'                then link_to 'Write Article', h.new_article_path, class: btns
    when 'system.pending_points_expired'    then link_to 'Check Points', h.points_user_path(Current.user), class: g_btns
    when 'member.completed_tasting_profile' then link_to 'Edit Profile', h.edit_user_tasting_preference_path(Current.user), class: btns
    when 'restaurant.reviewed', 'restaurant.claimed', 'restaurant.wine_program.accepted'
      link_to 'Find Restaurant', h.restaurants_path, class: g_btns
    end
  end

  private

  def btns
    'btn btn-xs btn-primary'
  end

  def g_btns
    'btn btn-xs btn-default'
  end

end
