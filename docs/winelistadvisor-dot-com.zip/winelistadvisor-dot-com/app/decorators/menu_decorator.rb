# frozen_string_literal: true

class MenuDecorator < ApplicationDecorator

  def og_meta_tags
    img = {
      url: restaurant.avatar.url,
      alt: "Featured Image for #{name}"
    }

    {
      type: 'restaurant.menu',
      url: h.menu_restaurant_url(restaurant, model),
      title: "#{restaurant.name} Menu: #{name}",
      description: description.present? ? h.truncate(description, length: 300) : "#{restaurant.name}'s menu on WineListAdvisor.",
      image: img,
      _: {
        restaurant: {
          restaurant: h.restaurant_url(restaurant)
        }
      }
    }
  end

end
