# frozen_string_literal: true

class EngagementDecorator < ApplicationDecorator

  def summary
    msg = case key
    when 'member.completed_tasting_profile'  then "Wine Tasting Profile completed"
    when 'member.joined'                     then "Joined the site"
    when 'restaurant.wine_program.accepted'  then "Successfully submitted information about the wine program at #{restaurant_link(thing)}"
    when 'restaurant.claimed'                then "#{restaurant_link(thing)} claimed successfully"
    when 'contests.article.won'              then "Won the #{thing.name} with #{article_link(thing_context)}"
    when 'article.published'                 then "#{article_link(thing)} was accepted for publication"
    when 'contests.wine_program.won'
      what = restaurant_link(thing_context&.restaurant)
      thing_context&.restaurant ? "Won the #{thing.name} with information for #{what}" : "Won the #{thing.name}"
    when 'restaurant.reviewed'
      "Reviewed restaurant #{restaurant_link(thing)}#{repeat? ? ' again' : ''}"
    when 'system.autoposted_content'      then "You've successfully configured and posted WLA content to an external social network"
    when 'friends.joined_from_invitation'
      if config.repeatable == 'none'
        "A friendship invitation was accepted for the first time (by #{user_link(thing)})"
      else
        "A friendship invitation was accepted by #{user_link(thing)}"
      end
    end

    return unless msg.present?

    msg[0].capitalize! unless msg[0] == '<'
    msg.sub(/\,\s*$/, '').html_safe
  end

  private

  def article_link(object)
    object ? link_to(object.title, article_path(object)) : 'an article, since removed,'
  end

  def restaurant_link(object)
    return 'a restaurant, since removed,' unless object.present?
    object = object.restaurant if object.respond_to?(:restaurant)
    link_to(object.name, restaurant_path(object), anchor: data['review_id'] ? "review_#{data['review_id']}" : nil)
  end

end
