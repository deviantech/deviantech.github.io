# frozen_string_literal: true

class LikeDecorator < ApplicationDecorator

  def label
    return 'like of a since-removed piece of content' unless thing

    case thing
    when Activity
      case thing.topic
      when'wall_post'
        thing.user == Current.user ? 'your post' : "a #{link_to 'post', h.view_liked_url(thing)} on #{user_link(thing.user, context: :possessive)} wall"
      when 'friendship'
        "friendship between #{user_link thing.user} and #{user_link thing.thing_context}"
      else "#{user_link(thing.user, context: :possessive)} #{link_to 'activity', h.view_liked_url(thing)}"
      end
    when Review then "#{user_link(thing.user, context: :possessive)} review of #{link_to thing.reviewable.name, h.view_liked_url(thing)}"
    when Article then "#{user_link(thing.user, context: :possessive)} article #{link_to thing.name, h.view_liked_url(thing)}"
    else "#{user_link(thing.user, context: :possessive)} #{link_to thing.class.name.downcase, h.view_liked_url(thing)}"
    end.html_safe
  end

end
