# frozen_string_literal: true

class ReviewDecorator < ApplicationDecorator

  def title
    if review.title.present? && publicly_visible?
      review.title
    else
      "Rating of #{reviewable_type == 'Restaurant' ? 'Wine Program' : reviewable_type.titleize}"
    end
  end

  def source_link
    link_to review.reviewable.label(:review), source_url, target: '_blank'
  end

  def source_url
    [url_for(review.reviewable), h.dom_id(review)].join('#')
  end

  def rating_breakdown
    [
      ['Overall', rating],
      ['Service', service_rating],
      ['Wines', wines_rating],
      ['Value', value_rating],
    ].map {|(a,b)| b && b > 0 ? "<strong>#{a}</strong>: #{b.to_f}" : nil}.compact.join("<br>").html_safe
  end

  def display_data_fields
    content_tag :div, class: 'review-data-fields' do
      applicable_data_fields.each do |(field, label, opts)|
        val = model.send(field)
        next if val == 'no'
        msg = opts[:glyph] ? h.glyph(opts[:glyph]) : label
        tip = label.downcase.sub('?', '')

        if %w(yes no unsure).include?(val)
          verdict = case val
          when 'yes' then 'Has'
          when 'unsure' then 'May have'
          when 'no' then 'Does not have'
          end
          concat content_tag(:div, msg, class: "#{val} item", data: {toggle: 'tooltip'}, title: "#{verdict} #{tip}")
        elsif opts[:detail]
          concat content_tag(:div, msg, class: 'detail item', data: {toggle: 'tooltip'}, title: "Has #{tip}: #{val}")
        end
      end
    end
  end

end
