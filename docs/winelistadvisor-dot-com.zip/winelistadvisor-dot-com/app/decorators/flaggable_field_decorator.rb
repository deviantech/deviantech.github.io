# frozen_string_literal: true

class FlaggableFieldDecorator < ApplicationDecorator

  def flaggers_other_flaggings_overview
    return unless user.flaggings.count > 1

    msgs = %w(pending confirmed dismissed).map do |kind|
      if (cnt = user.flaggings.send(kind).count) > 0
        [cnt, kind].join(' ')
      end
    end.compact.join(' / ')

    msgs ? "[#{msgs}]" : ''
  end

end
