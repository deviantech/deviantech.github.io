# frozen_string_literal: true

class MessageDecorator < ApplicationDecorator
  decorates Conversation::Message

  ALLOWED_TAGS = %w(a b em strong i br)
  ALLOWED_ATTRIBUTES = %w(href)

  def body
    h.sanitize(model.body, tags: ALLOWED_TAGS, attributes: ALLOWED_ATTRIBUTES).gsub(/\n/, '<br/>').html_safe
  end

  def kind
    type.split('::').last.underscore
  end

  def top_level_partial
    "messages/#{kind}"
  end

  def partial_name
    "messages/#{kind}_#{topic}"
  end

end
