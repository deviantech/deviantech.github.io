# frozen_string_literal: true

class UserDecorator < ApplicationDecorator

  def og_meta_tags(context: :user)
    fb_id = identities.by_provider(:facebook).first
    img = {
      url: avatar.url,
      height: avatar_height,
      width: avatar_width,
      alt: "#{name}'s Avatar"
    }.delete_if {|k,v| v.blank? }

    og_base_for_current_page(context: context).merge({
      type: 'profile',
      title: context == :tasting_preferences ? "#{first_name}'s Wine Tasting Profile" : name,
      image: img,
      _: {
        fb: {
          profile_id: fb_id&.third_party_id
        }
      }
    })
  end

  def has_location_info?
    has_any_field? %w(city state)
  end

  def location_info
    return unless has_location_info?
    [city, state].select(&:present?).join(', ')
  end

  def badge(size: :normal, text: false)
    lvl = user.level.present? ? user.level : 'Brand New Member'
    content_tag :span, text ? lvl.titleize : '', class: "user-badge user-badge-#{text ? 'text' : lvl.underscore} badge-size-#{size}"
  end

  private

  def og_base_for_current_page(context: :user)
    {
      url: context == :tasting_preferences ? h.tasting_profile_user_url(model) : h.profile_user_url(model),
      description: "#{name} has been a WLA member since #{created_at.strftime("%B %e, %Y")}."
    }
  end

end
