# frozen_string_literal: true

class ArticleDecorator < ApplicationDecorator

  def og_meta_tags
    img = {
      url: featured_image.url,
      height: featured_image_height,
      width: featured_image_width,
      alt: "Featured Image for #{title}"
    }.delete_if {|k,v| v.blank? }

    {
      type: 'article',
      url: h.article_url(model),
      title: name,
      description: summary,
      image: img,
      _: {
        article: {
          published_time: reviewed_at,
          publisher: App.social[:facebook],
          section: category.name
        }
      }
    }
  end

  def source_link
    link_to title, h.article_path(model), target: '_blank'
  end

  def author_byline
    return author_alias if author_alias.present?
    user_link user, personalize_to_you: false
  end

end
