# frozen_string_literal: true

class Like < ApplicationRecord
  belongs_to :user
  belongs_to :thing, polymorphic: true, counter_cache: true

  scope :of_thing, ->(thing) {
    where(thing_type: thing.class.name.sub('Decorator', ''), thing_id: thing.id)
  }

  validates :user, uniqueness: {scope: [:thing_type, :thing_id]}

  after_commit :add_notification, :social_broadcast, on: :create

  PUBLISHABLE_THINGS = %w(Article Restaurant)
  LIKEABLE_CLASSES = %w(Article Restaurant Activity Review)

  def self.get_likeable(klass_name, id)
    if LIKEABLE_CLASSES.include?(klass_name)
      klass_name.constantize.find(id)
    end
  end

  private

  def add_notification
    if thing.is_a?(Activity) && thing.topic == 'friendship'
      [thing.user, thing.thing_context].each do |u|
        next if u == user
        u.notify "content.liked", thing: self, thing_context: thing
      end
    else
      return if user == thing.responsible_user
      return if thing.is_a?(Article) && thing.author_alias.present?
      thing.responsible_user&.notify "content.liked", thing: self, thing_context: thing
    end
  end

  def social_broadcast # only social broadcast for articles and restaurants (FB requires an OG object for liking, can't really link to a comment anyway)
    return true unless PUBLISHABLE_THINGS.include?(thing.class.name)
    SocialPublishingService.call(:liked, self)
  end
end
