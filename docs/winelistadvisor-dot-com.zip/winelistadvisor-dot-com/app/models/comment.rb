# frozen_string_literal: true

class Comment < ApplicationRecord
  include Flaggable
  hide_at_n_flags 3

  def label(context=nil)
    "Comment on #{commentable&.label || '[missing object]'}"
  end

  validates :body, presence: true

  belongs_to :user
  belongs_to :commentable, polymorphic: true, counter_cache: true, touch: true

  after_commit :add_activity, :add_notification, :notify_other_commenters, :social_broadcast, on: :create

  default_scope -> { order('id ASC') }


  def commentable_label # For administrate
    commentable&.label
  end

  def to_partial_path
    case commentable
    when Activity then 'comments/comment_minimal'
    else 'comments/comment'
    end
  end

  private

  def add_activity
    Activity.add_comment(self)
  end

  def social_broadcast
    SocialPublishingService.call(:added_comment, self)
  end

  def add_notification
    return if user == commentable.responsible_user
    return if commentable.is_a?(Article) && commentable.author_alias.present?
    klass = commentable.class == Activity && commentable.topic == 'wall_post' ? 'wall_post' : commentable.class.name.underscore
    commentable&.responsible_user&.notify "#{klass}.commented_on", thing: self, thing_context: commentable
  end

  def notify_other_commenters
    commentable.commenting_users.to_a.uniq.each do |commenter|
      next if commenter == user
      next if commenter == commentable.responsible_user
      commenter.notify "comment.on_comment_thread", thing: self, thing_context: commentable, data: { commenter_id: user.id }
    end
  end
end
