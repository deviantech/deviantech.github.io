# frozen_string_literal: true

module Wine # Placeholder for the descriptions
  VARIETAL_DESCRIPTIONS = {
    riesling: 'A floral and fruity white wine that comes in variable sweetness.  Tastes of citrus (lime, lemon juice) and stone fruit (white peach and nectarine, with floral and sweet herbal elements).',
    pinot_gris: 'A dry, light-bodied white grape. The taste is delicate citrus (lime, water, orange zest) and fruits (apple skins and pear sauce).',
    sauvignon_blanc: 'A light-bodied, high-citrus (grapefruit), dry white wine with exotic fruits (melon, passion fruit, kiwi) and an herbal quality (mint, grass, green pepper).',
    chardonnay: 'A medium to full-bodied white wine, tasting of yellow citrus (lemon) and fruits (yellow pear and apple); sometimes having notes of butterscotch, cinnamon and toasted caramel.',
    cabernet_sauvignon: 'A full-bodied red wine tasting of black cherry, black currant and cedar (from oak).  Bold in tannins and has a long finish caused by higher levels of alcohol.',
    syrah: 'A full-bodied red wine tasting of blueberry, plum, meat, black pepper and tobacco; has a meaty taste (jerky, beef broth).',
    zinfandel: 'A medium-bodied red wine tasting of a wide variety of fruits (raspberry, sour cherry, plum, blueberry, blackberry and boysenberry), with notes of sweet tobacco; fruit forward and spicy with a medium length finish.',
    pinot_noir: 'A lighter-bodied red, very dry, tasting of cherry and cranberry, and red-rose with vegetal notes of beet, mushroom and rhubarb.',
  }
end
