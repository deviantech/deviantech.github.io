# frozen_string_literal: true

class BulkInvitation
  include ActiveModel::Model
  attr_accessor :user, :emails, :message
  attr_reader :good_emails, :bad_emails

  validates :user, presence: true
  validate :emails_ok

  def emails=(str)
    @cant_invite = []
    @emails = str.to_s.split(/[,\s]/).map(&:strip).select(&:present?)
    @good_emails, @bad_emails = @emails.partition {|e| e =~ Devise.email_regexp }

    @emails
  end

  def save
    return self unless valid?

    @good_emails.each do |email|
      # If the user we're inviting is already on the site, just invite them directly
      if other_user = User.find_by(email: email)
        next if user.friend_request(other_user)
      end

      # after_commit hook will handle actually sending the associated email
      inv = user.invitations.create(email: email, message: message)
      next if inv.save

      @cant_invite << inv
    end

    return unless valid?
    @persisted = @cant_invite.blank?
  end

  def persisted?
    !! @persisted
  end

  private

  def emails_ok
    if @bad_emails.present?
      errors.add(:emails, "must be properly formatted (these look incorrect: #{@bad_emails.map{|e| "'#{e}'"}.to_sentence})")
    elsif @good_emails.blank?
      errors.add(:emails, "(properly formatted) must be provided")
    elsif @cant_invite.present?
      errors.add(:emails, "weren't all sent (perhaps some were already invited?). Unsent: #{@cant_invite.map(&:email).map{|e| "'#{e}'"}.to_sentence}")
    end
  end

end
