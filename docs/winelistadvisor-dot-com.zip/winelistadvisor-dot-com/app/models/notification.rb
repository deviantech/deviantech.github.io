# frozen_string_literal: true

# Adding a new notifications requires:
#     * Adding key/settings to NOTIFICATIONS constant in this file
#     * Adding key/display to #headline in NotificationDecorator (optional: add details or image as well)
#     * Adding new app/views/mailers/notification_mailer/UNDERSCORED_VERSION_OF_KEY_NAME.html.haml mailer template
#     * Adding new entry in spec/models/notification_spec.rb
class Notification < ApplicationRecord
  default_scope -> { order('id DESC') }
  belongs_to :user
  belongs_to :engagement, required: false
  belongs_to :thing, polymorphic: true, required: false
  belongs_to :thing_context, polymorphic: true, required: false

  scope :unread, -> { where(read_at: nil) }
  scope :read, -> { where.not(read_at: nil) }
  scope :by_key, ->(k) { where(key: k) }

  before_create :create_engagement! # Before, because we store the created engagement record
  after_commit :create_activity!, :send_notifications!, on: :create

  def read?
    !read_at.nil?
  end

  def unread?
    !read?
  end

  def self.mark_read(notes)
    Notification.where(id: notes.pluck(:id)).update_all read_at: Time.now
  end

  CHANNELS = %i(email web).freeze

  def self.underscored_key(key)
    key_parts(key).join('_')
  end

  def self.key_parts(key)
    key.split(/[\.:]/)
  end

  def key_parts
    self.class.key_parts(key)
  end

  def underscored_key
    self.class.underscored_key(key)
  end

  NOTIFICATIONS = {
    "content.liked" => {
      desc: "Someone likes a piece of your content (article, review, etc.)",
      subject: ->(n) { "#{n.thing.user.name} liked your #{n.thing_context.class.name.downcase}" },
      default_skip: [:email]
      },
    "article.commented_on" => {
      desc: "One of your articles is commented on",
      subject: ->(n) { "#{n.thing.user.name} left a comment on your article: #{n.thing_context.title}!" },
      },
    "article.contest:won" => {
      desc: "Your article is selected as the winner of a #{Contests::Article.period_type}ly contest",
      subject: ->(n) { "Congratulations, you've won the #{n.thing.name}!" }
      },
    "article.published" => {
      desc: "One of your articles is accepted for publication",
      subject: ->(n) { "Congratulations, your article '#{n.thing.title}' has been published!" }
      },
    "article.rejected" => {
      desc: "An article is declined for publication",
      subject: ->(n) { "Your article '#{n.thing.title}' was unable to be published at this time" }
      },

    "comment.on_comment_thread" => {
      desc: "Someone comments in a comment thread of which you're already a part",
      subject: ->(n) { "#{n.thing.user.first_name} commented in a comment thread you're part of" }
      },

    "conversation.message_received" => {
      desc: "You receive a message from another user",
      subject: ->(n) { "#{n.thing.user.first_name} messaged you on WLA" },
      unless: ->(n) { n.thing.seen_by?(n.user) }, # Don't bother sending if user's already in the channel/seen the message
      email: { delay: 5.minutes },                # Leave time for user to see themselves
      },

    "engagement_reward.earned.badge" => {
      desc: "You earn a new level badge as a reward for engagement in the community",
      subject: ->(n) { "You've earned a new badge reward on Wine List Advisor!" },
      },

    "engagement_reward.earned.payout" => {
      desc: "You earn a new payout as a reward for engagement in the community",
      subject: ->(n) { "You've earned a new payout reward on Wine List Advisor" },
      },

    "engagement_redemption:paid" => {
      desc: "You're issued a Wine Gift Card as reward for engaging on the site",
      subject: ->(n) { "You've earned Wine from WineListAdvisor.com!" }
      },

    'friend_request:accepted' => {
      desc: "Someone accepts your friend request",
      subject: ->(n) { "#{n.thing_context.name} has accepted your friend request!" },
      unless: ->(n) { n.data['status_was'] == 'requested' }, # Don't bother notifying the user who accepted the friendship
      },
    'friend_request:pending' => {
      desc: "Someone requests you as their friend",
      subject: ->(n) { "#{n&.thing_context ? n.thing_context.name : 'Someone'} has requested you as a friend on WineListAdvisor.com!" }
      },

    "moderation:flagged" => {
      desc: "Something you posted is flagged as inappropriate/spam",
      subject: ->(n) { "Someone flagged your content as #{n.thing_context.reason.humanize.downcase}" }
      },
    "moderation:hidden" => {
      desc: "Moderators hide something you posted",
      subject: ->(n) { "WLA Moderation: content hidden" }
      },
    "moderation:hidden:from_flags" => {
      desc: "Something you posted is hidden due to the number of flags it's received",
      subject: ->(n) { "WLA Moderation: content hidden" }
      },
    "moderation:shown" => {
      desc: "Moderators un-hide something that was previously hidden by them or due to flags",
      subject: ->(n) { "WLA Moderation: content shown" }
      },
    "moderation:shown:from_flags" => {
      desc: "Something you posted is re-shown as the number of flags it's received declines",
      subject: ->(n) { "WLA Moderation: content shown" }
      },

    "restaurant.claim_approved" => {
      desc: "Your claim to own a restaurant is approved",
      subject: ->(n) { "Congratulations, you've successfully claimed your restaurant!" }
      },
    "restaurant.claim_rejected" => {
      desc: "Your claim to own a restaurant is rejected",
      subject: ->(n) { 'Your restaurant claim has not been accepted at this time' }
      },
    "restaurant.reviewed" => {
      desc: "Someone reviews a restaurant you own",
      subject: ->(n) { "#{n.thing.user.first_name} left a review for #{n.thing_context.name}" }
      },

    "wall_post.commented_on" => {
      desc: "Someone comments on something you posted on someone's wall",
      subject: ->(n) { "#{n.thing.user.first_name} commented on a post on your wall" }
      },
    "wall_post.created" => {
      desc: "Someone posts something on your wall",
      subject: ->(n) { "#{n&.thing&.user ? n.thing.user.first_name : 'Someone'} posted on your wall" }
      },

    "wine_program:accepted" => {
      desc: "WLA accepts wine program information you submit for a restaurant",
      subject: ->(n) { 'Congratulations, your Wine List Profile has been published!' }
      },
    "wine_program.contest:won" => {
      desc: "Wine program information you submit for a restaurant wins a #{Contests::WineProgram.period_type}ly contest",
      subject: ->(n) { "Congratulations, you've won the #{n.thing.name}!" }
      },
    "wine_program:not_accepted" => {
      desc: "WLA does not accept wine program information you submit for a restaurant",
      subject: ->(n) {
        (n.thing.owners? || n.thing.pending_ownership_claim?) ? nil : 'Your Wine List Profile submission has not been accepted for publication at this time'
      }
      },

    "system.social.autopost_network_connected" => {
      desc: "You've connected an external network that supports auto-posting",
      subject: ->(n) { "Autoposting to #{n.thing.provider.titleize} is available -- you may want to edit your settings" }
      },
    "system.points.expiring_soon" => {
      hidden: true,
      desc: "Reminder to take action soon to prevent Wine Points from expiring",
      subject: ->(n) { "#{n.data['points'].to_i} Point#{'s' unless n.data['points'] == 1 } expiring soon - take action now!" },
      unless: ->(n) { n.data['points'].to_i.zero? }, # Don't send if there's nothing pending
      },
    "system.points.expired" => {
      hidden: true,
      desc: "Notification that Wine Points have expired",
      subject: ->(n) { "#{n.data['points'].to_i} Point#{'s' unless n.data['points'] == 1 } have expired" },
      unless: ->(n) { n.data['points'].to_i.zero? }, # Don't send if there's nothing pending
      },
    "system.account_email_confirmation.reminder" => {
      hidden: true,
      desc: "Reminder to confirm your account email access to retain site access",
      subject: ->(n) { 'Confirm your email account to retain access!' },
      unless: ->(n) { n.user.confirmed_at.present? },
      },
    "system.web_message" => {
      desc: "Various system status messages",
      skip_channels: [:email]
      },
  }


  def self.notification_groups_for_settings
    to_include = NOTIFICATIONS.select {|k,v| !v[:hidden] } # skip hidden keys (non-currently-active, e.g. wine-related, or system-based and to be sent regardless of settings)
    to_include.group_by {|k,v| group_header_mapping(k.split(/[\.:]/).first) }.sort
  end

  def self.group_header_mapping(raw)
    case raw
    when 'engagement_redemption' then 'Gift Cards'
    when 'moderation' then 'Moderation'
    when 'system' then 'System Notifications'
    else raw.pluralize.titleize
    end
  end

  NOTIFICATIONS.keys.each do |key|
    scope underscored_key(key), -> { where(key: key) }
  end

  def self.add!(key, **params)
    note = new(params.merge(key: key))
    return if note.config[:unless] && note.config[:unless][note]
    note.save
  end

  def email_subject
    config[:subject] && config[:subject][self]
  end

  THING_REQUIRED = %w(wall_post.created)

  # Actual notification occurs in background jobs -- check that sending still needed before actually executing the action
  def still_ready_for_notification?
    return if read?
    return if config[:unless] && config[:unless][self]
    return if THING_REQUIRED.include?(key) && !thing
    true
  end

  def config
    (NOTIFICATIONS[key] || {}).tap do |c|
      CHANNELS.each do |channel|
        c[channel] = c[channel] || {}
      end
    end
  end

  private

  def create_activity!
    activity_key = case key
    when 'friend_request:accepted'    then :add_friendship
    when 'article.published'          then :add_published_article
    when 'restaurant.claim_approved'  then :add_claimed_restaurant
    when 'article.contest:won'        then :add_article_contest_winner
    when 'wine_program.contest:won'   then :add_wine_program_contest_winner
    end

    if activity_key
      Activity.send(activity_key, thing)
    end
  end

  def create_engagement!
    (engagement_key, engagement_user, args) = case key
    when 'article.published'          then ['article.published', thing.user]
    when 'restaurant.claim_approved'  then ['restaurant.claimed', thing.claimed_by]
    when 'article.contest:won'        then ['contests.article.won', thing.winning_user]
    when 'wine_program.contest:won'   then ['contests.wine_program.won', thing.winning_user]
    when 'wine_program:accepted'      then ['restaurant.wine_program.accepted', thing.user]
    end

    if engagement_key
      self.engagement = EngagementService.call( engagement_user, engagement_key, thing, args || {} )
    end
  end

  def skip_channel?(channel)
    config[:skip_channels] && config[:skip_channels].include?(channel)
  end

  def send_notifications!
    Notification::CHANNELS.each do |channel|
      next if skip_channel?(channel)
      next unless user.notify_via?(channel, key)
      send("notify_via_#{channel}")
    end
  end

  def notify_via_email
    NotificationMailer.send(underscored_key, self).deliver_later(wait: config[:email][:delay] || 30.seconds)
  end

  def notify_via_web
    NotificationBroadcastJob.perform_later(self)
  end

end
