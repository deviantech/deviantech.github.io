# frozen_string_literal: true

class TastingProfile < ApplicationRecord
  belongs_to :user
  validates :user, presence: true, on: :create

  def label
    user ? "#{user.name}'s Wine Profile" : "Unattached Wine Profile"
  end

  CATEGORIES = %i(red_wine white_wine champagne rose)

  WINES = {
    reds: %i(cabernet_sauvignon syrah zinfandel pinot_noir malbec merlot sangiovese barbera).sort,
    whites: %i(riesling pinot_gris sauvignon_blanc chardonnay moscato gewurztraminer chenin_blanc).sort
  }
  VARIETALS = WINES.flat_map {|k,v| v }.sort
  ABOUT_LABELS = {
    reds: 'How do you like your Whites? (e.g. dry, acidic, floral, sweet, light-bodied, etc.)',
    whites: 'How do you like your Reds? (e.g.,rich, full-bodied, dry, sweet, dark berries, etc.)',
  }

  after_commit :track_profile_completed

  SEEKING_OPTIONS = [
    [:value,    "Value is most important to me when I purchase wine at a restaurant"],
    [:trending, %q{I am most interested in trying wines that are popular and trending at a restaurant; please show me what's "hot"}],
    [:prestige, 'Prestige is very important to me; I like selecting wines that have a high level of prestige, name recognition, and "cache"'],
    [:variety,  'I am very open to trying new varieties of wines and want to explore the wine list'],
  ]

  PURCHASE_INFLUENCES_OPTIONS = [
    [:discounts,        "Discounts and sales"],
    [:recommendations,  "Recommendations from friends and family"],
    [:expert_ratings,   "Expert ratings"],
    [:tasting_notes,    "Tasting notes"],
  ]

  enum seeking: SEEKING_OPTIONS.map(&:first)
  enum purchase_influences: PURCHASE_INFLUENCES_OPTIONS.map(&:first)

  # Handle inputs from numeric-slider
  def price_range=(hash)
    self.price_min = hash[:Min]
    self.price_max = hash[:Max]
  end

  def profile_completed?
    completed_at.present?
  end

  def profile_begun?
    return true if ENUM_SELECTS.any? {|f| has_value?(f) }
    return true if TEXT_FIELDS.any?  {|f| has_value?(f) }
    return true if FIELDS_WITH_DEFAULTS.any? {|f| has_nondefault_value?(f) }

    false
  end

  DEFAULTS = {
    price_min: 40,
    price_max: 60,
  }.merge(
    (CATEGORIES + VARIETALS).each_with_object({}) {|v,obj| obj[v] = 5 }
  )

  TEXT_FIELDS = %i(geo_preferences favorite_wineries memorable_experiences favorite_wines tasting_expertise about_reds about_whites)
  ENUM_SELECTS = %i(seeking purchase_influences)
  FIELDS_WITH_DEFAULTS = DEFAULTS.keys
  ALL_VALID_PARAMS = TEXT_FIELDS + ENUM_SELECTS + FIELDS_WITH_DEFAULTS + [:id, price_range: [:Min, :Max]]

  private

  def check_profile_completed?
    return unless ENUM_SELECTS.all? {|f| has_value?(f) }
    return unless TEXT_FIELDS.all?  {|f| has_value?(f) }
    return unless FIELDS_WITH_DEFAULTS.all? {|f| has_value?(f) } && FIELDS_WITH_DEFAULTS.any? {|f| has_nondefault_value?(f) }

    true
  end

  def has_value?(f)
    send(f).present?
  end

  def has_nondefault_value?(f)
    has_value?(f) && DEFAULTS[f] != send(f)
  end

  def track_profile_completed
    return unless !profile_completed? && check_profile_completed?
    self.update completed_at: Time.now
    EngagementService.call self.user, 'member.completed_tasting_profile', self
    Activity.add_completed_tasting_profile self.user, self
  end
end
