# frozen_string_literal: true

class WineProgram < ApplicationRecord
  include Contestable

  class << self
    def geo_columns
      %w(submission_latitude submission_longitude submission_geo_accuracy)
    end

    def member_submittable_columns
      geo_columns + %w(corkage corkage_fee corkage_notes discounts sommelier highlights pairing_menu)
    end

    def skip_when_copying
      geo_columns + %w(id restaurant_id created_at updated_at reviewed_at reviewed_by_id user_id state based_on_id)
    end

    def permitted_attributes_for(role = :member)
      return member_submittable_columns unless :owner == role

      ['id'] + (self.column_names - self.skip_when_copying)
    end

    def create_copy_for(user, restaurant:, of: nil)
      return of if of && of.user == user

      new.tap do |c|
        c.based_on_id = of&.id
        c.user = user
        c.restaurant = restaurant

        c.attributes = of.attributes.except( *skip_when_copying ) if of
        c.instance_variable_set("@skip_info_requirements", true)

        c.save!
      end
    end

  end


  belongs_to :restaurant
  belongs_to :user

  belongs_to :reviewed_by, class_name: 'User', required: false
  belongs_to :based_on, class_name: self.name, required: false

  validates :restaurant, presence: true, on: :create
  validate :ensure_only_one_per_user_restaurant, on: :create

  scope :by_user, ->(u) { where(user_id: u.id) }
  scope :by_restaurant, ->(r) { where(restaurant_id: r.id) }


  before_update :prep_track_profile_updates
  after_commit :track_profile_updates, on: :update


  include GuardedStateMachine
  state_machine auto_scopes: true, initial: :draft do
    state :draft
    state :pending, enter: :notify_submitted
    state :accepted
      state :passed_over  # So we can add code to roll back accepting program in the future
    state :owners
      state :pending_ownership_claim
      state :obsoleted    # So we can add code to roll back setting owners in the future


    event :submit do
      transitions from: :draft, to: :pending, guard: :ready_for_submit_guard
    end

    event :accept, timestamp: :reviewed_at, success: :add_notification do
      transitions from: :pending, to: :accepted, on_transition: :handle_acceptance, guard: [:admin_provided_guard, :ready_for_acceptance_guard]
    end

    event :reject, timestamp: :reviewed_at, success: :add_notification do
      transitions from: :pending, to: :draft, guard: :admin_provided_guard
    end

    event :pass_over, timestamp: :reviewed_at, success: :add_notification do
      transitions from: :pending, to: :passed_over, on_transition: :handle_passing_over, guard: :admin_provided_guard
    end

    event :obsolete, timestamp: :reviewed_at, success: :add_notification do
      transitions from: [:pending, :accepted], to: :obsoleted, guard: :admin_provided_guard
    end

    event :mark_as_pending_ownership_claim do
      transitions from: WineProgram.state_machine.states.map(&:name), on_transition: :mark_transitioning_to_owners, to: :pending_ownership_claim
    end

    event :mark_as_owners do
      transitions from: [:draft, :pending, :pending_ownership_claim], to: :owners, on_transition: :handle_ownership, guard: :admin_provided_guard
    end
  end

  def display_state
    self.class.display_state( state )
  end

  def self.display_state( state )
    case state
    when 'pending'      then 'Pending admin review'
    when 'owners'       then "You've claimed ownership over the restaurant"
    when 'passed_over'  then 'A different submission was accepted'
    when 'owners'                   then "You own the restaurant"
    when 'pending_ownership_claim'  then "Your restaurant claim is being evaluated"
    when 'obsoleted'                then 'The owner has claimed their restaurant'
    else state.titleize
    end
  end

  validates :contact_name, :contact_position, :contact_email, presence: true, if: :run_validations_for_owners?

  def label(context=nil)
    "Wine Program at #{restaurant&.name || 'a removed restaurant'}"
  end

  private

  def notify_submitted
    AdminMailer.wine_program_pending_review(self).deliver_later(wait: 1.minute)
  end

  def ensure_only_one_per_user_restaurant
    errors.add(:base, "You have already submitted wine program information for this restaurant!") if WineProgram.by_user(user).by_restaurant(restaurant).any?
  end

  def ensure_info_provided
    return true if @skip_info_requirements
    return true unless self.class.member_submittable_columns.all? {|col| self.send(col).blank? || self.send(col) == '0' }
    errors.add(:base, "Please provide some information about the wine program before saving!")
  end

  def mark_transitioning_to_owners(*_)
    @transitioning_to_owners = true
  end

  # Don't run owner-only validations until after completed assigning ownership
  def run_validations_for_owners?
    return if @skip_info_requirements
    (pending_ownership_claim? || owners?) && !@transitioning_to_owners
  end

  def ready_for_acceptance_guard(*_)
    unless restaurant&.unclaimed?
      msg = if restaurant.nil? then "Wine program is not attached to a restaurant."
      elsif restaurant.claimed? then "The restaurant has been claimed (in which case wine program info can only come from the owner)."
      else "The restaurant's pending ownership claim must be resolved before accepting submitted program information."
      end

      return fail_with_error msg
    end

    unless restaurant.wine_program_id.blank? || restaurant.wine_program_id == self.id
      return fail_with_error "The restaurant already has an accepted Wine Program"
    end

    valid?
  end

  def ready_for_submit_guard(*_)
    if restaurant.nil?
      return fail_with_error "Wine program is not attached to a restaurant."
    end

    if restaurant.claimed?
      return fail_with_error "The restaurant has been claimed (in which case wine program info can only come from the owner)."
    end

    unless restaurant.wine_program_id.blank? || restaurant.wine_program_id == self.id
      return fail_with_error "The restaurant already has an accepted Wine Program"
    end

    return valid?
  end

  def handle_acceptance(admin)
    make_restaurant_use_this
    restaurant.submitted_wine_programs.pending.where.not(id: self.id).map {|p| p.pass_over!(admin) }
  end

  def handle_passing_over(*_)
    self.review_feedback = 'Another submission was already accepted.'
  end

  def handle_ownership(admin)
    @skip_info_requirements = true
    make_restaurant_use_this
    mark_transitioning_to_owners
    restaurant.submitted_wine_programs.where(state: ['pending', 'accepted']).where.not(id: self.id).map {|p| p.obsolete!(admin) }
    # TODO: eventually will want to be able to handle revoking ownership claim, in which case need to automatically put these back for review
  end

  def make_restaurant_use_this(*_)
    restaurant&.update_attribute :wine_program, self
  end

  def track_profile_updates
    return unless @do_track_profile_updates
    Activity.add_updated_restaurant_profile(self)
  end

  def prep_track_profile_updates
    @do_track_profile_updates = owners? && changed? && !state_changed?
    true
  end

  def add_notification
    which = accepted? ? 'accepted' : 'not_accepted'
    user.notify "wine_program:#{which}", thing: self, thing_context: restaurant, data: {state: state}
  end
end
