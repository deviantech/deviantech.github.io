# frozen_string_literal: true

class SpMenu < ApplicationRecord
  belongs_to :restaurant
  has_many :sp_menu_sections, dependent: :destroy, inverse_of: :sp_menu
  accepts_nested_attributes_for :sp_menu_sections
  has_many :sp_menu_items, through: :sp_menu_sections, inverse_of: :sp_menu
end
