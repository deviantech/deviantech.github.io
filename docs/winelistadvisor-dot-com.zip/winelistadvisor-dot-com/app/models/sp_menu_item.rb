# frozen_string_literal: true

class SpMenuItem < ApplicationRecord
  belongs_to :sp_menu_section

  def price
    [price_min, price_max].uniq.compact
  end

  # TODO: Add JS menu display, or better displaying from http://docs.singleplatform.com/spv3/publisher_api/#resources of
  # item_attributes and choices
end
