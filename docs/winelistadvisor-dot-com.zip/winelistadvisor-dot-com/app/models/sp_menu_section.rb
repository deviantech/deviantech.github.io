# frozen_string_literal: true

class SpMenuSection < ApplicationRecord
  belongs_to :sp_menu
  has_many :sp_menu_items, dependent: :destroy, inverse_of: :sp_menu_section
  accepts_nested_attributes_for :sp_menu_items
end
