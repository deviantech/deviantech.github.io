# frozen_string_literal: true

class Conversation < ApplicationRecord
  include ConversationActions
  belongs_to :initiating_user, class_name: 'User'
  has_many :all_messages, class_name: 'Conversation::AbstractMessage', dependent: :destroy
  has_many :messages, -> { where(type: 'Conversation::Message') }, class_name: 'Conversation::Message'
  has_many :events, -> { where(type: 'Conversation::Event') }, class_name: 'Conversation::Event'

  has_many :conversation_participations, dependent: :destroy
  has_many :users, through: :conversation_participations


  validate :users_are_friends, :at_least_two_users, on: :create

  def self.converse_with(user, other_user_ids)
    uids = (other_user_ids.map(&:to_i) + [user.id] - [0]).uniq.sort

    conv = user.conversations.detect do |cn|
      cn.conversation_participations.pluck(:user_id).sort == uids
    end

    conv ||= Conversation.create(user_ids: uids, initiating_user: user)
  end

  def name_for(user)
    (users.pluck(:name) - [user.name]).sort.join(', ')
  end

  def other_users(*these_users)
    users - these_users
  end

  private

  def users_are_friends
    return if users.all? {|u| u == initiating_user || initiating_user.friends_with?(u) }
    errors.add(:base, "You can only begin conversations with your friends")
  end

  def at_least_two_users
    return if user_ids.uniq.length > 1 || users.uniq.count > 1
    errors.add(:base, "You can't start a conversation with yourself!")
  end
end
