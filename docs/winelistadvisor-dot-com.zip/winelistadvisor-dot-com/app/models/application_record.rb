# frozen_string_literal: true

class ApplicationRecord < ActiveRecord::Base
  self.abstract_class = true

  # So if we might have a Decorator or might have a model, we can just
  # call .model to be sure we have the underlying object
  def model
    self
  end

  def label(context = nil)
    if self.respond_to?(:name)
      [generic_label, name || id].join(': ')
    else
      [generic_label, id].join(' ')
    end
  end

  def generic_label(context = nil)
    self.class.name.titleize.downcase
  end

  def to_s
    label
  end
end
