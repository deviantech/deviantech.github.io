# frozen_string_literal: true

class Engagement < ApplicationRecord
  paginates_per 50

  belongs_to :user
  belongs_to :thing, polymorphic: true, required: false
  belongs_to :thing_context, polymorphic: true, required: false
  has_one :engagement_reward

  has_one :notification

  validates :key, :user, presence: true
  validates :thing, presence: true, if: -> { config&.thing_required? }

  scope :before, ->(d) { where( Engagement.arel_table[:created_at].lt(d)) }
  scope :since, ->(d) { where( Engagement.arel_table[:created_at].gt(d)) }
  # NOTE: Postgres-specific: https://blog.modeanalytics.com/postgres-sql-date-functions/
  scope :this_month, -> { where( "DATE_TRUNC('month',created_at) = DATE_TRUNC('month',now())") }
  scope :by_key, ->(k) { where(key: k) if k }
  scope :with_thing, ->(t) { where(thing_id: t.id, thing_type: t.class.name) }

  before_create :calculate_running_total
  after_commit :update_user_points_and_rewards, on: :create
  after_commit :send_notification_of_engagement_points_change, on: :create
  after_commit :send_additional_notifications, on: :create

  def still_ready_for_notification?
    return if config&.user_action?
    return unless points > 0
    true
  end

  def config
    @config ||= EngagementConfig.find(key)
  rescue ActiveRecord::RecordNotFound => e
    return if Rails.env.test?
    raise e
  end

  private

  def calculate_running_total
    return true unless user
    self.running_total = user.engagements.sum(:points) + points
  end

  def update_user_points_and_rewards
    return true unless user && !points.to_f.zero?
    EngagementReward.sync_new_engagement(user, self)
  end

  def send_notification_of_engagement_points_change
    return unless still_ready_for_notification?
    EngagementBroadcastJob.perform_later(self)
  end

  def send_additional_notifications
    case key
    when 'system.pending_points_expired' then user.notify 'system.points.expired', thing: user, thing_context: self, data: {points: points.abs}
    end
  end
end
