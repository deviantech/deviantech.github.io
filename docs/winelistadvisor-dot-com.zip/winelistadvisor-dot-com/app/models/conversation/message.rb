# frozen_string_literal: true

class Conversation::Message < Conversation::AbstractMessage
  belongs_to :user, required: true

  validates :body, presence: true
  validate :user_in_conversation, on: :create
  validates :topic, inclusion: { in: %w(text).freeze }

  private

  def user_in_conversation
    if user.blank?
      errors.add(:user, 'must be provided')
      return
    end

    c_users = conversation&.users
    errors.add(:base, 'You must be part of a conversation send messages to it!') unless c_users && c_users.include?(user)
  end

  def additional_after_commit_broadcasting
    conversation&.users.each do |u|
      next if u == user
      u.notify "conversation.message_received", thing: self, thing_context: nil # Can't store conversation in thing_context b/c UUID, not Integer ID
    end
  end

end
