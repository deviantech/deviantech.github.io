# frozen_string_literal: true

class Conversation::AbstractMessage < ApplicationRecord
  self.table_name = 'messages'
  self.abstract_class = true

  belongs_to :conversation

  scope :by, ->(user) { where(user: user) }
  scope :conversation_events, -> { where(type: 'Conversation::Event') }
  scope :conversation_messages, -> { where(type: 'Conversation::Message') }

  validates :type, inclusion: { in: %w(Conversation::Message Conversation::Event).freeze }


  after_commit :broadcast, on: :create

  def seen_by?(user)
    # TODO: track seen by each participating user: https://github.com/ledermann/unread
    return false
  end

  private

  def broadcast
    MessageBroadcastJob.perform_later(self)
    additional_after_commit_broadcasting
  end

  def additional_after_commit_broadcasting
    # Hook for subclasses (using this rather than a direct after_commit call in subclass
    # in order to be sure the message broadcast job is run first, then any notifications)
  end

end
