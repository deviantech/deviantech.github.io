# frozen_string_literal: true

class Conversation::Event < Conversation::AbstractMessage
  validate :meta_provided, on: :create
  validates :topic, inclusion: { in: %w(users_added users_removed user_left).freeze }

  def related_users
    User.where(id: meta['user_ids'])
  end

  private

  def meta_provided
    return if meta['user_ids'].present?
    errors.add(:base, 'Events expect additional metafields to be set')
  end

end
