class ContentSection < ApplicationRecord
  belongs_to :restaurant
  belongs_to :published_by, class_name: 'User', required: false
  belongs_to :user

  validates :title, presence: true, uniqueness: { scope: :restaurant_id }
  validates :body, presence: true



  include AASM
  include AasmCompatibilityGuard

  aasm whiny_transitions: !Rails.env.test? do
    state :unpublished, initial: true
    state :published


    event :publish do
      transitions from: :unpublished, to: :published, guard: :content_writer_provided_guard
    end

    event :unpublish do
      transitions from: :published, to: :unpublished, guard: :content_writer_provided_guard
    end
  end

  private

  def set_tracking(user)
    if user&.content_writer?
      self.published_by = user
      self.published_at = Time.now
    end
  end

  def content_writer_provided_guard(user)
    set_tracking(user)
    return true if user&.content_writer?

    errors.add(:base, "Only a content writer can make this transition")
    false
  end


end
