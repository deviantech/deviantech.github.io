# frozen_string_literal: true

class Searchers::User < Searchers::Base
  set_scalar_attributes :q
  set_array_attributes  :origin_preferences, :into_varietals, :into_categories


  def filter_params_provided?
    origin_preferences&.any?(&:present?) || into_varietals&.any?(&:present?) || into_categories&.any?(&:present?)
  end

  def origin_preference_options
    [
      ['new_world', 'New World wines'],
      ['old_world', 'Old World wines'],
    ]
  end

  def search_results
    @search_results ||= tasting_profile_filter ? base_search.where(id: tasting_profile_filter.select(:user_id) ) : base_search
  end

  def tasting_profile_filter
    return @tasting_profile_filter if defined?(@tasting_profile_filter)

    @tasting_profile_filter = begin
      prefs = origin_preferences&.select(&:present?)
      vars = into_varietals&.select(&:present?)
      cats = into_categories&.select(&:present?)

      if prefs.present? || cats.present? || vars.present?
        base_filter = TastingProfile.all
        t = TastingProfile.arel_table

        if prefs.present?
          val = prefs.length == 2 ? :both : prefs.first
          base_filter = base_filter.where(origins: val)
        end

        if cats.present? # Especially into == rated 7 or higher
          cats.each do |cat|
            base_filter = base_filter.where( t[cat].gteq(7) )
          end
        end

        if vars.present? # Especially into == rated 7 or higher
          vars.each do |var|
            base_filter = base_filter.where( t[var].gteq(7) )
          end
        end
      end

      base_filter
    end
  end


end
