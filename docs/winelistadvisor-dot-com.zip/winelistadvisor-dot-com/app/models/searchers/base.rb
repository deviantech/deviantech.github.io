# frozen_string_literal: true

class Searchers::Base
  include ActiveModel::Model

  class << self

    def searched_class
      @searched_class ||= ('::' + name.split('::').last).constantize rescue nil
      @searched_class || raise("Subclasses must use set_searched_class to specify the search target")
    end

    def set_searched_class(klass)
      @searched_class = klass
    end

    def set_scalar_attributes(*args)
      @scalar_attributes = args
      attr_accessor *args
    end

    def set_array_attributes(*args)
      @array_attributes = args
      attr_accessor *args
    end

    def set_facets(*args)
      @facets = args
    end


    # attr_reader... except always return an Array
    #
    def facets
      Array(@facets)
    end

    def scalar_attributes
      Array(@scalar_attributes)
    end

    def array_attributes
      Array(@array_attributes)
    end


    # Shared Implementation Logic
    #
    def search_attributes
      scalar_attributes + array_attributes
    end

    def permitted_fields
      [
        *(scalar_attributes + [:latitude, :longitude]),
        array_attributes.each_with_object({}) {|a,h| h[a] = []}
      ]
    end

    def set_numeric_scalars(*fields)
      fields.each do |field|
        define_method("#{field}=") do |raw|
          instance_variable_set("@#{field}", raw.to_i)
        end
      end
    end

  end



  attr_accessor :current_user, :page, :scope, :opts, :latitude, :longitude

  def initialize(user, page:, scope:, params: {}, **opts)
    super(params)
    self.current_user = user
    self.page = page.to_i < 1 ? 1 : page.to_i
    self.scope = scope
    self.opts = opts
    after_initialize
  end

  def params_provided?
    q.present? || filter_params_provided?
  end

  def something_provided?
    geo_params_provided? || params_provided?
  end

  def geo_params_provided?
    base_search_relation.respond_to?(:near) && latitude.present? && longitude.present?
  end

  def label
    if q.present? && geo_params_provided?
      %Q{Searching for "#{q}" near #{latitude}, #{longitude}}
    elsif q.present?
      %Q{Searching for "#{q}"}
    elsif geo_params_provided?
      %Q{Searching near #{latitude}, #{longitude}}
    end
  end

  def filter_params_provided?
    (self.class.search_attributes - [:q]).any? do |attrib|
      val = send(attrib)
      val.present? && Array(val).present?
    end
  end

  def results
    @results ||= begin
      raw = params_provided? ? search_results : geo_params_provided? ? geo_results : featured_results
      decorator ? decorator.decorate_collection(raw) : raw
    end
  end

  def featured_results
    base_search_relation.featured.page( page ).per(12)
  end

  def facets
    @facets ||= self.class.facets.each_with_object({}) {|f, hash| hash[f] = get_facet(f) }
  end

  def self.supports_remote_search?
    false
  end

  private

  def per_page
    50
  end

  def geo_results
    featured_results
  end

  def decorator
    return @decorator if defined?(@decorator)
    @decorator = "#{self.class.searched_class}Decorator".constantize rescue nil
  end

  def search_results
    @search_results ||= base_search
  end

  def after_initialize
  end

  Facet = Struct.new(:label, :id, :count) do
    include ActionView::Helpers::SanitizeHelper

    def initialize(*)
      super
      self.count ||= 0
    end

    def id
      self['id'].present? ? self['id'] : label
    end

    def pretty_label
      "#{strip_tags label || 'Unspecified'} <small>(#{count})</small>".html_safe
    end
  end

  def null_search
    self.class.new(current_user)
  end

  def base_search
    @base_search ||= if scope == 'remote' && !self.class.supports_remote_search?
      []
    else
      base = base_search_relation
      base = base.search_for(q) if q.present?
      apply_facet_filters(
        base.page(page).per(per_page)
      )
    end
  end

  # Optional hook for implementing subclasses
  def apply_facet_filters(relation)
    relation
  end

  def raw_facets
    @raw_facets ||= base_search.pluck(*self.class.facets)
  end

  # TODO: Performance!
  def get_facet(field, source: raw_facets)
    raw = get_facet_data(field, source)
    raw.sort_by {|k,v| k.to_s}.map { |key, data| data }
  end

  def get_facet_data(field, source)
    id_index = self.class.facets.index("#{field}_id".to_sym)
    counts = Hash.new {|h,k| h[k] = Facet.new(k) }

    source.each do |record|
      key = record[ self.class.facets.index(field) ]
      counts[key].count += 1

      if id_index
        counts[key].id ||= record[ id_index ]
      end
    end

    counts
  end

  # Handle not returning bulk data from e.g. Wine APIs, if present
  def base_search_relation
    self.class.searched_class.respond_to?(:slim) ? self.class.searched_class.slim : self.class.searched_class
  end

end
