# frozen_string_literal: true

class Searchers::Restaurant < Searchers::Base
  set_scalar_attributes :q, :geo
  set_array_attributes  :price_ranges

  def base_search
    opts = {price_ranges: price_ranges, scope: scope, page: page}

    # User explicit entry, or else current location, or else selected Now Serving, or else our default location (SF).
    opts[:geo] = if geo.present? then geo
    elsif latitude.present? && longitude.present?
      {
        latitude: latitude,
        longitude: longitude
      }
    else
      NowServingLocation.label now_serving_context
    end

    RestaurantService::Searcher.new(q, opts).call
  end

  def geo_results
    base_search
  end

  def base_search_relation # Used to narrow featured down to the correct location
    super.near( NowServingLocation.label(now_serving_context), 25)
  end

  def price_range_options
    1.upto(4).map {|i| [i, "<span>#{'$' * i}</span>".html_safe] }
  end

  def filter_params_provided?
    price_ranges&.any?(&:present?)
  end

  def self.supports_remote_search?
    true
  end

  def now_serving_context
    @now_serving || NowServingLocation.default
  end

  def after_initialize
    @now_serving = opts.delete(:now_serving)
  end

end
