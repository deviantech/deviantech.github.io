# frozen_string_literal: true

class Searchers::Article < Searchers::Base
  set_scalar_attributes :q
  set_array_attributes  :categories

  def filter_params_provided?
    categories&.any?(&:present?)
  end

  def featured_results
    self.class.searched_class.published.newest_first.includes(:user).limit(5)
  end

  def search_results
    base_search.by_category_ids(categories)
  end

end
