# frozen_string_literal: true

class Identity < ApplicationRecord
  belongs_to :user, inverse_of: :identities, required: true
  validates :provider, :uid, presence: true, uniqueness: {scope: :user_id}
  validates :token, presence: true

  scope :by_provider, ->(network) { where(provider: network) }

  has_many :external_social_posts

  # This appears to violate FB's requirements -- requiring explicit opt-in for now
  # after_initialize :set_notifications_on_by_default, if: :new_record?
  after_create :send_autoposting_notification

  SUPPORTED_NETWORKS = %w(facebook twitter linkedin google foursquare).freeze

  def supported_social_notifications
    SocialPublishingService.supported_social_notifications(provider)
  end

  def publishable?(key)
    if expires_at.present? && Time.now >= expires_at
      AdminMailer.system_alert("Identity (#{id} - #{provider})'s access token has expired -- which I believe means they haven't logged in for 60 days or so, so we can't do things on their behalf server-side as they're not active users. Research/confirm this is true, then resolve this message.", identity: self).deliver_later
      return false
    end

    return false unless supported_social_notifications && supported_social_notifications.keys.include?(key.to_sym)
    return false unless notify_on?(key)

    true
  end

  def publisher
    "SocialPublishingService::#{provider.classify}".constantize rescue nil
  end

  def notify_on?(key)
    ['true', '1', 1].include?( notify_on[key.to_s] )
  end

  def self.network_name(provider)
    case provider
    when 'linkedin' then 'LinkedIn'
    else provider&.titleize
    end
  end

  def self.basic_omniauth_data(auth)
    # Twitter includes a huge amount of useless information that we can ignore...
    auth_to_store = 'twitter' == auth['provider'] ? auth.except('extra') : auth

    {
      token: auth['credentials']['token'],
      expires_at: determine_expiration( auth['credentials']['expires_at'] ),
      secret: auth['credentials']['secret'],
      data: auth_to_store
    }
  end

  def self.update_from_omniauth(auth)
    find_by(provider: auth.provider, uid: auth_uid(auth)).tap do |ident|
      ident&.update( basic_omniauth_data(auth) )
    end
  end

  def self.build_from_omniauth(auth, logged_in_user)
    params = basic_omniauth_data(auth).merge({
      provider: auth['provider'],
      uid: auth_uid(auth),
      third_party_id: auth.dig('extra', 'raw_info', 'third_party_id'), # For FB only
    })

    if (email = auth['info']['email']).present?
      logged_in_user ||= User.find_by(email: email)
    end

    if logged_in_user
      logged_in_user.identities.build(params)
    else
      user_params = {
        name: auth['info']['name'],
        email: auth['info']['email'],
        password: Devise.friendly_token[0,20],
        remote_avatar_url: auth['info']['image'],
        age: '1', tos: '1'
      }

      Identity.new(params).tap do |ident|
        ident.build_user(user_params).tap do |user|
          user.skip_confirmation! # No need to confirm email
          user.built_from_omniauth!
        end
      end
    end
  end

  def network_name
    self.class.network_name(provider)
  end

  def label
    "#{network_name} Account (#{account_label})"
  end

  def account_label
    data&.dig('info', 'email') ||
      data&.dig('info', 'nickname') ||
      data&.dig('info', 'name') ||
      raise(NotImplementedError, "Specify label for #{provider} records")
  end

  def set_notifications_on_by_default
    if self.notify_on.blank?
      self.notify_on = supported_social_notifications.each_with_object({}) do |(key, label), hash|
        hash[key] = '1'
      end
    end
  end

  # LinkedIn doesn't have UIDs, so fall back to email
  def self.auth_uid(auth)
    auth['uid'] || auth['info']['email']
  end

  def self.determine_expiration(raw)
    raw && Time.at(raw)
  end

  def send_autoposting_notification
    return true if supported_social_notifications.blank?
    user.notify 'system.social.autopost_network_connected', thing: self
  end
end
