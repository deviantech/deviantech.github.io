# frozen_string_literal: true

class Contests::Article < ApplicationRecord
  include ContestLogic

  def contested_scope
    :published_sans_aliases
  end

end
