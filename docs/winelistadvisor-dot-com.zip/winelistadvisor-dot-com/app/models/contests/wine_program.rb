# frozen_string_literal: true

class Contests::WineProgram < ApplicationRecord
  include ContestLogic

  def contested_scope
    :accepted
  end

  def winning_restaurant
    winner&.restaurant
  end

end
