# frozen_string_literal: true

module Contests
  def self.table_name_prefix
    'contests_'
  end
end
