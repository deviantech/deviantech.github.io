# frozen_string_literal: true

module Likeable
  extend ActiveSupport::Concern

  included do
    has_many :likes, as: :thing, dependent: :destroy
    has_many :liking_users, through: :likes, source: :user
    attr_readonly :likes_count
  end

end
