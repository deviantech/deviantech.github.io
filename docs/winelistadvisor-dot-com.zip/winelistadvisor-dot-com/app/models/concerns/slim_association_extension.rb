# frozen_string_literal: true

# Needed to make count work with the manually-applied select (to avoid loading unneeded record data)
module SlimAssociationExtension

  # Note: this may ignore where/limit clauses...
  def count(*args)
    if respond_to?(:proxy_association)
      proxy_association.klass.where(proxy_association.reflection.foreign_key => proxy_association.owner.id).count
    else
      # kaminari total_pages...
      if args.first == :all
        self.except(:select).count('*')
      else
        super
      end
    end
  end

end
