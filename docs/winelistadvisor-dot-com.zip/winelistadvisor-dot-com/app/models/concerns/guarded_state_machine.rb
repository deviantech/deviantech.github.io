# frozen_string_literal: true

module GuardedStateMachine
  extend ActiveSupport::Concern

  included do
    # https://github.com/troessner/transitions
    # TODO: eventually replace https://github.com/troessner/transitions with AASM, which supports multiple state machines per model
    include ActiveModel::Transitions unless self.ancestors.include?(Flaggable)

    validate :errors_from_state_transitions
  end

  def display_state
    state.titleize if respond_to?(:state)
  end

  private

  def method_missing(method_name, *arguments, &block)
    if method_name.to_s =~ /set_timestamp_(.*)/
      self.update_attribute($1, Time.now)
    else
      super
    end
  end

  def respond_to_missing?(method_name, include_private = false)
    method_name.to_s.start_with?('set_timestamp_') || super
  end

  def moderator_provided_guard(moderator)
    ok = if moderator&.moderator?
      self.reviewed_by = moderator if self.respond_to?("reviewed_by=")
      true
    end

    ok || fail_with_error("Only a moderator can make this transition")
  end

  def admin_provided_guard(admin)
    ok = if admin&.admin?
      self.reviewed_by = admin if self.respond_to?("reviewed_by=")
      true
    end

    ok || fail_with_error("Only an admin can make this transition")
  end

  def fail_with_error(msg, field = :base)
    @errors_from_state_transitions ||= []
    return false if @errors_from_state_transitions.find {|(f,m)| f == field && msg == m}

    @errors_from_state_transitions.push([field, msg])
    valid?

    return false
  end

  def errors_from_state_transitions
    Array(@errors_from_state_transitions).each do |(field, msg)|
      errors.add field, msg
    end
  end

  def event_failed(event)
    self.valid? # Force state transition failure to appear as invalid model w/ errors
  end

end
