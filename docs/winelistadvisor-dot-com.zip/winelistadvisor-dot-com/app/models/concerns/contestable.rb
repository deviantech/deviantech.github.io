# frozen_string_literal: true

module Contestable
  extend ActiveSupport::Concern

  included do
    has_one :contest_won, class_name: "Contests::#{name}", foreign_key: :winner_id, inverse_of: :winner

    scope :entered_contest_between, ->(a,z) {
      t = arel_table

      # Convert the provided date (implicitly in PST/Time.zone) to PST-timestamped string, so
      # Rails will autoconvert it to UTC when running the query against the timestamp column
      a = a.to_time.in_time_zone(Time.zone).beginning_of_day
      z = z.to_time.in_time_zone(Time.zone).end_of_day

      where( t[:reviewed_at].between(a..z) )
    }
  end

end
