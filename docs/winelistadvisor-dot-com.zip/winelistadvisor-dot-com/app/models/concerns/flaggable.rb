# frozen_string_literal: true

# To include:
#   * add fields to table: moderator_hidden_by_id, moderator_hidden_at, flag_count, :moderation_status {default 'visible'}
#   * add method :responsible_user (for notification routing)
#   * add routes,
#   * add admin/moderator functionality
#     - add moderation controller
#     - add moderation dashboard
#     - add moderation views (_show_details.html)
#     - add class to moderation/dashboard/_overview.html.haml
#   * for moderation, also add #source_link to the decorator
#   * ensure update UI to include flag links (flag_link in application helper) AND to hide whatever part should be hidden if moderated away
module Flaggable
  extend ActiveSupport::Concern

  HIDE_AT_N_FLAGS = 4

  included do
    include AASM
    include AasmCompatibilityGuard
    include GuardedStateMachine # NOTE: including for guard methods, not for Transitions (using AASM here now)
    has_many :flaggings, as: :flagged, dependent: :destroy
    has_many :flagging_users, through: :flaggings, source: :user
    belongs_to :moderator_hidden_by, class_name: 'User', required: false

    scope :visible, -> { not_moderator_hidden.not_auto_hidden }
    scope :with_flags, -> { where('flag_count > 0').order('flag_count DESC') }
    scope :not_moderator_hidden, -> { where(moderator_hidden_by_id: nil) }
    scope :moderator_hidden, -> { where.not(moderator_hidden_by_id: nil) }
    scope :moderator_pending, -> { with_flags.not_moderator_hidden }
    scope :not_auto_hidden, -> { where(['flag_count < ?', hide_at_n_flags]) }

    @hide_at_n_flags = HIDE_AT_N_FLAGS

    aasm :moderation, no_direct_assignment: !Rails.env.test?, create_scopes: false, column: :moderation_status do
      state :visible, initial: true, after_enter: :clear_moderation_meta
      state :moderator_hidden, after_enter: :set_moderation_meta

      event :moderator_hide, success: :create_moderation_notification do
        transitions to: :moderator_hidden, from: :visible, guard: :moderator_provided_guard
      end

      event :moderator_show, success: :create_moderation_notification do
        transitions to: :visible, from: :moderator_hidden, guard: :moderator_provided_guard
      end
    end

  end

  module ClassMethods
    def hide_at_n_flags(n = nil)
      n ? (@hide_at_n_flags = n) : @hide_at_n_flags
    end
  end

  def responsible_user
    respond_to?(:user) ? user : raise(NotImplementedError)
  end

  # For administrate
  def pending_flaggings; flaggings.pending; end
  def confirmed_flaggings; flaggings.confirmed; end
  def dismissed_flaggings; flaggings.dismissed; end

  def flagging_path_name
    "new_#{self.class.name.split('::').last.underscore}_flagging_path"
  end

  def flaggable_name
    self.class.name
  end

  def current_state_scope
    moderator_hidden? ? 'moderator_hidden' : 'moderator_pending'
  end

  def hidden_by_flags?
    moderator_hidden? || auto_hidden?
  end

  def auto_hidden?
    flag_count >= hide_at_n_flags
  end

  def moderator_dismiss_flags!(mod)
    return unless mod && mod.moderator?

    transaction do
      flaggings.pending.map{|f| f.dismiss!(mod) }
    end
  end

  def moderator_pending?
    !moderator_hidden? && flag_count > 0
  end

  private

  def hide_at_n_flags
    # Note that Tag class doesn't have the hide_at_n_flags method from Gutentag::Tag... can clean this up if that's resolved
    (self.class.respond_to?(:hide_at_n_flags) ? self.class.hide_at_n_flags : nil) || Flaggable::HIDE_AT_N_FLAGS
  end

  def update_moderation_counter_cache(changed_flag)
    was_auto_hidden = auto_hidden?
    self.flag_count = flaggings.not_dismissed.count
    now_auto_hidden = auto_hidden?

    if was_auto_hidden != now_auto_hidden # Only if auto-hide status changed
      unless moderator_hidden? # Only if not already moderator hidden
        responsible_user.notify "moderation:#{now_auto_hidden ? 'hidden' : 'shown'}:from_flags", thing: self, thing_context: changed_flag
      end
    end

    save(touch: false)
  end

  def set_moderation_meta(mod)
    self.moderator_hidden_by = mod
    self.moderator_hidden_at = Time.now
    save
  end

  def clear_moderation_meta(mod)
    self.moderator_hidden_by = nil
    self.moderator_hidden_at = nil
    save
  end

  def create_moderation_notification(*args)
    responsible_user.notify "moderation:#{moderator_hidden? ? 'hidden' : 'shown'}", thing: self
  end

end
