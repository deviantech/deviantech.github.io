# frozen_string_literal: true

module Taggable
  extend ActiveSupport::Concern

  included do
    # https://github.com/pat/gutentag
    Gutentag::ActiveRecord.call self
  end

end
