# frozen_string_literal: true

module ModalSupport

  def self.included(base)
    base.helper_method :modal_requested?, :modal_size_modifier
  end

  # To automatically support link_to_modal links
  def render(*args, &block)
    options = _normalize_render(*args, &block)

    if modal_requested?
      options[:layout] = 'modal'
    end

    super(options, &block)
  end

  # http://api.rubyonrails.org/v5.1/classes/ActionController/Redirecting.html
  def redirect_to(options = {}, response_status = {})
    if modal_requested?
      super
      self.response_body = %Q{document.location = "#{ ERB::Util.unwrapped_html_escape(response.location) }";}
    else
      super
    end
  end

  private

  VALID_MODAL_SIZES = %w(sm lg)

  def modal_requested?
    request.headers['X-Via-Modal']
  end

  def modal_size_modifier
    rqst = request.headers['X-Modal-Size']
    rqst = nil unless rqst && VALID_MODAL_SIZES.include?(rqst)
    rqst ? "modal-#{rqst}" : nil
  end

end
