# frozen_string_literal: true

module Reviewable
  extend ActiveSupport::Concern

  included do
    has_many :reviews, as: :reviewable, dependent: :destroy
    has_many :bookmarks, as: :bookmarkable, dependent: :destroy
    has_many :bookmarking_users, through: :bookmarks, source: :user
  end

  def rating
    @rating ||= member_rating || begin
      num = reviews.average(:rating)
      num ? ("%.1f" % reviews.average(:rating).to_f) : nil
    end
  end

  # For Administrate, and eventually a hook for counter_caching this column
  def reviews_count
    member_ratings_count || reviews.count
  end

  def reviewable_name
    name
  end

  def responsible_user
    respond_to?(:user) ? user : raise(NotImplementedError)
  end

end
