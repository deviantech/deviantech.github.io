# frozen_string_literal: true

module TokenFindable
  extend ActiveSupport::Concern

  module ClassMethods

    def find_by_token(token)
      find_by id: verifier.verify(token)
    rescue ActiveSupport::MessageVerifier::InvalidSignature
      nil
    end

    def verifier
      @verifier ||= ActiveSupport::MessageVerifier.new( Rails.application.secret_key_base + self.name )
    end

  end

  def token
    self.class.verifier.generate(self.id, expires_in: 1.month)
  end

end
