# frozen_string_literal: true

module EngagementRewardable
  extend ActiveSupport::Concern

  included do
    validates :points, :kind, presence: true
    validates :face_value, inclusion: {in: EngagementRedemption::VALID_REDEMPTION_DOLLAR_VALUES}, if: :payout?
    validates :face_value, absence: { message: "cannot be set unless kind is 'payout'" }, unless: :payout?
    validates :level, absence: { message: "cannot be set unless kind is 'badge'" }, unless: :badge?

    VALID_KINDS ||= %w(badge payout)
    enum kind: VALID_KINDS
    validate_enum_attributes :kind, message: "is invalid (it must be one of: #{VALID_KINDS.inspect})"

    scope :in_order, -> { reorder('points ASC') }
  end

end
