# frozen_string_literal: true

# For performance over the wire, in 99% of cases we don't need to show where each field came from
module WithExternalDataSources
  extend ActiveSupport::Concern

  included do
    scope :slim, -> { select( column_names.reject {|c| c.ends_with?('_data') } ) }
  end

  def data_outdated?(source)
    dt = last_refreshed(source)
    dt.blank? || dt < data_must_refresh_every(source).ago
  end

  def last_refreshed(source)
    colname = "#{source}_data"
    return nil unless self.class.column_names.include?(colname)

    (send(colname) || {})['refreshed_at']
  end

  private

  def data_must_refresh_every(source)
    case source
    when :yelp, :single_platform then 24.hours
    else 24.hours
    end
  end

end
