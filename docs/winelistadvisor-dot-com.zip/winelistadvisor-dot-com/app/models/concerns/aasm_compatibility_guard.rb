# frozen_string_literal: true

module AasmCompatibilityGuard
  extend ActiveSupport::Concern

  private
  
  def aasm_fire_event(state_machine_name, name, options, *args, &block)
    return super if options[:persist]

    raise "#{self.class.name} #{state_machine_name} called #{name} without a !"
  end

end
