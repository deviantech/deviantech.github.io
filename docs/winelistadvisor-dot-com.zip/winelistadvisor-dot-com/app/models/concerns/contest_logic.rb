# frozen_string_literal: true

# Note: stores start_on and finish_on as Dates, implicitly meaning in the configured base timezone (PST).
module ContestLogic
  extend ActiveSupport::Concern

  included do
    belongs_to :winner, class_name: "::#{contested_klass_name}", required: false
    belongs_to :winner_selected_by, class_name: 'User', required: false
    has_one :winning_user, through: :winner, source: :user

    scope :for, -> (day) { where(['start_on <= ? AND finish_on >= ?', day, day]) }
    scope :finished, -> { where(['finish_on < ?', Date.current]) }
    scope :with_winner, -> { completed.where.not(winner_id: nil) }
    default_scope -> { order('finish_on DESC') }

    validate :one_per_timespan, on: :create

    include GuardedStateMachine
    state_machine auto_scopes: true, initial: :running do
      state :running      # Contest is still collecting entries
      state :pending
      state :completed

      event :close_contest, success: :notify_or_complete do
        transitions from: :running, to: :pending
      end

      event :complete_without_winner, timestamp: :winner_selected_at do
        transitions from: :pending, to: :completed
      end

      event :select_winner, timestamp: :winner_selected_at, success: :add_notification do
        transitions from: :pending, to: :completed, on_transition: :set_winner_data, guard: :winner_selecting_guard
      end

      event :select_random_winner, timestamp: :winner_selected_at, success: :add_notification do
        transitions from: :pending, to: :completed, on_transition: :set_random_winner_data
      end
    end
  end

  module ClassMethods

    def ensure_up_to_date!
      prev = find_or_create_contest_for!(in_last_period)

      unscoped.running.finished.map {|f| f.close_contest! }

      this = find_or_create_contest_for!(Time.current)
    end

    def contested_klass_name
      name.split('::').last
    end

    def contested_klass
      "::#{contested_klass_name}".constantize
    end

    def period_type
      :month # :week
    end

    private def find_or_create_contest_for!(somewhere_in_range)
      unscoped.for(somewhere_in_range).first || unscoped.create!(contest_range(somewhere_in_range))
    end

    private def in_last_period
      @in_last_period ||= Date.current.send("beginning_of_#{period_type}") - 5.days
    end

    private def contest_range(middle = Date.current)
      {
        start_on:   middle.send("beginning_of_#{period_type}"),
        finish_on:  middle.send("end_of_#{period_type}")
      }
    end

  end

  def entries
    self.class.contested_klass.
      send(contested_scope).
      entered_contest_between(start_on, finish_on)
  end

  def name
    @name ||= [
      self.class.contested_klass_name.underscore.titleize,
      'Contest:',
      period_name
    ].join(' ').squeeze(' ')
  end

  def num_entries # for admin dashboard
    entries.count
  end

  def period_name
    return (start_on + 5.days).strftime("%B %Y") if :month == self.class.period_type

    [start_on.strftime("%B %e"), finish_on.strftime("%B %e, %Y")].join(' - ')
  end

  def contest_name
    "#{period_name} #{self.class.contested_klass_name.underscore.titleize} Contest"
  end

  def label
    contest_name
  end

  private

  def contested_scope
    :all
  end

  def winner_selecting_guard(admin, winner)
    return false unless admin.present? && admin.admin? # Don't allow transition without a user passed in
    return fail_with_error("The selected winner isn't one of the contest's entries") unless entries.include?(winner)
    true
  end

  def set_winner_data(admin, winner)
    self.attributes = {
      winner_selected_by: admin,
      winner: winner,
    }
  end

  def set_random_winner_data
    self.attributes = {
      winner: entries.sample
    }
  end

  # Contest was just marked pending. It the next step is clear, take it. Otherwise, notify admins.
  def notify_or_complete
    case entries.count
    when 0 then complete_without_winner && save
    when 1 then select_random_winner && save
    else notify_admins_that_pending
    end
  end

  def target_class_name
    self.class.contested_klass.name.underscore
  end


  def one_per_timespan
    return unless self.class.for(start_on + 1.day).any?
    errors.add(:base, "Only one contest can be run per #{self.class.period_type}")
  end

  def notify_admins_that_pending
    AdminMailer.contest_pending(self).deliver_later(wait: 1.minute)
  end

  def add_notification
    return true unless winning_user
    winning_user.notify "#{winner.class.name.underscore}.contest:won", thing: self, thing_context: winner

    return true unless target_class_name == 'article'
    SocialPublishingService.call(:article_contest_won, self)
  end
end
