# frozen_string_literal: true

module ConversationActions

  def add_message(user, txt)
    return false unless Pundit.policy!(user, self).show?

    messages.create!(user: user, body: txt, topic: 'text')
  end

  def add_users(user, other_users)
    return false unless Pundit.policy!(user, self).add_users?

    valid_users = Array(other_users).to_a.select do |other|
      next if self.users.include?(other)
      next unless user.friends_with?(other)
      !!(self.users << other)
    end.compact

    return false unless valid_users.any?

    add_event('users_added', meta: {user_ids: valid_users.map(&:id)})
  end

  def remove_users(user, other_users)
    return false unless Pundit.policy!(user, self).manage? || Array(other_users) == [user]

    valid_users = Array(other_users).to_a.select do |other|
      next unless self.users.include?(other)
      !!(self.users.delete(other))
    end.compact

    return false unless valid_users.any?

    add_event('users_removed', meta: {user_ids: valid_users.map(&:id)})
  end

  def user_left(user)
    return false unless Pundit.policy!(user, self).show?
    return false unless !!(self.users.delete(user))

    add_event('user_left', meta: {user_ids: [user.id]})
  end

  private

  def add_event(kind, meta:)
    events.create!(meta: meta, topic: kind)
  end

end
