# frozen_string_literal: true

module DataFields
  extend ActiveSupport::Concern

  module ClassMethods
    def data_fields(*fields)
      fields.map(&:to_s).each do |field|
        define_method(field) do
          self.data && self.data[field]
        end

        define_method("#{field}=") do |val|
          self.data ||= {}
          self.data[field] = val
        end
      end
    end
  end

end
