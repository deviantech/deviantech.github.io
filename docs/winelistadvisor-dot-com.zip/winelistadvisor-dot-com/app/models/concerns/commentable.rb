# frozen_string_literal: true

# Be sure to include section in view_comment_url for any new Commentables
module Commentable
  extend ActiveSupport::Concern

  included do
    has_many :comments, as: :commentable, dependent: :destroy
    has_many :commenting_users, through: :comments, source: :user
    attr_readonly :comments_count
  end

  def responsible_user
    respond_to?(:user) ? user : raise(NotImplementedError)
  end

end
