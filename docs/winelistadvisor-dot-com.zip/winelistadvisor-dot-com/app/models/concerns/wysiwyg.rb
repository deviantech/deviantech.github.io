# frozen_string_literal: true

class WysiwygScrubber < Rails::Html::PermitScrubber
  def initialize
    super
    self.tags = %w( a img table comment blockquote h1 h2 h3 h4 h5 h6 pre br p div span ul ol li table thead tbody tr th td dd dl dt b strong i u em  )
    self.attributes = %w( style href src target class id )
  end

  def skip_node?(node)
    node.text?
  end
end

module Wysiwyg
  extend ActiveSupport::Concern

  included do
    include ActionView::Helpers::SanitizeHelper # for strip_tags, sanitize
  end

  module ClassMethods

    def wysiwyg_fields(*attrs)
      attrs.each do |attr|
        define_method("#{attr}=") do |raw|
          raw = raw.to_s.sub(/\A(<p><br><\/p>)+/, '') # Strip leading blank spaces
          self[attr] = sanitize(raw, scrubber: WysiwygScrubber.new)
        end
      end
    end

  end

end
