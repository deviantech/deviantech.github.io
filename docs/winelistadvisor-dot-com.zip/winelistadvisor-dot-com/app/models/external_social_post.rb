# frozen_string_literal: true

class ExternalSocialPost < ApplicationRecord
  belongs_to :identity
  before_create :cache_identity_provider
  after_create :track_external_network_connected

  scope :by_provider, ->(net) { where(provider: net) }
  scope :with_link, ->(l) { where(link: l) }

  private

  def cache_identity_provider
    self.provider ||= identity&.provider
  end

  def track_external_network_connected
    return unless u = identity&.user
    EngagementService.call u, 'system.autoposted_content', self
  end
end
