# frozen_string_literal: true

class Flagging < ApplicationRecord
  include GuardedStateMachine

  belongs_to :user
  belongs_to :flagged, polymorphic: true
  belongs_to :reviewed_by, class_name: 'User', required: false

  validates :user, presence: true, on: :create
  validates :flagged, presence: true, on: :create
  validate :requires_reason
  validate :validate_no_duplicate_flags, on: :create

  scope :not_dismissed, -> { where.not(state: 'dismissed') }
  scope :on, ->(obj) { where(flagged_type: obj.class.name, flagged_id: obj.id) if obj }
  scope :by_type, ->(klass) { where(flagged_type: klass.to_s) if klass }

  after_commit  :update_flagged_counter_cache, on: [:create, :update, :destroy]
  after_commit  :create_notification, on: :create

  enum reasons: [:spam, :inappropriate, :copyright_violation]

  state_machine auto_scopes: true, initial: :pending do
    state :pending
    state :confirmed
    state :dismissed

    event :confirm, timestamp: :reviewed_at, success: :update_flagged_counter_cache do
      transitions from: :pending, to: :confirmed, guard: :moderator_provided_guard
    end

    event :dismiss, timestamp: :reviewed_at, success: :update_flagged_counter_cache do
      transitions from: :pending, to: :dismissed, guard: :moderator_provided_guard
    end
  end

  private

  # Not simple counter_cache: :flag_count because we manually ignore admin-dismissed flags
  def update_flagged_counter_cache
    flagged&.send(:update_moderation_counter_cache, self)
  end

  def validate_no_duplicate_flags
    return unless Flagging.where(user_id: user_id, flagged_type: flagged_type, flagged_id: flagged_id).exists?
    errors.add :base, "You have already flagged this particular item"
  end

  def requires_reason
    return if reason.present?
    errors.add :reason, "must be provided"
  end

  def create_notification
    return if flagged.responsible_user == user
    flagged.responsible_user.notify "moderation:flagged", thing: flagged, thing_context: self
  end

end
