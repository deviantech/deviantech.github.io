# frozen_string_literal: true

class UserImage < ApplicationRecord
  belongs_to :user
  mount_uploader :image, UserImageUploader
  validates :user, :image, presence: true, on: :create

  belongs_to :attached_to, polymorphic: true, required: false

  before_create :attempt_attaching

  scope :unattached, -> { where(attached_to_type: nil, attached_to_id: nil) }
  scope :in_context, ->(ctx) do
    (qry, vals) = ctx.each_with_object([[], []]) do |(key, val),ary|
      ary[0] << "context->'#{key}' = ?"
      ary[1] << val.to_s
    end

    where(qry.join(' AND '), *vals)
  end

  scope :for_wall_post, ->(m) { in_context(kind: 'wall_post', activity_id: m.respond_to?(:id) ? m.id : m) }
  scope :for_review_of, ->(m) { in_context(kind: 'review', restaurant_id: m.respond_to?(:id) ? m.id : m)  }

  scope :pending_for_review_of, ->(r) { unattached.for_review_of(r) }
  scope :pending_for_any_wall_post, -> { unattached.in_context(kind: 'wall_post') }

  VALID_CONTEXT_FIELDS = %i(kind restaurant_id review_id activity_id)

  private

  # If uploading images to an existing review/whatever (i.e. editing), attach directly
  # without waiting for user to hit update.
  def attempt_attaching
    to_attach = case context['kind']
    when 'review'    then user.reviews.find_by(id: context['review_id'])
    when 'wall_post' then user.activities.by_key(:wall_post).find_by(id: context['activity_id'])
    end

    self.attached_to = to_attach if to_attach
  end
end
