# frozen_string_literal: true

class User < ApplicationRecord
  include TokenFindable
  include Featurable
  has_friendship

  def on_friendship_created(friendship)
    return unless friendship.requested?
    return if friendship.friendable.joined_from_invitation&.user == friendship.friend # Skip email if created from invitation
    friendship.friendable.notify 'friend_request:pending', thing: friendship, thing_context: friendship.friend
  end

  def on_friendship_accepted(friendship)
    friendship.friendable.notify 'friend_request:accepted', thing: friendship, data: {'status_was' => friendship.status_before_last_save}, thing_context: friendship.friend
    SocialPublishingService.call(:following, friendship)
  end

  include PgSearch
  pg_search_scope :search_for, against: [:name, :email, :about, :city, :state], using: { tsearch: { any_word: true, prefix: true }, trigram: {only: [:email, :name]} }


  include Wysiwyg
  wysiwyg_fields :about

  VALID_ROLES = %w(user moderator admin content_writer)
  enum role: VALID_ROLES

  def moderator?
    admin? || super
  end

  def content_writer?
    admin? || super
  end

  mount_uploader :avatar, UserAvatarUploader

  # Fallback to gravatar if not avatar explicitly uploaded
  include Gravtastic
  gravtastic

  # Include default devise modules. Others available are:
  # :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable, :confirmable,
         :recoverable, :rememberable, :trackable, :validatable,
         :omniauthable, omniauth_providers: Identity::SUPPORTED_NETWORKS

  scope :needs_confirmation_reminder, -> {
    where(confirmed_at: nil).
    where(unconfirmed_email: nil). # trying to remind users who've signed in but never confirmed, not reminding on email changes
    where.not(confirmation_token: nil).
    where(confirmation_resent_at: nil).
    where(
      arel_table[:confirmation_sent_at].gt(
        Time.now - Devise.allow_unconfirmed_access_for + 3.days
      )
    )
  }

  def needs_confirmation_reminder?
    return unless confirmation_sent_at && !confirmed_at && !confirmation_resent_at
    return if Time.now > confirmation_sent_at + Devise.allow_unconfirmed_access_for # too late, don't bother reminding
    Time.now + 3.days > confirmation_sent_at + Devise.allow_unconfirmed_access_for
  end

  has_many :identities, inverse_of: :user, dependent: :destroy
  accepts_nested_attributes_for :identities

  has_one :tasting_profile, dependent: :destroy
  accepts_nested_attributes_for :tasting_profile

  has_many :invitations
  has_one :joined_from_invitation, class_name: 'Invitation', foreign_key: :joined_user_id, inverse_of: :joined_user

  has_many :engagements, -> { order('id DESC') }, dependent: :destroy
  has_many :engagement_redemptions, -> { order('id DESC') }, dependent: :destroy
  has_many :engagement_rewards, -> { order('id DESC') }, dependent: :destroy
  has_many :articles
  has_many :published_articles, -> { where(review_status: 'published') }, class_name: 'Article'
  has_many :own_published_articles, -> { where(review_status: 'published', author_alias: nil) }, class_name: 'Article'
  has_many :reviewed_articles, foreign_key: :reviewed_by_id, class_name: 'Article'
  has_many :claimed_restaurants, class_name: 'Restaurant', foreign_key: :claimed_by_id, inverse_of: :claimed_by

  has_many :reviews, dependent: :destroy
  has_many :comments, dependent: :destroy

  has_many :bookmarks, dependent: :destroy
  has_many :flaggings, dependent: :destroy

  has_many :user_images

  has_many :submitted_wine_programs, class_name: 'WineProgram'

  has_many :restaurant_bookmarks,          -> { where(bookmarkable_type: 'Restaurant') }, class_name: 'Bookmark'
  has_many :bookmarked_restaurants,        through: "restaurant_bookmarks", source: :bookmarkable, source_type: 'Restaurant'
  has_many :tried_restaurant_bookmarks,    -> { Bookmark.tried.where(bookmarkable_type: 'Restaurant') }, class_name: 'Bookmark'
  has_many :tried_restaurants,             through: "tried_restaurant_bookmarks", source: :bookmarkable, source_type: 'Restaurant'
  has_many :untried_restaurant_bookmarks,  -> { Bookmark.not_tried.where(bookmarkable_type: 'Restaurant') }, class_name: 'Bookmark'
  has_many :untried_restaurants,           through: "untried_restaurant_bookmarks", source: :bookmarkable, source_type: 'Restaurant'

  has_many :conversation_participations, dependent: :destroy
  has_many :conversations, through: :conversation_participations

  has_many :notifications
  has_many :activities

  has_many :likes

  def likes?(thing)
    likes.of_thing(thing).first
  end

  scope :since, ->(dt) { where(['created_at >= ?', dt]) }

  extend FriendlyId
  friendly_id :name, use: [:slugged, :finders, :history]

  validates :slug, format: { with: /\A[\w\d\-_]+\z/}, uniqueness: true
  validates :email, presence: true, uniqueness: true
  validates :name, presence: true
  validate :avatar_dimensions

  attr_accessor :age, :tos
  validate :validate_terms_accepted, unless: :persisted?

  after_initialize :set_defaults, if: :new_record?
  after_commit :fill_profile_notification, on: :create

  after_create do
    EngagementService.call self, 'member.joined', self
  end

  after_commit :add_activity_on_changes, on: :update
  after_commit :establish_inviter_friendship, on: :create
  after_commit :sync_newsletter_preferences, on: [:create, :update]

  def name=(str)
    self['name'] = str.to_s.gsub(/[^\s\w]/, '').squeeze(' ').strip
  end

  def first_name
    n = name.to_s.split.first
    n.length > 2 ? n : name
  end

  def label
    name || 'Anonymous User'
  end

  def tasting_profile_completed?
    return unless tasting_profile
    tasting_profile.persisted? && tasting_profile.profile_completed?
  end


  def points_this_month
    engagements.this_month.sum(:points)
  end

  # Devise/Omniauth integration

  def update_from_omniauth(data)
    if info = data["info"]
      self.email ||= info['email']
      self.name ||= info['name']
    end

    if !avatar? && remote = data['info']['image']
      self.remote_avatar_url = remote
      valid? # check - e.g. if twitter avatar is too small for our validations, just skip it
      if errors[:avatar]
        if respond_to?("update_avatar_from_#{data['provider']}", true)
          token = data.dig('credentials', 'token')
          secret = data.dig('credentials', 'secret')
          DelayedMethodJob.enqueue(self, "update_avatar_from_#{data['provider']}", token, secret) if token.present? && persisted?
        end

        self.remote_avatar_url = nil
        valid? # reset errors
      end
    end

  end

  def self.new_with_session(params, session)
    super.tap do |user|
      if data = session["devise.omniauth_data"]
        user.update_from_omniauth(data)
        Identity.build_from_omniauth(data, user)
        user.skip_confirmation!
      end

      # If joined from a specific emailed invitation
      if token = session["invitation_token"]
        if invite = Invitation.pending.find_by_token( token )
          user.skip_confirmation! # emailed, so can skip confirming email
          user.instance_variable_set("@invited_by_invitation", invite)
        end
      end

      # If joined from a user -- add the friendship, but we don't know the invite was via email so don't skip confirmation
      if generic_invitation_source = User.find_by_token( session["invited_by_token"] )
        user.instance_variable_set("@invited_by", generic_invitation_source)
      end
    end
  end

  def gotten_engagement?(key, thing: nil)
    base = engagements.by_key(key)
    base = thing ? base.with_thing(thing) : base
    base.any?
  end

  # Notifications

  # Send the notification unless we've been explicitly opted out
  def notify_via?(channel, key)
    unless Notification::NOTIFICATIONS.include?(key)
      return false if key =~ /\.commented_on/ # Unsupported commentable type - abort, but no error needed
      raise "Unknown notification key: #{key}"
    end

    # Has the user explicitly disabled notifications via this channel for this key?
    notification_settings.dig(channel.to_s, key.to_s) != '0'
  end

  def notify(key, thing:, **args)
    self.notifications.add!(key, args.merge(thing: thing))
  end

  def system_notify(msg, details: nil)
    notify 'system.web_message', thing: self, data: {msg: msg, details: details}.select {|k,v| v.present? }
  end

  def built_from_omniauth!
    @from_omniauth = true
  end

  private

  def fill_profile_notification
    return if tasting_profile_completed?
    system_notify %Q{
      Please #{ActionController::Base.helpers.link_to 'complete your profile', Rails.application.routes.url_helpers.edit_user_url(self)} to help friends and family better suggest wines that particularly appeal to your custom tastes!
    }
  end

  def avatar_dimensions
    return unless avatar?
    min_height = min_width = 200
    return if avatar_height.to_i >= min_height && avatar_width.to_i >= min_width

    self.remove_avatar!
    unless @from_omniauth
      msg = "must be at least #{min_width}px wide and #{min_height}px tall"
      msg += " (uploaded image is #{avatar_width}x#{avatar_height})" if avatar_width && avatar_height
      errors.add(:avatar, msg)
    end
  end

  def set_defaults
    self.role ||= :user

    if self.newsletter_preferences.blank?
      self.newsletter_preferences = NewsletterService.newsletters_mapping.each_with_object({}) do |(name, id), hash|
        hash[id] = true
      end
    end

    if self.notification_settings.blank?
      self.notification_settings = Notification::NOTIFICATIONS.select {|k,data| data[:default_skip]}.each_with_object({}) do |(k, data), hash|
        data[:default_skip].each do |channel|
          hash[channel.to_s] ||= {}
          hash[channel.to_s][k] = '0'
        end
      end
    end

    if self.level.blank?
      self.level = EngagementRewardLevel::NEW_USER_BADGE
    end
  end

  def skip_tracking_profile_changes
    @skip_tracking_profile_changes = true
  end

  def add_activity_on_changes
    return if @skip_tracking_profile_changes
    tracking = %w(about name city state)
    tracked_changes = saved_changes.select {|k,v| tracking.include?(k) }
    return unless tracked_changes.present?
    Activity.add_updated_user_profile(self, tracked_changes)
  end

  def establish_inviter_friendship
    if @invited_by_invitation
      @invited_by_invitation.accept!(self)
    end

    if u = @invited_by_invitation&.user || joined_from_invitation&.user || @invited_by
      u.friend_request(self)
      self.accept_request(u)
      EngagementService.call(u, 'friends.joined_from_invitation', self)
    end
  end

  def sync_newsletter_preferences
    return unless previous_changes.keys.any? {|k| %w(email newsletter_preferences name).include?(k) }
    NewsletterSyncJob.perform_later(self)
  end

  def validate_terms_accepted
    errors.add(:base, "You must certify that you are over the legal drinking age in your state") unless age.to_i > 0
    errors.add(:base, "You must accept the Terms of Use") unless tos.to_i > 0
  end

  def update_avatar_from_facebook(token, secret)
    api = Koala::Facebook::API.new(token)
    url = api.get_picture_data('me', type: 'large').dig('data', 'url')

    get_remote_avatar url
  end

  def update_avatar_from_twitter(token, secret)
    api = ::Twitter::REST::Client.new do |config|
      config.consumer_key        = ENV.fetch('TWITTER_APP_KEY')
      config.consumer_secret     = ENV.fetch('TWITTER_APP_SECRET')
      config.access_token        = token
      config.access_token_secret = secret
    end
    url = api.user.profile_image_uri('200x200').to_s

    get_remote_avatar url
  end

  def get_remote_avatar(url)
    return if avatar?
    self.remote_avatar_url = url
    save # Try saving -- if image is too small it'll just fail, and we're in a background job so no harm done
  end

end
