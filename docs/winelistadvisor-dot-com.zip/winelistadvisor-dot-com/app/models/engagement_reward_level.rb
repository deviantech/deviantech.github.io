# frozen_string_literal: true

class EngagementRewardLevel < ApplicationRecord
  include EngagementRewardable
  validates :level, presence: true, uniqueness: true, if: :badge?

  validates :points, uniqueness: { scope: :kind }
  validate :point_spread_increases, if: :badge?

  after_update :update_levels

  NEW_USER_BADGE = 'Neophyte' # Before they're assigned any other state

  has_many :engagement_rewards, foreign_key: :config_id
  scope :possible_rewards, -> (was, will) { where(points: (was+1)..will).in_order }
  scope :for_display, -> { where('points > ?', 0).in_order }
  scope :for_payout, -> { where(kind: 'payout') }
  scope :for_badge, -> { where(kind: 'badge') }

  def self.next_for_points(pts)
    where('points > ?', pts).order('points ASC').first.tap do |r|
      r.define_singleton_method(:points_away) do
        r && (r.points - pts)
      end
    end
  end

  def self.prev_for_points(pts)
    where('points <= ?', pts).order('points DESC').first.tap do |r|
      r.define_singleton_method(:points_since) do
        r && (pts - r.points)
      end
    end
  end

  def user_explanation
    badge? ? %Q{a new badge ("#{level}")} : "a $#{face_value} gift certificate"
  end

  def label
    msg = badge? ? "Badge: #{level}" : "Payout: $#{face_value}"
    msg += " (at #{points} point#{points == 1 ? '' : 's'})"
    msg
  end

  def bestow_upon(user, engagement)
    user.engagement_rewards.by_config(self).first_or_create!(engagement: engagement)
  end

  private

  def point_spread_increases
    _p = self.class.prev_for_points(points)
    _n = self.class.next_for_points(points)
    if _p && _n
      return if _p.points_since < _n.points_away
      errors.add(:points, "is an invalid value -- we're attempting to make each badge reward more difficult to receive then the previous ones, but this change would make it #{_p.points_since} points from the previous reward and only #{_n.points_away} to the next.")
    end
  end

  def update_levels
    return unless saved_change_to_level?
    User.where(level: level_before_last_save).update_all level: level
  end
end
