# frozen_string_literal: true

class Faq < ApplicationRecord
  scope :for_display, -> { where(display: true) }
end
