# frozen_string_literal: true

class EngagementReward < ApplicationRecord
  belongs_to :user
  belongs_to :engagement
  belongs_to :config, class_name: 'EngagementRewardLevel', required: false
  has_one :engagement_redemption

  include EngagementRewardable
  validates :level, presence: true, uniqueness: {scope: :user_id}, if: :badge?


  scope :by_config, ->(config) { where(config: config) }

  # NOTE: should stand alone if the settings/config is ever removed (i.e. you earned the reward, grandfathered in)
  validates :user, :engagement, presence: true
  validates :config, presence: true, on: :create

  before_validation :set_from_config, on: :create
  before_create :apply_to_user, :create_redemption_as_needed
  after_commit :add_notification, on: :create
  after_commit :add_activity, on: :create, if: :badge?

  class << self
    def next_for(user) # Accepts user or a point level
      EngagementRewardLevel.next_for_points(user.respond_to?(:points) ? user.points : user)
    end

    def prev_for(user) # Accepts user or a point level
      EngagementRewardLevel.prev_for_points(user.respond_to?(:points) ? user.points : user)
    end

    def points_to_next_reward(user)
      next_for(user).points_away
    end

    def points_from_prev_reward(user)
      prev_for(user)&.points_since.to_i
    end

    # Note: engagement is most recent, and has already been saved/committed.
    def sync_new_engagement(user, engagement)
      prev_points = user.points
      user.update points: user.engagements.sum(:points)

      possible_rewards = EngagementRewardLevel.possible_rewards(prev_points, user.points)

      issue_engagement_reward(user, engagement, possible_rewards) if possible_rewards.any?
    end

    private

    def issue_engagement_reward(user, engagement, possible_rewards)
      possible_rewards.each do |reward_level|
        reward_level.bestow_upon(user, engagement)
      end
    end

  end



  private

  CONFIGURED_FIELDS = %w(face_value level kind points)

  def set_from_config
    return unless config

    CONFIGURED_FIELDS.each do |field|
      self.send("#{field}=", config.send(field))
    end
  end

  def apply_to_user
    return unless badge? && user

    user.update! level: level
  end

  def create_redemption_as_needed
    return unless payout? && user && face_value.to_i > 0

    self.engagement_redemption = build_engagement_redemption(user: user, face_value: self.face_value)
  end

  def add_notification
    user.notify "engagement_reward.earned.#{kind}", thing: self
  end

  def add_activity
    Activity.add_engagement_reward(self)
  end

end
