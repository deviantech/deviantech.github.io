# frozen_string_literal: true

class ReviewTag < ApplicationRecord
  validates :name, presence: true, uniqueness: true
  scope :active, -> { where(active: true) }

  def self.by_name(tag)
    where('lower(name) = ?', tag.downcase).first
  end
end
