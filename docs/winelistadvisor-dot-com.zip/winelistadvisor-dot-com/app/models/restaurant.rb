# frozen_string_literal: true

class Restaurant < ApplicationRecord
  reverse_geocoded_by :latitude, :longitude # Don't expect to do reverse geocoding, but connect w/ Geocoder

  has_many_attached :pdf_menus
  validate :correct_pdf_menus_mime_types


  include WithExternalDataSources
  include Reviewable
  include Featurable
  include Components::RestaurantClaimStateMachine
  include Likeable # Not directly used currently, b/c can add to bookmarked lists instead

  # TODO: only necessary until https://github.com/alexreisner/geocoder/issues/1247 is merged in
  class << self
    public :near_scope_options
  end

  validates :name, presence: true
  validates :external_menu_url, format: { with: /\A(https?:)?\/\/.+\..+/, message: 'must be a valid URL' }, if: ->(m) { m.external_menu_url.present? }

  # Usually ID will be fine, but sometimes Yelp includes non-URL-safe characters and things would get messy without friendly_id
  extend FriendlyId
  friendly_id :slug_candidates, use: [:slugged, :finders]
  def slug_candidates
    [:yelp_id, [:name, :city], [:name, :city, :state], [:name, :city, :state, :country]]
  end


  belongs_to :claimed_by, class_name: 'User', inverse_of: :claimed_restaurants, required: false
  belongs_to :reviewed_by, class_name: 'User', required: false

  has_many :submitted_wine_programs, class_name: 'WineProgram'
  has_many :content_sections, dependent: :destroy, inverse_of: :restaurant
  has_many :published_content_sections, -> { published }, class_name: 'ContentSection'

  belongs_to :wine_program, dependent: :destroy, required: false
  accepts_nested_attributes_for :wine_program

  has_many :external_photos, class_name: 'ExternalRestaurantPhoto', dependent: :destroy, inverse_of: :restaurant
  has_many :sp_external_photos, -> { from_single_platform }, class_name: 'ExternalRestaurantPhoto', inverse_of: :restaurant
  accepts_nested_attributes_for :sp_external_photos
  has_many :yelp_external_photos, -> { from_yelp }, class_name: 'ExternalRestaurantPhoto', inverse_of: :restaurant
  accepts_nested_attributes_for :yelp_external_photos

  has_many :sp_menus, dependent: :destroy, inverse_of: :restaurant
  accepts_nested_attributes_for :sp_menus
  has_many :sp_menu_sections, through: :sp_menus
  has_many :sp_menu_items, through: :sp_menu_sections

  mount_uploader :avatar, RestaurantAvatarUploader

  include PgSearch
  pg_search_scope :search_by_name, against: :name, using: { trigram: {only: [:name]} }

  scope :in_price_ranges, -> (ary) {
    if ary.present?
      t = Restaurant.arel_table
      sp_ranges = ary.include?(4) ? (ary + [5]) : ary # SP ranges 1-5, Yelp 1-4. Normalize by searching for 5 when given 4

      # Using arel_table to ensure proper parenthesis nesting on the OR statement
      where(
        t[:yelp_price_range].in(ary).or(
          t[:sp_price_range].in(sp_ranges)
        )
      )
    end
  }

  scope :claimed_since, -> (dt) { where(['claimed_at >= ?', dt]) }
  scope :pending, -> { pending_review }

  scope :single_platform_connection_attempt_needed, -> {
    refreshed = Restaurant.arel_table[:refreshed_single_platform_match_at]
    where(refreshed_single_platform_match_at: nil).or( where( refreshed.lt(Restaurant.refresh_every(:single_platform_match).ago) ) )
  }

  belongs_to :claim_reviewed_by, class_name: 'User', required: false

  after_commit :check_opentable_id, on: :create

  def label(context = nil)
    :review == context ? "the Wine Program at #{name}" : super
  end

  def generic_label(context = nil)
    :review == context ? 'wine program' : 'restaurant'
  end

  def responsible_user
    claimed? ? claimed_by : nil
  end


  # Make dom_id use the slug rather than the possibly-containing-bad-characters ID
  def to_key; [slug] end

  def delivery_url
    nil # TODO: would be great to add this functionality... (used to be provided by eat24_url in Yelp V2 API)
  end

  # Note: these two may need extra logic to find a valid URL when none from Yelp
  def reservation_url
    opentable_reservation_url
  end

  def delivery_url?
    delivery_url.present?
  end

  def reservation_url?
    reservation_url.present?
  end

  # Probably not needed in production (unclear why needed in development), but chrome is much happier
  # with protocol-less '//' links in development
  def yelp_image_url
    if Rails.env.development?
      super.to_s.sub(/\Ahttps?:\/\//, '//')
    else
      super
    end
  end

  def opentable_id?
    return false if opentable_id.nil? || opentable_id.zero?
    opentable_id
  end

  def opentable_reservation_url # Use 0 as indicator of already searched
    return unless opentable_id?
    "http://www.opentable.com/single.aspx?rid=#{opentable_id}"
  end

  def self.refresh_every(service)
    case service
    when :yelp then 24.hours
    when :single_platform then 24.hours
    when :single_platform_match then 15.days
    end
  end

  def price_range
    return yelp_price_range if yelp_price_range
    [sp_price_range.to_i, 4].min # SP ranges 1-5, Yelp 1-4. Normalize by returning 4 for SP 5
  end

  VALID_PDF_CONTENT_TYPES = %w(application/pdf)
  private

  def check_opentable_id
    RestaurantDataJob.perform_later(self) if opentable_id.nil?
  end


  def correct_pdf_menus_mime_types
    return if pdf_menus.none?
    return if pdf_menus.all? {|pdf| pdf.content_type.in?(VALID_PDF_CONTENT_TYPES) }

    errors.add(:pdf_menus, 'must all must be PDF files')
  end

end
