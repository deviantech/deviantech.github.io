# frozen_string_literal: true

module Components::RestaurantClaimStateMachine
  extend ActiveSupport::Concern

  included do
    include GuardedStateMachine
    state_machine auto_scopes: true, attribute_name: :claim_status, initial: :unclaimed do
      state :unclaimed
      state :pending_review, enter: :notify_admin
      state :claimed

      event :submit, timestamp: :claimed_at do
        transitions from: :unclaimed, to: :pending_review, on_transition: :update_user_submittable_associations_on_claim, guard: :ensure_claimant_info_provided
      end

      event :approve, timestamp: :reviewed_at, success: :add_notification do
        transitions from: :pending_review, to: :claimed, on_transition: :update_user_submittable_associations_on_claim_acceptance, guard: :admin_provided_guard
      end

      event :reject, timestamp: :reviewed_at, success: :add_notification do
        transitions from: [:pending_review, :claimed], to: :unclaimed, guard: :admin_provided_guard
      end
    end
  end

  def submit_claim!(who, params)
    self.claimed_by = who
    self.claimant_phone = params[:claimant_phone]
    submit! && save!
  end

  private

  # Don't allow claiming unless phone number is provided
  def ensure_claimant_info_provided
    return true if claimant_phone.present? && claimant_phone.gsub(/\D/, '').length > 6
    fail_with_error "valid phone number must be provided to claim this restaurant", :claimant_phone
  end

  def notify_admin
    AdminMailer.restaurant_pending_review(self).deliver_later(wait: 1.minute)
  end

  def update_user_submittable_associations_on_claim
    program_for_claimed_owner.mark_as_pending_ownership_claim!
  end

  def update_user_submittable_associations_on_claim_acceptance(admin)
    owners_program = program_for_claimed_owner
    owners_program.mark_as_owners!(admin)
  end

  def program_for_claimed_owner
    program = submitted_wine_programs.by_user(claimed_by).first
    program ||= WineProgram.create_copy_for(claimed_by, of: wine_program, restaurant: self)

    program
  end

  def add_notification
    which = claimed? ? 'claim_approved' : 'claim_rejected'
    claimed_by&.notify "restaurant.#{which}", thing: self
  end

end
