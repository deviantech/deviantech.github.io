# frozen_string_literal: true

class ExternalRestaurantPhoto < ApplicationRecord
  belongs_to :restaurant

  scope :from_yelp, -> { where(source: 'yelp') }
  scope :from_single_platform, -> { where(source: 'single_platform') }
  scope :of_restaurant, -> { where(items: nil) }
  scope :of_menu_item, -> { where.not(items: nil) }

  validates :url, presence: true

  def url=(str)
    super str.to_s.sub(/\Ahttps?:\/\//, '//')
  end
end
