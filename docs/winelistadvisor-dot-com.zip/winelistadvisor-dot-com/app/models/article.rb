# frozen_string_literal: true

class Article < ApplicationRecord
  MAX_SUMMARY_LENGTH = 200
  MIN_PUBLISHABLE_LENGTH = 100 # words

  include Flaggable
  hide_at_n_flags 3

  include Featurable
  include ActionView::Helpers::SanitizeHelper # for strip_tags, sanitize

  include Wysiwyg
  wysiwyg_fields :body

  include Contestable
  include Commentable
  include Likeable

  def label(context=nil)
    category && context == :with_category ? %Q{Article "#{self.title}", posted in #{category.name}} : self.title
  end

  mount_uploader :featured_image, FeaturedImageUploader

  belongs_to :user
  belongs_to :category, class_name: 'Category'
  belongs_to :reviewed_by, class_name: 'User', required: false

  validates :user, :category, presence: true
  validates :body, presence: true, length: {minimum: 20}
  validates :summary, length: {maximum: MAX_SUMMARY_LENGTH}
  validates :review_status, inclusion: %w(draft pending_review published)
  validate :featured_image_dimensions, :featured_image_content_type

  scope :newest_first, -> { order('reviewed_at DESC') }
  scope :not_drafts, -> { where(review_status: %w(pending_review published)) }
  scope :submitted_since, -> (dt) { where(['submitted_at >= ?', dt]) }
  scope :pending, -> { pending_review }
  scope :published_sans_aliases, -> { published.without_aliased_articles }

  scope :by_category_ids, ->(ids ) {
    ids = ids&.select(&:present?)
    where(category_id: ids) if ids.present?
  }

  scope :without_aliased_articles, -> { where(author_alias: nil) }

  include PgSearch
  pg_search_scope :search_for, against: [:title, :summary, :body]

  # Usually ID will be fine, but sometimes Yelp includes non-URL-safe characters and things would get messy without friendly_id
  extend FriendlyId
  friendly_id :slug_candidates, use: [:slugged, :finders, :history]

  def slug_candidates
    return [:id] unless published?

    [
      :title,
      [:category, :title]
    ]
  end

  def should_generate_new_friendly_id?
    return true if slug.blank?
    return true if title_changed?
    return true if review_status_changed? && ('published' == review_status || 'published' == review_status_was)
  end

  def summary
    return self['summary'] if self['summary'].present?
    return '' unless body.present?

    self['summary'] = strip_tags(body).gsub(/([\.\!\?])/, '\1 ')[0..MAX_SUMMARY_LENGTH]
  end

  # NOTE: success is only run if persisted (and after runs after persisting so after's changes don't persist),
  # so only use with bang methods!!
  include AASM
  include AasmCompatibilityGuard
  include GuardedStateMachine
  aasm :review, whiny_transitions: false, no_direct_assignment: !Rails.env.test?, column: :review_status do
    state :draft, initial: true
    state :pending_review, after_enter: [:notify_submitted, :set_timestamp_submitted_at]
    state :published

    event :submit do
      transitions to: :pending_review, from: :draft, guard: [:has_minimum_length]
    end

    event :publish, success: [:set_timestamp_reviewed_at, :add_notification, :social_broadcast] do
      transitions from: :pending_review, to: :published, guard: [:admin_provided_guard, :has_featured_image]
    end

    event :reject, success: [:set_timestamp_reviewed_at, :add_notification] do
      transitions from: [:pending_review, :published], to: :draft, guard: :admin_provided_guard
    end
  end



  # For consistent access, e.g. from Activities regarding Comments
  def name; title; end

  def public_author?
    author_alias.blank?
  end


  private

  def featured_image_dimensions
    return unless featured_image?
    return if featured_image_width.to_i >= FeaturedImageUploader::MAIN_WIDTH && featured_image_height.to_i >= FeaturedImageUploader::MAIN_HEIGHT

    remove_featured_image!
    msg = "after cropping, Featured Image must be at least #{FeaturedImageUploader::MAIN_WIDTH}px wide and #{FeaturedImageUploader::MAIN_HEIGHT}px tall"
    msg += " (uploaded image has been discarded, it was #{featured_image_width}x#{featured_image_height})" if featured_image_width && featured_image_height

    errors.add(:featured_image, msg)
  end

  def featured_image_content_type
    return unless featured_image? || featured_image_changed?
    return if featured_image.content_type
    errors.add(:featured_image, 'must have a valid content type specified')
  end

  def notify_submitted
    return true unless public_author? # If admin submitted, don't bother emailing admin that there's one pending
    return true if user&.admin?

    AdminMailer.article_pending_review(self).deliver_later(wait: 1.minute)
  end

  def add_notification
    return true unless public_author?
    which = published? ? 'published' : 'rejected'
    user.notify "article.#{which}", thing: self
  end

  def social_broadcast
    return true unless public_author?
    SocialPublishingService.call(:article_published, self)
  end


  def has_featured_image(*_)
    return true if featured_image?
    fail_with_error "Article cannot be published without selecting a featured image!"
  end

  def has_minimum_length(*_)
    return true if body.split.length > MIN_PUBLISHABLE_LENGTH
    fail_with_error "Article must be at least #{MIN_PUBLISHABLE_LENGTH} words before it can be published!"
  end
end
