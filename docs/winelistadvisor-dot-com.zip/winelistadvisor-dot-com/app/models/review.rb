# frozen_string_literal: true

class Review < ApplicationRecord
  include Taggable
  include Flaggable
  hide_at_n_flags 3
  include Likeable

  def label(context=nil)
    "Review #{self.id} (of #{reviewable.label})"
  end

  VALID_TYPES = %w(Restaurant).freeze
  TAGGABLE_TYPES = %w(Restaurant).freeze
  ATTACHABLE_TYPES = %w(Restaurant).freeze

  belongs_to :reviewable, polymorphic: true, inverse_of: :reviews, touch: true
  belongs_to :user, inverse_of: :reviews

  has_one :bookmark, inverse_of: :review

  has_many :images, as: :attached_to, class_name: 'UserImage'

  scope :of, ->(reviewable) { where(reviewable_id: reviewable.id, reviewable_type: reviewable.class.name.to_s.sub('Decorator', '')) if reviewable }
  scope :of_kind, ->(klass_name) { where(reviewable_type: klass_name) }
  scope :by_members,  -> { where(by_staff: false) }
  scope :by_member,   -> { where(by_staff: false) }
  scope :by_staff,    -> { where(by_staff: true) }
  scope :since, -> (dt) { where(['created_at >= ?', dt]) }
  default_scope -> { order('reviews.id desc') }

  validate :valid_rating
  validate :valid_associations, on: :create
  validates :reviewable, presence: true, on: :create

  before_create :attach_user_images
  after_commit :update_caches, on: [:create, :update, :destroy]
  after_commit :add_activity, :add_notification, :add_engagement, :social_broadcast, :enqueue_completion_reminder, on: :create


  include DataFields
  VALID_DATA_FIELDS = [:sommelier, :more_than_50, :wine_flights, :corkage, :regional_specialty]
  data_fields *VALID_DATA_FIELDS

  def applicable_data_fields
    case reviewable_type
    when 'Restaurant'
      [
        [:sommelier, 'Sommelier?', glyph: :user],
        [:more_than_50, 'More than 50 wines?', glyph: :list],
        [:wine_flights, 'Wine flights available?', glyph: :plane],
        [:corkage, 'Corkage?', detail: true, glyph: :usd],
        [:regional_specialty, 'Regional Specialty?', detail: true, glyph: :globe],
      ]
    else []
    end
  end

  def rating_num
    rating - rating.to_i == 0 ? rating.to_i : rating
  end

  def publicly_visible?
    public_notes? && !hidden_by_flags?
  end

  def show?(field)
    return false unless publicly_visible?
    send(field).present?
  end

  def taggable?
    TAGGABLE_TYPES.include?(reviewable_type)
  end

  def attachable?
    ATTACHABLE_TYPES.include?(reviewable_type)
  end

  def default_tag_options
    return [] unless taggable?

    case reviewable_type
    when 'Restaurant' then
      ReviewTag.active.pluck(:name, :description)
    else
      # TODO: customize these default tags to the current user
      Gutentag::Tag.order('taggings_count DESC').limit(10).pluck(:name)
    end.sort
  end

  def tag_names=(str)
    super(str.to_s.split(',')) if taggable?
  end

  DETAILS_FIELDS = %i(recommendations service_rating wines_rating value_rating)

  def details_unfilled?
    return false unless DETAILS_FIELDS.all? {|f| send(f).blank? || send(f) == 0}
    return false unless applicable_data_fields.map(&:first).all? {|f| send(f).blank? || send(f) == 'unsure' }

    true
  end

  private

  def attach_user_images
    return unless attachable?
    pending = user&.user_images&.pending_for_review_of(reviewable)
    Array(pending).each do |img|
      self.images << img
    end
  end

  def valid_rating
    return unless rating_changed?

    if rating.blank?          then errors.add :rating, "must be provided"
    elsif rating.to_i < 0.5   then errors.add :rating, "must be a half star or greater"
    elsif rating.to_f > 5     then errors.add :rating, "cannot be higher than five stars"
    end
  end

  def valid_associations
    add_bookmark_connection
    return if bookmark && bookmark.user == user
    errors.add(:bookmark, "must be owned by the owner of this review")
  end

  def add_bookmark_connection
    return unless reviewable
    self.bookmark ||= user.bookmarks.find_or_initialize_by(bookmarkable_id: reviewable.id, bookmarkable_type: reviewable.class.name)
  end

  def update_caches
    return unless reviewable

    # Update both staff and member in case this was one and switched to the other
    reviewable.update!({
      "staff_ratings_count" => reviewable.reviews.send("by_staff").count,
      "staff_rating"        => reviewable.reviews.send("by_staff").average(:rating),
      "member_ratings_count" => reviewable.reviews.send("by_member").count,
      "member_rating"        => reviewable.reviews.send("by_member").average(:rating),
    })

    reviewable.wine.update_review_caches(which) if reviewable.respond_to?(:wine)
  end

  def add_activity
    Activity.add_review(self)
  end

  def add_engagement
    return true if by_staff?
    EngagementService.call user, "#{reviewable.class.name.underscore}.reviewed", reviewable, {review_id: self.id}
  end

  def add_notification
    return true if reviewable&.responsible_user == user
    reviewable&.responsible_user&.notify "#{reviewable.class.name.underscore}.reviewed", thing: self, thing_context: reviewable
  end

  def social_broadcast
    SocialPublishingService.call(:added_review, self)
  end

  def enqueue_completion_reminder
    return unless details_unfilled?
    UserMailer.incomplete_review_reminder(self).deliver_later(wait_until: Time.zone.now.end_of_day + 7.hours)
  end
end
