# frozen_string_literal: true

# EngagementReward(kind: 'payout') creates the record of money owed. EngagementRedemption tracks the redemption status.
class EngagementRedemption < ApplicationRecord
  belongs_to :user
  belongs_to :engagement_reward
  belongs_to :marked_paid_by, class_name: 'User', required: false

  VALID_REDEMPTION_DOLLAR_VALUES = [25,50,100] # Taken from https://www.paypal-gifts.com/us/brands/wine-com.html

  after_create :notify_admins_that_pending
  validates :user, :face_value, :engagement_reward, presence: true

  # For Administrate
  def user_email
    user&.email
  end

  include GuardedStateMachine
  state_machine auto_scopes: true, initial: :pending do
    state :pending
    state :paid

    event :mark_paid, timestamp: :marked_paid_at, success: :add_notification do
      transitions from: :pending, to: :paid, on_transition: :set_payment_data, guard: :payment_marking_guard
    end

  end

  def label(context=nil)
    "$#{face_value.to_i} Gift Card"
  end

  private

  def notify_admins_that_pending
    AdminMailer.engagement_redemption_pending(self).deliver_later(wait: 1.minute)
  end

  def add_notification
    user.notify 'engagement_redemption:paid', thing: self
  end

  def payment_marking_guard(admin, order_number)
    return false unless admin.present? && admin.admin? # Don't allow transition without a user passed in
    return fail_with_error("confirmation code must be provided to mark the gift card as paid") unless order_number.present?
    true
  end

  def set_payment_data(admin, order_number)
    self.attributes = {
      marked_paid_by: admin,
      order_number: order_number,
    }
  end

end
