# frozen_string_literal: true

class EngagementConfig < ApplicationRecord
  # Because these are stored in the production DB, we don't have a dev version of ground truth.
  EXPECTED_KEYS = %w(
    member.completed_tasting_profile
    member.joined
    friends.joined_from_invitation
    article.published
    restaurant.claimed
    restaurant.reviewed
    restaurant.wine_program.accepted
    contests.article.won
    contests.wine_program.won
    system.autoposted_content
    system.pending_points_expired
  )


 VALID_REPEATABLE_OPTIONS_FOR_SELECT = [
    ['Not Repeatable', 'none'],
    ['Unlimited Repeats', 'any'],
    ['Once per associated thing', 'thing'],
  ]
  VALID_REPEATABLE_OPTIONS = VALID_REPEATABLE_OPTIONS_FOR_SELECT.map {|k,v| v }
  MAX_POINTS_PER_MONTH = 50

  validates :repeatable, presence: true, inclusion: {in: VALID_REPEATABLE_OPTIONS}
  validates :description, presence: true
  validate :max_per_month_valid

  def self.for_display
    EngagementConfigDecorator.decorate_collection where('id <> ?', 'system.pending_points_expired')
  end

  def label
    description
  end

  def show_repeatable
    case repeatable
    when 'none' then 'No'
    when 'any' then 'Unlimited'
    when 'thing'
      case id
      when 'friends.joined_from_invitation' then 'Once per friend'
      else
        if id.starts_with?('restaurant.') then 'Once per restaurant'
        else 'Once per context'
        end
      end
    end
  end

  private

  def max_per_month_valid
    return if max_per_month.to_i.zero?
    if repeatable == 'none'
      errors.add(:max_per_month, "doesn't make any sense for non-repeatable events")
    end
  end

end
