# frozen_string_literal: true

class Invitation < ApplicationRecord
  include TokenFindable

  belongs_to :user
  belongs_to :joined_user, class_name: 'User', required: false, inverse_of: :joined_from_invitation

  validates :email, presence: true, format: { with: Devise.email_regexp }, uniqueness: {scope: :user_id}

  scope :unsent, -> { where(sent_at: nil) }
  scope :sent, -> { where.not(sent_at: nil) }
  scope :pending, -> { where(joined_user_id: nil) }

  after_commit :send_invitation, on: :create

  def sent?
    sent_at.present?
  end

  def to_param
    token
  end

  def accept!(joined)
    return unless joined_user_id.nil?
    update! joined_user: joined
  end

  private

  def send_invitation
    Email::InvitationJob.perform_later(self)
  end
end
