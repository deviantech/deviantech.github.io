# frozen_string_literal: true

class Bookmark < ApplicationRecord
  belongs_to :user, inverse_of: :bookmarks
  belongs_to :bookmarkable, polymorphic: true, inverse_of: :bookmarks
  belongs_to :review, inverse_of: :bookmark, required: false

  scope :tried, -> { where(state: 'tried') }
  scope :not_tried, -> { where(state: 'pending') }
  scope :with_review, -> { joins(:review) }
  scope :unreviewed, -> { where(review_id: nil) }
  scope :by_bookmarkable, ->(r) { where(bookmarkable_type: r.class.name.sub('Decorator', ''), bookmarkable_id: r.id) }

  validates_presence_of :user, :bookmarkable

  before_save :toggle_state
  after_commit :social_broadcast, on: :create

  # https://github.com/troessner/transitions
  include ActiveModel::Transitions
  state_machine auto_scopes: false, initial: :pending do
    state :pending
    state :tried

    event :mark_tried do
      transitions to: :tried, from: [:pending, :tried]
    end

    event :remove_tried do
      transitions to: :pending, from: [:pending, :tried]
    end
  end

  private

  def toggle_state
    return unless review_id_changed?
    return unless review
    mark_tried if pending?
  end

  def social_broadcast
    return if tried?
    return unless bookmarkable.is_a?(Restaurant)

    SocialPublishingService.call(:wants_to_visit_restaurant, self)
  end

end
