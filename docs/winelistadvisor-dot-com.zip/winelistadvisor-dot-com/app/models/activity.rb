# frozen_string_literal: true

# Adding new activity:
#   - Add the key to VALID_TOPICS
#   - Edit activity_decorator to add a headline, + optionally more, for the new key
#   - Add new Activity#add_TOPIC_HERE method to trigger saving the activity
#   - Use the new Activity#add_TOPIC_HERE method somewhere -- ensure new activity is created
#   - Update activity_spec.rb to ensure we track that creation is triggered when expected
class Activity < ApplicationRecord
  include Flaggable
  # Only wall posts
  def flaggable_name; 'Post' end

  def label(context=nil)
    topic == 'wall_post' ? "post on #{user.name}'s profile" : "#{user.name}'s activity"
  end

  include Commentable
  include Likeable
  def responsible_user
    'wall_post' == topic ? thing : user
  end


  VALID_TOPICS = %w(
    updated_user_profile
    updated_restaurant_profile
    friendship
    published_article
    review
    comment
    wall_post
    claimed_restaurant
    article_contest_winner
    wine_program_contest_winner
    engagement_reward
    completed_tasting_profile
  ).freeze

  belongs_to :user, touch: true
  belongs_to :thing, polymorphic: true, required: false
  belongs_to :thing_context, polymorphic: true, required: false
  has_many :images, as: :attached_to, class_name: 'UserImage'

  validates :topic, presence: true, inclusion: {in: VALID_TOPICS}, on: :create
  validate :check_validity, on: :create

  before_create :attach_user_images
  after_commit :add_notification, :social_broadcast, on: :create


  include DataFields
  data_fields :body

  default_scope -> { order('id DESC') }
  scope :by_key, ->(k) { where(topic: k) }
  scope :wall_posts_by, ->(u) { where(user_id: u.id, topic: 'wall_post') }
  scope :wall_posts_involving, ->(u) {
    where(thing_id: u.id).or( where(user_id: u.id) ).where(topic: 'wall_post')
  }

  # User Home (only for me): show activities of friends, plus any wall_posts to me [note duplicated]
  scope :home_feed_for, ->(user) {
    where(user_id: user.friends.select(:id)).or(
      where(thing_id: user.id, topic: 'wall_post')
    ).or(
      where(topic: 'friendship', thing_context_id: user.id).or(
        where(topic: 'friendship', user_id: user.id)
      )
    )
  }

  # User Activity (for me or any friend: show all activities taken by me, plus any wall_posts to me [note duplicated]
  scope :activity_feed_for, ->(user) {
    where(user_id: user.id).or(
      where(thing_id: user.id, topic: 'wall_post')
    ).or(
      where(thing_context_id: user.id, topic: 'friendship')
    )
  }

  VALID_TOPICS.each do |topic|
    scope topic, -> { where(topic: topic) }
  end

  def self.add_updated_user_profile(user, changes)
    return if user.activities.updated_user_profile.where(['created_at > ?', 1.day.ago]).any?
    user.send(:skip_tracking_profile_changes)
    add :updated_user_profile, user: user, data: changes
  end

  def self.add_updated_restaurant_profile(wine_program)
    return unless wine_program.owners?
    return if wine_program.user.activities.updated_restaurant_profile.where(['created_at > ?', 1.day.ago]).any?
    add :updated_restaurant_profile, user: wine_program.user, thing: wine_program.restaurant, thing_context: wine_program
  end

  def self.add_review(review)
    add :review, user: review.user, thing: review, thing_context: review.reviewable
  end

  def self.add_engagement_reward(reward)
    add :engagement_reward, user: reward.user, thing: reward
  end

  def self.add_comment(comment)
    return if comment.commentable.is_a?(Activity)
    add :comment, user: comment.user, thing: comment, thing_context: comment.commentable
  end

  def self.add_wall_post(from_user, to_user, data)
    data = {body: data} if data.is_a?(String)
    add :wall_post, user: from_user, thing: to_user, data: data
  end

  def self.add_completed_tasting_profile(user, tasting_profile)
    add :completed_tasting_profile, user: user, thing: tasting_profile
  end


  # Created from notifications

  def self.add_claimed_restaurant(restaurant)
    add :claimed_restaurant, user: restaurant.claimed_by, thing: restaurant
  end

  def self.add_article_contest_winner(contest)
    add :article_contest_winner, user: contest.winning_user, thing: contest.winner, thing_context: contest
  end

  def self.add_wine_program_contest_winner(contest)
    add :wine_program_contest_winner, user: contest.winning_user, thing: contest.winner, thing_context: contest, data: {restaurant_id: contest.winner.restaurant_id}
  end

  def self.add_friendship(friendship)
    add :friendship, user: friendship.friend, thing: friendship, thing_context: friendship.friendable
  end

  def self.add_published_article(article)
    return if article.author_alias.present?
    add :published_article, user: article.user, thing: article, thing_context: article.category
  end

  ATTACHABLE_TOPICS = %w(wall_post).freeze

  private

  def self.add(topic, user:, **args)
    user.activities.send(topic).create(args)
  end

  def add_notification
    return true unless 'wall_post' == topic
    return true if thing == user
    thing.notify 'wall_post.created', thing: self, thing_context: user
  end

  def social_broadcast
    return true unless 'wall_post' == topic
    return true unless thing == user

    SocialPublishingService.call(:posted, self)
  end

  def attachable?
    ATTACHABLE_TOPICS.include?(topic)
  end

  def attach_user_images
    return unless attachable?
    pending = user&.user_images&.pending_for_any_wall_post
    Array(pending).each do |img|
      self.images << img
    end
  end

  def check_validity
    case topic
    when 'wall_post'
      unless body.present? || (persisted? ? images.any? : user&.user_images&.pending_for_any_wall_post&.any?)
        errors.add(:base, "Either an image or some text must be provided!")
      end
    end
  end
end
