# frozen_string_literal: true

class Category < ApplicationRecord
  validates :name, presence: true, uniqueness: true

  scope :for_nav, -> { select(:name, :slug) }

  has_many :published_articles, -> { where(review_status: 'published') }, class_name: 'Article'

  extend FriendlyId
  friendly_id :name, use: [:slugged, :finders]

  def should_generate_new_friendly_id?
    slug.blank? || name_changed?
  end

end
