# frozen_string_literal: true

class RestaurantPolicy < ApplicationPolicy

  def claim_not_rejected
    return false unless user
    admin? || (record.claimed_by_id == user.id && (record.claimed? || record.pending_review?))
  end

  def claim?
    user && (
      record.unclaimed? ||
        (record.pending_review? && record.claimed_by_id == user.id)
      )
  end

  def manage_content?
    admin? || content_writer?
  end

  def edit?
    return false unless user
    record.claimed? && (admin? || record.claimed_by_id == user.id)
  end

  alias_method :update?, :edit?

  def update_pdf_menus?
    admin? || update?
  end

end
