# frozen_string_literal: true

class ArticlePolicy < ApplicationPolicy

  # Published articles are shown to everyone. Otherwise only to authors and admins.
  def show?
    return true if record.published?
    owned?
  end

  def update?
    return false if record.published?
    owned?
  end

  alias_method :edit?, :update?
  alias_method :submit?, :owned?
  alias_method :destroy?, :owned?
end
