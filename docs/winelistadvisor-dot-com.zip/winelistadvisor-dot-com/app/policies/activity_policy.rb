# frozen_string_literal: true

class ActivityPolicy < ApplicationPolicy

  def destroy?
    return true if record.topic == 'wall_post' && user && [record.thing_id, record.user_id].include?(user.id)
    false
  end

  def flag?
    return false unless record.topic == 'wall_post'
    return false if destroy?
    !! user
  end

  alias_method :edit?, :destroy?
  alias_method :update?, :destroy?
end
