# frozen_string_literal: true

class UserPolicy < ApplicationPolicy

  def show
    true # used for tasting profiles too
  end

  alias_method :edit?, :owned?
  alias_method :update?, :owned?
  alias_method :points?, :owned_or_admin?
  alias_method :destroy?, :owned?

  def owner_id_field
    :id
  end

  def moderate?
    admin? || user&.moderator?
  end

  def friend?
    self? || user&.friends_with?(record)
  end

  def self?
    user == record
  end

end
