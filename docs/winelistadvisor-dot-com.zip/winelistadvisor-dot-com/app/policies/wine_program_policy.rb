# frozen_string_literal: true

class WineProgramPolicy < ApplicationPolicy

  def edit?
    return true if admin?
    return true if record.new_record?
    owned? && (record.draft? || record.owners? || record.pending_ownership_claim?)
  end

  alias_method :new?, :edit?
  alias_method :update?, :edit?
  alias_method :destroy?, :edit?

end
