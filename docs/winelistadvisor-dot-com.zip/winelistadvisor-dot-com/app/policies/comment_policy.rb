# frozen_string_literal: true

class CommentPolicy < ApplicationPolicy

  alias_method :edit?, :owned_or_admin?
  alias_method :update?, :owned_or_admin?
  alias_method :destroy?, :owned_or_admin?
  alias_method :leave_staff_review?, :admin?

end
