# frozen_string_literal: true

class ApplicationPolicy
  attr_reader :user, :record

  def initialize(user, record)
    @user = user
    @record = record
  end

  def index?
    false
  end

  def show?
    scope.where(id: record.id).exists?
  end

  def create?
    false
  end

  def new?
    create?
  end

  def update?
    false
  end

  def edit?
    update?
  end

  def destroy?
    false
  end

  def scope
    Pundit.policy_scope!(user, record.class)
  end

  class Scope
    attr_reader :user, :scope

    def initialize(user, scope)
      @user = user
      @scope = scope
    end

    def resolve
      scope
    end
  end



  # HELPERS

  def admin?
    user&.admin?
  end

  def content_writer?
    user&.content_writer?
  end

  def owned_or_admin?
    owned? || admin?
  end

  # Customize in subclasses with non-standard ownership ID linkage
  def owner_id_field
    :user_id
  end

  def owner_id
    raise "#{record.class.name} does not respond to specified owner_id field :#{owner_id_field}. Policy needs rewriting." unless record.respond_to?(owner_id_field)
    record.send(owner_id_field)
  end

  def owned?
    user && user.persisted? && user.id == owner_id
  end

end
