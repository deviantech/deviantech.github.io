# frozen_string_literal: true

class ConversationPolicy < ApplicationPolicy

  def add_users?
    show?
  end

  def show?
    record.users.include?(user)
  end

  def manage?
    record.initiating_user == user
  end

end
