# frozen_string_literal: true

class PointsExpiryJob < ApplicationJob
  queue_as :default

  EXPIRE_AFTER_N_MONTHS = 6
  WARN_AFTER_N_MONTHS = EXPIRE_AFTER_N_MONTHS - 2
  NOTIFY_WITHIN_N_DAYS = 14
  EXPIRY_KEY = 'system.pending_points_expired'

  def perform
    potential_users.find_each { |user| act_on(user) }
  end

  private

  def potential_users
    User.
      where('points > ?', 0).
      where('created_at < ?', (EXPIRE_AFTER_N_MONTHS.months - NOTIFY_WITHIN_N_DAYS.days).ago) # No point pulling up new users who haven't been around long enough to expire
  end

  def act_on(user)
    return unless most_recent = user.engagements.first

    if most_recent.created_at <= EXPIRE_AFTER_N_MONTHS.months.ago
      do_expiry(user)
    elsif most_recent.created_at <= EXPIRE_AFTER_N_MONTHS.months.ago + NOTIFY_WITHIN_N_DAYS.days
      prev = user.notifications.by_key('system.points.expiring_soon').first
      if prev.nil? || prev.created_at < NOTIFY_WITHIN_N_DAYS.day.ago
        send_expiration_pending_notification(user, most_recent)
      end
    end
  end

  def send_expiration_pending_notification(user, most_recent)
    expiry_date = most_recent.created_at + EXPIRE_AFTER_N_MONTHS.months
    user.notify 'system.points.expiring_soon', thing: user, thing_context: most_recent, data: {points: EngagementReward.points_from_prev_reward(user), expiry_date: expiry_date}
  end

  def do_expiry(user)
    EngagementService.call user, EXPIRY_KEY, nil
  end
end
