# frozen_string_literal: true

class SidekiqJob
  # TODO:ARCHIVED


  # include Sidekiq::Worker
  # include Rails.application.routes.url_helpers # https://github.com/rails/rails/issues/29992

  # class << self
  #   def default_url_options
  #     Rails.application.config.action_controller.default_url_options
  #   end
  # end
end
