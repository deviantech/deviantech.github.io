# frozen_string_literal: true

class Api::UpdateRecordJob < ApplicationJob
  queue_as :default

  def perform(record, source)
    ident = record.send("#{source}_id")

    if presented = api(source).get(ident)
      presented.onboard_on!(record)
    else
      binding.pry if Rails.env.development?
      Rollbar.warn("Has this actually been deleted, or just connection error? If can tell for sure, add deletion...", record, source)
    end
  end

  private

  def api(source)
    namespace = source.classify
    "#{namespace}::Api".constantize
  end

end
