# frozen_string_literal: true

class NewsletterSyncJob < ApplicationJob
  queue_as :default

  def perform(user)
    return unless App.sync_with_mailchimp?
    NewsletterService.sync_member(user)
  end

end
