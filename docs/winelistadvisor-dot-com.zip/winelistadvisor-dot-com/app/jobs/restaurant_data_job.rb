# frozen_string_literal: true

class RestaurantDataJob < ApplicationJob
  queue_as :default

  # TODO: catch ratelimit errors and do NOT set the ID to 0 in that case (reschedule job to try again later)
  def perform(restaurant)
    return unless restaurant.opentable_id.nil?

    restaurant.update_attribute :opentable_id, OpentableService.get_opentable_id(restaurant) || 0
  end

  def self.enqueue
    Restaurant.slim.where(opentable_id: nil).find_each {|r| perform_later(r) }
  end

end
