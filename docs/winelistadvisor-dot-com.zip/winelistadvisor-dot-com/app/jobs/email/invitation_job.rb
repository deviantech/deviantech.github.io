# frozen_string_literal: true

class Email::InvitationJob < ApplicationJob
  queue_as :priority

  def perform(invite)
    return if invite.sent?
    UserMailer.invitation(invite).deliver_now
    invite.update(sent_at: Time.now)
  end
end
