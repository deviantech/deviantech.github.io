# frozen_string_literal: true

class EngagementBroadcastJob < ApplicationJob
  queue_as :priority

  def perform(engagement)
    return unless engagement.still_ready_for_notification?
    WebNotificationsChannel.broadcast_to engagement.user, topic: 'engagement', kind: 'alert', body: render_body(engagement)
  end

  private

  def render_body(engagement)
    engagement = EngagementDecorator.decorate(engagement)
    ApplicationController.render_with_signed_in_user(engagement.user, inline: "#{engagement.summary}: received #{engagement.points} point#{'s' unless engagement.points == 1}", locals: {engagement: engagement})
  end

end
