# frozen_string_literal: true

class ConnectExistingRestaurantsWithSinglePlatformJob < ApplicationJob
  queue_as :default

  def perform
    Restaurant.single_platform_connection_attempt_needed.find_in_batches(batch_size: 100) do |unknowns|
      perform_for_batch(unknowns)
    end
  end

  private

  def perform_for_batch(unknowns)
    SinglePlatform::Matcher.new(unknowns).call.each do |r, spid|
      begin
        if spid.present? && r.single_platform_id != spid
          r.update_attributes! single_platform_id: spid
          Api::UpdateRecordJob.perform_later(r, 'single_platform')
        end
      rescue StandardError => e
        Rollbar.error(e, "ConnectExistingRestaurantsWithSinglePlatformJob failed", r, spid)
      end
    end

    Restaurant.where(id: unknowns.map(&:id)).update_all refreshed_single_platform_match_at: Time.now
  end
end
