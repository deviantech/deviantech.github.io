# frozen_string_literal: true

class ContestJob < ApplicationJob
  queue_as :default

  def perform
    [Contests::Article, Contests::WineProgram].each do |klass|
      klass.ensure_up_to_date!
    end
  end

end
