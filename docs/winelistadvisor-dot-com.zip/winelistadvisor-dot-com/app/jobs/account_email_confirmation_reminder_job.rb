# frozen_string_literal: true

class AccountEmailConfirmationReminderJob < ApplicationJob
  queue_as :priority

  def self.enqueue
    User.needs_confirmation_reminder.find_each {|r| perform_later(r) }
  end

  def perform(user)
    return unless user.needs_confirmation_reminder?
    @user = user

    send_reminder
    track_reminder_sent
  end

  private

  def send_reminder
    @user.notify('system.account_email_confirmation.reminder', thing: @user)
  end

  def track_reminder_sent
    @user.update confirmation_resent_at: Time.now
  end
end
