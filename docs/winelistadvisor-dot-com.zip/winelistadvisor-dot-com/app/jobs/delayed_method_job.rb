# frozen_string_literal: true

class DelayedMethodJob < ApplicationJob
  queue_as :default

  def self.enqueue(model, method, *args)
    return unless model.persisted?
    perform_later(model.class.name, model.id, method, args)
  end

  def perform(klass_name, instance_id, method, args)
    if instance = klass_name.constantize.find(instance_id)
      args.present? ? instance.send(method, *args) : instance.send(method)
    end
  end
end
