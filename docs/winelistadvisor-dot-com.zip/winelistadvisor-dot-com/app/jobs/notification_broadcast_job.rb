# frozen_string_literal: true

class NotificationBroadcastJob < ApplicationJob
  queue_as :priority

  def perform(notification)
    return unless notification.still_ready_for_notification?
    WebNotificationsChannel.broadcast_to notification.user, topic: 'notification', kind: 'alert', body: render_notification(notification), notification_id: notification.id
  end

  private

  def render_notification(notification)
    notification = NotificationDecorator.decorate(notification)
    ApplicationController.render_with_signed_in_user(notification.user, partial: "notifications/notification", locals: {notification: notification})
  end

end
