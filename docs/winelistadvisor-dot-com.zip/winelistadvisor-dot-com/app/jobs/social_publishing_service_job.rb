# frozen_string_literal: true

class SocialPublishingServiceJob < ApplicationJob
  queue_as :priority

  attr_reader :key, :user, :thing, :ctx
  def perform(key, user:, thing:, ctx:)
    @key = key.to_sym
    @user, @thing, @ctx = user, thing, ctx

    user.identities.each do |ident|
      next unless ident.publishable?(key)
      attempt_for_identity(ident)
    end
  end

  private

  def attempt_for_identity(identity)
    return unless pub = publisher_for_identity(identity)

    pub.call
  rescue => e
    # Report the error, but continue attempting to process on other networks
    Rollbar.error(e)
    raise e if Rails.env.test? || Rails.env.development?
  end

  def publisher_for_identity(identity)
    identity.publisher&.new(key, user: user, identity: identity, thing: thing, ctx: ctx)
  end

end
