# frozen_string_literal: true

class UpdateFeaturedJob < ApplicationJob
  queue_as :default

  def perform
    Featurable::IncludedIn.included_in.each do |klass|
      update_featured(klass)
    end
  end

  NUM_FEATURED = 20

  private

  def update_featured(klass)
    fn = "update_featured_#{klass.name.underscore.pluralize}"
    respond_to?(fn, true) ? send(fn) : raise(NotImplementedError, "UpdateFeaturedJob doesn't support #{klass.name} via #{fn}")
  end

  def update_featured_articles
    newly_featured = Article.published.order('comments_count DESC').limit(NUM_FEATURED)
    newly_featured.update_all("featured = comments_count")

    clear_previously_featured Article, newly_featured
  end

  def update_featured_users
    newly_featured_ids = best_engagement_earners_last_month.map do |earner|
      User.find(earner.user_id).update_attribute(:featured, earner.total_points)
      earner.user_id
    end

    clear_previously_featured User, newly_featured_ids
  end

  def update_featured_restaurants
    newly_featured = Restaurant.where('member_rating > 2.5').order('member_rating DESC').limit(NUM_FEATURED)
    newly_featured.update_all("featured = round(member_rating * 100)")

    clear_previously_featured Restaurant, newly_featured

    # Now add some extras to try to be sure we have featured restaurants in each region
    feature_restaurants_in_each_serving_location(newly_featured)
  end

  def feature_restaurants_in_each_serving_location(newly_featured)
    NowServingLocation::KNOWN_LOCATIONS.each do |label, geo|
      pity_feature_for_geo = Restaurant.near(geo, 60).where.not(id: newly_featured.pluck(:id)).reorder('member_rating DESC, yelp_price_range DESC').limit(NUM_FEATURED).pluck(:id)
      Restaurant.where(id: pity_feature_for_geo).update_all("featured = round(COALESCE(member_rating, 1) * 10)")
    end
  end

  def clear_previously_featured(klass, newly_featured)
    newly_featured_ids = newly_featured.is_a?(ActiveRecord::Relation) ? newly_featured.select(:id) : newly_featured
    return unless newly_featured_ids.any? # If nothing new, leave the old
    klass.where.not(id: newly_featured_ids).update_all(featured: nil)
  end

  def best_engagement_earners_last_month
    @earners ||= begin
      earned = Engagement.since(1.month.ago).where.not(points: 0).select(:user_id, "sum(points) as total_points").group(:user_id).order('total_points DESC').limit(NUM_FEATURED).all

      if earned.length < NUM_FEATURED
        earned += User.admin.select("id as user_id, 1 as total_points").all
      end

      earned.uniq {|u| u.user_id}.take(NUM_FEATURED)
    end
  end

end
