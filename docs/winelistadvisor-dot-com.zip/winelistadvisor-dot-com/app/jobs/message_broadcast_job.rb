# frozen_string_literal: true

class MessageBroadcastJob < ApplicationJob
  queue_as :priority

  def perform(message)
    ConversationChannel.broadcast_to message.conversation, message: render_message(message), topic: 'message', who: message.user.id
  end

  private

  def render_message(message)
    message = MessageDecorator.decorate(message)
    ApplicationController.render_with_signed_in_user(message.user, partial: message.top_level_partial, locals: {message: message})
  end

end
