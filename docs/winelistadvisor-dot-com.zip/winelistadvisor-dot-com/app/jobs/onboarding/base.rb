# frozen_string_literal: true

class Onboarding::Base < SidekiqJob
  # TODO:ARCHIVED
  # sidekiq_options unique: :until_executed

  # include Sidekiq::Throttled::Worker
  # sidekiq_throttle({
  #   concurrency: { limit: 1 },
  #   threshold: { limit: 1, period: 1.days }
  # })


  # # 600 seconds minimum + the default formula
  # sidekiq_retry_in do |retry_count|
  #   1.hour + ((retry_count ** 4) + 15 + (rand(30) * (retry_count + 1)))
  # end


  # class_attribute :api

  # def perform
  #   return if Time.now - last_updated_at < 1.day # enforce pause, mostly to avoid SP error when hit API with future dates

  #   self.class.api.updated_since(last_updated_at, batch_size: batch_size, max_pages: max_pages, pause_between_fetches: 1) do |sp|
  #     next unless sp.onboardable?
  #     onboard_single(sp)
  #   end

  #   $redis.set(success_key, Time.now)
  # end

  # def self.reset_onboarding_success!
  #   $redis.del( new.send(:success_key) )
  # end

  # private

  # def onboard_single(sp)
  #   Onboarding::Single.perform_in(6.hours, sp.class.name, sp.raw)
  # end

  # def key(k)
  #   [klass_key_base, k.to_s].join(':')
  # end

  # def success_key
  #   key(:last_updated)
  # end

  # def klass_key_base
  #   self.class.name.split('::').last.sub('Job', '').underscore.singularize
  # end

  # def last_updated_at
  #   if (raw = $redis.get(success_key)).present?
  #     return Time.parse(raw)
  #   end

  #   App.production? ? 10.years.ago : 1.month.ago
  # end

  # def batch_size
  #   500
  # end

  # def max_pages
  #   nil
  # end

end
