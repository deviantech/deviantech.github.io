# frozen_string_literal: true

class Onboarding::Single < SidekiqJob
  # TODO:ARCHIVED
  #
  # include Sidekiq::Throttled::Worker

  # sidekiq_throttle({
  #   # Limit to 2 for Restaurants (may want dynamic for others eventually, for now w/ 2 we get very intermittent ratelimit issues, can't do more)
  #   concurrency: { limit: 2, key_suffix: ->(presenter, raw) { presenter } }
  # })

  # sidekiq_options unique: :until_executed, unique_args: ->(args) {
  #   presenter, raw = args
  #   case presenter
  #   when 'SinglePlatform::RestaurantPresenter' then [raw['location_id']]
  #   else raise("Attempting to onboard with unknown presenter: #{presenter}")
  #   end
  # }

  # # 300 seconds minimum + the default formula
  # sidekiq_retry_in do |retry_count|
  #   10.minutes + ((retry_count ** 4) + 15 + (rand(30) * (retry_count + 1)))
  # end

  # def perform(presenter, raw)
  #   presenter.constantize.new(raw).onboard!
  # rescue ServiceError::RetryableBackendError, ActiveRecord::Deadlocked => e
  #   sleep 10 # If we're hitting rate limits, slow down ALL jobs briefly before rescheduling for the future
  #   Onboarding::Single.perform_in(1.hour + rand(3600), presenter, raw)
  #   Rollbar.error(e, waiting: "retrying job in an hour", presenter: presenter, raw: raw)
  # rescue ServiceError::Base => e
  #   Onboarding::Single.perform_in(2.days + rand(3600), presenter, raw)
  #   Rollbar.error(e, waiting: "pausing two days before retrying", presenter: presenter, raw: raw)
  # end

end
