# frozen_string_literal: true

class Onboarding::RestaurantsJob < Onboarding::Base
  # TODO:ARCHIVED
  # self.api = SinglePlatform::Api

  # private

  # def batch_size
  #   # 5000 # SP's default batch size
  #   5_000
  # end

end
